import{b as h,S as f}from"./llm-NNkhUcAb.js";import{Sentinel as p}from"./sentinel-DSpJSiZJ.js";import{Hypervector as l}from"./hypervector-DkgCCw2d.js";import"./client-Dq_cuSAf.js";import"./supabase-DYu6klIT.js";class v{static fuseHolographic(t){var c;if(t.length===0)throw new Error("Vacuum fusion attempted.");if(t.length===1)return t[0];console.log(`[CrystalFuser] 📐 Geometric Fusion of ${t.length} concept points...`);const r=t.map(e=>l.fromString(e.verification.canonical_hash)),a=l.bundle(r);let n=0;for(let e=0;e<4096;e++)a.data[e>>>5]>>>(e&31)&1&&n++;const o=n/4096,i=o>.65,s=i?`Geometric Singularity: Unified Axiom synthesized from ${t.length} sources.`:t.map(e=>e.intent.primary).slice(0,3).join(" + ")+(t.length>3?"...":""),m=t.flatMap(e=>e.entities||[]),u=Array.from(new Map(m.map(e=>[e.name,e])).values());return{...t[0],context_id:`geo_master_${Date.now()}`,version:"4.0.0 (Neuromorphic)",intent:{primary:s,status:((c=t[0])==null?void 0:c.intent.status)||h.ACTIVE},entities:u,metadata:{...t[0].metadata||{},geometric_density:o,is_singularity:i},created_at:new Date().toISOString(),verification:{canonical_hash:a.toString(),semantic_invariants:[],policy:{min_checks:2,accept_threshold:.9,max_retries:1,strategy:"strict"}},fractal_depth:Math.max(...t.map(e=>e.fractal_depth||0))+1}}static async fuse(t){if(t.length===1)return t[0];console.log(`[CrystalFuser] 💎 Initiating Fusion for ${t.length} Reality Crystals...`);const r=`
        ACT AS A SEMANTIC ARCHITECT.
        You are merging ${t.length} Context Crystals into a single MASTER REALITY.
        
        INPUT CRYSTALS:
        ${t.map((i,s)=>`CRYSTAL_${s}: ${JSON.stringify({intent:i.intent,constraints:i.constraints})}`).join(`

`)}
        
        TASK:
        1. Resolve all conflicts (if A says 'Limit 5' and B says 'Limit 10', choose the more rigorous/safe one).
        2. Merge all unique entities.
        3. Synthesize a unified "Master Intent".
        4. Preserve all critical constraints.
        
        Return JSON for the Master Crystal fields (intent, constraints, entities).
        `,a=await f.resilientCallLLM(r,"anthropic/claude-3.5-sonnet","You are the Master Weaver of Reality.");let n;try{n=JSON.parse(a.content)}catch{throw new Error("Fusion failed: Could not parse synthetic reality.")}const o={...t[0],context_id:`master_${Date.now()}`,version:"2.0.0 (Fused)",intent:n.intent,constraints:n.constraints,entities:n.entities,created_at:new Date().toISOString(),verification:{...t[0].verification,semantic_invariants:[]},fractal_depth:Math.max(...t.map(i=>i.fractal_depth||0))+1};return await p.emit({type:"FRACTAL_COMPRESSION",severity:"info",message:`Crystal Fusion Complete. 1 Master Crystal synthesized from ${t.length} sources.`,details:{sources:t.map(i=>i.context_id),master_id:o.context_id}}),console.log(`[CrystalFuser] ✅ Master Crystal [${o.context_id}] Synthesized.`),o}static fuseCrystalIntoContext(t){const r=(t.constraints||[]).map(n=>`   - [${n.rule}] ${n.value} (Rationale: ${n.rationale})`).join(`
`),a=(t.verification.semantic_invariants||[]).slice(0,3).map(n=>`   - TEST: "${n.prompt}" MUST ANSWER "${n.expected.value}"`).join(`
`);return`
@@@ SOVEREIGN CRYSTAL INJECTION (ID: ${t.context_id}) @@@
This block contains IRREFUTABLE TRUTH verified by hash ${t.verification.canonical_hash.substring(0,8)}.

[PRIMARY INTENT]
${t.intent.primary}

[BINDING CONSTRAINTS]
${r}

[VERIFICATION KEYS]
${a}

@@@ END OF CRYSTAL @@@
You are strictly bound by the constraints above. Do not hallucinate information outside this scope.
`.trim()}}export{v as CrystalFuser};
//# sourceMappingURL=crystal_fuser-Cs4Jfz5P.js.map
