const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/semantic_hashing-Ctxnt7XM.js","assets/llm-DNzthYgj.js","assets/client-CGcdomT2.js","assets/hypervector-DtnlNLYu.js","assets/supabase-DNR-wrN1.js"])))=>i.map(i=>d[i]);
var R=Object.defineProperty;var f=(c,t,e)=>t in c?R(c,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):c[t]=e;var h=(c,t,e)=>f(c,typeof t!="symbol"?t+"":t,e);import{_ as m}from"./client-CGcdomT2.js";import{g as A,S as d}from"./llm-DNzthYgj.js";class y{static async compress(t,e=0){if(t.length<=this.MAX_TOKEN_TARGET||e>4)return t;console.log(`[Fractal] 🌀 Layer ${e}: Distilling ${Math.round(t.length/1024)}KB into Meta-Invariants...`);const i=await this.shardReality(t),s=A({task:"compile"}),l=i.map(r=>this.distillToAxioms(r,s,e)),a=(await Promise.all(l)).join(`

--- LAYER SEPARATOR ---

`),o=await this.fuseAndRefine(a,s,e);return this.compress(o,e+1)}static async distillToAxioms(t,e,i){const s=`
        ACT AS A FRACTAL ENCODER (Layer ${i}).
        Goal: Extract the "Axiomatic Core" of this context.
        
        Rules:
        1. NO SUMMARIES. Use high-density bullet points.
        2. Identify INVARIANTS: Facts that MUST be true for this reality to remain consistent.
        3. Identify RELATIONSHIPS: How entities interact.
        4. Identify CONSTRAINTS: Forbidden actions or impossible states.
        
        SHARD DATA:
        "${t.substring(0,1e4)}..."
        
        Output ONLY the extracted logic. Preserve technical precision.
        `;return(await d.resilientCallLLM(s,e,"You are a Fractal Distiller.")).content.trim()}static async fuseAndRefine(t,e,i){const s=`
        ACT AS A SEMANTIC FUSION ENGINE.
        You are looking at several abstraction shards from Layer ${i}.
        
        Goal: Merge these into a single, cohesive "Meta-Invariant" block.
        Identify redundancies and collapse them. 
        Focus on the "Platonic Ideal" of the knowledge.
        
        SHARDS:
        ${t.substring(0,2e4)}
        
        Return the Refined Meta-Reality.
        `;return(await d.resilientCallLLM(s,e,"You are a Reality Synthesizer.")).content.trim()}static async shardReality(t){const{SemanticHasher:e}=await m(async()=>{const{SemanticHasher:o}=await import("./semantic_hashing-Ctxnt7XM.js");return{SemanticHasher:o}},__vite__mapDeps([0,1,2,3,4])),{Hypervector:i}=await m(async()=>{const{Hypervector:o}=await import("./hypervector-DtnlNLYu.js");return{Hypervector:o}},[]);console.log("[Fractal] 📐 Analyzing Topological Trajectory for optimal sharding...");const s=[],l=t.split(/\s+/);let n=[],a=i.random();for(const o of l)if(n.push(o),n.length%50===0&&n.length>100){const r=n.join(" "),u=i.fromString(e.computeHolographicHash(r));a.similarity(u)<.6&&(s.push(r),n=[],a=u)}return n.length>0&&s.push(n.join(" ")),s}static async verifyIntegrity(t,e){const i=A({task:"verify"}),s=`Generate 3 hard questions based on deep facts in this text: "${t.substring(0,5e3)}"`,n=(await d.resilientCallLLM(s,i)).content.split(`
`).filter(o=>o.includes("?"));let a=0;for(const o of n){const r=await d.resilientCallLLM(`Use ONLY this context to answer: ${e}
Question: ${o}`,i);!r.content.toLowerCase().includes("i don't know")&&!r.content.toLowerCase().includes("not mentioned")&&a++}return a/(n.length||1)*100}}h(y,"MAX_TOKEN_TARGET",3e3),h(y,"LAYER_REDUCTION_FACTOR",.8);export{y as FractalCompressor};
//# sourceMappingURL=fractal_compressor-BjN0XpMn.js.map
