const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/semantic_hashing-OfSksjfg.js","assets/llm-NNkhUcAb.js","assets/client-Dq_cuSAf.js","assets/hypervector-DkgCCw2d.js","assets/supabase-DYu6klIT.js","assets/sentinel-DSpJSiZJ.js"])))=>i.map(i=>d[i]);
import{_ as m,A as f}from"./client-Dq_cuSAf.js";import{S as v}from"./llm-NNkhUcAb.js";import{supabase as h}from"./supabase-DYu6klIT.js";class w{static async synthesizeFromContradiction(n,e){console.log(`[VaccineEngine] 💉 Analyzing contradiction for context ${n.context_id}...`);const{SemanticHasher:c}=await m(async()=>{const{SemanticHasher:_}=await import("./semantic_hashing-OfSksjfg.js");return{SemanticHasher:_}},__vite__mapDeps([0,1,2,3,4])),{Hypervector:o}=await m(async()=>{const{Hypervector:_}=await import("./hypervector-DkgCCw2d.js");return{Hypervector:_}},[]),s=o.fromString(c.computeHolographicHash(e.claim_a)),l=o.fromString(c.computeHolographicHash(e.claim_b)),i=s.bind(l),t=await f.realSHA256(i.toString()),{data:r}=await h.from("vaccines").select("*").eq("error_signature_hash",t).single();if(r)return console.log("[VaccineEngine] ⚡ Vaccine already exists for this pattern. Strengthening..."),await h.rpc("increment_vaccine_potency",{vid:r.vaccine_id}),r;const g=`
        LOGICAL DNA EXTRACTION
        
        A contradiction was found in an AI-generated knowledge crystal:
        CLAIM A: "${e.claim_a}"
        CLAIM B: "${e.claim_b}"
        
        Task: Identify the underlying LOGICAL FALLACY (e.g., Causal Reversal, Temporal Inconsistency, Scope Creep).
        Then, write a UNIVERSAL RULE (Meta-Invariant) that prevents this specific logical error.
        
        Return JSON:
        {
            "fallacy": "string",
            "rule": "High-level human readable rule",
            "logical_constraint": "Precise mathematical/logical constraint",
            "pattern_to_block": "Semantic pattern that triggers this error"
        }
        `,p=await v.resilientCallLLM(g,"google/gemini-pro","You are a Formal Logician.");let a;try{a=JSON.parse(p.content)}catch{return null}const u={error_signature_hash:t,fallacy_type:a.fallacy,meta_invariant:{rule:a.rule,logical_constraint:a.logical_constraint,prohibited_pattern:a.pattern_to_block},context_domain:n.domain||"general"},{error:d}=await h.from("vaccines").insert({...u,meta_invariant:u.meta_invariant});if(d)return console.error("[VaccineEngine] ❌ Failed to store vaccine:",d.message),null;console.log(`[VaccineEngine] ✅ New Vaccine synthesized: ${a.fallacy} ("${a.rule}")`);const{Sentinel:y}=await m(async()=>{const{Sentinel:_}=await import("./sentinel-DSpJSiZJ.js");return{Sentinel:_}},__vite__mapDeps([5,2,4,1]));return await y.emit({type:"VACCINE_SYNTHESIS",severity:"info",message:`New Vaccine synthesized for ${a.fallacy}: "${a.rule}"`,details:{fallacy:a.fallacy,rule:a.rule,domain:n.domain}}),await y.triggerEntanglement(u.vaccine_id||t),u}static async synthesizePrecognitiveVaccine(n,e){console.log(`[VaccineEngine] 🔮 Precognitive synthesis for predicted error: "${e}"`);const c=`PRECOGNITIVE_FAILURE: [${e}] in DOMAIN: [${n.domain}]`,o=await(await m(async()=>{const{Attestation:r}=await import("./client-Dq_cuSAf.js").then(g=>g.i);return{Attestation:r}},[])).Attestation.realSHA256(c),s=`
        PRECOGNITIVE DNA EXTRACTION
        
        The Oracle predicted a future failure in an AI knowledge crystal:
        PREDICTED FAILURE: "${e}"
        DOMAIN: "${n.domain}"
        
        Task: Identify the underlying LOGICAL FALLACY that would cause this.
        Write a UNIVERSAL RULE (Meta-Invariant) to BLOCK this failure before it ever happens.
        
        Return JSON:
        {
            "fallacy": "string",
            "rule": "High-level human readable rule",
            "logical_constraint": "Precise mathematical/logical constraint",
            "pattern_to_block": "Semantic pattern that triggers this error"
        }
        `,l=await v.resilientCallLLM(s,"google/gemini-pro","You are a Precognitive Logician.");let i;try{i=JSON.parse(l.content)}catch{return null}const t={error_signature_hash:o,fallacy_type:i.fallacy,meta_invariant:{rule:i.rule,logical_constraint:i.logical_constraint,prohibited_pattern:i.pattern_to_block},context_domain:n.domain||"general"};return await h.from("vaccines").insert({...t,meta_invariant:t.meta_invariant}),console.log(`[VaccineEngine] 💉 PRE-IMMUNIZED: System is now protected against "${i.fallacy}" (Oracle Prediction).`),t}static async getActiveGuards(n,e){const{SemanticHasher:c}=await m(async()=>{const{SemanticHasher:t}=await import("./semantic_hashing-OfSksjfg.js");return{SemanticHasher:t}},__vite__mapDeps([0,1,2,3,4])),{data:o,error:s}=await h.from("vaccines").select("*").eq("context_domain",e).limit(20);if(s||!o||o.length===0)return[];const l=c.computeHolographicHash(n);return o.map(t=>{var a;const r=((a=t.meta_invariant)==null?void 0:a.prohibited_pattern)||t.fallacy_type,g=c.computeHolographicHash(r),p=c.holographicSimilarity(l,g);return{vaccine:t,similarity:p}}).filter(t=>t.similarity>.4).sort((t,r)=>r.similarity-t.similarity).slice(0,5).map(t=>t.vaccine)}}export{w as VaccineEngine};
//# sourceMappingURL=vaccine_engine-CkFjQwHz.js.map
