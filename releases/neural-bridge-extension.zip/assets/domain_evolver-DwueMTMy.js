var m=Object.defineProperty;var l=(o,e,t)=>e in o?m(o,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):o[e]=t;var c=(o,e,t)=>l(o,typeof e!="symbol"?e+"":e,t);import{S as d}from"./llm-BLnz7_CX.js";import{Sentinel as v}from"./sentinel-C_ggrGDp.js";import{C as f}from"./client-BYTJAMrK.js";import"./supabase-DYu6klIT.js";class g{static async evolveDomain(e){var r;console.log("[DomainEvolver] 🧠 Analyzing context for evolutionary potential...");const t=`
        ACT AS AN ONTOLOGICAL ARCHITECT.
        The following text does not fit any standard knowledge domain.
        
        TEXT: "${e.substring(0,500)}"
        
        TASK:
        1. Synthesize a UNIQUE domain name for this knowledge.
        2. Extract 3 fundamental AXIOMS (rules) that govern this specific "random" reality.
        3. Assign an Evolution Confidence score (0.0 to 1.0).
        
        Return JSON:
        {
            "domain": "...",
            "axioms": ["...", "...", "..."],
            "confidence": 0.0
        }
        `;let s;try{s=await d.resilientCallLLM(t,f.model_stack.free,"You are a master of spontaneous ontology.")}catch(i){if((i&&typeof i=="object"&&"message"in i&&typeof i.message=="string"?i.message:"")==="SOVEREIGN_REQUIRED")return{domain:"sovereign_evolution",axioms:["Logic is the only anchor","Structure survives chaos"],confidence:1,discovered_at:new Date().toISOString()};throw i}let a;try{a=JSON.parse(((r=s.content.match(/\{[\s\S]*\}/))==null?void 0:r[0])||"{}")}catch{a={domain:"stochastic_anomaly",axioms:[],confidence:.1}}const n={domain:a.domain||"unknown_evolution",axioms:a.axioms||[],confidence:Number(a.confidence)||0,discovered_at:new Date().toISOString()};return n.confidence>.7&&(this.evolvedCache.set(n.domain,n),await v.emit({type:"CHAOS_EVOLUTION",severity:"info",message:`New Domain Evolved: ${n.domain.toUpperCase()}`,details:n})),n}}c(g,"evolvedCache",new Map);export{g as DomainEvolver};
//# sourceMappingURL=domain_evolver-DwueMTMy.js.map
