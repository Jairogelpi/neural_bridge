const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/semantic_hashing-CYq_rfBx.js","assets/llm-VqcXcz0T.js","assets/client-CGcdomT2.js","assets/hypervector-DtnlNLYu.js","assets/supabase-PCba1xJM.js","assets/sentinel-BCfMb6jL.js"])))=>i.map(i=>d[i]);
import{_,A as f}from"./client-CGcdomT2.js";import{S as v}from"./llm-VqcXcz0T.js";import{s as l}from"./supabase-PCba1xJM.js";class w{static async synthesizeFromContradiction(a,t){console.log(`[VaccineEngine] 💉 Analyzing contradiction for context ${a.context_id}...`);const{SemanticHasher:i}=await _(async()=>{const{SemanticHasher:s}=await import("./semantic_hashing-CYq_rfBx.js");return{SemanticHasher:s}},__vite__mapDeps([0,1,2,3,4])),{Hypervector:o}=await _(async()=>{const{Hypervector:s}=await import("./hypervector-DtnlNLYu.js");return{Hypervector:s}},[]),m=o.fromString(i.computeHolographicHash(t.claim_a)),u=o.fromString(i.computeHolographicHash(t.claim_b)),n=m.bind(u),r=await f.realSHA256(n.toString()),{data:c}=await l.from("vaccines").select("*").eq("error_signature_hash",r).single();if(c)return console.log("[VaccineEngine] ⚡ Vaccine already exists for this pattern. Strengthening..."),await l.rpc("increment_vaccine_potency",{vid:c.vaccine_id}),c;const h=`
        LOGICAL DNA EXTRACTION
        
        A contradiction was found in an AI-generated knowledge crystal:
        CLAIM A: "${t.claim_a}"
        CLAIM B: "${t.claim_b}"
        
        Task: Identify the underlying LOGICAL FALLACY (e.g., Causal Reversal, Temporal Inconsistency, Scope Creep).
        Then, write a UNIVERSAL RULE (Meta-Invariant) that prevents this specific logical error.
        
        Return JSON:
        {
            "fallacy": "string",
            "rule": "High-level human readable rule",
            "logical_constraint": "Precise mathematical/logical constraint",
            "pattern_to_block": "Semantic pattern that triggers this error"
        }
        `,y=await v.resilientCallLLM(h,"google/gemini-pro","You are a Formal Logician.");let e;try{e=JSON.parse(y.content)}catch{return null}const g={error_signature_hash:r,fallacy_type:e.fallacy,meta_invariant:{rule:e.rule,logical_constraint:e.logical_constraint,prohibited_pattern:e.pattern_to_block},context_domain:a.domain||"general"},{error:d}=await l.from("vaccines").insert({...g,meta_invariant:g.meta_invariant});if(d)return console.error("[VaccineEngine] ❌ Failed to store vaccine:",d.message),null;console.log(`[VaccineEngine] ✅ New Vaccine synthesized: ${e.fallacy} ("${e.rule}")`);const{Sentinel:p}=await _(async()=>{const{Sentinel:s}=await import("./sentinel-BCfMb6jL.js");return{Sentinel:s}},__vite__mapDeps([5,2,4]));return await p.emit({type:"VACCINE_SYNTHESIS",severity:"info",message:`New Vaccine synthesized for ${e.fallacy}: "${e.rule}"`,details:{fallacy:e.fallacy,rule:e.rule,domain:a.domain}}),await p.triggerEntanglement(g.vaccine_id||r),g}static async synthesizePrecognitiveVaccine(a,t){console.log(`[VaccineEngine] 🔮 Precognitive synthesis for predicted error: "${t}"`);const i=`PRECOGNITIVE_FAILURE: [${t}] in DOMAIN: [${a.domain}]`,o=await(await _(async()=>{const{Attestation:c}=await import("./client-CGcdomT2.js").then(h=>h.i);return{Attestation:c}},[])).Attestation.realSHA256(i),m=`
        PRECOGNITIVE DNA EXTRACTION
        
        The Oracle predicted a future failure in an AI knowledge crystal:
        PREDICTED FAILURE: "${t}"
        DOMAIN: "${a.domain}"
        
        Task: Identify the underlying LOGICAL FALLACY that would cause this.
        Write a UNIVERSAL RULE (Meta-Invariant) to BLOCK this failure before it ever happens.
        
        Return JSON:
        {
            "fallacy": "string",
            "rule": "High-level human readable rule",
            "logical_constraint": "Precise mathematical/logical constraint",
            "pattern_to_block": "Semantic pattern that triggers this error"
        }
        `,u=await v.resilientCallLLM(m,"google/gemini-pro","You are a Precognitive Logician.");let n;try{n=JSON.parse(u.content)}catch{return null}const r={error_signature_hash:o,fallacy_type:n.fallacy,meta_invariant:{rule:n.rule,logical_constraint:n.logical_constraint,prohibited_pattern:n.pattern_to_block},context_domain:a.domain||"general"};return await l.from("vaccines").insert({...r,meta_invariant:r.meta_invariant}),console.log(`[VaccineEngine] 💉 PRE-IMMUNIZED: System is now protected against "${n.fallacy}" (Oracle Prediction).`),r}static async getActiveGuards(a,t){const{data:i,error:o}=await l.from("vaccines").select("*").eq("context_domain",t).order("severity",{ascending:!1}).limit(5);return o||!i?[]:i}}export{w as VaccineEngine};
//# sourceMappingURL=vaccine_engine-Bzfputj3.js.map
