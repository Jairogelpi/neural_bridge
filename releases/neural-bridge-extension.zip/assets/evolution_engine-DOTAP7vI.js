import{b as c,S as l}from"./llm-BLnz7_CX.js";import"./client-BYTJAMrK.js";class m{static breed(t,n){var i,a;console.log(`[EvolutionEngine] 🌹 Breeding Generation ${t.version} & ${n.version}...`);const o=this.crossoverConstraints(t.constraints||[],n.constraints||[]),e={...t.intent,primary:`${t.intent.primary} + ${n.intent.primary} [SYNTHESIS]`,status:c.ACTIVE};return{...t,context_id:`child_${Date.now()}_gen`,version:`${parseInt(t.version)+1}.0.0`,intent:e,constraints:o,rlm_stats:{q_score:((((i=t.rlm_stats)==null?void 0:i.q_score)||.5)+(((a=n.rlm_stats)==null?void 0:a.q_score)||.5))/2,usage_count:0,last_reward_at:new Date().toISOString(),volatility:.1},created_at:new Date().toISOString(),verification:{...t.verification,canonical_hash:"PENDING_REHASH"}}}static reap(t){const n=t.filter(o=>{const e=o.rlm_stats||{q_score:.5,usage_count:0};return e.usage_count>10&&e.q_score<.2});return console.log(`[EvolutionEngine] 💀 Reaping ${n.length} weak crystals.`),n.map(o=>o.context_id)}static crossoverConstraints(t,n){const o=[...t,...n];return Array.from(new Map(o.map(s=>[s.id,s])).values()).filter(()=>Math.random()>.1)}static async evolve(t,n,o){console.log(`
🧬 [EvolutionEngine] DETECTED WEAKNESS (Score: ${o}). Initiating Evolution...`);try{const e=`
            ACT AS AN AI EVOLUTION ENGINEER.
            
            CONTEXT:
            User Intent: "${t}"
            Failed Prompt: "${n}"
            Reliability Score: ${o} (Too Low)

            TASK:
            Analyze WHY this prompt failed to generate a valid Crystal.
            Is it ambiguous? Missing constraints? Too complex?
            
            Return a single sentence diagnosis.
            `;console.log("🔬 [EvolutionEngine] Diagnosing failure logic...");const i=(await l.resilientCallLLM(e,"anthropic/claude-3-haiku","Evolution Engineer")).content;console.log(`   > Diagnosis: ${i.substring(0,100)}...`);const a=`
            ACT AS A GENETIC ALGORITH FOR PROMPTS.

            DIAGNOSIS: ${i}
            ORIGINAL PROMPT: "${n}"

            TASK:
            Rewrite the ORIGINAL PROMPT to fix the diagnosed issue.
            - Make it more robust.
            - Add explicit constraints if needed.
            - Optimize for machine-readability.

            Return ONLY the new prompt text. Do not explain.
            `;console.log("🧪 [EvolutionEngine] Mutating prompt DNA...");const r=(await l.resilientCallLLM(a,"google/gemini-2.0-flash-exp:free","Genetic Mutation Algo")).content;return r&&r.length>10?(console.log("✨ [EvolutionEngine] EVOLUTION COMPLETE. New Strategy Generated."),r):null}catch(e){return console.error("💀 [EvolutionEngine] Evolution failed:",e),null}}}export{m as EvolutionEngine};
//# sourceMappingURL=evolution_engine-DOTAP7vI.js.map
