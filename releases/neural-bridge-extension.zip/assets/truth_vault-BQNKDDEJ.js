const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/fractal_compressor-vuXs94xI.js","assets/client-Dq_cuSAf.js","assets/llm-NNkhUcAb.js","assets/evolution_engine-P2__sEYc.js","assets/vaccine_engine-CkFjQwHz.js","assets/supabase-DYu6klIT.js","assets/rlm_engine-DQmFPgCP.js"])))=>i.map(i=>d[i]);
import{_ as v,A as I}from"./client-Dq_cuSAf.js";import{supabase as f}from"./supabase-DYu6klIT.js";import{U as R,d as b,S as T,C as E,b as w}from"./llm-NNkhUcAb.js";import{SemanticHasher as _}from"./semantic_hashing-OfSksjfg.js";import{Hypervector as C}from"./hypervector-DkgCCw2d.js";class S{static async mineCrystal(t,e={}){var c,u,y;console.log(`[Crystallization] 💎 Starting mining process for ${t.length} chars...`);const i=await R.solve(t);if(i.status==="UNSAT")throw new Error(`[Crystallization] ⛔ ONTOLOGICAL REFUSAL: ${i.message}`);let a=t;if(e.compress!==!1){const{FractalCompressor:l}=await v(async()=>{const{FractalCompressor:g}=await import("./fractal_compressor-vuXs94xI.js");return{FractalCompressor:g}},__vite__mapDeps([0,1,2]));a=await l.compress(t)}const r=e.domain||await b(a),s=T.getOptimalModel({domain:r,task:"compile",isCritical:!0}),d=await T.resilientCallLLM(`CRYSTALLIZE THIS KNOWLEDGE:

${a}

Return ONLY JSON.`,s,`You are the CRYSTALLIZATION ENGINE.
Your goal is to extract IRREFUTABLE TRUTH from the input text and freeze it into a "Crystal".

You MUST return a valid JSON object matching the Crystal v0.1 schema:
{
  "entities": [{"name": "...", "type": "...", "category": "..."}],
  "intent": {"primary": "...", "status": "active"},
  "constraints": [
    {
      "id": "c_unique_id",
      "rule": "MUST|NEVER|IF_THEN", 
      "value": "Exact rule text", 
      "rationale": "Why this is true"
    }
  ],
  "verification": {
    "semantic_invariants": [
      {
        "id": "inv_001",
        "prompt": "Question to verify truth",
        "expected": {"type": "string", "value": "Expected Answer"},
        "rationale": "..."
      }
    ]
  }
}

CRITICAL RULES:
- Extracted constraints must be LOGICALLY BINDING.
- The "intent" should represent the core purpose of this knowledge.
- Invariants must be testable questions that PROVE the AI understands this crystal.
- AUTO-INFER: Look for numerical facts, dates, named entities, and logical dependencies. Create 3-5 invariants automatically.`);let n;try{let l=d.content;const g=l.match(/```(?:json)?\s*([\s\S]*?)```/);g&&g[1]&&(l=g[1]),n=JSON.parse(l.trim())}catch(l){throw new Error(`[Crystallization] Failed to parse Crystal JSON: ${l}`)}const m={scp_version:"1.0",context_id:`cry_${Date.now()}_${Math.random().toString(36).substr(2,5)}`,created_at:new Date().toISOString(),version:"1.0.0",tier:e.tier||"community",domain:r,source:{platform:"neural-bridge-refinery",url:"internal://crystallization",timestamp:new Date().toISOString(),model:s},intent:{primary:((c=n.intent)==null?void 0:c.primary)||"Knowledge Transfer",status:w.ACTIVE},author:e.author||{id:"system_refinery",name:"Neural Bridge Refinery",reputation:1},constraints:(n.constraints||[]).map(l=>({id:l.id||`c_${Math.random().toString(36).substr(2,4)}`,rule:l.rule||E.MUST,value:l.value,rationale:l.rationale||"Extracted truth"})),entities:n.entities||[],verification:{canonical_hash:"",semantic_invariants:(((u=n.verification)==null?void 0:u.semantic_invariants)||[]).map(l=>{var g,p;return{id:l.id||`inv_${Math.random().toString(36).substr(2,4)}`,kind:"fact_check",prompt:l.prompt,expected:{type:((g=l.expected)==null?void 0:g.type)||"string",value:(p=l.expected)==null?void 0:p.value},weight:1,strict:!0,rationale:l.rationale||"Verification check"}}),policy:{min_checks:2,accept_threshold:.8,max_retries:1,strategy:"strict"}}},h={...m};return h.verification.canonical_hash=void 0,m.verification.canonical_hash=await I.realSHA256(JSON.stringify(h)),console.log(`[Crystallization] ✅ Minted Crystal [${m.context_id}] (${(y=m.constraints)==null?void 0:y.length} constraints)`),m}static vectorFieldExtraction(t){const e=t.split(/\s+/).filter(a=>a.length>3),i=[];for(let a=0;a<e.length;a++){const r=_.computeSimHash(e[a]),s=C.fromString(r);let o=0;for(let n=0;n<4096;n++)s.data[n>>>5]>>>(n&31)&1&&o++;const d=o/4096;d>.7&&i.push({id:`axiom_${Date.now()}_${a}`,rule:E.MUST,value:e[a],rationale:"Geometric Singularity: High-Density Logical Invariant"}),d<.1&&i.push({id:`axiom_neg_${Date.now()}_${a}`,rule:E.NEVER,value:e[a],rationale:"Entropic Singularity: Negative Logic Cluster"})}return i}static mineProtoCrystal(t,e="general",i={}){const a=this.vectorFieldExtraction(t),r=_.computeSimHash(t);return{scp_version:"1.0",context_id:`proto_${Date.now()}`,created_at:new Date().toISOString(),version:"0.1.0-proto",tier:"community",domain:e,tags:[`lsh:${r}`],source:{platform:"neural-bridge-flash",url:"internal://flash_crystallization",timestamp:new Date().toISOString(),model:"REGEX_ENGINE"},intent:{primary:"Proto-Context",status:w.ACTIVE},constraints:a,verification:{canonical_hash:"proto_hash_pending",semantic_invariants:[],policy:{min_checks:0,accept_threshold:.5,max_retries:0,strategy:"lenient"}},author:{id:"flash_engine",name:"Flash Crystallizer",reputation:.1}}}static async sublimateCrystal(t){var a;if(t.tier!=="community"&&t.type!=="proto")return t;console.log(`[Crystallization] ⚗️ Sublimating Proto-Crystal [${t.context_id}]...`);const e=((a=t.constraints)==null?void 0:a.map(r=>r.value).join(`
`))||"";if(!e)return t;const i=await S.mineCrystal(e,{domain:t.domain,author:{id:"sublimator",name:"Sublimation Engine",reputation:.9}});return i.supersedes=t.context_id,i}}class V{static async scanForContradictions(t){const{data:e,error:i}=await f.from("crystals").select("*");if(i||!e)return[];const a=[];for(const r of e){if(r.context_id===t.context_id||r.domain!==t.domain)continue;const s=`You are the Neural Bridge Truth Arbiter.
Analyze two knowledge crystals and detect if they contain CONTRADICTING information.
Contradictions are direct logical conflicts (e.g., A says "X is true", B says "X is false").

Return JSON:
{
  "has_contradiction": boolean,
  "explanation": "why they conflict",
  "claim_a": "conflicting claim from A",
  "claim_b": "conflicting claim from B",
  "severity": "critical|warning"
}`,o=`Crystal A (New): ${JSON.stringify(t.constraints)}
Crystal B (Existing): ${JSON.stringify(r.constraints)}

Do these conflict?`;try{const d=await T.callLLM(o,"nvidia/nemotron-3-nano-30b-a3b:free",s),n=JSON.parse(d.content.replace(/```json|```/g,"").trim());n.has_contradiction&&a.push({crystal_id_a:t.context_id,crystal_id_b:r.context_id,claim_a:n.claim_a,claim_b:n.claim_b,explanation:n.explanation,severity:n.severity})}catch(d){console.error("Error during contradiction scan:",d)}}return a}static async heal(t){for(const e of t){console.log(`[SELF-HEALING] Contradiction detected: ${e.explanation}`),await f.from("kv_store").upsert({key:`contradiction_${Date.now()}`,value:e,updated_at:new Date().toISOString()});const{EvolutionEngine:i}=await v(async()=>{const{EvolutionEngine:o}=await import("./evolution_engine-P2__sEYc.js");return{EvolutionEngine:o}},__vite__mapDeps([3,2,1])),{data:a}=await f.from("crystals").select("*").eq("context_id",e.crystal_id_a).single(),{data:r}=await f.from("crystals").select("*").eq("context_id",e.crystal_id_b).single();if(a&&r){console.log(`[TruthVault] 🧬 Breeding resolution for contradiction: ${e.crystal_id_a} x ${e.crystal_id_b}`);const o=i.breed(a,r);await this.saveTruth(o),await f.from("crystals").update({status:"archived"}).in("context_id",[e.crystal_id_a,e.crystal_id_b])}const{VaccineEngine:s}=await v(async()=>{const{VaccineEngine:o}=await import("./vaccine_engine-CkFjQwHz.js");return{VaccineEngine:o}},__vite__mapDeps([4,1,2,5]));a&&await s.synthesizeFromContradiction(a,e)}}static async retrieveBestCrystal(t){let e=f.from("crystals").select("*");const{data:i,error:a}=await e;if(a||!i||i.length===0)return null;const r=i.filter(o=>o.domain===t.domain);if(r.length===0)return null;t.tags&&t.tags.length>0&&r.sort((o,d)=>{const n=(o.tags||[]).filter(h=>{var c;return(c=t.tags)==null?void 0:c.includes(h)}).length;return(d.tags||[]).filter(h=>{var c;return(c=t.tags)==null?void 0:c.includes(h)}).length-n});let s=r[0]||null;return s&&(s.tier==="community"||s.type==="proto")&&(s=await S.sublimateCrystal(s)),s}static async retrieveSemanticallySimilar(t,e){var h;const i=_.computeSimHash(t),{data:a,error:r}=await f.from("crystals").select("*").eq("domain",e);if(r||!a)return[];const s=[];for(const c of a){const u=c,y=(u.tags||[]).find(O=>O.startsWith("lsh:"));if(!y)continue;const l=y.replace("lsh:","");let p=1-_.hammingDistance(i,l)/64;const N=C.fromString(((h=u.verification)==null?void 0:h.canonical_hash)||"").getFisherInformation();p+=N*.15,p>.4&&s.push({crystal:u,score:p})}const o=s.sort((c,u)=>u.score-c.score).slice(0,10).map(c=>c.crystal),{data:d}=await f.from("crystals").select("usage_count"),n=(d||[]).reduce((c,u)=>c+(u.usage_count||0),0)||1e3,{RLMEngine:m}=await v(async()=>{const{RLMEngine:c}=await import("./rlm_engine-DQmFPgCP.js");return{RLMEngine:c}},__vite__mapDeps([6,1]));return m.rankCandidates(o,n,e)}static async checkReality(t,e){var s,o;console.log(`[TruthVault] 🛡️ Defending reality for domain: ${e}...`);const i=_.computeSimHash(t),{data:a,error:r}=await f.from("crystals").select("*").eq("domain",e).limit(10);if(r||!a||a.length===0)return{is_conflict:!1};for(const d of a){const n=d,m=(n.tags||[]).find(u=>u.startsWith("lsh:")),h=m?m.replace("lsh:",""):(s=n.verification)==null?void 0:s.canonical_hash;if(h&&_.hammingDistance(i,h)>32)continue;const c=`
            REALITY ARBITRATION
            ---
            You are a Neural Bridge Truth Arbiter. Verify if the NEW TEXT contradicts the established FOUNDATION TRUTH.
            
            FOUNDATION TRUTH (Crystal):
            "${JSON.stringify(n.constraints)}"
            
            NEW TEXT:
            "${t}"
            
            TASK: Identify if the new text has a logic-level contradiction with the truth.
            
            Return JSON:
            {
                "is_conflict": boolean,
                "reason": "precise explanation of the logic failure"
            }
            `;try{const u=await T.resilientCallLLM(c,"nvidia/nemotron-3-nano-30b-a3b:free","Arbiter of Reality"),y=JSON.parse(((o=u.content.match(/\{[\s\S]*\}/))==null?void 0:o[0])||"{}");if(y.is_conflict)return{is_conflict:!0,contradiction_reason:y.reason,conflicting_entry:n}}catch{console.warn("[TruthVault] Arbitration failed for candidate:",n.context_id)}}return{is_conflict:!1}}static async healReality(t,e){console.log(`[TruthVault] 💉 Healing reality conflict: "${e.reason}"...`);const i=`
        ONTOLOGICAL HEALING
        ---
        The following text contains a contradiction with the Truth Vault.
        
        ERROR: "${e.reason}"
        TRUTH: "${JSON.stringify(e.entry.constraints)}"
        ORIGINAL TEXT: "${t}"
        
        TASK: Rewrite the ORIGINAL TEXT so that it is factually consistent with the TRUTH.
        Keep the user's intent but remove the contradiction.
        
        Return ONLY the healed text.
        `;return(await T.resilientCallLLM(i,"google/gemini-2.0-flash-exp:free","Time-Traveling Truth Healer")).content.trim()}static async saveTruth(t){console.log(`[TruthVault] 💎 Crystallizing new truth: ${t.context_id.substring(0,8)}`);const e=_.computeSimHash(t.intent.primary),i=[...t.tags||[],`lsh:${e}`],{error:a}=await f.from("crystals").upsert({context_id:t.context_id,domain:t.domain,intent:t.intent,constraints:t.constraints,entities:t.entities,verification:t.verification,tags:i,usage_count:t.usage_count||1,author:t.author,source:t.source,created_at:t.created_at||new Date().toISOString()});a?console.error("[TruthVault] ❌ Failed to save truth:",a.message):console.log("[TruthVault] ✅ Knowledge persistent in collective lattice.")}}export{V as TruthVault};
//# sourceMappingURL=truth_vault-BQNKDDEJ.js.map
