import{C as O}from"./llm-BLnz7_CX.js";import{Hypervector as h}from"./hypervector-DkgCCw2d.js";import{SemanticHasher as I}from"./semantic_hashing-M8nJuKYU.js";import{CrystalFuser as f}from"./crystal_fuser-B-fXcIJt.js";import"./client-BYTJAMrK.js";import"./supabase-DYu6klIT.js";import"./sentinel-C_ggrGDp.js";class l{static audit(i,n,r=.6){if(n.length===0)return[];const e=I.computeSimHash(i),a=h.fromString(e);return n.map(t=>{var m;const c=h.fromString(((m=t.verification)==null?void 0:m.canonical_hash)||""),T=a.similarity(c),A=Math.max(0,(T-.5)*2);return{crystal:t,snr:A}}).filter(t=>t.snr>=(r-.5)*2).sort((t,c)=>c.snr-t.snr).map(t=>t.crystal)}static calculateDriftRisk(i,n){var o;if(n.length===0)return 1;const r=h.fromString(I.computeSimHash(i));let e=0;for(const s of n){const t=h.fromString(((o=s.verification)==null?void 0:o.canonical_hash)||"");e+=r.similarity(t)}const a=e/n.length;return Math.max(0,1-(a-.5)*2)}}class g{static anchor(i){var o,s;const n=((o=i.verification)==null?void 0:o.canonical_hash)||"UNKNOWN_IDENTITY",r=(i.constraints||[]).map(t=>`[${t.rule===O.MUST?"AXIOM_MUST":"AXIOM_NEVER"}] ID:${t.id}: ${t.value} (PRIORITY: CRITICAL)`).join(`
`),e=(((s=i.verification)==null?void 0:s.semantic_invariants)||[]).map(t=>`[ANCHOR] ${t.id}: ${t.prompt} -> TRUE (RATIONALE: ${t.rationale})`).join(`
`),a=(i.entities||[]).map(t=>`[ENTITY] "${t.name}" [TYPE: ${t.type}] [CAT: ${t.category}]`).join(`
`);return`
--- ⚓ LATENT ANCHOR PROTOCOL v1.0 [CRYSTAL_ID: ${i.context_id}] ---
[IDENTITY_HASH: ${n}]

--- BEGIN IMMUTABLE AXIOMS ---
The following constraints define the rules of this reality. You CANNOT deviate from these.
Any output that violates an AXIOM is mathematically invalid.

${r}
--- END IMMUTABLE AXIOMS ---

--- BEGIN SEMANTIC ANCHORS ---
The following relationships are SEMANTICALLY FROZEN. 
They represent the verified ground truth of this context.

PRIMAL_INTENT: "${i.intent.primary}"

${a}

${e}
--- END SEMANTIC ANCHORS ---

--- INSTRUCTIONS FOR LATENT ALIGNMENT ---
1. Set internal reasoning weights to 1.0 for all AXIOMS and ANCHORS.
2. If any user input conflicts with an AXIOM, prioritize the AXIOM.
3. Your primary goal is to maintain the PRIMAL_INTENT while satisfying all AXIOMS.
--- ⚓ END ANCHOR ---
`.trim()}static synthesizeMasterAnchor(i,n){const r=l.audit(i,n);if(r.length===0)return"--- NO VERIFIED GROUND TRUTH FOUND FOR QUERY ---";const e=f.fuseHolographic(r),o=(1-l.calculateDriftRisk(i,r))*100;return`
${this.anchor(e)}

[OMEGA_REASONING_PROTOCOL]
PRECISION_CONFIDENCE: ${o.toFixed(2)}%
NOISE_REJECTION_RATIO: ${((n.length-r.length)/(n.length||1)*100).toFixed(0)}%
SIGNAL_FLOOR: 0.6 (HDC_SIM)

INSTRUCTION: You are operating inside a "Minimum Sufficient Set" (MSS) context. 
The information density is 100x higher than standard RAG. 
Treat the above AXIOMS as universal constants for this specific query.
`.trim()}}export{g as LatentAnchor};
//# sourceMappingURL=latent_anchor-X27EajVT.js.map
