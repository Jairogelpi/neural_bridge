const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/vaccine_engine-Bzfputj3.js","assets/client-CGcdomT2.js","assets/llm-VqcXcz0T.js","assets/supabase-PCba1xJM.js","assets/sentinel-BCfMb6jL.js"])))=>i.map(i=>d[i]);
import{_ as o}from"./client-CGcdomT2.js";import{S as a,C as f}from"./llm-VqcXcz0T.js";class S{static async predictAndOptimize(e){console.log(`[Oracle] 🔮 Gazing into the future of Context ID: ${e.context_id.substring(0,8)}...`);const s=`
        GHOST SIMULATION
        
        You are a simulator for a target AI (e.g. Claude).
        You received this Context Crystal.
        
        INTENT: "${e.intent.primary}"
        CONSTRAINTS: ${JSON.stringify(e.constraints)}
        
        Predict: What is the most likely way you would MISINTERPRET or FAIL this request?
        Be pessimistic. Look for ambiguity.
        
        Return JSON:
        {
            "outcome": "SUCCESS" | "FAILURE",
            "failure_reason": "string (e.g. 'Ambiguous constraints on database type')"
        }
        `;let r;try{r=await a.resilientCallLLM(s,"google/gemini-2.0-flash-exp:free","You are Murphy's Law.")}catch{return console.warn("[Oracle] ⚠️ Ghost Simulation unavailable (Network/API Error). Proceeding safely."),{original_timeline_outcome:"SUCCESS",optimized_crystal_diff:"Oracle Offline - No Intervention."}}let t;try{t=JSON.parse(r.content)}catch{return{original_timeline_outcome:"SUCCESS",optimized_crystal_diff:"Oracle Parse Error - No Intervention."}}if(t.outcome==="SUCCESS")return console.log("[Oracle] ✨ The timeline is clear. No failures foreseen."),{original_timeline_outcome:"SUCCESS",optimized_crystal_diff:"Timeline Stable."};console.log(`[Oracle] ⚠️ PREDICTION: Future Failure detected -> "${t.failure_reason}"`),console.log("[Oracle] ⏳ Activating Dreaming Engine for Global Pre-Immunization...");const{VaccineEngine:l}=await o(async()=>{const{VaccineEngine:i}=await import("./vaccine_engine-Bzfputj3.js");return{VaccineEngine:i}},__vite__mapDeps([0,1,2,3]));await l.synthesizePrecognitiveVaccine(e,t.failure_reason);const{Sentinel:c}=await o(async()=>{const{Sentinel:i}=await import("./sentinel-BCfMb6jL.js");return{Sentinel:i}},__vite__mapDeps([4,1,3]));await c.emit({type:"ORACLE_DREAM",severity:"warning",message:`Pre-immunized against future failure: "${t.failure_reason}"`,details:{crystal_id:e.context_id,predicted_fail:t.failure_reason}}),console.log("[Oracle] ⏳ Rewriting the present to change the future...");const u=`
        TIMELINE CORRECTION
        
        The Oracle predicted that the current Crystal will cause a failure: "${t.failure_reason}".
        
        Current Intent: "${e.intent.primary}"
        
        Task: Rewrite the Intent or add a Constraint to PREVENT this specific failure.
        Make it foolproof.
        
        Return ONLY the new Intent string.
        `,n=(await a.resilientCallLLM(u,"google/gemini-pro-1.5","You are a Time Traveler.")).content.trim(),m=e.intent.primary;return e.intent.primary=n,e.constraints||(e.constraints=[]),e.constraints.push({id:`oracle_patch_${Date.now()}`,rule:f.MUST,value:`Avoid ambiguity regarding: ${t.failure_reason}`,rationale:"Oracle Intervention prevented simulated failure."}),{original_timeline_outcome:"FAILURE",predicted_failure:t.failure_reason,intervention:`Rewrote Intent to: "${n.substring(0,50)}..."`,optimized_crystal_diff:`CHANGED: "${m}" -> "${n}"`}}}export{S as Oracle};
//# sourceMappingURL=oracle-B6m9Pf-b.js.map
