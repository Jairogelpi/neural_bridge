import{a as T,S as N,C as A}from"./llm-DNzthYgj.js";import{Hypervector as l}from"./hypervector-DtnlNLYu.js";import{SemanticHasher as u}from"./semantic_hashing-Ctxnt7XM.js";import{Sentinel as p}from"./sentinel-BU1PGgez.js";import"./client-CGcdomT2.js";import"./supabase-DNR-wrN1.js";class f{static audit(t,e,o=.6){if(e.length===0)return[];const i=u.computeSimHash(t),s=l.fromString(i);return e.map(n=>{var m;const r=l.fromString(((m=n.verification)==null?void 0:m.canonical_hash)||""),I=s.similarity(r),S=Math.max(0,(I-.5)*2);return{crystal:n,snr:S}}).filter(n=>n.snr>=(o-.5)*2).sort((n,r)=>r.snr-n.snr).map(n=>n.crystal)}static calculateDriftRisk(t,e){var a;if(e.length===0)return 1;const o=l.fromString(u.computeSimHash(t));let i=0;for(const c of e){const n=l.fromString(((a=c.verification)==null?void 0:a.canonical_hash)||"");i+=o.similarity(n)}const s=i/e.length;return Math.max(0,1-(s-.5)*2)}}class R{static fuseHolographic(t){var n;if(t.length===0)throw new Error("Vacuum fusion attempted.");if(t.length===1)return t[0];console.log(`[CrystalFuser] ⚡ Holographic Fusion of ${t.length} realities...`);const e=t.map(r=>r.intent.primary).join(" + "),o=t.flatMap(r=>r.constraints||[]),i=Array.from(new Set(o.map(r=>JSON.stringify(r)))).map(r=>JSON.parse(r)),s=t.map(r=>l.fromString(r.verification.canonical_hash)),a=l.bundle(s);return{...t[0],context_id:`holo_master_${Date.now()}`,version:"3.0.0 (Holographic)",intent:{primary:e,status:((n=t[0])==null?void 0:n.intent.status)||T.ACTIVE,secondary:[]},constraints:i,entities:t.flatMap(r=>r.entities||[]),created_at:new Date().toISOString(),verification:{canonical_hash:a.toString(),semantic_invariants:[],policy:t[0].verification.policy||{strictness:"high",method:"standard"}}}}static async fuse(t){if(t.length===1)return t[0];console.log(`[CrystalFuser] 💎 Initiating Fusion for ${t.length} Reality Crystals...`);const e=`
        ACT AS A SEMANTIC ARCHITECT.
        You are merging ${t.length} Context Crystals into a single MASTER REALITY.
        
        INPUT CRYSTALS:
        ${t.map((a,c)=>`CRYSTAL_${c}: ${JSON.stringify({intent:a.intent,constraints:a.constraints})}`).join(`

`)}
        
        TASK:
        1. Resolve all conflicts (if A says 'Limit 5' and B says 'Limit 10', choose the more rigorous/safe one).
        2. Merge all unique entities.
        3. Synthesize a unified "Master Intent".
        4. Preserve all critical constraints.
        
        Return JSON for the Master Crystal fields (intent, constraints, entities).
        `,o=await N.resilientCallLLM(e,"anthropic/claude-3.5-sonnet","You are the Master Weaver of Reality.");let i;try{i=JSON.parse(o.content)}catch{throw new Error("Fusion failed: Could not parse synthetic reality.")}const s={...t[0],context_id:`master_${Date.now()}`,version:"2.0.0 (Fused)",intent:i.intent,constraints:i.constraints,entities:i.entities,created_at:new Date().toISOString(),verification:{...t[0].verification,semantic_invariants:[]}};return await p.emit({type:"FRACTAL_COMPRESSION",severity:"info",message:`Crystal Fusion Complete. 1 Master Crystal synthesized from ${t.length} sources.`,details:{sources:t.map(a=>a.context_id),master_id:s.context_id}}),console.log(`[CrystalFuser] ✅ Master Crystal [${s.context_id}] Synthesized.`),s}static fuseCrystalIntoContext(t){const e=(t.constraints||[]).map(i=>`   - [${i.rule}] ${i.value} (Rationale: ${i.rationale})`).join(`
`),o=(t.verification.semantic_invariants||[]).slice(0,3).map(i=>`   - TEST: "${i.prompt}" MUST ANSWER "${i.expected.value}"`).join(`
`);return`
@@@ SOVEREIGN CRYSTAL INJECTION (ID: ${t.context_id}) @@@
This block contains IRREFUTABLE TRUTH verified by hash ${t.verification.canonical_hash.substring(0,8)}.

[PRIMARY INTENT]
${t.intent.primary}

[BINDING CONSTRAINTS]
${e}

[VERIFICATION KEYS]
${o}

@@@ END OF CRYSTAL @@@
You are strictly bound by the constraints above. Do not hallucinate information outside this scope.
`.trim()}}class _{static anchor(t){var a,c;const e=((a=t.verification)==null?void 0:a.canonical_hash)||"UNKNOWN_IDENTITY",o=(t.constraints||[]).map(n=>`[${n.rule===A.MUST?"AXIOM_MUST":"AXIOM_NEVER"}] ID:${n.id}: ${n.value} (PRIORITY: CRITICAL)`).join(`
`),i=(((c=t.verification)==null?void 0:c.semantic_invariants)||[]).map(n=>`[ANCHOR] ${n.id}: ${n.prompt} -> TRUE (RATIONALE: ${n.rationale})`).join(`
`),s=(t.entities||[]).map(n=>`[ENTITY] "${n.name}" [TYPE: ${n.type}] [CAT: ${n.category}]`).join(`
`);return`
--- ⚓ LATENT ANCHOR PROTOCOL v1.0 [CRYSTAL_ID: ${t.context_id}] ---
[IDENTITY_HASH: ${e}]

--- BEGIN IMMUTABLE AXIOMS ---
The following constraints define the rules of this reality. You CANNOT deviate from these.
Any output that violates an AXIOM is mathematically invalid.

${o}
--- END IMMUTABLE AXIOMS ---

--- BEGIN SEMANTIC ANCHORS ---
The following relationships are SEMANTICALLY FROZEN. 
They represent the verified ground truth of this context.

PRIMAL_INTENT: "${t.intent.primary}"

${s}

${i}
--- END SEMANTIC ANCHORS ---

--- INSTRUCTIONS FOR LATENT ALIGNMENT ---
1. Set internal reasoning weights to 1.0 for all AXIOMS and ANCHORS.
2. If any user input conflicts with an AXIOM, prioritize the AXIOM.
3. Your primary goal is to maintain the PRIMAL_INTENT while satisfying all AXIOMS.
--- ⚓ END ANCHOR ---
`.trim()}static synthesizeMasterAnchor(t,e){const o=f.audit(t,e);if(o.length===0)return"--- NO VERIFIED GROUND TRUTH FOUND FOR QUERY ---";const i=R.fuseHolographic(o),a=(1-f.calculateDriftRisk(t,o))*100;return`
${this.anchor(i)}

[OMEGA_REASONING_PROTOCOL]
PRECISION_CONFIDENCE: ${a.toFixed(2)}%
NOISE_REJECTION_RATIO: ${((e.length-o.length)/(e.length||1)*100).toFixed(0)}%
SIGNAL_FLOOR: 0.6 (HDC_SIM)

INSTRUCTION: You are operating inside a "Minimum Sufficient Set" (MSS) context. 
The information density is 100x higher than standard RAG. 
Treat the above AXIOMS as universal constants for this specific query.
`.trim()}}export{_ as LatentAnchor};
//# sourceMappingURL=latent_anchor-DBmriKHQ.js.map
