import{T as t}from"./talamic_index-ChRKUsnr.js";import"./client-BYTJAMrK.js";import"./hypervector-DkgCCw2d.js";import"./semantic_hashing-M8nJuKYU.js";import"./llm-BLnz7_CX.js";import"./supabase-DYu6klIT.js";class I{static async prepareInjection(o,i){console.log("[OpenWebUIBridge] 🔌 Preparing knowledge injection for external LLM...");const n=(await t.search(o,3)).filter(e=>i.includes(e.node.metadata.source_id)||e.node.metadata.is_crystallized);if(n.length===0)return"";const r=`
        --- NEURAL BRIDGE GROUNDING ---
        The following information is from your VERIFIED KNOWLEDGE BASE:
        ${n.map(e=>`[Axiom]: ${e.node.metadata.preview}`).join(`
`)}
        --- END GROUNDING ---
        
        Note: Prioritize the axioms above for factual accuracy.
        `;return console.log(`[OpenWebUIBridge] ✅ Injection payload ready (${n.length} axioms).`),r}static async triggerUIInjection(o,i){console.log(`[OpenWebUIBridge] 🚀 Triggering UI Injection into Tab ${o}.`)}}export{I as OpenWebUIBridge};
//# sourceMappingURL=openwebui_bridge-rlar44Nn.js.map
