class I{static rehydrate(n){const e=`
[SYSTEM INSTRUCTION: RESUME CONTEXT STATE]
You are resuming an existing high-context session.
Ignore your default statelessness. You must synchronize your internal state with the following "Knowledge Crystal".
`,i=`
CONTEXT METADATA:
- Domain: ${(n.domain||"general").toUpperCase()}
- Validated Intent: "${n.intent.primary}"
- Context ID: ${n.context_id}
`,s=`
ACTIVE ENTITIES:
${(n.entities||[]).map(t=>`- ${t.name} (${t.category||"general"}): ${t.type}`).join(`
`)}
`,a=`
IMMUTABLE CONSTRAINTS:
${(n.constraints||[]).map(t=>`- [${t.rule}] ${t.value}`).join(`
`)}
`,o=`
VERIFICATION CONTRACT:
The user will verify your understanding using these invariants. FAIL to satisfy them creates a Reality Breach.
${n.verification.semantic_invariants.map(t=>`- ${t.prompt}`).join(`
`)}
`;return`${e}${i}${s}${a}${o}
[INSTRUCTION]
1. Ingest this Crystal.
2. Acknowledge with: "Context Synchronized. Ready to resume [Intent]."
3. Do NOT summarize the Crystal unless asked. Just BECOME the state.
`}}export{I as RehydrationEngine};
//# sourceMappingURL=rehydration-Bb0vzfBR.js.map
