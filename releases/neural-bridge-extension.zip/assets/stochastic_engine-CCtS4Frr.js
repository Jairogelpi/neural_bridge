const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/semantic_hashing-OfSksjfg.js","assets/llm-NNkhUcAb.js","assets/client-Dq_cuSAf.js","assets/hypervector-DkgCCw2d.js","assets/supabase-DYu6klIT.js"])))=>i.map(i=>d[i]);
import{_ as c}from"./client-Dq_cuSAf.js";import{Sentinel as m}from"./sentinel-DSpJSiZJ.js";import{supabase as l}from"./supabase-DYu6klIT.js";import{S as d}from"./llm-NNkhUcAb.js";class y{static async processChaos(t){const{SemanticHasher:o}=await c(async()=>{const{SemanticHasher:e}=await import("./semantic_hashing-OfSksjfg.js");return{SemanticHasher:e}},__vite__mapDeps([0,1,2,3,4])),{Hypervector:r}=await c(async()=>{const{Hypervector:e}=await import("./hypervector-DkgCCw2d.js");return{Hypervector:e}},[]);console.log("[StochasticPurifier] 🌀 Purifying information density...");const s=o.computeHolographicHash(t),a=r.fromString(s),n=a.getEntropy(),i=a.getFisherInformation();return await m.emit({type:"ENTROPY_PURIFICATION",severity:"info",message:`Mathematical purification complete. Bit-Entropy: ${n.toFixed(4)}, Potential: ${i.toFixed(4)}`,details:{input_length:t.length,entropy:n,potential:i}}),{semanticPotential:i,entropy:n}}static async performPredictiveCoding(t,o){var i;console.log(`[StochasticEngine] 🧠 Performing Predictive Coding for domain: ${o}...`);const{data:r}=await l.from("crystals").select("intent").eq("domain",o).eq("tier","sovereign").limit(3);if(!r||r.length===0)return{predictionError:1,residualContent:t};const a=`
        ACT AS A PREDICTIVE CODER (Active Inference Mode).
        Examine these existing Axioms:
        ${r.map(e=>e.intent.primary).join(`
- `)}
        
        INPUT: "${t.substring(0,1e3)}..."
        
        TASK:
        1. Predict what this input says based ONLY on the Axioms.
        2. Identify the "Residual" (What information in the input is NOT predictable by the Axioms?).
        
        Return JSON:
        {"prediction_error": 0.0-1.0, "residual_content": "..."}
        `,n=await d.resilientCallLLM(a,"anthropic/claude-3.5-sonnet","Predictive Coder");try{const e=JSON.parse(((i=n.content.match(/\{[\s\S]*\}/))==null?void 0:i[0])||"{}");return{predictionError:e.prediction_error||.5,residualContent:e.residual_content||t}}catch{return{predictionError:.8,residualContent:t}}}static async entropyBalancer(t){return t>.8?(console.warn(`[StochasticEngine] ⚠️ HIGH ENTROPY DETECTED (${t}). Triggering lattice stabilization...`),!1):!0}}export{y as StochasticEngine};
//# sourceMappingURL=stochastic_engine-CCtS4Frr.js.map
