import{S as g}from"./llm-BLnz7_CX.js";import{FalsificationEngine as m}from"./falsification-C5IuxlWv.js";import"./client-BYTJAMrK.js";class i{static async evolve(r,t){console.log(`[Hegel] 🧬 Starting Dialectical Evolution for: "${r.substring(0,40)}..."`);let e=r;const n=[],a=3;for(let s=1;s<=a;s++){console.log(`[Hegel] Round ${s}: Challenging Thesis...`);const o=await m.challenge(e,t);if(o.survived){console.log(`[Hegel] ✅ Thesis survived Round ${s}. Evolution complete.`);const y=await i.calculateFreeEnergy(e,t);return{final_thesis:e,iterations:s,history:n,is_resilient:!0,final_free_energy:y,final_accuracy:1}}console.log(`[Hegel] ⚠️ Thesis destroyed by: "${o.attack_vector}". Synthesizing new truth...`);const u=`
            THE NEUROMORPHIC DIALECTIC (Active Inference Mode)
            
            Current Thesis (Thesis): "${e}"
            Prediction Error (Attack): "${o.attack_vector}"
            Context: "${t.substring(0,500)}..."
            
            OBJECTIVE: Propose a synthesis that minimizes Variational Free Energy.
            This means:
            1. ACCURACY: It must fully resolve the prediction error (the attack).
            2. COMPLEXITY: It must be as simple as possible (Minimum Description Length).
            
            Return ONLY the new synthesized Thesis string. No markdown.
            `,c=(await g.resilientCallLLM(u,"anthropic/claude-3.5-sonnet","You are a Variational Free Energy Optimizer.")).content.trim(),h=await i.calculateFreeEnergy(e,t),f=await i.calculateFreeEnergy(c,t)-h;console.log(`[Hegel] 🧠 Free Energy Delta: ${f.toFixed(4)} (Objective: < 0)`),n.push({round:s,thesis:e,attack:o.attack_vector,synthesis:c}),console.log(`[Hegel] 🔄 Evolved Thesis: "${c.substring(0,50)}..."`),e=c}const l=await i.calculateFreeEnergy(e,t);return{final_thesis:e,iterations:a,history:n,is_resilient:!1,final_free_energy:l,final_accuracy:.5}}static async calculateFreeEnergy(r,t){const e=Math.log2(r.length+1)*.1,n=`
        SCORE THE ACCURACY of this thesis against the provided context.
        Thesis: "${r}"
        Context: "${t.substring(0,1e3)}..."
        
        Return a single number between 0 and 1, where 1 is "perfect explanation" 
        and 0 is "irrelevant or wrong".
        RETURN ONLY THE NUMBER.
        `,a=await g.resilientCallLLM(n,"google/gemini-2.0-flash-exp:free","Semantic Accuracy Scorer"),l=parseFloat(a.content.trim())||.1;return e-l}}export{i as DialecticalEngine};
//# sourceMappingURL=dialectical_engine-C605XEIH.js.map
