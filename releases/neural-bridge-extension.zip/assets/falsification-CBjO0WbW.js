import{S as r}from"./llm-NNkhUcAb.js";import"./client-Dq_cuSAf.js";class g{static async challenge(t,i){console.log(`[Falsifier] ⚔️ Launching Red Team attack on: "${t.substring(0,40)}..."`);const n=`
        You are the RED TEAM. Your goal is to DESTROY the following claim using logic, edge cases, and facts.
        
        CONTEXT: "${i.substring(0,500)}..."
        CLAIM: "${t}"
        
        Task: Find a logical flaw, a counter-example, or a context where this claim is FALSE.
        If the claim is strictly true and unbreakable, admit defeat.
        
        Return JSON:
        {
            "successful_attack": boolean,
            "counter_argument": "string (The attack)",
            "severity": "high" | "low" | "none"
        }
        `,c=await r.resilientCallLLM(n,"anthropic/claude-3.5-sonnet","You are a Ruthless Logician.");let e;try{e=JSON.parse(c.content)}catch{return{survived:!0,attack_vector:"Red Team failed to form coherent attack",defense:"Claim is trivial",resilience_score:.5}}if(e.successful_attack){console.log(`[Falsifier] ⚠️ Attack detected: "${e.counter_argument}"`);const s=`
            You are the SUPREME COURT.
            
            Original Claim: "${t}"
            Red Team Attack: "${e.counter_argument}"
            
            Is this attack Valid? Does it actually disprove the claim?
            Or is it nitpicking / irrelevant context?
            
            Return JSON:
            {
                "attack_valid": boolean,
                "reason": "explanation",
                "final_verdict_on_claim": "TRUE" | "FALSE" | "NUANCED"
            }
            `,o=await r.resilientCallLLM(s,"google/gemini-pro-1.5","You are an Impartial Judge.");try{const a=JSON.parse(o.content);return a.attack_valid&&a.final_verdict_on_claim!=="TRUE"?{survived:!1,attack_vector:e.counter_argument,defense:"None possible. Argument collapsed.",resilience_score:0}:{survived:!0,attack_vector:e.counter_argument,defense:`Withstood attack. Judge ruled: ${a.reason}`,resilience_score:.95}}catch{return{survived:!1,attack_vector:"Judicial Error",defense:"Mistrial",resilience_score:0}}}return{survived:!0,attack_vector:"None found",defense:"Claim is self-evidently robust",resilience_score:1}}}export{g as FalsificationEngine};
//# sourceMappingURL=falsification-CBjO0WbW.js.map
