var l=Object.defineProperty;var n=(a,e,t)=>e in a?l(a,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):a[e]=t;var r=(a,e,t)=>n(a,typeof e!="symbol"?e+"":e,t);import{S as p}from"./llm-BAaIsMkJ.js";import"./attestation-H4FSZ5sE.js";class h{static async findBestJudges(e,t=3){var s;if(this.capabilityCache.has(e))return this.capabilityCache.get(e);console.log(`[ExpertRegistry] 🔍 Discovering elite models for domain: [${e}]...`);const c=`
        ACT AS AN AI CAPABILITY ARCHITECT.
        Identify the top 3 LLMs that have the HIGHEST ZERO-SHOT REASONING accuracy for the domain: "${e}".
        Consider models like: claude-3.5-sonnet, gpt-4o, o1, gemini-1.5-pro, deepseek-v3, nemotron.
        
        Return ONLY a JSON array of OpenRouter model strings.
        `;try{const o=await p.resilientCallLLM(c,"google/gemini-2.0-flash-exp:free","Capability Auditor"),i=JSON.parse(((s=o.content.match(/\[[\s\S]*\]/))==null?void 0:s[0])||"[]");if(i.length>0)return this.capabilityCache.set(e,i.slice(0,t)),i.slice(0,t)}catch{console.warn("[ExpertRegistry] Meta-discovery failed. Falling back to robust defaults.")}return["anthropic/claude-3.5-sonnet","openai/gpt-4o","google/gemini-pro-1.5"]}static flush(){this.capabilityCache.clear()}}r(h,"capabilityCache",new Map);export{h as ExpertRegistry};
//# sourceMappingURL=expert_registry-C7C7SdH8.js.map
