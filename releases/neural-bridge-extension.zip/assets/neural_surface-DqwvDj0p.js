const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/truth_vault-Bnuaiivt.js","assets/client-BYTJAMrK.js","assets/supabase-DYu6klIT.js","assets/llm-BLnz7_CX.js","assets/semantic_hashing-M8nJuKYU.js","assets/hypervector-DkgCCw2d.js","assets/evolution_engine-DOTAP7vI.js","assets/synaptic_binder-CYYjHj9z.js","assets/talamic_index-ChRKUsnr.js"])))=>i.map(i=>d[i]);
var N=Object.defineProperty;var m=(a,t,e)=>t in a?N(a,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):a[t]=e;var _=(a,t,e)=>m(a,typeof t!="symbol"?t+"":t,e);import{C as g,_ as c}from"./client-BYTJAMrK.js";import{S as p}from"./llm-BLnz7_CX.js";import{T as v}from"./talamic_index-ChRKUsnr.js";import"./hypervector-DkgCCw2d.js";import"./semantic_hashing-M8nJuKYU.js";import"./supabase-DYu6klIT.js";class O{static async initiateSession(t){const e=`SESSION_${Date.now()}`;return this.activeSessions.set(e,{id:e,active_crystal_ids:t,history:[],created_at:new Date().toISOString()}),console.log(`[NeuralSurface] 💬 Session ${e} initiated with ${t.length} crystals.`),e}static async groundedChat(t,e){const s=this.activeSessions.get(t);if(!s)throw new Error("Session not found");console.log(`[NeuralSurface] 💬 Processing grounded query: "${e.substring(0,50)}..."`);const n=`
        ACT AS A SOVEREIGN KNOWLEDGE ORACLE.
        Your responses MUST be strictly grounded in the FOLLOWING VERIFIED KNOWLEDGE:
        
        KNOWLEDGE BASE:
        ${(await v.search(e,5)).filter(i=>s.active_crystal_ids.some(d=>i.node.metadata.source_id.includes(d))).map(i=>i.node.metadata.preview).join(`
---
`)||"No direct crystals found for this specific query. Stick to general neuromorphic principles."}
        
        CONSTRAINTS:
        - If the information is not in the knowledge base, state it clearly.
        - Do not speculate beyond the provided axioms.
        - Maintain absolute factual fidelity.
        `,o=await p.resilientCallLLM(e,g.model_stack.flash,n);return s.history.push({role:"user",content:e}),s.history.push({role:"assistant",content:o.content}),o.content}static getSession(t){return this.activeSessions.get(t)}static async refineKnowledge(t,e){var l;const s=this.activeSessions.get(t);if(!s||s.active_crystal_ids.length===0)return;console.log(`[NeuralSurface] 🧬 Initiating Recursive Refinement for ${s.active_crystal_ids.length} crystals...`);const{TruthVault:f}=await c(async()=>{const{TruthVault:n}=await import("./truth_vault-Bnuaiivt.js");return{TruthVault:n}},__vite__mapDeps([0,1,2,3,4,5])),{EvolutionEngine:E}=await c(async()=>{const{EvolutionEngine:n}=await import("./evolution_engine-DOTAP7vI.js");return{EvolutionEngine:n}},__vite__mapDeps([6,3,1]));for(const n of s.active_crystal_ids){const{data:o}=await(await c(async()=>{const{supabase:r}=await import("./supabase-DYu6klIT.js");return{supabase:r}},[])).supabase.from("crystals").select("*").eq("context_id",n).single();if(!o)continue;const i=o,d=`
            NEURAL REFINEMENT PROTOCOL
            ---
            You are a Knowledge Architect. Analyze the following interaction and refine the CRYSTAL to incorporate new nuances, corrections, or deeper understanding discovered during the conversation.
            
            CRYSTAL (Current State):
            ${JSON.stringify(i.constraints)}
            
            INTERACTION OUTCOME:
            "${e}"
            
            TASK: Mutate the crystal's constraints to reflect this growth. 
            Do not lose existing truth, but sharpen its accuracy.
            
            Return ONLY a valid JSON array of updated constraints.
            `;try{const r=await p.resilientCallLLM(d,g.model_stack.flash,"Knowledge Architect"),u=JSON.parse(((l=r.content.match(/\[[\s\S]*\]/))==null?void 0:l[0])||"[]");if(u.length>0){const{SynapticBinder:h}=await c(async()=>{const{SynapticBinder:w}=await import("./synaptic_binder-CYYjHj9z.js");return{SynapticBinder:w}},__vite__mapDeps([7,8,1,5,4,3,2]));console.log(`[NeuralSurface] 🧬 Spawning fractal child for Crystal ${i.context_id.substring(0,8)}...`);const S=await h.fractalize(i,JSON.stringify(u),"REFINEMENT");S.constraints=u;const y=await h.bind(S);await f.saveTruth(y),console.log(`[NeuralSurface] ✨ Fractal Evolution Complete. New Child: ${y.context_id}`)}}catch(r){console.warn(`[NeuralSurface] 🧬 Refinement failed for crystal ${n}:`,r)}}}}_(O,"activeSessions",new Map);export{O as NeuralSurface};
//# sourceMappingURL=neural_surface-DqwvDj0p.js.map
