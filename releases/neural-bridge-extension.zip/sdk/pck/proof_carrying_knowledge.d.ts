/**
 * PROOF-CARRYING KNOWLEDGE (PCK)
 *
 * Revolutionary feature: Knowledge that carries its own verifiable proof.
 * No external API calls needed for verification.
 *
 * Core Principle: The PROOF is embedded in the KNOWLEDGE itself.
 * Anyone can verify independently by re-computing the proof chain.
 */
export type ProofType = 'axiom' | 'derivation' | 'extraction' | 'composition' | 'negation' | 'witness';
export type DerivationRule = 'direct_quote' | 'paraphrase' | 'numeric_bound' | 'temporal_order' | 'logical_and' | 'logical_or' | 'modus_ponens' | 'transitivity';
export interface ProofNode {
    id: string;
    type: ProofType;
    claim: string;
    source?: {
        document: string;
        section?: string;
        page?: number;
        url?: string;
        retrieved_at: string;
        content_hash: string;
    };
    derivation?: {
        rule: DerivationRule;
        premises: string[];
        justification: string;
    };
    extraction?: {
        pattern: string;
        matched_text: string;
        position: {
            start: number;
            end: number;
        };
    };
    proof_hash: string;
    timestamp: string;
    verifiable: boolean;
    verification_cost: 0;
}
export interface ProofCarryingKnowledge {
    pck_version: '1.0';
    pck_id: string;
    created_at: string;
    claim: {
        statement: string;
        domain: string;
        confidence: number;
    };
    proof_tree: {
        root: string;
        nodes: Map<string, ProofNode>;
    };
    merkle_root: string;
    signature: {
        algorithm: 'SHA256-HMAC';
        value: string;
        public_key?: string;
    };
}
export declare class PCKBuilder {
    private nodes;
    private claim;
    private domain;
    /**
     * Add an axiom - a base fact from an authoritative source
     */
    addAxiom(params: {
        claim: string;
        source_document: string;
        source_content: string;
        section?: string;
        url?: string;
    }): string;
    /**
     * Add an extraction - a specific value extracted from source text
     */
    addExtraction(params: {
        claim: string;
        source_text: string;
        pattern: RegExp;
        axiom_id: string;
    }): string | null;
    /**
     * Add a derivation - knowledge derived from other proofs
     */
    addDerivation(params: {
        claim: string;
        rule: DerivationRule;
        premises: string[];
        justification: string;
    }): string;
    /**
     * Set the main claim this PCK proves
     */
    setClaim(statement: string, domain: string): this;
    /**
     * Build the final PCK
     */
    build(rootId: string): ProofCarryingKnowledge;
    private generateId;
    private hash;
    private hashNode;
    private computeMerkleRoot;
    private calculateConfidence;
    private getRuleStrength;
}
export interface VerificationResult {
    valid: boolean;
    confidence: number;
    checks_performed: number;
    failed_checks: string[];
    verification_time_ms: number;
    external_calls_made: 0;
}
export declare class PCKVerifier {
    /**
     * Verify a PCK completely offline - no external calls
     */
    static verify(pck: ProofCarryingKnowledge): VerificationResult;
    /**
     * Verify a specific claim against a PCK
     */
    static verifyClaim(pck: ProofCarryingKnowledge, claim: string): {
        supported: boolean;
        proof_path: string[];
        confidence: number;
    };
    private static hash;
    private static recomputeMerkleRoot;
    private static recomputeNodeHash;
    private static isValidDerivation;
    private static claimsMatch;
    private static getNodeConfidence;
    private static getProofPath;
}
