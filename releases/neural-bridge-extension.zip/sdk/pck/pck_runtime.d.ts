/**
 * PCK RUNTIME - Production Integration
 *
 * Connects Proof-Carrying Knowledge to the Neural Bridge system.
 * Enables zero-cost verification in production.
 */
import type { ProofCarryingKnowledge, VerificationResult } from './proof_carrying_knowledge';
export interface CompileOptions {
    domain: string;
    extract_numbers?: boolean;
    extract_entities?: boolean;
    extract_temporals?: boolean;
}
export interface VerifyAnswerResult {
    valid: boolean;
    confidence: number;
    supported_claims: string[];
    unsupported_claims: string[];
    contradictions: string[];
    proof_verification: VerificationResult;
    llm_calls_made: 0;
    verification_time_ms: number;
}
export declare class PCKRuntime {
    /**
     * Compile a source document into Proof-Carrying Knowledge
     * This is done ONCE when you have authoritative source material
     */
    static compile(source: string, options: CompileOptions): Promise<ProofCarryingKnowledge>;
    /**
     * Verify an LLM answer against a PCK - ZERO API CALLS
     */
    static verifyAnswer(pck: ProofCarryingKnowledge, answer: string): Promise<VerifyAnswerResult>;
    private static extractClaims;
    private static checkContradiction;
    private static escapeRegex;
}
