/**
 * NEURAL BRIDGE PROTOCOL (NBP) - Core Types
 *
 * This file defines the "Crystal" format: the universal container for verifiable knowledge.
 * In the "Trojan Horse" strategy, this is the format we want everyone to adopt.
 */
export interface CrystalMetadata {
    scp_version: '1.0';
    context_id: string;
    created_at: string;
    name?: string;
    description?: string;
}
export interface CrystalSource {
    platform: string;
    url: string;
    timestamp: string;
    model?: string;
    creator?: string;
}
export declare enum ConstraintRule {
    MUST = "MUST",
    NEVER = "NEVER",
    IF_THEN = "IF_THEN",
    RANGE = "RANGE",
    ENUM = "ENUM",
    REGEX = "REGEX"
}
export interface CrystalConstraint {
    id: string;
    rule: ConstraintRule;
    value: string;
    rationale: string;
    severity?: 'critical' | 'high' | 'medium' | 'low';
}
export interface Crystal {
    nbp_version: '1.0';
    id: string;
    created_at: string;
    name: string;
    description?: string;
    domain?: string;
    constraints: CrystalConstraint[];
    source?: CrystalSource;
    verification?: {
        hash: string;
        signature?: string;
        integrity_proof?: string;
    };
}
