/**
 * NBP Schema Builder
 *
 * A lightweight, fluent API to define Crystals.
 * Usage:
 *   const MyPolicy = DefineCrystal.named('ISO 27001')
 *     .must('encrypt_data_at_rest')
 *     .never('store_passwords_plaintext')
 *     .build();
 */
import { Crystal } from './types';
export declare class CrystalBuilder {
    private crystal;
    private constraints;
    constructor(name: string);
    /**
     * Define a mandatory requirement
     */
    must(value: string, rationale?: string): this;
    /**
     * Define a prohibition
     */
    never(value: string, rationale?: string): this;
    /**
     * Define a conditional requirement
     */
    if(condition: string, thenRequirement: string): this;
    domain(domain: string): this;
    description(desc: string): this;
    /**
     * Finalize and build the Crystal structure
     */
    build(): Crystal;
    private addConstraint;
}
export declare const DefineCrystal: {
    named: (name: string) => CrystalBuilder;
};
