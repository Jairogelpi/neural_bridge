var a = Object.defineProperty;
var c = (s, e, t) => e in s ? a(s, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : s[e] = t;
var r = (s, e, t) => c(s, typeof e != "symbol" ? e + "" : e, t);
class i {
  /**
   * SAVE KEYS: Stores a set of API keys.
   */
  static async saveKeys(e) {
    console.log("[KeyManager] 💾 Securing sovereign keys..."), typeof chrome < "u" && chrome.storage ? await chrome.storage.local.set({ [this.STORAGE_KEY]: e }) : localStorage.setItem(this.STORAGE_KEY, JSON.stringify(e));
  }
  /**
   * GET KEY: Retrieves a specific key if it exists.
   */
  static async getKey(e) {
    let t = {};
    if (typeof chrome < "u" && chrome.storage)
      t = (await chrome.storage.local.get(this.STORAGE_KEY))[this.STORAGE_KEY] || {};
    else {
      const o = localStorage.getItem(this.STORAGE_KEY);
      o && (t = JSON.parse(o));
    }
    return t[e] || null;
  }
  /**
   * CLEAR KEYS
   */
  static async clearKeys() {
    typeof chrome < "u" && chrome.storage ? await chrome.storage.local.remove(this.STORAGE_KEY) : localStorage.removeItem(this.STORAGE_KEY);
  }
  /**
   * GET ALL KEYS: Returns the current set of keys.
   */
  static async getAllKeys() {
    if (typeof chrome < "u" && chrome.storage)
      return (await chrome.storage.local.get(this.STORAGE_KEY))[this.STORAGE_KEY] || {};
    {
      const e = localStorage.getItem(this.STORAGE_KEY);
      return e ? JSON.parse(e) : {};
    }
  }
}
r(i, "STORAGE_KEY", "nb_sovereign_keys");
export {
  i as KeyManager
};
//# sourceMappingURL=key_manager-ChsPY2N_.js.map
