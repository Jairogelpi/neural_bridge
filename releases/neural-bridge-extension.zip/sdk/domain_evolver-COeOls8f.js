var m = Object.defineProperty;
var l = (o, e, n) => e in o ? m(o, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : o[e] = n;
var c = (o, e, n) => l(o, typeof e != "symbol" ? e + "" : e, n);
import { a as d, S as v } from "./index-DVUTQuLV.js";
class f {
  /**
   * Detects or evolves a domain from unstructured text.
   */
  static async evolveDomain(e) {
    var r;
    console.log("[DomainEvolver] 🧠 Analyzing context for evolutionary potential...");
    const n = `
        ACT AS AN ONTOLOGICAL ARCHITECT.
        The following text does not fit any standard knowledge domain.
        
        TEXT: "${e.substring(0, 500)}"
        
        TASK:
        1. Synthesize a UNIQUE domain name for this knowledge.
        2. Extract 3 fundamental AXIOMS (rules) that govern this specific "random" reality.
        3. Assign an Evolution Confidence score (0.0 to 1.0).
        
        Return JSON:
        {
            "domain": "...",
            "axioms": ["...", "...", "..."],
            "confidence": 0.0
        }
        `;
    let s;
    try {
      s = await d.resilientCallLLM(n, "nvidia/nemotron-3-nano-30b-a3b:free", "You are a master of spontaneous ontology.");
    } catch (a) {
      if ((a && typeof a == "object" && "message" in a && typeof a.message == "string" ? a.message : "") === "SOVEREIGN_REQUIRED")
        return {
          domain: "sovereign_evolution",
          axioms: ["Logic is the only anchor", "Structure survives chaos"],
          confidence: 1,
          discovered_at: (/* @__PURE__ */ new Date()).toISOString()
        };
      throw a;
    }
    let i;
    try {
      i = JSON.parse(((r = s.content.match(/\{[\s\S]*\}/)) == null ? void 0 : r[0]) || "{}");
    } catch {
      i = { domain: "stochastic_anomaly", axioms: [], confidence: 0.1 };
    }
    const t = {
      domain: i.domain || "unknown_evolution",
      axioms: i.axioms || [],
      confidence: Number(i.confidence) || 0,
      discovered_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    return t.confidence > 0.7 && (this.evolvedCache.set(t.domain, t), await v.emit({
      type: "CHAOS_EVOLUTION",
      severity: "info",
      message: `New Domain Evolved: ${t.domain.toUpperCase()}`,
      details: t
    })), t;
  }
}
c(f, "evolvedCache", /* @__PURE__ */ new Map());
export {
  f as DomainEvolver
};
//# sourceMappingURL=domain_evolver-COeOls8f.js.map
