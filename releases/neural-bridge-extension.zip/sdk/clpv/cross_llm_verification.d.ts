/**
 * CROSS-LLM PORTABLE VERIFICATION (CLPV)
 *
 * Revolutionary feature: Verification receipts that work with ANY LLM.
 *
 * Key capabilities:
 * 1. Model-independent receipts (GPT-4, Claude, Gemini, Llama, etc.)
 * 2. Verification is INDEPENDENT of the model that generated the response
 * 3. Receipts are portable across different AI systems
 * 4. Universal verification protocol
 *
 * Why this matters:
 * - Enterprises use multiple LLMs
 * - Need consistent verification across all models
 * - Receipts should be auditable regardless of source
 */
export type LLMProvider = 'openai' | 'anthropic' | 'google' | 'meta' | 'mistral' | 'cohere' | 'unknown';
export interface LLMIdentifier {
    provider: LLMProvider;
    model: string;
    version?: string;
    detected_from?: string;
}
export interface PortableReceipt {
    clpv_version: '1.0';
    receipt_id: string;
    created_at: string;
    source_llm: LLMIdentifier;
    content: {
        question_hash: string;
        answer_hash: string;
        answer_length: number;
        language: string;
    };
    verification: {
        is_valid: boolean;
        confidence: number;
        method: 'pck' | 'smt' | 'zkv' | 'hybrid';
        features: {
            numbers: Array<{
                value: number;
                unit: string;
            }>;
            entities: string[];
            claims: string[];
            temporal: string[];
        };
        issues: Array<{
            type: 'contradiction' | 'hallucination' | 'unsupported' | 'inconsistency';
            description: string;
            severity: 'low' | 'medium' | 'high' | 'critical';
        }>;
    };
    proof: {
        semantic_hash: string;
        merkle_root: string;
        signature: string;
        verification_key: string;
    };
    portability: {
        cross_model_verified: boolean;
        verification_models: string[];
        protocol_version: string;
        backwards_compatible: boolean;
    };
}
export interface CrossVerificationResult {
    verified: boolean;
    confidence: number;
    cross_model: {
        original_model: string;
        verifying_model: string;
        agreement_score: number;
        discrepancies: string[];
    };
    portability_proof: {
        receipt_valid: boolean;
        signature_valid: boolean;
        features_match: boolean;
        hash_match: boolean;
    };
    verification_time_ms: number;
}
export interface SemanticFeatures {
    numbers: Array<{
        value: number;
        unit: string;
    }>;
    entities: string[];
    claims: string[];
    temporal: string[];
}
export declare class LLMDetector {
    /**
     * Detect which LLM generated a response
     * Works by analyzing response patterns and metadata
     */
    static detect(response: string, metadata?: Record<string, unknown>): LLMIdentifier;
    private static parseModelString;
    private static analyzePatterns;
}
export declare class PortableReceiptGenerator {
    private secretKey;
    constructor(secretKey?: string);
    /**
     * Generate a portable receipt from any LLM response
     * The receipt is model-independent and can be verified by ANY system
     */
    generate(params: {
        question: string;
        answer: string;
        source_llm?: LLMIdentifier;
        verification_result?: {
            is_valid: boolean;
            confidence: number;
            issues?: Array<{
                type: string;
                description: string;
                severity: string;
            }>;
        };
    }): PortableReceipt;
    /**
     * Internal helper to extract features (made public for the cross-verifier cast)
     */
    extractFeatures(text: string): SemanticFeatures;
    private createSemanticHash;
    private createMerkleRoot;
    private detectLanguage;
    private hash;
    private sign;
}
export declare class CrossLLMVerifier {
    /**
     * Verify a portable receipt - works with ANY LLM source
     * The verification is INDEPENDENT of the model that generated the response
     */
    static verify(receipt: PortableReceipt, answer?: string): CrossVerificationResult;
    /**
     * Cross-verify: Take a receipt from one LLM and verify it works with another
     */
    static crossVerify(params: {
        receipt: PortableReceipt;
        new_answer: string;
        new_llm: LLMIdentifier;
    }): CrossVerificationResult;
    private static verifyStructure;
    private static verifySignature;
    private static verifyFeatures;
    private static calculateAgreement;
}
export declare class CLPVRuntime {
    private static generator;
    /**
     * Create a portable receipt from any LLM response
     */
    static createReceipt(params: {
        question: string;
        answer: string;
        llm?: string | LLMIdentifier;
    }): PortableReceipt;
    /**
     * Verify a portable receipt
     */
    static verifyReceipt(receipt: PortableReceipt, answer?: string): CrossVerificationResult;
    /**
     * Cross-verify: Verify a receipt against a different LLM's response
     */
    static crossVerify(params: {
        original_receipt: PortableReceipt;
        new_answer: string;
        new_llm: string;
    }): CrossVerificationResult;
    /**
     * Get supported LLM providers
     */
    static getSupportedProviders(): LLMProvider[];
    /**
     * Check if a receipt is portable to a specific LLM
     */
    static isPortableTo(receipt: PortableReceipt, targetLLM: string): boolean;
}
