export interface LLMCall {
    prompt: string;
    maxTokens: number;
    temperature: number;
}
export interface LLMResponse {
    text: string;
    usedTokens?: number;
}
export interface LLMClient {
    name: string;
    call(req: LLMCall): Promise<LLMResponse>;
}
