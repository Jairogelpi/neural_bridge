import type { Transcript } from "../transcript/transcript";
import type { LLMClient } from "./llm/llm_client";
export interface Budget {
    maxCalls: number;
    maxTokensPerCall: number;
}
export interface CompileResult {
    draft: any;
    notes: string[];
    usedCalls: number;
}
export declare function compileCrystalRLM(params: {
    transcript: Transcript;
    llm: LLMClient;
    budget: Budget;
    cacheGet: (key: string) => any | null;
    cacheSet: (key: string, val: any) => void;
}): Promise<CompileResult>;
