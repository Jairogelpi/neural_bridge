import type { Transcript } from "../transcript/transcript";
import type { ContextCrystal } from "../core/scp_types";
export declare function finalizeCrystal(params: {
    draft: any;
    transcript: Transcript;
}): Promise<ContextCrystal>;
