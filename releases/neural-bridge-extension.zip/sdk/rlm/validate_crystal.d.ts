export type CrystalDraft = any;
export interface DraftIssues {
    missing: string[];
    warnings: string[];
    quality: number;
    tooLarge: boolean;
}
export declare function validateDraft(d: CrystalDraft): DraftIssues;
