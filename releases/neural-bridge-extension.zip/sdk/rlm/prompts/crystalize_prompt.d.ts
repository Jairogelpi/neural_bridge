export declare function buildCrystalizePrompt(params: {
    transcriptSlice: string;
    mode: "create" | "repair" | "minimize";
    issues?: {
        missing: string[];
        warnings: string[];
    };
    currentCrystalJson?: string;
}): string;
