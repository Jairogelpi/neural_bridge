import type { SessionBootstrapResponse, CompileRequest, CompileResponse, TelemetryRequest } from "./api_types";
export declare class SaaSClient {
    private baseUrl;
    private sessionToken;
    private config;
    constructor(baseUrl?: string);
    bootstrap(): Promise<SessionBootstrapResponse>;
    compile(params: CompileRequest): Promise<CompileResponse>;
    sendTelemetry(params: TelemetryRequest & {
        author_id?: string;
        reputation_impact?: number;
    }): Promise<void>;
    registerAuthor(params: {
        name: string;
        handle: string;
        public_key: string;
    }): Promise<{
        author_id: string;
        status: string;
    }>;
    getAuthor(authorId: string): Promise<any>;
    getHostProfile(platform: string): Promise<any>;
    private getInstallId;
    private generateSecureToken;
}
