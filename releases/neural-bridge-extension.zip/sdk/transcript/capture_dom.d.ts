import type { Transcript } from "./transcript";
/**
 * Transcript-aware capture.
 * Identifies messages/turns.
 */
export declare function captureTranscriptFromDOM(params: {
    platform: "chatgpt" | "gemini" | "claude" | "other";
    capture_method?: string;
}): Transcript;
