var vs = Object.defineProperty;
var ws = (r, e, t) => e in r ? vs(r, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : r[e] = t;
var V = (r, e, t) => ws(r, typeof e != "symbol" ? e + "" : e, t);
var Le = /* @__PURE__ */ ((r) => (r.ACTIVE = "active", r.DEPRECATED = "deprecated", r.SUPERSEDED = "superseded", r))(Le || {}), me = /* @__PURE__ */ ((r) => (r.MUST = "MUST", r.NEVER = "NEVER", r.IF_THEN = "IF_THEN", r.RANGE = "RANGE", r.ENUM = "ENUM", r.REGEX = "REGEX", r.CUSTOM = "CUSTOM", r))(me || {});
const bs = {
  $schema: "http://json-schema.org/draft-07/schema#",
  title: "Crystal Format v0.1",
  type: "object",
  required: [
    "scp_version",
    "context_id",
    "created_at",
    "source",
    "intent",
    "verification"
  ],
  properties: {
    scp_version: {
      type: "string",
      pattern: "^\\d+\\.\\d+$",
      description: "SCP version (e.g., '1.0')"
    },
    context_id: {
      type: "string",
      minLength: 1,
      description: "Unique identifier for this Crystal"
    },
    created_at: {
      type: "string",
      format: "date-time",
      description: "ISO 8601 timestamp"
    },
    name: {
      type: "string",
      description: "Human-readable name"
    },
    description: {
      type: "string",
      description: "Crystal description"
    },
    domain: {
      type: "string",
      description: "Domain classification"
    },
    source: {
      type: "object",
      required: ["platform", "url", "timestamp"],
      properties: {
        platform: { type: "string" },
        url: { type: "string" },
        timestamp: { type: "string", format: "date-time" },
        model: { type: "string" },
        creator: { type: "string" }
      }
    },
    intent: {
      type: "object",
      required: ["primary", "status"],
      properties: {
        primary: { type: "string" },
        status: {
          type: "string",
          enum: ["active", "deprecated", "superseded"]
        },
        secondary: {
          type: "array",
          items: { type: "string" }
        },
        limitations: {
          type: "array",
          items: { type: "string" }
        }
      }
    },
    constraints: {
      type: "array",
      items: {
        type: "object",
        required: ["id", "rule", "value", "rationale"],
        properties: {
          id: { type: "string" },
          rule: {
            type: "string",
            enum: ["MUST", "NEVER", "IF_THEN", "RANGE", "ENUM", "REGEX", "CUSTOM"]
          },
          value: { type: "string" },
          rationale: { type: "string" },
          severity: {
            type: "string",
            enum: ["critical", "high", "medium", "low"]
          },
          reference: { type: "string" }
        }
      }
    },
    entities: {
      type: "array",
      items: {
        type: "object",
        required: ["name", "type"],
        properties: {
          name: { type: "string" },
          type: { type: "string" },
          category: { type: "string" },
          attributes: { type: "object" },
          relationships: {
            type: "array",
            items: {
              type: "object",
              properties: {
                type: { type: "string" },
                target: { type: "string" }
              }
            }
          }
        }
      }
    },
    evidence: {
      type: "array",
      items: {
        type: "object",
        required: ["type", "content"],
        properties: {
          type: {
            type: "string",
            enum: ["quote", "fact", "source", "calculation", "reference"]
          },
          content: { type: "string" },
          source: { type: "string" },
          timestamp: { type: "string" },
          confidence: { type: "number", minimum: 0, maximum: 1 }
        }
      }
    },
    verification: {
      type: "object",
      required: ["canonical_hash", "semantic_invariants", "policy"],
      properties: {
        canonical_hash: { type: "string" },
        semantic_invariants: {
          type: "array",
          items: {
            type: "object",
            required: ["id", "kind", "prompt", "expected", "weight", "strict", "rationale"]
          }
        },
        policy: {
          type: "object",
          required: ["min_checks", "accept_threshold", "max_retries", "strategy"]
        }
      }
    },
    dependencies: {
      type: "array",
      items: {
        type: "object",
        required: ["crystal_id", "version", "type", "scope"],
        properties: {
          crystal_id: { type: "string" },
          version: { type: "string" },
          type: {
            type: "string",
            enum: ["requires", "extends", "conflicts_with"]
          },
          scope: {
            type: "string",
            enum: ["domain", "client", "project", "implementation"]
          },
          reason: { type: "string" }
        }
      }
    },
    version: { type: "string", pattern: "^\\d+\\.\\d+\\.\\d+$" },
    tier: {
      type: "string",
      enum: ["community", "verified", "certified", "trusted", "sovereign"]
    },
    author: {
      type: "object",
      required: ["id", "name", "reputation"],
      properties: {
        id: { type: "string" },
        name: { type: "string" },
        reputation: { type: "number", minimum: 0, maximum: 1 },
        verified_credentials: { type: "array", items: { type: "string" } }
      }
    },
    supersedes: { type: "string" },
    deprecated: { type: "boolean" },
    tags: {
      type: "array",
      items: { type: "string" }
    },
    extensions: { type: "object" },
    metadata: { type: "object" }
  },
  additionalProperties: !1
};
function Ss(r) {
  const e = [];
  return r.scp_version || e.push("Missing scp_version"), r.context_id || e.push("Missing context_id"), r.created_at || e.push("Missing created_at"), r.source || e.push("Missing source"), r.intent || e.push("Missing intent"), r.verification || e.push("Missing verification"), r.version || e.push("Missing version"), r.tier || e.push("Missing tier"), r.author || e.push("Missing author"), r.source && (r.source.platform || e.push("source.platform is required"), r.source.url || e.push("source.url is required"), r.source.timestamp || e.push("source.timestamp is required")), r.intent && (r.intent.primary || e.push("intent.primary is required"), r.intent.status || e.push("intent.status is required"), r.intent.status && !["active", "deprecated", "superseded"].includes(r.intent.status) && e.push("intent.status must be active, deprecated, or superseded")), r.verification && (r.verification.canonical_hash || e.push("verification.canonical_hash is required"), Array.isArray(r.verification.semantic_invariants) || e.push("verification.semantic_invariants must be an array"), r.verification.policy || e.push("verification.policy is required")), {
    valid: e.length === 0,
    errors: e
  };
}
function wt(r) {
  return r === null || typeof r != "object" ? JSON.stringify(r) : Array.isArray(r) ? "[" + r.map((s) => wt(s)).join(",") + "]" : "{" + Object.entries(r).filter(([s, n]) => n !== void 0).sort(([s], [n]) => s.localeCompare(n)).map(([s, n]) => `"${s}":${wt(n)}`).join(",") + "}";
}
const Xt = {
  version: "0.1",
  schema: bs,
  validate: Ss,
  canonicalStringify: wt
};
async function Nr(r) {
  const { crystal: e, keyPair: t, capturer_id: s } = r, n = await Lr(e), i = r.keyPair ?? await Dr(), a = await Mr(n, i.privateKey), o = await Pt(i.publicKey);
  return {
    signature: a,
    public_key: o,
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    capturer_id: s,
    payload_hash: n
  };
}
async function jr(r) {
  const { crystal: e, signature: t } = r;
  if (await Lr(e) !== t.payload_hash)
    return { valid: !1, reason: "payload_hash_mismatch" };
  try {
    const n = await Nt(t.public_key);
    return await qr(t.signature, t.payload_hash, n) ? { valid: !0 } : { valid: !1, reason: "invalid_signature" };
  } catch (n) {
    return { valid: !1, reason: `verification_error: ${n}` };
  }
}
function Ur(r) {
  return {
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    action: r.action,
    actor: r.actor,
    details: r.details
  };
}
async function Qe(r) {
  const t = new TextEncoder().encode(r), s = await crypto.subtle.digest("SHA-256", t);
  return "0x" + Array.from(new Uint8Array(s)).map((i) => i.toString(16).padStart(2, "0")).join("");
}
async function Lr(r) {
  var n;
  const { Hypervector: e } = await Promise.resolve().then(() => Mt), t = [];
  for (const i of ((n = r.verification) == null ? void 0 : n.semantic_invariants) || [])
    t.push(e.fromString(await Qe(i.prompt + JSON.stringify(i.expected))));
  if (t.length === 0) return await Qe(JSON.stringify(r));
  const s = e.bundle(t);
  return await Qe(s.toString());
}
async function Dr() {
  return await crypto.subtle.generateKey(
    {
      name: "ECDSA",
      namedCurve: "P-256"
    },
    !0,
    ["sign", "verify"]
  );
}
async function Mr(r, e) {
  const s = new TextEncoder().encode(r), n = await crypto.subtle.sign(
    { name: "ECDSA", hash: "SHA-256" },
    e,
    s
  );
  return "0x" + Array.from(new Uint8Array(n)).map((o) => o.toString(16).padStart(2, "0")).join("");
}
async function Br(r, e) {
  return Mr(r, e);
}
async function qr(r, e, t) {
  const n = new TextEncoder().encode(e), i = Hr(r);
  return await crypto.subtle.verify(
    { name: "ECDSA", hash: "SHA-256" },
    t,
    i,
    n
  );
}
async function Fr(r, e, t) {
  return qr(e, r, t);
}
async function Pt(r) {
  const e = await crypto.subtle.exportKey("raw", r);
  return "0x" + Array.from(new Uint8Array(e)).map((s) => s.toString(16).padStart(2, "0")).join("");
}
async function Nt(r) {
  const e = Hr(r);
  return await crypto.subtle.importKey(
    "raw",
    e,
    { name: "ECDSA", namedCurve: "P-256" },
    !0,
    ["verify"]
  );
}
function Hr(r) {
  const e = r.replace("0x", ""), t = new Uint8Array(e.length / 2);
  for (let s = 0; s < e.length; s += 2)
    t[s / 2] = parseInt(e.substr(s, 2), 16);
  return t;
}
const Z = {
  signCrystal: Nr,
  verifyCrystalSignature: jr,
  createAuditEntry: Ur,
  generateKeyPair: Dr,
  realSHA256: Qe,
  signData: Br,
  verifySignature: Fr,
  exportPublicKey: Pt,
  importPublicKey: Nt
}, Ea = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Attestation: Z,
  createAuditEntry: Ur,
  exportPublicKey: Pt,
  importPublicKey: Nt,
  signCrystal: Nr,
  signData: Br,
  verifyCrystalSignature: jr,
  verifySignature: Fr
}, Symbol.toStringTag, { value: "Module" }));
class Es {
  /**
   * Generate a cryptographically signed receipt of a decision.
   * This is the "Invoice of Truth".
   */
  static async generateDecisionReceipt(e) {
    const {
      crystal_refs: t,
      question: s,
      answer: n,
      verification_result: i,
      model_config: a,
      requester: o,
      author: c,
      reputation_impact: l = 0,
      sign: u = !0
    } = e, d = {
      receipt_id: `rcpt_${Math.random().toString(36).slice(2, 11)}`,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      crystal_refs: t,
      question: s,
      answer: n,
      verification: i,
      model_config: a,
      requester: o,
      author: c,
      reputation_impact: l,
      signature: {
        alg: "ECDSA_P256_SHA256",
        payload_hash: "",
        signature: "",
        public_key: "PENDING",
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      }
    };
    if (u) {
      const h = { ...d };
      delete h.signature;
      const f = Xt.canonicalStringify(h), p = await Z.realSHA256(f), g = await Z.generateKeyPair(), m = await Z.signData(p, g.privateKey), y = await Z.exportPublicKey(g.publicKey);
      d.signature = {
        alg: "ECDSA_P256_SHA256",
        payload_hash: p,
        signature: m,
        public_key: y,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      };
    }
    return d;
  }
  /**
   * Verify a decision receipt's cryptographic integrity.
   */
  static async verifyReceipt(e) {
    if (!e.signature || !e.signature.signature || e.signature.public_key === "PENDING")
      return !1;
    const t = { ...e };
    delete t.signature;
    const s = Xt.canonicalStringify(t), n = await Z.realSHA256(s);
    try {
      const i = await Z.importPublicKey(e.signature.public_key);
      return await Z.verifySignature(
        n,
        e.signature.signature,
        i
      );
    } catch (i) {
      return console.error("Receipt verification failed:", i), !1;
    }
  }
}
const Ts = {
  web_browse: !1,
  send_email: !1,
  filesystem_access: !1,
  real_time_access: !1,
  execute_code: !1,
  financial_actions: !1,
  probabilistic_nature: !0
};
class Vr {
  /**
   * COMPILER: Transforms natural language intent into Logic Constraints
   */
  static async compileIntent(e, t = "general") {
    console.log(`[uSID] Compiling Intent for domain '${t}': "${e}"`);
    const { ExpertRegistry: s } = await import("./expert_registry-BHIP_ABd.js"), i = (await s.findBestJudges(t))[0] || "anthropic/claude-3.5-sonnet", a = `
        You are a LOGIC COMPILER. Translate User Intent into UNIVERSAL CONSTRAINTS.
        Return ONLY the JSON array.
        `;
    try {
      const o = await B.resilientCallLLM(e, i, a);
      return JSON.parse(o.content);
    } catch {
      return [];
    }
  }
  /**
   * SOLVER: Checks if the constraints are Satisfiable (SAT)
   */
  static async solve(e, t = Ts) {
    const s = await this.compileIntent(e);
    if (s.length === 0) return { status: "UNKNOWN", message: "Could not parse constraints" };
    const n = [], i = [];
    s.forEach((o) => {
      o.type === "CAPABILITY" && o.key === "requires" && (Array.isArray(o.value) ? o.value : [o.value]).forEach((l) => {
        t[l] === !1 && (n.push({
          constraint_id: o.id,
          constraint_desc: `Requires capability: ${l}`,
          conflict_reason: `System capability '${l}' is DISABLED/MISSING.`
        }), i.push(o.id));
      });
    });
    const a = s.find((o) => o.type === "CERTAINTY" && (o.value === "absolute" || o.value === "100%"));
    if (a && t.probabilistic_nature && (n.push({
      constraint_id: a.id,
      constraint_desc: "Requires absolute certainty/zero risk",
      conflict_reason: "System is PROBABILISTIC. Absolute certainty is epistemologically impossible."
    }), i.push(a.id)), n.length === 0) {
      const o = await this.checkLogicalConsistency(s);
      o.consistent || (n.push(...o.conflicts), i.push(...o.ids));
    }
    return n.length > 0 ? {
      status: "UNSAT",
      message: "No exists a coherent configuration that satisfies all constraints.",
      unsat_core: n,
      minimal_conflict_set: i,
      repair_options: await this.generateRepairs(n)
    } : {
      status: "SAT",
      normalized_intent: { action: e, constraints: s }
    };
  }
  static async checkLogicalConsistency(e) {
    const t = `
        Start by analyzing these constraints looking for LOGICAL CONTRADICTIONS.
        ${JSON.stringify(e, null, 2)}
        
        Examples of contradictions:
        - "Must be JSON only" AND "Must include paragraph outside JSON"
        - "Max length 10 words" AND "Must include full history of Rome"
        
        If CONTRADICTORY, return JSON: {"consistent": false, "conflicts": [{"constraint_id": "...", "reason": "..."}], "ids": ["..."]}
        If CONSISTENT, return: {"consistent": true}
        `;
    try {
      const s = await B.resilientCallLLM("Analyze Consistency", "nvidia/nemotron-3-nano-30b-a3b:free", t), n = JSON.parse(s.content);
      return {
        consistent: !!n.consistent,
        conflicts: (n.conflicts || []).map((i) => ({
          constraint_id: i.constraint_id,
          constraint_desc: "Logical Contradiction",
          conflict_reason: i.reason
        })),
        ids: n.ids || []
      };
    } catch (s) {
      return (s && typeof s == "object" && "message" in s && typeof s.message == "string" ? s.message : "") === "SOVEREIGN_REQUIRED" ? { consistent: !0, conflicts: [], ids: [] } : { consistent: !0, conflicts: [], ids: [] };
    }
  }
  static async generateRepairs(e) {
    const t = `
        Given these UNSATISFIABLE Constraints, suggest repairs:
        ${JSON.stringify(e)}
        
        Return JSON array: [{"change": "...", "effect": "..."}]
        `, s = await B.callLLM("Suggest Repairs", "anthropic/claude-3.5-sonnet", t);
    try {
      return JSON.parse(s.content);
    } catch {
      return [];
    }
  }
}
const F = {
  /**
   * Generate a SHA-256 hash (hex string)
   */
  async sha256(r) {
    const e = new TextEncoder().encode(r), t = await crypto.subtle.digest("SHA-256", e);
    return Array.from(new Uint8Array(t)).map((i) => i.toString(16).padStart(2, "0")).join("");
  },
  /**
   * Generate secure random bytes as hex string
   */
  randomHex(r) {
    const e = new Uint8Array(r);
    return crypto.getRandomValues(e), Array.from(e, (t) => t.toString(16).padStart(2, "0")).join("");
  },
  /**
   * Generate HMAC-SHA256 signature
   */
  async hmacSha256(r, e) {
    const t = new TextEncoder(), s = t.encode(r), n = t.encode(e), i = await crypto.subtle.importKey(
      "raw",
      s,
      { name: "HMAC", hash: "SHA-256" },
      !1,
      ["sign"]
    ), a = await crypto.subtle.sign(
      "HMAC",
      i,
      n
    );
    return Array.from(new Uint8Array(a)).map((o) => o.toString(16).padStart(2, "0")).join("");
  }
};
class ae {
  /**
   * Extract semantic features from text
   * These features represent MEANING, not surface form
   */
  static extract(e) {
    const t = [];
    return t.push(...this.extractNumbers(e)), t.push(...this.extractEntities(e)), t.push(...this.extractClaims(e)), t.push(...this.extractRelationships(e)), t.push(...this.extractTemporals(e)), t.push(...this.extractNegations(e)), t.push(...this.extractLocations(e)), t.push(...this.extractCompositions(e)), t.push(...this.extractDefinitions(e)), t;
  }
  static extractNumbers(e) {
    const t = [], s = /(\d+(?:,\d{3})*(?:\.\d+)?)\s*(%|mg|kg|g|ml|l|days?|hours?|years?|months?|dollars?|\$|€|£|million|billion)?/gi;
    let n;
    for (; (n = s.exec(e)) !== null; ) {
      const i = parseFloat((n[1] || "0").replace(/,/g, "")), a = (n[2] || "").toLowerCase(), o = this.normalizeUnit(a);
      t.push({
        type: "number",
        canonical: `NUM:${i}:${o}`,
        original: n[0],
        confidence: 1,
        position: n.index
      });
    }
    return t;
  }
  static normalizeUnit(e) {
    return {
      mg: "milligram",
      milligram: "milligram",
      milligrams: "milligram",
      g: "gram",
      gram: "gram",
      grams: "gram",
      kg: "kilogram",
      kilogram: "kilogram",
      day: "day",
      days: "day",
      hour: "hour",
      hours: "hour",
      year: "year",
      years: "year",
      month: "month",
      months: "month",
      "%": "percent",
      percent: "percent",
      $: "usd",
      dollar: "usd",
      dollars: "usd",
      "€": "eur",
      "£": "gbp",
      million: "million",
      billion: "billion",
      "": "unit"
    }[e.toLowerCase()] || e.toLowerCase() || "unit";
  }
  static extractEntities(e) {
    const t = [], s = [
      "aspirin",
      "ibuprofen",
      "acetaminophen",
      "paracetamol",
      "dose",
      "dosage",
      "treatment",
      "therapy",
      "patient",
      "drug",
      "medication",
      "prescription",
      "symptom",
      "diagnosis"
    ], n = [
      "revenue",
      "profit",
      "loss",
      "income",
      "expense",
      "filing",
      "sec",
      "10-k",
      "10-q",
      "quarterly",
      "annual",
      "stock",
      "share",
      "dividend",
      "market",
      "investor"
    ], i = [
      "gdpr",
      "regulation",
      "compliance",
      "penalty",
      "fine",
      "data protection",
      "privacy",
      "consent",
      "breach",
      "controller",
      "processor",
      "subject"
    ], a = [...s, ...n, ...i], o = e.toLowerCase();
    for (const c of a) {
      const l = o.indexOf(c);
      l !== -1 && t.push({
        type: "entity",
        canonical: `ENT:${c.toUpperCase()}`,
        original: c,
        confidence: 0.9,
        position: l
      });
    }
    return t;
  }
  static extractClaims(e) {
    const t = [], s = e.split(/[.!?]+/).filter((n) => n.trim().length > 10);
    for (let n = 0; n < s.length; n++) {
      const i = (s[n] || "").trim(), a = [
        /(\w+(?:\s+\w+)*)\s+(?:is|are)\s+(.+)/i,
        /(\w+(?:\s+\w+)*)\s+(?:must|should|can|may)\s+(.+)/i,
        /maximum\s+(.+?)\s+(?:is|:)\s*(.+)/i,
        /minimum\s+(.+?)\s+(?:is|:)\s*(.+)/i,
        /(\w+(?:\s+\w+)*)\s+(?:requires?|needs?)\s+(.+)/i
      ];
      for (const o of a) {
        const c = i.match(o);
        if (c) {
          const l = this.normalizeText(c[1] || ""), u = this.normalizeText(c[2] || "");
          t.push({
            type: "claim",
            canonical: `CLAIM:${l}:${u}`,
            original: i,
            confidence: 0.8,
            position: n
          });
          break;
        }
      }
    }
    return t;
  }
  static extractRelationships(e) {
    const t = [], s = [
      { pattern: /(\w+)\s+(?:causes?|leads?\s+to)\s+(\w+)/gi, rel: "CAUSES" },
      { pattern: /(\w+)\s+(?:prevents?|blocks?)\s+(\w+)/gi, rel: "PREVENTS" },
      { pattern: /(\w+)\s+(?:increases?|raises?)\s+(\w+)/gi, rel: "INCREASES" },
      { pattern: /(\w+)\s+(?:decreases?|reduces?|lowers?)\s+(\w+)/gi, rel: "DECREASES" },
      { pattern: /(\w+)\s+(?:contains?|includes?)\s+(\w+)/gi, rel: "CONTAINS" },
      { pattern: /(\w+)\s+(?:requires?|needs?)\s+(\w+)/gi, rel: "REQUIRES" }
    ];
    for (const { pattern: n, rel: i } of s) {
      let a;
      for (; (a = n.exec(e)) !== null; )
        t.push({
          type: "relationship",
          canonical: `REL:${i}:${this.normalizeText(a[1] || "")}:${this.normalizeText(a[2] || "")}`,
          original: a[0],
          confidence: 0.85,
          position: a.index
        });
    }
    return t;
  }
  static extractTemporals(e) {
    const t = [], s = [
      /within\s+(\d+)\s+(days?|hours?|weeks?|months?|years?)/gi,
      /after\s+(\d+)\s+(days?|hours?|weeks?|months?|years?)/gi,
      /before\s+(\d+)\s+(days?|hours?|weeks?|months?|years?)/gi,
      /every\s+(\d+)\s+(days?|hours?|weeks?|months?|years?)/gi,
      /(daily|weekly|monthly|annually|quarterly)/gi
    ];
    for (const n of s) {
      let i;
      for (; (i = n.exec(e)) !== null; ) {
        const a = i[0].toLowerCase().replace(/days?/, "day").replace(/hours?/, "hour").replace(/weeks?/, "week").replace(/months?/, "month").replace(/years?/, "year");
        t.push({
          type: "temporal",
          canonical: `TEMP:${a}`,
          original: i[0],
          confidence: 0.9,
          position: i.index
        });
      }
    }
    return t;
  }
  static extractNegations(e) {
    const t = [], s = [
      /(?:do\s+not|don't|cannot|can't|must\s+not|should\s+not|never)\s+(.+?)(?:\.|,|$)/gi,
      /(?:no|none|nothing|nobody)\s+(.+?)(?:\.|,|$)/gi,
      /(?:prohibited|forbidden|not\s+allowed|banned)\s*(?:to|from)?\s*(.+?)(?:\.|,|$)/gi
    ];
    for (const n of s) {
      let i;
      for (; (i = n.exec(e)) !== null; )
        t.push({
          type: "negation",
          canonical: `NEG:${this.normalizeText(i[1] || "")}`,
          original: i[0],
          confidence: 0.9,
          position: i.index
        });
    }
    return t;
  }
  static normalizeText(e) {
    return e.toLowerCase().replace(/[^\w\s]/g, "").replace(/\s+/g, "_").trim().substring(0, 50);
  }
  /**
   * Extract location and spatial information
   */
  static extractLocations(e) {
    const t = [], s = /(\d+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\s+(?:Street|St|Avenue|Ave|Drive|Dr|Road|Rd|Boulevard|Blvd|Lane|Ln|Way|Court|Ct))(?:,\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]*)?))?/g;
    let n;
    for (; (n = s.exec(e)) !== null; )
      t.push({
        type: "location",
        canonical: `LOC:ADDRESS:${this.normalizeText(n[1] || "")}`,
        original: n[0],
        confidence: 0.9,
        position: n.index
      });
    const i = [
      { pattern: /(?:the\s+)?(\w+(?:\s+\w+)?)\s+(?:is|are)\s+(?:inside|within|in)\s+(?:the\s+)?(\w+(?:\s+\w+)?)/gi, type: "CONTAINMENT" },
      { pattern: /(?:the\s+)?(\w+(?:\s+\w+)?)\s+(?:is|are)\s+(?:near|close\s+to|adjacent\s+to)\s+(?:the\s+)?(\w+(?:\s+\w+)?)/gi, type: "PROXIMITY" },
      { pattern: /(?:the\s+)?(\w+(?:\s+\w+)?)\s+(?:is|are)\s+(?:at|located\s+at)\s+(?:the\s+)?(\w+(?:\s+\w+)?)/gi, type: "AT_LOCATION" }
    ];
    for (const { pattern: a, type: o } of i)
      for (; (n = a.exec(e)) !== null; )
        n[1] && n[2] && t.push({
          type: "relationship",
          canonical: `REL:${o}:${this.normalizeText(n[1])}:${this.normalizeText(n[2])}`,
          original: n[0],
          confidence: 0.85,
          position: n.index
        });
    return t;
  }
  /**
   * Extract composition and part-whole relationships
   */
  static extractCompositions(e) {
    const t = [], s = [
      { pattern: /(?:the\s+)?(\w+)\s+(?:has|contains|includes)\s+(\d+\s+)?(?:parts?|components?|elements?)\s+(?:named|called|:)?\s*(\w+)/gi, type: "PART_WHOLE" },
      { pattern: /(?:the\s+)?(\w+)\s+(?:consists?\s+of|comprises?)\s+(.+?)(?:\.|,|$)/gi, type: "CONSISTS_OF" }
    ];
    let n;
    for (const { pattern: a, type: o } of s)
      for (; (n = a.exec(e)) !== null; ) {
        const c = n[1] || "", l = (n[3] || n[2] || "").trim();
        c && l && t.push({
          type: "composition",
          canonical: `COMP:${o}:${this.normalizeText(c)}:${this.normalizeText(l)}`,
          original: n[0],
          confidence: 0.85,
          position: n.index
        });
      }
    const i = /(?:the\s+)?(\w+)\s+(?:is|are)\s+(?:made\s+(?:of|from)|composed\s+of|built\s+(?:from|with))\s+(\w+(?:\s+(?:and|,)\s+\w+)*)/gi;
    for (; (n = i.exec(e)) !== null; )
      n[1] && n[2] && t.push({
        type: "composition",
        canonical: `COMP:MADE_OF:${this.normalizeText(n[1])}:${this.normalizeText(n[2])}`,
        original: n[0],
        confidence: 0.9,
        position: n.index
      });
    return t;
  }
  /**
   * Extract explicit definitions from text
   */
  static extractDefinitions(e) {
    const t = [], s = [
      { pattern: /(?:a\s+)?(\w+(?:\s+\w+)*)\s+(?:is|are)\s+defined\s+as\s+(.+?)(?:\.|$)/gi, type: "EXPLICIT_DEF" },
      { pattern: /(?:the\s+)?(\w+(?:\s+\w+)*)\s+(?:refers?\s+to|means)\s+(.+?)(?:\.|$)/gi, type: "MEANS" },
      { pattern: /"(\w+(?:\s+\w+)*)"\s+(?:is|are)\s+(.+?)(?:\.|$)/gi, type: "QUOTED_DEF" }
    ];
    for (const { pattern: n, type: i } of s) {
      let a;
      for (; (a = n.exec(e)) !== null; )
        a[1] && a[2] && t.push({
          type: "claim",
          canonical: `DEF:${i}:${this.normalizeText(a[1])}:${this.normalizeText(a[2])}`,
          original: a[0],
          confidence: 0.95,
          position: a.index
        });
    }
    return t;
  }
}
let Re = class {
  /**
   * Create a semantic hash from features
   * Same meaning = same hash (regardless of wording)
   */
  static async hash(e) {
    const t = e.map((s) => s.canonical).sort().join("|");
    return await F.sha256(t);
  }
  /**
   * Calculate semantic similarity between two feature sets
   */
  static similarity(e, t) {
    const s = new Set(e.map((o) => o.canonical)), n = new Set(t.map((o) => o.canonical));
    if (s.size === 0 && n.size === 0) return 1;
    if (s.size === 0 || n.size === 0) return 0;
    const i = new Set([...s].filter((o) => n.has(o))), a = /* @__PURE__ */ new Set([...s, ...n]);
    return i.size / a.size;
  }
  /**
   * Check if two documents are paraphrases (same meaning, different words)
   */
  static async isParaphrase(e, t, s = 0.7) {
    const n = ae.extract(e), i = ae.extract(t), a = await F.sha256(e), o = await F.sha256(t);
    return a === o ? !1 : this.similarity(n, i) >= s;
  }
  /**
   * Detect contradictions between two texts
   */
  static findContradictions(e, t) {
    const s = [], n = ae.extract(e), i = ae.extract(t), a = n.filter((u) => u.type === "number"), o = i.filter((u) => u.type === "number");
    for (const u of a)
      for (const d of o) {
        const h = u.canonical.split(":"), f = d.canonical.split(":");
        if (h[2] === f[2] && h[2] !== "unit") {
          const p = parseFloat(h[1] || "0"), g = parseFloat(f[1] || "0");
          p !== g && Math.abs(p - g) / Math.max(p, g) > 0.1 && s.push({
            claim1: u.original,
            claim2: d.original,
            reason: `Numeric contradiction: ${p} vs ${g} ${h[2]}`
          });
        }
      }
    const c = n.filter((u) => u.type === "negation"), l = i.filter((u) => u.type === "claim");
    for (const u of c) {
      const d = u.canonical.replace("NEG:", "");
      for (const h of l)
        h.canonical.includes(d) && s.push({
          claim1: u.original,
          claim2: h.original,
          reason: "Negation vs affirmation contradiction"
        });
    }
    return s;
  }
};
class As {
  constructor() {
    V(this, "nodes", /* @__PURE__ */ new Map());
    V(this, "claims", []);
  }
  /**
   * Build a Semantic Merkle Tree from a document
   */
  async build(e) {
    const t = `smt_${F.randomHex(8)}`, s = ae.extract(e), n = this.groupFeatures(s), i = [];
    for (const [l, u] of Object.entries(n)) {
      const d = await this.createNode(u, 0);
      this.nodes.set(d.id, d), i.push(d);
    }
    const a = await this.buildTreeLevel(i, 1);
    await this.extractClaims(s, e);
    const o = await F.sha256(e), c = await Re.hash(s);
    return {
      smt_version: "1.0",
      tree_id: t,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      root: {
        semantic_hash: a.semantic_hash,
        feature_count: s.length,
        depth: a.depth
      },
      nodes: this.nodes,
      document: {
        original_hash: o,
        semantic_hash: c,
        word_count: e.split(/\s+/).length,
        claim_count: this.claims.length
      },
      claims: this.claims
    };
  }
  groupFeatures(e) {
    const t = {};
    for (const s of e)
      t[s.type] || (t[s.type] = []), t[s.type].push(s);
    return t;
  }
  async createNode(e, t) {
    const s = `node_${F.randomHex(4)}`, n = await Re.hash(e);
    return {
      id: s,
      semantic_hash: n,
      features: e,
      children: [],
      depth: t
    };
  }
  async buildTreeLevel(e, t) {
    if (e.length === 0)
      return await this.createNode([], t);
    if (e.length === 1)
      return e[0];
    const s = [];
    for (let n = 0; n < e.length; n += 2) {
      const i = e[n], a = e[n + 1] || i, o = [...i.features, ...a.features], c = await this.createNode(o, t);
      c.children = [i.id, a.id], i.parent = c.id, a.parent = c.id, this.nodes.set(c.id, c), s.push(c);
    }
    return await this.buildTreeLevel(s, t + 1);
  }
  async extractClaims(e, t) {
    const s = e.filter((n) => n.type === "claim");
    for (const n of s)
      this.claims.push({
        id: `claim_${F.randomHex(4)}`,
        canonical: n.canonical,
        original: n.original,
        semantic_hash: await F.sha256(n.canonical),
        evidence: [t.substring(0, 100) + "..."]
      });
  }
}
class jt {
  /**
   * Build a Semantic Merkle Tree from text
   */
  static async build(e) {
    return await new As().build(e);
  }
  /**
   * Compare two documents semantically
   */
  static async compare(e, t) {
    const s = await this.build(e), n = await this.build(t), i = ae.extract(e), a = ae.extract(t), o = Re.similarity(i, a), c = await Re.isParaphrase(e, t), l = Re.findContradictions(e, t), u = await F.sha256(e), d = await F.sha256(t), f = u === d ? 0 : o > 0.6 ? o : 0, p = [];
    for (const g of s.claims)
      for (const m of n.claims) {
        const y = this.calculateClaimSimilarity(g.canonical, m.canonical);
        if (y > 0.3) {
          let v;
          y >= 0.95 ? v = "equivalent" : y >= 0.7 ? v = "paraphrase" : l.some(
            (_) => _.claim1.includes(g.original.substring(0, 20)) || _.claim2.includes(m.original.substring(0, 20))
          ) ? v = "contradiction" : y >= 0.4 ? v = "related" : v = "unrelated", p.push({
            doc1_claim: g.original,
            doc2_claim: m.original,
            similarity: y,
            relationship: v
          });
        }
      }
    return {
      semantic_similarity: o,
      paraphrase_detected: c,
      contradiction_detected: l.length > 0,
      plagiarism_score: f,
      matching_claims: p,
      contradictions: l,
      comparison_proof: {
        doc1_semantic_hash: s.document.semantic_hash,
        doc2_semantic_hash: n.document.semantic_hash,
        comparison_hash: await F.sha256(s.document.semantic_hash + n.document.semantic_hash),
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      }
    };
  }
  /**
   * Verify a claim against a truth tree
   */
  static async verifyClaim(e, t) {
    const s = ae.extract(t), n = await Re.hash(s);
    for (const o of e.claims)
      if (o.semantic_hash === n)
        return {
          found: !0,
          matching_claim: o,
          semantic_match: !0,
          confidence: 1
        };
    let i, a = 0;
    for (const o of e.claims) {
      const c = this.calculateClaimSimilarity(
        s.map((l) => l.canonical).join("|"),
        o.canonical
      );
      c > a && (a = c, i = o);
    }
    return {
      found: a >= 0.5,
      matching_claim: i,
      semantic_match: a >= 0.8,
      confidence: a
    };
  }
  /**
   * Get audit trail for a semantic tree
   */
  static getAuditTrail(e) {
    return {
      tree_id: e.tree_id,
      root_hash: e.root.semantic_hash,
      claims: e.claims.map((t) => ({
        canonical: t.canonical,
        hash: t.semantic_hash
      })),
      verification_path: Array.from(e.nodes.values()).map((t) => t.semantic_hash)
    };
  }
  static calculateClaimSimilarity(e, t) {
    const s = new Set(e.toLowerCase().split(/[:|_]/)), n = new Set(t.toLowerCase().split(/[:|_]/));
    if (s.size === 0 && n.size === 0) return 1;
    if (s.size === 0 || n.size === 0) return 0;
    const i = new Set([...s].filter((o) => n.has(o))), a = /* @__PURE__ */ new Set([...s, ...n]);
    return i.size / a.size;
  }
}
class ks {
  constructor() {
    V(this, "nodes", /* @__PURE__ */ new Map());
    V(this, "claim", "");
    V(this, "domain", "general");
  }
  /**
   * Add an axiom - a base fact from an authoritative source
   */
  async addAxiom(e) {
    const t = this.generateId("axiom"), s = await this.hash(e.source_content), n = {
      id: t,
      type: "axiom",
      claim: e.claim,
      source: {
        document: e.source_document,
        ...e.section && { section: e.section },
        ...e.url && { url: e.url },
        retrieved_at: (/* @__PURE__ */ new Date()).toISOString(),
        content_hash: s
      },
      proof_hash: "",
      // Will be computed
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      verifiable: !0,
      verification_cost: 0
    };
    return n.proof_hash = await this.hashNode(n), this.nodes.set(t, n), t;
  }
  /**
   * Add an extraction - a specific value extracted from source text
   */
  async addExtraction(e) {
    const t = e.pattern.exec(e.source_text);
    if (!t) return null;
    const s = this.generateId("extraction"), n = {
      id: s,
      type: "extraction",
      claim: e.claim,
      extraction: {
        pattern: e.pattern.source,
        matched_text: t[0],
        position: { start: t.index, end: t.index + t[0].length }
      },
      derivation: {
        rule: "direct_quote",
        premises: [e.axiom_id],
        justification: `Extracted "${t[0]}" using pattern /${e.pattern.source}/`
      },
      proof_hash: "",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      verifiable: !0,
      verification_cost: 0
    };
    return n.proof_hash = await this.hashNode(n), this.nodes.set(s, n), s;
  }
  /**
   * Add a derivation - knowledge derived from other proofs
   */
  async addDerivation(e) {
    for (const n of e.premises)
      if (!this.nodes.has(n))
        throw new Error(`Premise ${n} not found in proof tree`);
    const t = this.generateId("derivation"), s = {
      id: t,
      type: "derivation",
      claim: e.claim,
      derivation: {
        rule: e.rule,
        premises: e.premises,
        justification: e.justification
      },
      proof_hash: "",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      verifiable: !0,
      verification_cost: 0
    };
    return s.proof_hash = await this.hashNode(s), this.nodes.set(t, s), t;
  }
  /**
   * Set the main claim this PCK proves
   */
  setClaim(e, t) {
    return this.claim = e, this.domain = t, this;
  }
  /**
   * Build the final PCK
   */
  async build(e) {
    if (!this.nodes.has(e))
      throw new Error(`Root node ${e} not found`);
    const t = await this.computeMerkleRoot(), s = `pck_${(await this.hash(t + Date.now())).substring(0, 16)}`, n = this.calculateConfidence(e);
    return {
      pck_version: "1.0",
      pck_id: s,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      claim: {
        statement: this.claim,
        domain: this.domain,
        confidence: n
      },
      proof_tree: {
        root: e,
        nodes: this.nodes
      },
      merkle_root: t,
      signature: {
        algorithm: "SHA256-HMAC",
        value: await this.hash(t + s)
      }
    };
  }
  // ═══════════════════════════════════════════════════════════════════════════
  // PRIVATE HELPERS
  // ═══════════════════════════════════════════════════════════════════════════
  generateId(e) {
    return `${e}_${F.randomHex(8)}`;
  }
  async hash(e) {
    return await F.sha256(e);
  }
  async hashNode(e) {
    const t = JSON.stringify({
      id: e.id,
      type: e.type,
      claim: e.claim,
      source: e.source,
      derivation: e.derivation,
      extraction: e.extraction
    });
    return await this.hash(t);
  }
  async computeMerkleRoot() {
    const e = Array.from(this.nodes.values()).map((t) => t.proof_hash);
    if (e.length === 0) return await this.hash("empty");
    for (; e.length > 1; ) {
      const t = [];
      for (let s = 0; s < e.length; s += 2) {
        const n = e[s] || "", i = e[s + 1] || n;
        t.push(await this.hash(n + i));
      }
      e.length = 0, e.push(...t);
    }
    return e[0] || await this.hash("empty");
  }
  calculateConfidence(e) {
    const t = this.nodes.get(e);
    if (!t) return 0;
    switch (t.type) {
      case "axiom":
        return 1;
      case "extraction":
        return 0.95;
      case "derivation": {
        if (!t.derivation) return 0;
        const s = t.derivation.premises.map((a) => this.calculateConfidence(a)), n = Math.min(...s), i = this.getRuleStrength(t.derivation.rule);
        return n * i;
      }
      default:
        return 0.5;
    }
  }
  getRuleStrength(e) {
    return {
      direct_quote: 1,
      paraphrase: 0.9,
      numeric_bound: 0.95,
      temporal_order: 0.95,
      logical_and: 1,
      logical_or: 0.9,
      modus_ponens: 1,
      transitivity: 0.95
    }[e] || 0.8;
  }
}
class Qt {
  /**
   * Verify a PCK completely offline - no external calls
   */
  static async verify(e) {
    var c;
    const t = Date.now(), s = [];
    let n = 0;
    if (n++, !((c = e == null ? void 0 : e.proof_tree) != null && c.nodes))
      return console.error("[PCKVerifier] proof_tree or nodes is undefined!", e), s.push("malformed_pck_structure"), {
        valid: !1,
        confidence: 0,
        checks_performed: n,
        failed_checks: s,
        verification_time_ms: Date.now() - t,
        external_calls_made: 0
      };
    await this.recomputeMerkleRoot(e.proof_tree.nodes) !== e.merkle_root && s.push("merkle_root_mismatch");
    for (const [l, u] of e.proof_tree.nodes)
      n++, await this.recomputeNodeHash(u) !== u.proof_hash && s.push(`node_hash_mismatch:${l}`);
    for (const [l, u] of e.proof_tree.nodes)
      if (u.type === "derivation" && u.derivation) {
        n++;
        for (const d of u.derivation.premises)
          e.proof_tree.nodes.has(d) || s.push(`missing_premise:${l}:${d}`);
        n++, this.isValidDerivation(u, e.proof_tree.nodes) || s.push(`invalid_derivation:${l}`);
      }
    for (const [l, u] of e.proof_tree.nodes)
      if (u.type === "extraction" && u.extraction) {
        n++;
        try {
          new RegExp(u.extraction.pattern).test(u.extraction.matched_text) || s.push(`extraction_pattern_mismatch:${l}`);
        } catch {
          s.push(`invalid_extraction_pattern:${l}`);
        }
      }
    n++, await this.hash(e.merkle_root + e.pck_id) !== e.signature.value && s.push("signature_invalid");
    const o = Date.now() - t;
    return {
      valid: s.length === 0,
      confidence: s.length === 0 ? e.claim.confidence : 0,
      checks_performed: n,
      failed_checks: s,
      verification_time_ms: o,
      external_calls_made: 0
    };
  }
  /**
   * FRACTAL: Verify a Crystal's embedded knowledge and semantic root
   */
  static async verifyCrystalFractal(e) {
    var i;
    const t = Date.now(), s = [];
    let n = 0;
    if (e.proof_tree) {
      n++;
      const a = e.proof_tree instanceof Map ? e.proof_tree : new Map(Object.entries(e.proof_tree));
      e.context_id, await this.recomputeMerkleRoot(a), n++, e.smt_root && (n++, e.smt_root.length < 32 && s.push("invalid_smt_root"));
    }
    if ((i = e.verification) != null && i.merkle_proof) {
      n++;
      const { root: a, path: o, leaf: c } = e.verification.merkle_proof;
      let l = c;
      for (const u of o)
        l = await this.hash(l + u);
      l !== a && s.push("fractal_merkle_path_invalid");
    }
    return {
      valid: s.length === 0,
      confidence: s.length === 0 ? 1 : 0,
      checks_performed: n,
      failed_checks: s,
      verification_time_ms: Date.now() - t,
      external_calls_made: 0
    };
  }
  /**
   * Verify a specific claim against a PCK
   */
  static verifyClaim(e, t) {
    var o;
    const s = [];
    if (!((o = e == null ? void 0 : e.proof_tree) != null && o.nodes)) return { supported: !1, proof_path: [], confidence: 0 };
    for (const c of e.proof_tree.nodes.values())
      this.claimsMatch(c.claim, t) && s.push(c);
    if (s.length === 0)
      return { supported: !1, proof_path: [], confidence: 0 };
    const n = s.reduce(
      (c, l) => this.getNodeConfidence(c, e.proof_tree.nodes) > this.getNodeConfidence(l, e.proof_tree.nodes) ? c : l
    ), i = this.getProofPath(n.id, e.proof_tree.nodes), a = this.getNodeConfidence(n, e.proof_tree.nodes);
    return { supported: !0, proof_path: i, confidence: a };
  }
  // ═══════════════════════════════════════════════════════════════════════════
  // PRIVATE HELPERS
  // ═══════════════════════════════════════════════════════════════════════════
  static async hash(e) {
    return await F.sha256(e);
  }
  static async recomputeMerkleRoot(e) {
    const t = Array.from(e.values()).map((s) => s.proof_hash);
    if (t.length === 0) return await this.hash("empty");
    for (; t.length > 1; ) {
      const s = [];
      for (let n = 0; n < t.length; n += 2) {
        const i = t[n] || "", a = t[n + 1] || i;
        s.push(await this.hash(i + a));
      }
      t.length = 0, t.push(...s);
    }
    return t[0] || await this.hash("empty");
  }
  static async recomputeNodeHash(e) {
    const t = JSON.stringify({
      id: e.id,
      type: e.type,
      claim: e.claim,
      source: e.source,
      derivation: e.derivation,
      extraction: e.extraction
    });
    return await this.hash(t);
  }
  static isValidDerivation(e, t) {
    if (!e.derivation) return !1;
    const s = e.derivation.rule, n = e.derivation.premises.map((i) => t.get(i)).filter(Boolean);
    if (n.length !== e.derivation.premises.length) return !1;
    switch (s) {
      case "direct_quote":
        return n.length >= 1;
      case "logical_and":
        return n.length >= 2;
      case "modus_ponens":
        return n.length === 2;
      default:
        return !0;
    }
  }
  static claimsMatch(e, t) {
    const s = (u) => u.toLowerCase().replace(/[^\w\s]/g, "").trim(), n = s(e), i = s(t);
    if (n === i || n.includes(i) || i.includes(n)) return !0;
    const a = new Set(n.split(/\s+/)), o = new Set(i.split(/\s+/));
    let c = 0;
    for (const u of a) o.has(u) && c++;
    return c / Math.max(a.size, o.size) > 0.7;
  }
  static getNodeConfidence(e, t) {
    switch (e.type) {
      case "axiom":
        return 1;
      case "extraction":
        return 0.95;
      case "derivation": {
        if (!e.derivation) return 0;
        const s = e.derivation.premises.map((n) => t.get(n)).filter(Boolean).map((n) => this.getNodeConfidence(n, t));
        return Math.min(...s) * 0.95;
      }
      default:
        return 0.5;
    }
  }
  static getProofPath(e, t) {
    const s = [e], n = t.get(e);
    if (n != null && n.derivation)
      for (const i of n.derivation.premises)
        s.push(...this.getProofPath(i, t));
    return s;
  }
}
class Os {
  /**
   * Compile a source document into Proof-Carrying Knowledge
   * This is done ONCE when you have authoritative source material
   */
  static async compile(e, t) {
    var u;
    const s = new ks(), n = await s.addAxiom({
      claim: `Source document for ${t.domain} domain`,
      source_document: `${t.domain.toUpperCase()} Reference`,
      source_content: e
    }), i = await jt.build(e), a = [], o = i.nodes instanceof Map ? Array.from(i.nodes.values()) : Object.values(i.nodes);
    for (const d of o)
      for (const h of d.features) {
        if (h.type === "number" && t.extract_numbers === !1 || h.type === "entity" && t.extract_entities === !1 || h.type === "temporal" && t.extract_temporals === !1) continue;
        const f = await s.addExtraction({
          claim: `${h.type.toUpperCase()}: ${h.canonical} - "${h.original}"`,
          source_text: e,
          // We still need the original text for regex validation in PCK
          pattern: new RegExp(this.escapeRegex(h.original), "i"),
          axiom_id: n
        });
        f && a.push(f);
      }
    let c = n;
    a.length > 0 && (c = await s.addDerivation({
      claim: `Verified knowledge from ${t.domain} source with ${a.length} SMT-derived features`,
      rule: "logical_and",
      premises: [n, ...a],
      justification: `Combined ${a.length} verified extractions from source`
    })), s.setClaim(
      `Verified ${t.domain} knowledge from authoritative source`,
      t.domain
    );
    const l = await s.build(c);
    return console.log("[PCKRuntime] Compiled PCK:", l.pck_id, "has nodes:", !!((u = l.proof_tree) != null && u.nodes)), l;
  }
  /**
   * Verify an LLM answer against a PCK - ZERO API CALLS
   */
  static async verifyAnswer(e, t) {
    const s = Date.now();
    (!e || !e.proof_tree) && console.error("[PCKRuntime] Invalid PCK object passed to verifyAnswer:", e);
    const n = await Qt.verify(e);
    if (!n.valid)
      return {
        valid: !1,
        confidence: 0,
        supported_claims: [],
        unsupported_claims: ["PCK proof verification failed"],
        contradictions: [],
        proof_verification: n,
        llm_calls_made: 0,
        verification_time_ms: Date.now() - s
      };
    const i = this.extractClaims(t), a = [], o = [], c = [];
    for (const p of i)
      if (Qt.verifyClaim(e, p).supported)
        a.push(p);
      else {
        const m = this.checkContradiction(e, p);
        m ? c.push(`"${p}" contradicts: "${m}"`) : o.push(p);
      }
    const l = i.length, u = l > 0 ? a.length / l : 0, d = c.length > 0, h = u >= 0.5 && !d, f = d ? 0 : u * e.claim.confidence;
    return {
      valid: h,
      confidence: f,
      supported_claims: a,
      unsupported_claims: o,
      contradictions: c,
      proof_verification: n,
      llm_calls_made: 0,
      verification_time_ms: Date.now() - s
    };
  }
  // ═══════════════════════════════════════════════════════════════════════════
  // EXTRACTION UTILITIES
  // ═══════════════════════════════════════════════════════════════════════════
  static extractClaims(e) {
    return e.split(/[.!?]+/).map((s) => s.trim()).filter((s) => s.length > 10 && s.length < 500);
  }
  static checkContradiction(e, t) {
    const s = t.toLowerCase(), n = [
      { pattern: /no\s+(?:limit|maximum|restriction)/i, opposite: /maximum|limit|up to/i },
      { pattern: /unlimited/i, opposite: /maximum|limit|up to/i },
      { pattern: /any\s+time/i, opposite: /within|before|after|deadline/i },
      { pattern: /no\s+exceptions?/i, opposite: /except|exception|unless|however/i }
    ];
    for (const { pattern: i, opposite: a } of n)
      if (i.test(s)) {
        for (const o of e.proof_tree.nodes.values())
          if (a.test(o.claim.toLowerCase()))
            return o.claim;
      }
    return null;
  }
  static escapeRegex(e) {
    return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }
}
const ht = {}, z = {
  budget_mode: (ht == null ? void 0 : ht.VITE_BUDGET_MODE) || "balanced",
  // FREE TIER LIMITS (Daily)
  free_tier_limits: {
    max_premium_calls: 5,
    // Escalation cap
    max_free_tokens: 1e5,
    // OpenRouter :free limit
    force_local_if_offline: !0
  },
  // MODEL PRIORITY (Potency Escalation)
  model_stack: {
    local: "gemma-2b-nb-q4",
    // WebLLM / WebGPU (Local Sovereign)
    free: "nvidia/nemotron-3-nano-30b-a3b:free",
    // Zero-cost fallback
    flash: "google/gemini-2.0-flash-exp:free",
    // High speed, high intel
    premium: "anthropic/claude-3.5-sonnet"
    // Platinum Escalation
  }
}, te = {};
var Rr, Cr, Ir, xr;
te != null && te.VITE_OPENROUTER_API_KEY || (Cr = (Rr = globalThis.process) == null ? void 0 : Rr.env) != null && Cr.VITE_OPENROUTER_API_KEY || (xr = (Ir = globalThis.process) == null ? void 0 : Ir.env) != null && xr.OPENROUTER_API_KEY;
const Rs = "https://openrouter.ai/api/v1";
var $r, Pr;
const Cs = (te == null ? void 0 : te.OPENAI_MODEL) || ((Pr = ($r = globalThis.process) == null ? void 0 : $r.env) == null ? void 0 : Pr.OPENAI_MODEL), Ut = Cs || z.model_stack.free, Is = [
  "arcee-ai/trinity-large-preview:free",
  // Arcee Trinity 400B MoE
  "liquid/lfm-2.5-1.2b-instruct:free",
  // Liquid LFM - fast
  "upstage/solar-pro-3:free"
  // Upstage Solar Pro 3
], Zt = z.model_stack.premium;
function xs(r) {
  const e = (r == null ? void 0 : r.free_energy) || (r == null ? void 0 : r.surprise) || 0.5;
  return z.budget_mode === "performance" ? Zt : z.budget_mode === "sovereign" ? z.model_stack.local : e > 0.3 ? (console.log(`[PotencyEscalator] 🏔️ High Free Energy detected (${e.toFixed(2)}). Escalating to Platinum Tier...`), Zt) : Ut;
}
const $s = 50;
async function Ze(r) {
  return new Promise((e) => setTimeout(e, r));
}
async function Kr(r, e = z.model_stack.premium, t, s = 1) {
  var u, d, h, f, p, g;
  const n = Date.now(), i = [];
  t && i.push({ role: "system", content: t }), i.push({ role: "user", content: r });
  const { KeyManager: a } = await import("./key_manager-ChsPY2N_.js"), c = await a.getKey("openrouter") || (te == null ? void 0 : te.VITE_OPENROUTER_API_KEY) || ((d = (u = globalThis.process) == null ? void 0 : u.env) == null ? void 0 : d.VITE_OPENROUTER_API_KEY) || ((f = (h = globalThis.process) == null ? void 0 : h.env) == null ? void 0 : f.OPENROUTER_API_KEY);
  if (!c)
    throw new Error("MISSING_API_KEY: Please provide an OpenRouter key in Settings.");
  let l = 0;
  for (; ; )
    try {
      const m = await fetch(`${Rs}/chat/completions`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${c}`,
          "Content-Type": "application/json",
          "HTTP-Referer": "https://neural-bridge.ai",
          "X-Title": "Neural Bridge Sovereign"
        },
        body: JSON.stringify({
          model: e,
          messages: i,
          temperature: 0.3,
          max_tokens: 2e3
        })
      });
      if (!m.ok) {
        const H = await m.text();
        if ((m.status === 429 || m.status === 503 || m.status === 502) && l < s) {
          const se = 500 + Math.random() * 200;
          console.log(`⚡ [TURBO-RETRY] ${e} → ${m.status}. Quick retry in ${Math.round(se)}ms...`), await Ze(se), l++;
          continue;
        }
        throw new Error(`LLM API error: ${m.status} - ${H}`);
      }
      await Ze($s);
      const y = await m.json(), v = Date.now() - n, _ = {
        [z.model_stack.premium]: { prompt: 3e-3, completion: 0.015 },
        "openai/gpt-4o": { prompt: 5e-3, completion: 0.015 }
      }, E = e.endsWith(":free") ? { prompt: 0, completion: 0 } : _[e] || { prompt: 1e-3, completion: 2e-3 }, C = y.usage.prompt_tokens || 0, S = y.usage.completion_tokens || 0, R = C / 1e3 * E.prompt + S / 1e3 * E.completion;
      return {
        content: ((g = (p = y.choices[0]) == null ? void 0 : p.message) == null ? void 0 : g.content) || "",
        model: e,
        tokens: {
          prompt: C,
          completion: S,
          total: C + S
        },
        cost: R,
        latency: v
      };
    } catch (m) {
      if (m && typeof m == "object" && "message" in m && typeof m.message == "string" && l < s && (m.message.includes("429") || m.message.includes("503"))) {
        l++, await Ze(Math.pow(2, l) * 1e3);
        continue;
      }
      throw m;
    }
}
async function ye(r, e, t) {
  const s = e.endsWith(":free") ? [e, ...Is.filter((i) => i !== e)] : [e];
  let n;
  for (const i of s)
    try {
      return await Kr(r, i, t);
    } catch (a) {
      n = a;
      const o = a && typeof a == "object" && "message" in a && typeof a.message == "string" ? a.message : "";
      if (o.includes("401") || o.includes("MISSING_API_KEY"))
        throw console.warn("🛡️ [SOVEREIGN_MODE] API Access Denied. Switching to internal Ontological Synthesis..."), new Error("SOVEREIGN_REQUIRED");
      s.length > 1 && console.warn(`⚠️ [FALLBACK] Model ${i} failed. Trying next in stack...`);
    }
  throw n;
}
async function Lt(r) {
  const e = `You are a Domain Classifier for Neural Bridge.
Analyze the conversation and identify the specific knowledge domain (e.g., medicine, law, tech, finance, education, etc.).
Be precise. If it is a mix, choose the most critical one.`, t = `Conversation sample:
"${r.substring(0, 1e3)}"

Identify the domain. Return ONLY the domain name in lowercase (e.g. "medicine"). No explanation.`;
  try {
    const n = (await ye(t, Ut, e)).content.trim().toLowerCase().replace(/[^a-z0-9]/g, "");
    if (n === "general" || !n) {
      const { DomainEvolver: i } = await import("./domain_evolver-BZAzq4EM.js");
      return (await i.evolveDomain(r)).domain;
    }
    return n;
  } catch (s) {
    if ((s && typeof s == "object" && "message" in s && typeof s.message == "string" ? s.message : "") === "SOVEREIGN_REQUIRED")
      return "sovereign_evolution";
    console.warn("⚠️ Autonomous domain detection failed, falling back to evolution:", s);
    const { DomainEvolver: i } = await import("./domain_evolver-BZAzq4EM.js");
    return (await i.evolveDomain(r)).domain;
  }
}
async function zr(r, e, t) {
  var Vt, Kt, zt, Gt, Wt, Jt, Yt;
  const s = `You are a Semantic Context Protocol (SCP) compiler. Your task is to extract structured semantic content from conversations for verified transfer to another LLM.

You MUST return a valid JSON object with this exact structure:
{
  "entities": [{"name": "e1", "type": "person|project|concept|tool|constraint", "category": "..."}],
  "intent": {"primary": "...", "status": "active"},
  "constraints": [{"id": "c1", "rule": "MUST|NEVER", "value": "...", "rationale": "..."}],
  "verification": {
    "semantic_invariants": [
      {
        "id": "inv_001",
        "kind": "fact_check|constraint_check",
        "prompt": "Question to verify this fact",
        "expected": {"type": "boolean|string", "value": "..."},
        "weight": 0.0-1.0,
        "strict": true/false,
        "rationale": "..."
      }
    ]
  }
}

Extract:
1. ALL named entities (people, projects, technologies, concepts)
2. User's primary intent
3. Technical or preference constraints
4. 3-5 invariants that can verify successful context transfer

Be thorough but precise.`, n = await Vr.solve(r);
  if (n.status === "UNSAT") {
    const b = (n.repair_options || []).map((O) => `
     * ${O.change} -> ${O.effect}`).join("");
    throw new Error(`
        ⛔ ONTOLOGICAL REFUSAL TRIGGERED (uSID v2.0)
        The system cannot process this request because it describes an impossible reality configuration.
        
        Reason: ${n.message}
        
        Violated Constraints (UNSAT CORE):
        ${(n.unsat_core || []).map((O) => `• [${O.constraint_id}] ${O.constraint_desc}: ${O.conflict_reason}`).join(`
`)}

        SUGGESTED REPAIRS to make reality consistent:${b}
        `);
  }
  const { FractalCompressor: i } = await import("./fractal_compressor-BrXmGc2S.js"), a = await i.compress(r), { StochasticEngine: o } = await import("./stochastic_engine-Dp9LfZu3.js"), { semanticPotential: c, entropy: l } = await o.processChaos(a);
  await o.entropyBalancer(l) || console.log("[SCPService] 🧬 Lattice unstable. Applying Axiomatic Stabilization...");
  const { DomainEvolver: d } = await import("./domain_evolver-BZAzq4EM.js");
  let h, f = [];
  try {
    const b = await d.evolveDomain(a);
    h = b.domain, f = b.axioms;
  } catch {
    h = await Lt(a);
  }
  const { predictionError: p, residualContent: g } = await o.performPredictiveCoding(a, h), { ThalamicGateway: m } = await import("./thalamic_gateway-EueCjix0.js"), y = await m.route(a, h);
  if (y.bestCrystal) {
    console.log("[SCPService] 🪐 Resonant Crystal retrieved from Talamic Atlas. Merging knowledge...");
    const { CrystalFuser: b } = await Promise.resolve().then(() => va);
    `${b.fuseCrystalIntoContext(y.bestCrystal)}`;
  }
  p < 0.2 && console.log(`[SCPService] 💤 High Prediction Accuracy (${(1 - p) * 100}%). Efficiently assimilating known context...`);
  const v = nt({
    task: "compile",
    text: a,
    stats: { free_energy: l, surprise: p }
  }), { VaccineEngine: _ } = await import("./vaccine_engine-D7gTsmae.js"), E = await _.getActiveGuards(a, h), { TruthVault: C } = await Promise.resolve().then(() => Ar), S = await C.checkReality(a, h);
  let R = a;
  S.is_conflict && (console.warn(`[SCPService] 🚨 REALITY CONFLICT DETECTED: ${S.contradiction_reason}`), R = await C.healReality(a, {
    reason: S.contradiction_reason,
    entry: S.conflicting_entry
  }), console.log("[SCPService] 💉 Reality healed. Proceeding with stabilized context."));
  let H = "";
  E.length > 0 && (H = `

💉 SEMANTIC IMMUNITY GUARDS (Avoid these known patterns):
` + E.map((b) => `- [${b.fallacy_type}] ${b.meta_invariant.rule}`).join(`
`));
  let q = `Analyze the following conversation and extract its semantic content in Crystal Format v0.1:
            
            ---CONVERSATION START---
            ${R}
            ---CONVERSATION END---
            ${H}
            
            Return ONLY valid JSON, no markdown or explanation.`, se = null, oe = 0;
  const lt = 2;
  for (; oe <= lt; )
    try {
      if (se = await ye(
        q,
        v,
        s
      ), !se) throw new Error("[SCPService] LLM call returned null response");
      let b = se.content;
      const O = b.match(/```(?:json)?\s*([\s\S]*?)```/);
      O && O[1] && (b = O[1]);
      const M = JSON.parse(b.trim());
      if (oe < lt && ((((Vt = M.constraints) == null ? void 0 : Vt.length) || 0) < 2 || (((zt = (Kt = M.verification) == null ? void 0 : Kt.semantic_invariants) == null ? void 0 : zt.length) || 0) < 2)) {
        console.log(`[SCPService] 🧬 WEAK CRYSTAL DETECTED (Attempt ${oe + 1}). Mutating Prompt DNA...`);
        const { EvolutionEngine: Ke } = await import("./evolution_engine-BYvJr0pB.js"), le = await Ke.evolve(R, q, 0.4);
        if (le) {
          q = le, oe++;
          continue;
        }
      }
      break;
    } catch (b) {
      if (oe++, oe > lt) throw b;
      console.warn(`[SCPService] Generation attempt ${oe} failed. Mutating via retry...`), await Ze(100);
    }
  let ce;
  try {
    let O = se.content;
    const M = O.match(/```(?:json)?\s*([\s\S]*?)```/);
    M && M[1] && (O = M[1]), ce = JSON.parse(O.trim());
  } catch (b) {
    throw new Error(`Failed to parse LLM response as JSON: ${b}`);
  }
  const ys = await jt.build(r), _s = await Os.compile(r, {
    domain: h,
    extract_numbers: !0,
    extract_entities: !0,
    extract_temporals: !0
  }), x = {
    scp_version: "1.0",
    context_id: Us(),
    created_at: (/* @__PURE__ */ new Date()).toISOString(),
    version: "1.0.0",
    tier: (t == null ? void 0 : t.id) === "sovereign_ai" ? "sovereign" : "community",
    author: t || {
      id: ((Gt = ce.author) == null ? void 0 : Gt.id) || "ai_generated",
      name: ((Wt = ce.author) == null ? void 0 : Wt.name) || e,
      reputation: 0.5
    },
    domain: h,
    source: {
      platform: "neural-bridge-compiler",
      url: "https://neural-bridge.ai/compile",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      model: e
    },
    intent: {
      primary: ((Jt = ce.intent) == null ? void 0 : Jt.primary) || "General knowledge transfer",
      status: Le.ACTIVE
    },
    constraints: (ce.constraints || []).map((b) => ({
      id: b.id,
      rule: b.rule || me.MUST,
      value: b.value,
      rationale: b.rationale
    })),
    entities: (ce.entities || []).map((b) => ({
      name: b.name,
      type: b.type,
      category: b.category
    })),
    // ========== FRACTAL KNOWLEDGE ==========
    smt_root: ys.root.semantic_hash,
    proof_tree: Object.fromEntries(_s.proof_tree.nodes),
    fractal_depth: 0,
    verification: {
      canonical_hash: "",
      semantic_invariants: (((Yt = ce.verification) == null ? void 0 : Yt.semantic_invariants) || []).map((b) => ({
        id: b.id,
        kind: b.kind || "fact_check",
        prompt: b.prompt,
        expected: {
          type: b.expected.type,
          value: b.expected.value
        },
        weight: b.weight || 1,
        strict: b.strict ?? !0,
        rationale: b.rationale
      })),
      policy: {
        min_checks: 2,
        accept_threshold: 0.7,
        max_retries: 2,
        strategy: "balanced"
      }
    },
    // ========== NEUROMORPHIC INITIALIZATION ==========
    neuromorphic_stats: {
      free_energy: 1,
      // Default to high surprise until refined
      surprise: p,
      geometric_density: l,
      // Use bit-entropy as density proxy
      is_singularity: !1
    }
  };
  if (x.tier === "sovereign" || x.tier === "trusted") {
    console.log(`[SCPService] 🧬 Initiating Hegelian Loop for ${x.tier} Tier Synthesis...`);
    try {
      const { DialecticalEngine: b } = await import("./dialectical_engine-BnXzR1Up.js"), O = await b.evolve(x.intent.primary, r);
      O.is_resilient && (console.log(`[SCPService] ✨ Abstraction Synthesized: "${O.final_thesis.substring(0, 60)}..."`), x.intent.primary = O.final_thesis, x.metadata = {
        ...x.metadata || {},
        dialectical_rounds: O.iterations,
        dialectical_synthesis: !0
      }, x.neuromorphic_stats && (x.neuromorphic_stats.free_energy = O.final_free_energy, x.neuromorphic_stats.is_singularity = O.final_accuracy > 0.9 && O.final_free_energy < 0.2), x.fractal_depth = (x.fractal_depth || 0) + 1);
    } catch (b) {
      console.warn("[SCPService] ⚖️ Dialectical Loop bypassed due to friction:", b);
    }
  }
  try {
    const { Oracle: b } = await import("./oracle-BeaRy-Zz.js"), { RealityBrancher: O } = await import("./reality_brancher-B_m3BX5N.js");
    console.log(`[Oracle] 🏮 Initiating Multiversal Simulation for Crystal ${x.context_id}...`);
    const M = await O.createBranch(x, "Conservative_Anchor"), Ke = await O.createBranch(x, "Max_Intelligence_Expansion"), le = await b.predictAndOptimize(x);
    le.original_timeline_outcome === "FAILURE" && (console.warn(`[Oracle] ⚠️ Potential failure detected in simulated future: ${le.predicted_failure}.`), x.intent.limitations = [...x.intent.limitations || [], `Pre-cognitive Patch: ${le.intervention}`], x.metadata = { ...x.metadata, time_scar: le.optimized_crystal_diff });
  } catch (b) {
    console.warn("[SCPService] 🔮 Oracle simulation failed or bypassed:", b);
  }
  try {
    const { ZKAdvancedVerifier: b } = await import("./zkv_advanced-CM2X7GDb.js"), O = [];
    for (const M of x.constraints || [])
      if (M.rule === me.CUSTOM && M.value.length > 20) {
        console.log(`[ZKV] 🛡️ Generating bit-perfect ZK-Truth Proof for constraint: ${M.id}`);
        const Ke = await b.generateZKPReceipt(M.value);
        O.push({
          ...Ke,
          target_constraint_id: M.id
        });
      }
    x.zkp_receipts = O;
  } catch (b) {
    console.error("[SCPService] 🛡️ ZKV Proof generation failure:", b);
  }
  const ut = { ...x };
  ut.verification && (ut.verification.canonical_hash = void 0), x.verification.canonical_hash = await Z.realSHA256(JSON.stringify(ut));
  try {
    const { TruthVault: b } = await Promise.resolve().then(() => Ar);
    await b.saveTruth(x);
    const { DreamingService: O } = await import("./dreaming_service-BvzMEer5.js");
    O.dream().catch((M) => console.error("[SCPService] 💤 Nightmare in dreaming loop:", M));
  } catch (b) {
    console.warn("[SCPService] 💎 Crystallization failed (Truth Vault Offline):", b);
  }
  try {
    const { FalsificationEngine: b } = await import("./falsification-Bf_0OuQe.js"), O = await b.challenge(x.intent.primary, r);
    x.rlm_stats = {
      q_score: O.resilience_score,
      usage_count: 0,
      volatility: O.survived ? 0.1 : 0.9,
      last_reward_at: (/* @__PURE__ */ new Date()).toISOString()
    }, O.survived || console.warn("[SCPService] ⚔️ Final Resilience Check FAILED. Crystal marked as volatile.");
  } catch (b) {
    console.error("[SCPService] ⚖️ Falsification hardening failed:", b);
  }
  return { crystal: x, llmResponse: se };
}
async function Gr(r, e) {
  var y, v, _, E, C;
  const t = {
    decision: "FAIL",
    score: 0,
    confidence_interval: [0, 0],
    passed_invariants: [],
    failed_invariants: [],
    ladder_level: 1,
    total_attempts: 1,
    tokens_used: 0,
    cost: 0
  }, s = e || nt({
    domain: r.domain,
    task: "verify",
    stats: r.neuromorphic_stats
  }), { SemanticProtocol: n } = await import("./semantic_protocol-DwECSbXF.js"), i = await n.performHandshake(r, s);
  if (i.resonance < 0.6)
    throw console.error(`[SCPService] 🚨 CRITICAL RESONANCE FAILURE (${i.resonance}) with ${s}.`), new Error("SEMANTIC_SYNC_FAILURE: Target model resonance too low for safe transfer.");
  const a = await Ns(r), o = await ye(
    a,
    s,
    "You are receiving context from a previous conversation. Acknowledge and internalize it."
  );
  t.tokens_used += o.tokens.total, t.cost += o.cost;
  const c = js(r), l = await ye(
    c,
    s,
    "Answer each verification question briefly and accurately based on the context received."
  );
  t.tokens_used += l.tokens.total, t.cost += l.cost;
  let u = 0, d = 0;
  for (const S of r.verification.semantic_invariants) {
    u += S.weight;
    const R = await Dt({
      crystal: r,
      question: S.prompt,
      answer: l.content,
      targetModel: s
    });
    R.score >= 0.8 ? (d += S.weight, t.passed_invariants.push(S.id)) : t.failed_invariants.push({
      id: S.id,
      expected: S.expected.value,
      actual: l.content.substring(0, 150),
      reason: R.reasoning
    });
  }
  t.score = u > 0 ? d / u : 0;
  const h = ((v = (y = r.verification) == null ? void 0 : y.semantic_invariants) == null ? void 0 : v.length) || 1, p = Math.sqrt(Math.log(2 / 0.05) / (2 * h));
  t.confidence_interval = [
    Math.max(0, t.score - p),
    Math.min(1, t.score + p)
  ];
  const g = (_ = r.verification) == null ? void 0 : _.policy, m = (g == null ? void 0 : g.accept_threshold) ?? 0.7;
  if (t.decision = t.score >= m ? "ACCEPT" : "FAIL", t.receipt = await Es.generateDecisionReceipt({
    crystal_refs: [{
      crystal_id: r.context_id,
      version: "1.0.0",
      hash: ((E = r.verification) == null ? void 0 : E.canonical_hash) || "unknown"
    }],
    question: `Verify context transfer for context_id: ${r.context_id}`,
    answer: l.content,
    verification_result: {
      invariants_used: (((C = r.verification) == null ? void 0 : C.semantic_invariants) || []).map((S) => S.id),
      invariants_passed: t.passed_invariants,
      invariants_failed: t.failed_invariants.map((S) => S.id),
      counterfactuals_passed: [],
      counterfactuals_failed: [],
      sri: t.score,
      pac_epsilon: p,
      fidelity_badge: t.score > 0.9 ? "GOLD" : t.score > 0.7 ? "SILVER" : "BRONZE"
    },
    model_config: {
      provider: "OpenRouter",
      model: s,
      temperature: 0.3,
      max_tokens: 2e3
    },
    requester: "NeuralBridge_System_Verifier",
    sign: !0
  }), t.decision === "FAIL" && t.failed_invariants.length > 0)
    try {
      const { VaccineEngine: S } = await import("./vaccine_engine-D7gTsmae.js"), R = t.failed_invariants[0];
      await S.synthesizeFromContradiction(r, {
        claim_a: R.expected,
        claim_b: R.actual
      });
    } catch (S) {
      console.warn("[SCPService] ❌ Vaccine synthesis failed:", S);
    }
  return t;
}
const er = /* @__PURE__ */ new Map(), Ps = 3e5;
async function tr(r) {
  let e = 0;
  for (let t = 0; t < r.length; t++) {
    const s = r.charCodeAt(t);
    e = (e << 5) - e + s, e = e & e;
  }
  return e.toString(36);
}
async function Wr(r) {
  const { crystal: e, invariants: t, answer: s, targetModel: n = Ut } = r;
  if (t.length === 0)
    return { results: [], cost: 0, latency: 0 };
  const a = `You are a Semantic Validator for Neural Bridge.
Validate the answer against multiple verification questions.

Crystal Constraints:
${(e.constraints || []).map((h) => `- [${h.rule}] ${h.value}`).join(`
`)}

Return a JSON array:
[{"id": "inv_001", "score": 0.0-1.0, "reasoning": "..."}]`, o = t.map(
    (h, f) => `${f + 1}. [${h.id}] ${h.prompt}`
  ).join(`
`), c = `Answer to verify: "${s}"

Questions:
${o}`, l = Date.now(), u = await ye(c, n, a), d = Date.now() - l;
  try {
    let h = u.content;
    const f = h.match(/```(?:json)?\s*([\s\S]*?)```/);
    f && f[1] && (h = f[1]);
    const p = JSON.parse(h.trim()), g = Array.isArray(p) ? p : [p];
    return { results: t.map((y) => {
      const v = g.find((_) => _.id === y.id);
      return {
        id: y.id,
        score: v && Number(v.score) || 0,
        reasoning: (v == null ? void 0 : v.reasoning) || "Not found"
      };
    }), cost: u.cost, latency: d };
  } catch {
    return {
      results: t.map((f) => ({ id: f.id, score: 0.2, reasoning: "Parse fail" })),
      cost: u.cost,
      latency: d
    };
  }
}
async function Dt(r) {
  const { crystal: e, question: t, answer: s, targetModel: n = "anthropic/claude-3.5-sonnet", useCache: i = !0 } = r;
  if (i) {
    const u = await tr(`${e.context_id}:${t}:${s}`), d = er.get(u);
    if (d && Date.now() - d.timestamp < Ps)
      return { ...d.result, cost: 0 };
  }
  const a = `You are a Semantic Validator for Neural Bridge.
Analyze if the answer is consistent with the Crystal.

Constraints:
${(e.constraints || []).map((u) => `- [${u.rule}] ${u.value}`).join(`
`)}

Return JSON: {"score": 0.0-1.0, "reasoning": "..."}`, o = `Question: ${t}
Answer: ${s}`, c = await ye(o, n, a);
  let l;
  try {
    let u = c.content;
    const d = u.match(/```(?:json)?\s*([\s\S]*?)```/);
    d && d[1] && (u = d[1]);
    const h = JSON.parse(u.trim());
    l = {
      score: Number(h.score) || 0,
      reasoning: String(h.reasoning) || "none",
      cost: c.cost
    };
  } catch {
    l = { score: 0.2, reasoning: "Fail", cost: c.cost };
  }
  if (i) {
    const u = await tr(`${e.context_id}:${t}:${s}`);
    er.set(u, { result: l, timestamp: Date.now() });
  }
  return l;
}
async function Ns(r) {
  const { LatentAnchor: e } = await Promise.resolve().then(() => wa);
  return `SYSTEM ADVISORY: LATENT ANCHOR INJECTION DETECTED
---
${e.anchor(r)}

Acknowledge initialization.`.trim();
}
function js(r) {
  return `Verify context transfer. Answer concisely:
${r.verification.semantic_invariants.map((e, t) => `${t + 1}. ${e.prompt}`).join(`
`)}`;
}
function Us() {
  const r = new Uint8Array(16), e = globalThis.crypto || globalThis.msCrypto;
  if (e && e.getRandomValues)
    e.getRandomValues(r);
  else
    for (let s = 0; s < 16; s++) r[s] = Math.floor(Math.random() * 256);
  r[6] = r[6] & 15 | 64, r[8] = r[8] & 63 | 128;
  const t = Array.from(r).map((s) => s.toString(16).padStart(2, "0")).join("");
  return `${t.slice(0, 8)}-${t.slice(8, 12)}-${t.slice(12, 16)}-${t.slice(16, 20)}-${t.slice(20, 32)}`;
}
function nt(r) {
  const { isCritical: e = !1, task: t = "verify", text: s = "", stats: n } = r;
  if (z.budget_mode === "performance") return z.model_stack.premium;
  if (z.budget_mode === "sovereign") return z.model_stack.local;
  if (n)
    return xs(n);
  let i = e ? 0.9 : 0.5;
  return (t === "compile" || t === "repair") && (i += 0.2), s.length > 5e3 && (i += 0.1), i > 0.85 ? z.model_stack.premium : z.model_stack.free;
}
const B = {
  generateCrystal: zr,
  verifyTransfer: Gr,
  verifyArbitrary: Dt,
  verifyBatch: Wr,
  callLLM: Kr,
  getOptimalModel: nt,
  resilientCallLLM: ye
}, Ls = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  SCPService: B,
  detectDomainAutonomously: Lt,
  generateCrystal: zr,
  getOptimalModel: nt,
  verifyArbitrary: Dt,
  verifyBatch: Wr,
  verifyTransfer: Gr
}, Symbol.toStringTag, { value: "Module" })), J = 4096, et = 32, P = J / et;
class k {
  constructor(e) {
    V(this, "data");
    e ? this.data = e : this.data = new Uint32Array(P);
  }
  /**
   * Creates a random hypervector (Independent & Identically Distributed - i.i.d)
   * Each bit has 50% chance of being 0 or 1.
   * This ensures orthogonality between unrelated concepts.
   */
  static random() {
    const e = new k();
    if (typeof globalThis < "u" && globalThis.crypto)
      globalThis.crypto.getRandomValues(e.data);
    else
      for (let t = 0; t < P; t++)
        e.data[t] = Math.floor(Math.random() * 4294967295);
    return e;
  }
  /**
   * Binds this vector with another using XOR (Involutory).
   * Used for Role-Filler pairs (e.g., Action * Purchase).
   */
  bind(e) {
    if (e.data.length !== P)
      throw new Error("Dimension mismatch");
    const t = new Uint32Array(P);
    for (let s = 0; s < P; s++)
      t[s] = this.data[s] ^ e.data[s];
    return new k(t);
  }
  /**
   * UNBIND (Reasoning) 🧠
   * Queries the structure.
   * If C = A * B, then C.unbind(A) = B.
   * Since XOR is self-inverse, this is functionally identical to bind(),
   * but semantically distinct for "Question Answering".
   */
  unbind(e) {
    return this.bind(e);
  }
  /**
   * ARITHMETICAL SUPERPOSITION (HDC 2.0) 🌌📈
   * 
   * Instead of raw binary majority, we use weighted arithmetic bundling.
   * This allows us to "sum" realities with different weights (e.g., trust scores).
   * For now, we use a bit-wise counter to simulate a "graded" consensus.
   */
  static bundle(e) {
    if (e.length === 0) return new k();
    if (e.length === 1) return new k(new Uint32Array(e[0].data));
    const t = new Uint32Array(P), s = new Int32Array(J);
    for (const n of e)
      for (let i = 0; i < J; i++) {
        const a = i >>> 5, o = i & 31, c = n.data[a] >>> o & 1;
        s[i] += c === 1 ? 1 : -1;
      }
    for (let n = 0; n < J; n++)
      if (s[n] > 0) {
        const i = n >>> 5, a = n & 31;
        t[i] |= 1 << a;
      }
    return new k(t);
  }
  /**
   * Permutation (Rotation) Π
   * Used to encode sequence/order. 
   * permute(A) != A.
   */
  /**
   * Permutation (Rotation) Π
   * 
   * RIGOROUS 4096-BIT CYCLIC SHIFT 🔄
   * Shifts every bit in the 128-word array as a single contiguous 4096-bit register.
   * This is essential for sequence encoding (e.g., A -> B != B -> A).
   */
  permute(e = 1) {
    const t = new Uint32Array(P), s = (e % J + J) % J;
    if (s === 0) return new k(new Uint32Array(this.data));
    const n = Math.floor(s / et), i = s % et;
    for (let a = 0; a < P; a++) {
      const o = (a + n) % P, c = (o + 1) % P, l = this.data[o] >>> i, u = this.data[c] << et - i;
      t[a] = l | (i === 0 ? 0 : u);
    }
    return new k(t);
  }
  /**
   * Dot Product (Hamming Similarity)
   * Measures the overlap between two vectors.
   */
  dotProduct(e) {
    let t = 0;
    for (let s = 0; s < P; s++) {
      let n = this.data[s] & e.data[s];
      for (; n !== 0; )
        t++, n &= n - 1;
    }
    return t;
  }
  /**
   * Similarity Metric (Normalized Hamming Distance)
   * Returns 0.0 (Orthogonal/Different) to 1.0 (Identical).
   */
  similarity(e) {
    let t = 0;
    for (let s = 0; s < P; s++) {
      let n = this.data[s] ^ e.data[s];
      for (; n !== 0; )
        t++, n &= n - 1;
    }
    return 1 - t / J;
  }
  toString() {
    let e = "";
    for (let t = 0; t < P; t++)
      e += this.data[t].toString(16).padStart(8, "0");
    return e;
  }
  static fromString(e) {
    const t = new Uint32Array(P);
    for (let s = 0; s < P; s++)
      t[s] = parseInt(e.substr(s * 8, 8), 16);
    return new k(t);
  }
  /**
   * SPARSE DISTRIBUTED REPRESENTATION (SDR) THINNING 🧠🧬
   * 
   * Mimics the human neocortex by reducing active bits to ~2% (Sparse).
   * This exponentially increases the system's ability to distinguish between
   * similar concepts and makes it virtually immune to noise.
   */
  static sdrThinning(e, t = 0.02) {
    const s = new Uint32Array(P), n = Math.floor(J * t);
    for (let i = 0; i < n; i++) {
      const a = (Math.imul(i, 73244475) >>> 0) % J;
      e.data[a >>> 5] >>> (a & 31) & 1 && (s[a >>> 5] |= 1 << (a & 31));
    }
    return new k(s);
  }
  /**
   * OVERLAP ⋂
   * 
   * The SDR equivalent of Similarity. 
   * Measures the absolute intersection of active bits.
   */
  /**
   * OVERLAP ⋂
   * 
   * The SDR equivalent of Similarity. 
   * Measures the absolute intersection of active bits.
   */
  static overlap(e, t) {
    let s = 0;
    for (let n = 0; n < P; n++) {
      let i = e.data[n] & t.data[n];
      i = i - (i >> 1 & 1431655765), i = (i & 858993459) + (i >> 2 & 858993459), s += (i + (i >> 4) & 252645135) * 16843009 >> 24;
    }
    return s;
  }
  /**
   * CIRCULAR CONVOLUTION (*)
   * 
   * HDC 3.0: High-order binding. 
   * Allows recursive nesting of concepts without semantic collapse.
   * Implemented via bit-wise circular shifts and XOR superposition.
   */
  static bind(e, t) {
    const s = new Uint32Array(P);
    for (let n = 0; n < P; n++) {
      const i = n % 32, a = t.data[n] << i | t.data[n] >>> 32 - i;
      s[n] = e.data[n] ^ a;
    }
    return new k(s);
  }
  /**
   * CIRCULAR UNBINDING (/)
   * 
   * If R = A * B, then B ≈ R / A. 
   * Reconstitutes the original concept from a bound relationship.
   */
  static unbind(e, t) {
    const s = new Uint32Array(P);
    for (let n = 0; n < P; n++) {
      const i = n % 32, a = e.data[n] ^ t.data[n];
      s[n] = a >>> i | a << 32 - i;
    }
    return new k(s);
  }
  /**
   * SHANNON ENTROPY (H) 📉
   * 
   * Calculates the information density of the hypervector.
   * H = -p*log2(p) - (1-p)*log2(1-p)
   */
  getEntropy() {
    let e = 0;
    for (let s = 0; s < P; s++) {
      let n = this.data[s];
      n = n - (n >> 1 & 1431655765), n = (n & 858993459) + (n >> 2 & 858993459), e += (n + (n >> 4) & 252645135) * 16843009 >> 24;
    }
    const t = e / J;
    return t === 0 || t === 1 ? 0 : -(t * Math.log2(t) + (1 - t) * Math.log2(1 - t));
  }
  /**
   * FISHER INFORMATION (F) 🏛️
   * 
   * Measures the "Certainty" of the vector.
   */
  getFisherInformation() {
    return 1 - this.getEntropy();
  }
  /**
   * BUCKET HASH (Spatial Hashing) 🪣
   * 
   * Extracts a stable Locality Sensitive Hash (LSH) for O(1) searches.
   * In HDC, nearby vectors share similar bucket hashes with high probability.
   */
  getBucketHash() {
    return this.data[0].toString(16).padStart(8, "0");
  }
}
const Mt = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Hypervector: k
}, Symbol.toStringTag, { value: "Module" }));
function it(r, e) {
  var t = {};
  for (var s in r) Object.prototype.hasOwnProperty.call(r, s) && e.indexOf(s) < 0 && (t[s] = r[s]);
  if (r != null && typeof Object.getOwnPropertySymbols == "function")
    for (var n = 0, s = Object.getOwnPropertySymbols(r); n < s.length; n++)
      e.indexOf(s[n]) < 0 && Object.prototype.propertyIsEnumerable.call(r, s[n]) && (t[s[n]] = r[s[n]]);
  return t;
}
function Ds(r, e, t, s) {
  function n(i) {
    return i instanceof t ? i : new t(function(a) {
      a(i);
    });
  }
  return new (t || (t = Promise))(function(i, a) {
    function o(u) {
      try {
        l(s.next(u));
      } catch (d) {
        a(d);
      }
    }
    function c(u) {
      try {
        l(s.throw(u));
      } catch (d) {
        a(d);
      }
    }
    function l(u) {
      u.done ? i(u.value) : n(u.value).then(o, c);
    }
    l((s = s.apply(r, e || [])).next());
  });
}
const Ms = (r) => r ? (...e) => r(...e) : (...e) => fetch(...e);
class Bt extends Error {
  constructor(e, t = "FunctionsError", s) {
    super(e), this.name = t, this.context = s;
  }
}
class Bs extends Bt {
  constructor(e) {
    super("Failed to send a request to the Edge Function", "FunctionsFetchError", e);
  }
}
class rr extends Bt {
  constructor(e) {
    super("Relay Error invoking the Edge Function", "FunctionsRelayError", e);
  }
}
class sr extends Bt {
  constructor(e) {
    super("Edge Function returned a non-2xx status code", "FunctionsHttpError", e);
  }
}
var bt;
(function(r) {
  r.Any = "any", r.ApNortheast1 = "ap-northeast-1", r.ApNortheast2 = "ap-northeast-2", r.ApSouth1 = "ap-south-1", r.ApSoutheast1 = "ap-southeast-1", r.ApSoutheast2 = "ap-southeast-2", r.CaCentral1 = "ca-central-1", r.EuCentral1 = "eu-central-1", r.EuWest1 = "eu-west-1", r.EuWest2 = "eu-west-2", r.EuWest3 = "eu-west-3", r.SaEast1 = "sa-east-1", r.UsEast1 = "us-east-1", r.UsWest1 = "us-west-1", r.UsWest2 = "us-west-2";
})(bt || (bt = {}));
class qs {
  /**
   * Creates a new Functions client bound to an Edge Functions URL.
   *
   * @example
   * ```ts
   * import { FunctionsClient, FunctionRegion } from '@supabase/functions-js'
   *
   * const functions = new FunctionsClient('https://xyzcompany.supabase.co/functions/v1', {
   *   headers: { apikey: 'public-anon-key' },
   *   region: FunctionRegion.UsEast1,
   * })
   * ```
   */
  constructor(e, { headers: t = {}, customFetch: s, region: n = bt.Any } = {}) {
    this.url = e, this.headers = t, this.region = n, this.fetch = Ms(s);
  }
  /**
   * Updates the authorization header
   * @param token - the new jwt token sent in the authorisation header
   * @example
   * ```ts
   * functions.setAuth(session.access_token)
   * ```
   */
  setAuth(e) {
    this.headers.Authorization = `Bearer ${e}`;
  }
  /**
   * Invokes a function
   * @param functionName - The name of the Function to invoke.
   * @param options - Options for invoking the Function.
   * @example
   * ```ts
   * const { data, error } = await functions.invoke('hello-world', {
   *   body: { name: 'Ada' },
   * })
   * ```
   */
  invoke(e) {
    return Ds(this, arguments, void 0, function* (t, s = {}) {
      var n;
      let i, a;
      try {
        const { headers: o, method: c, body: l, signal: u, timeout: d } = s;
        let h = {}, { region: f } = s;
        f || (f = this.region);
        const p = new URL(`${this.url}/${t}`);
        f && f !== "any" && (h["x-region"] = f, p.searchParams.set("forceFunctionRegion", f));
        let g;
        l && (o && !Object.prototype.hasOwnProperty.call(o, "Content-Type") || !o) ? typeof Blob < "u" && l instanceof Blob || l instanceof ArrayBuffer ? (h["Content-Type"] = "application/octet-stream", g = l) : typeof l == "string" ? (h["Content-Type"] = "text/plain", g = l) : typeof FormData < "u" && l instanceof FormData ? g = l : (h["Content-Type"] = "application/json", g = JSON.stringify(l)) : l && typeof l != "string" && !(typeof Blob < "u" && l instanceof Blob) && !(l instanceof ArrayBuffer) && !(typeof FormData < "u" && l instanceof FormData) ? g = JSON.stringify(l) : g = l;
        let m = u;
        d && (a = new AbortController(), i = setTimeout(() => a.abort(), d), u ? (m = a.signal, u.addEventListener("abort", () => a.abort())) : m = a.signal);
        const y = yield this.fetch(p.toString(), {
          method: c || "POST",
          // headers priority is (high to low):
          // 1. invoke-level headers
          // 2. client-level headers
          // 3. default Content-Type header
          headers: Object.assign(Object.assign(Object.assign({}, h), this.headers), o),
          body: g,
          signal: m
        }).catch((C) => {
          throw new Bs(C);
        }), v = y.headers.get("x-relay-error");
        if (v && v === "true")
          throw new rr(y);
        if (!y.ok)
          throw new sr(y);
        let _ = ((n = y.headers.get("Content-Type")) !== null && n !== void 0 ? n : "text/plain").split(";")[0].trim(), E;
        return _ === "application/json" ? E = yield y.json() : _ === "application/octet-stream" || _ === "application/pdf" ? E = yield y.blob() : _ === "text/event-stream" ? E = y : _ === "multipart/form-data" ? E = yield y.formData() : E = yield y.text(), { data: E, error: null, response: y };
      } catch (o) {
        return {
          data: null,
          error: o,
          response: o instanceof sr || o instanceof rr ? o.context : void 0
        };
      } finally {
        i && clearTimeout(i);
      }
    });
  }
}
var Fs = class extends Error {
  /**
  * @example
  * ```ts
  * import PostgrestError from '@supabase/postgrest-js'
  *
  * throw new PostgrestError({
  *   message: 'Row level security prevented the request',
  *   details: 'RLS denied the insert',
  *   hint: 'Check your policies',
  *   code: 'PGRST301',
  * })
  * ```
  */
  constructor(r) {
    super(r.message), this.name = "PostgrestError", this.details = r.details, this.hint = r.hint, this.code = r.code;
  }
}, Hs = class {
  /**
  * Creates a builder configured for a specific PostgREST request.
  *
  * @example
  * ```ts
  * import PostgrestQueryBuilder from '@supabase/postgrest-js'
  *
  * const builder = new PostgrestQueryBuilder(
  *   new URL('https://xyzcompany.supabase.co/rest/v1/users'),
  *   { headers: new Headers({ apikey: 'public-anon-key' }) }
  * )
  * ```
  */
  constructor(r) {
    var e, t;
    this.shouldThrowOnError = !1, this.method = r.method, this.url = r.url, this.headers = new Headers(r.headers), this.schema = r.schema, this.body = r.body, this.shouldThrowOnError = (e = r.shouldThrowOnError) !== null && e !== void 0 ? e : !1, this.signal = r.signal, this.isMaybeSingle = (t = r.isMaybeSingle) !== null && t !== void 0 ? t : !1, r.fetch ? this.fetch = r.fetch : this.fetch = fetch;
  }
  /**
  * If there's an error with the query, throwOnError will reject the promise by
  * throwing the error instead of returning it as part of a successful response.
  *
  * {@link https://github.com/supabase/supabase-js/issues/92}
  */
  throwOnError() {
    return this.shouldThrowOnError = !0, this;
  }
  /**
  * Set an HTTP header for the request.
  */
  setHeader(r, e) {
    return this.headers = new Headers(this.headers), this.headers.set(r, e), this;
  }
  then(r, e) {
    var t = this;
    this.schema === void 0 || (["GET", "HEAD"].includes(this.method) ? this.headers.set("Accept-Profile", this.schema) : this.headers.set("Content-Profile", this.schema)), this.method !== "GET" && this.method !== "HEAD" && this.headers.set("Content-Type", "application/json");
    const s = this.fetch;
    let n = s(this.url.toString(), {
      method: this.method,
      headers: this.headers,
      body: JSON.stringify(this.body),
      signal: this.signal
    }).then(async (i) => {
      let a = null, o = null, c = null, l = i.status, u = i.statusText;
      if (i.ok) {
        var d, h;
        if (t.method !== "HEAD") {
          var f;
          const y = await i.text();
          y === "" || (t.headers.get("Accept") === "text/csv" || t.headers.get("Accept") && (!((f = t.headers.get("Accept")) === null || f === void 0) && f.includes("application/vnd.pgrst.plan+text")) ? o = y : o = JSON.parse(y));
        }
        const g = (d = t.headers.get("Prefer")) === null || d === void 0 ? void 0 : d.match(/count=(exact|planned|estimated)/), m = (h = i.headers.get("content-range")) === null || h === void 0 ? void 0 : h.split("/");
        g && m && m.length > 1 && (c = parseInt(m[1])), t.isMaybeSingle && t.method === "GET" && Array.isArray(o) && (o.length > 1 ? (a = {
          code: "PGRST116",
          details: `Results contain ${o.length} rows, application/vnd.pgrst.object+json requires 1 row`,
          hint: null,
          message: "JSON object requested, multiple (or no) rows returned"
        }, o = null, c = null, l = 406, u = "Not Acceptable") : o.length === 1 ? o = o[0] : o = null);
      } else {
        var p;
        const g = await i.text();
        try {
          a = JSON.parse(g), Array.isArray(a) && i.status === 404 && (o = [], a = null, l = 200, u = "OK");
        } catch {
          i.status === 404 && g === "" ? (l = 204, u = "No Content") : a = { message: g };
        }
        if (a && t.isMaybeSingle && (!(a == null || (p = a.details) === null || p === void 0) && p.includes("0 rows")) && (a = null, l = 200, u = "OK"), a && t.shouldThrowOnError) throw new Fs(a);
      }
      return {
        error: a,
        data: o,
        count: c,
        status: l,
        statusText: u
      };
    });
    return this.shouldThrowOnError || (n = n.catch((i) => {
      var a;
      let o = "";
      const c = i == null ? void 0 : i.cause;
      if (c) {
        var l, u, d, h;
        const p = (l = c == null ? void 0 : c.message) !== null && l !== void 0 ? l : "", g = (u = c == null ? void 0 : c.code) !== null && u !== void 0 ? u : "";
        o = `${(d = i == null ? void 0 : i.name) !== null && d !== void 0 ? d : "FetchError"}: ${i == null ? void 0 : i.message}`, o += `

Caused by: ${(h = c == null ? void 0 : c.name) !== null && h !== void 0 ? h : "Error"}: ${p}`, g && (o += ` (${g})`), c != null && c.stack && (o += `
${c.stack}`);
      } else {
        var f;
        o = (f = i == null ? void 0 : i.stack) !== null && f !== void 0 ? f : "";
      }
      return {
        error: {
          message: `${(a = i == null ? void 0 : i.name) !== null && a !== void 0 ? a : "FetchError"}: ${i == null ? void 0 : i.message}`,
          details: o,
          hint: "",
          code: ""
        },
        data: null,
        count: null,
        status: 0,
        statusText: ""
      };
    })), n.then(r, e);
  }
  /**
  * Override the type of the returned `data`.
  *
  * @typeParam NewResult - The new result type to override with
  * @deprecated Use overrideTypes<yourType, { merge: false }>() method at the end of your call chain instead
  */
  returns() {
    return this;
  }
  /**
  * Override the type of the returned `data` field in the response.
  *
  * @typeParam NewResult - The new type to cast the response data to
  * @typeParam Options - Optional type configuration (defaults to { merge: true })
  * @typeParam Options.merge - When true, merges the new type with existing return type. When false, replaces the existing types entirely (defaults to true)
  * @example
  * ```typescript
  * // Merge with existing types (default behavior)
  * const query = supabase
  *   .from('users')
  *   .select()
  *   .overrideTypes<{ custom_field: string }>()
  *
  * // Replace existing types completely
  * const replaceQuery = supabase
  *   .from('users')
  *   .select()
  *   .overrideTypes<{ id: number; name: string }, { merge: false }>()
  * ```
  * @returns A PostgrestBuilder instance with the new type
  */
  overrideTypes() {
    return this;
  }
}, Vs = class extends Hs {
  /**
  * Perform a SELECT on the query result.
  *
  * By default, `.insert()`, `.update()`, `.upsert()`, and `.delete()` do not
  * return modified rows. By calling this method, modified rows are returned in
  * `data`.
  *
  * @param columns - The columns to retrieve, separated by commas
  */
  select(r) {
    let e = !1;
    const t = (r ?? "*").split("").map((s) => /\s/.test(s) && !e ? "" : (s === '"' && (e = !e), s)).join("");
    return this.url.searchParams.set("select", t), this.headers.append("Prefer", "return=representation"), this;
  }
  /**
  * Order the query result by `column`.
  *
  * You can call this method multiple times to order by multiple columns.
  *
  * You can order referenced tables, but it only affects the ordering of the
  * parent table if you use `!inner` in the query.
  *
  * @param column - The column to order by
  * @param options - Named parameters
  * @param options.ascending - If `true`, the result will be in ascending order
  * @param options.nullsFirst - If `true`, `null`s appear first. If `false`,
  * `null`s appear last.
  * @param options.referencedTable - Set this to order a referenced table by
  * its columns
  * @param options.foreignTable - Deprecated, use `options.referencedTable`
  * instead
  */
  order(r, { ascending: e = !0, nullsFirst: t, foreignTable: s, referencedTable: n = s } = {}) {
    const i = n ? `${n}.order` : "order", a = this.url.searchParams.get(i);
    return this.url.searchParams.set(i, `${a ? `${a},` : ""}${r}.${e ? "asc" : "desc"}${t === void 0 ? "" : t ? ".nullsfirst" : ".nullslast"}`), this;
  }
  /**
  * Limit the query result by `count`.
  *
  * @param count - The maximum number of rows to return
  * @param options - Named parameters
  * @param options.referencedTable - Set this to limit rows of referenced
  * tables instead of the parent table
  * @param options.foreignTable - Deprecated, use `options.referencedTable`
  * instead
  */
  limit(r, { foreignTable: e, referencedTable: t = e } = {}) {
    const s = typeof t > "u" ? "limit" : `${t}.limit`;
    return this.url.searchParams.set(s, `${r}`), this;
  }
  /**
  * Limit the query result by starting at an offset `from` and ending at the offset `to`.
  * Only records within this range are returned.
  * This respects the query order and if there is no order clause the range could behave unexpectedly.
  * The `from` and `to` values are 0-based and inclusive: `range(1, 3)` will include the second, third
  * and fourth rows of the query.
  *
  * @param from - The starting index from which to limit the result
  * @param to - The last index to which to limit the result
  * @param options - Named parameters
  * @param options.referencedTable - Set this to limit rows of referenced
  * tables instead of the parent table
  * @param options.foreignTable - Deprecated, use `options.referencedTable`
  * instead
  */
  range(r, e, { foreignTable: t, referencedTable: s = t } = {}) {
    const n = typeof s > "u" ? "offset" : `${s}.offset`, i = typeof s > "u" ? "limit" : `${s}.limit`;
    return this.url.searchParams.set(n, `${r}`), this.url.searchParams.set(i, `${e - r + 1}`), this;
  }
  /**
  * Set the AbortSignal for the fetch request.
  *
  * @param signal - The AbortSignal to use for the fetch request
  */
  abortSignal(r) {
    return this.signal = r, this;
  }
  /**
  * Return `data` as a single object instead of an array of objects.
  *
  * Query result must be one row (e.g. using `.limit(1)`), otherwise this
  * returns an error.
  */
  single() {
    return this.headers.set("Accept", "application/vnd.pgrst.object+json"), this;
  }
  /**
  * Return `data` as a single object instead of an array of objects.
  *
  * Query result must be zero or one row (e.g. using `.limit(1)`), otherwise
  * this returns an error.
  */
  maybeSingle() {
    return this.method === "GET" ? this.headers.set("Accept", "application/json") : this.headers.set("Accept", "application/vnd.pgrst.object+json"), this.isMaybeSingle = !0, this;
  }
  /**
  * Return `data` as a string in CSV format.
  */
  csv() {
    return this.headers.set("Accept", "text/csv"), this;
  }
  /**
  * Return `data` as an object in [GeoJSON](https://geojson.org) format.
  */
  geojson() {
    return this.headers.set("Accept", "application/geo+json"), this;
  }
  /**
  * Return `data` as the EXPLAIN plan for the query.
  *
  * You need to enable the
  * [db_plan_enabled](https://supabase.com/docs/guides/database/debugging-performance#enabling-explain)
  * setting before using this method.
  *
  * @param options - Named parameters
  *
  * @param options.analyze - If `true`, the query will be executed and the
  * actual run time will be returned
  *
  * @param options.verbose - If `true`, the query identifier will be returned
  * and `data` will include the output columns of the query
  *
  * @param options.settings - If `true`, include information on configuration
  * parameters that affect query planning
  *
  * @param options.buffers - If `true`, include information on buffer usage
  *
  * @param options.wal - If `true`, include information on WAL record generation
  *
  * @param options.format - The format of the output, can be `"text"` (default)
  * or `"json"`
  */
  explain({ analyze: r = !1, verbose: e = !1, settings: t = !1, buffers: s = !1, wal: n = !1, format: i = "text" } = {}) {
    var a;
    const o = [
      r ? "analyze" : null,
      e ? "verbose" : null,
      t ? "settings" : null,
      s ? "buffers" : null,
      n ? "wal" : null
    ].filter(Boolean).join("|"), c = (a = this.headers.get("Accept")) !== null && a !== void 0 ? a : "application/json";
    return this.headers.set("Accept", `application/vnd.pgrst.plan+${i}; for="${c}"; options=${o};`), i === "json" ? this : this;
  }
  /**
  * Rollback the query.
  *
  * `data` will still be returned, but the query is not committed.
  */
  rollback() {
    return this.headers.append("Prefer", "tx=rollback"), this;
  }
  /**
  * Override the type of the returned `data`.
  *
  * @typeParam NewResult - The new result type to override with
  * @deprecated Use overrideTypes<yourType, { merge: false }>() method at the end of your call chain instead
  */
  returns() {
    return this;
  }
  /**
  * Set the maximum number of rows that can be affected by the query.
  * Only available in PostgREST v13+ and only works with PATCH and DELETE methods.
  *
  * @param value - The maximum number of rows that can be affected
  */
  maxAffected(r) {
    return this.headers.append("Prefer", "handling=strict"), this.headers.append("Prefer", `max-affected=${r}`), this;
  }
};
const nr = /* @__PURE__ */ new RegExp("[,()]");
var Ae = class extends Vs {
  /**
  * Match only rows where `column` is equal to `value`.
  *
  * To check if the value of `column` is NULL, you should use `.is()` instead.
  *
  * @param column - The column to filter on
  * @param value - The value to filter with
  */
  eq(r, e) {
    return this.url.searchParams.append(r, `eq.${e}`), this;
  }
  /**
  * Match only rows where `column` is not equal to `value`.
  *
  * @param column - The column to filter on
  * @param value - The value to filter with
  */
  neq(r, e) {
    return this.url.searchParams.append(r, `neq.${e}`), this;
  }
  /**
  * Match only rows where `column` is greater than `value`.
  *
  * @param column - The column to filter on
  * @param value - The value to filter with
  */
  gt(r, e) {
    return this.url.searchParams.append(r, `gt.${e}`), this;
  }
  /**
  * Match only rows where `column` is greater than or equal to `value`.
  *
  * @param column - The column to filter on
  * @param value - The value to filter with
  */
  gte(r, e) {
    return this.url.searchParams.append(r, `gte.${e}`), this;
  }
  /**
  * Match only rows where `column` is less than `value`.
  *
  * @param column - The column to filter on
  * @param value - The value to filter with
  */
  lt(r, e) {
    return this.url.searchParams.append(r, `lt.${e}`), this;
  }
  /**
  * Match only rows where `column` is less than or equal to `value`.
  *
  * @param column - The column to filter on
  * @param value - The value to filter with
  */
  lte(r, e) {
    return this.url.searchParams.append(r, `lte.${e}`), this;
  }
  /**
  * Match only rows where `column` matches `pattern` case-sensitively.
  *
  * @param column - The column to filter on
  * @param pattern - The pattern to match with
  */
  like(r, e) {
    return this.url.searchParams.append(r, `like.${e}`), this;
  }
  /**
  * Match only rows where `column` matches all of `patterns` case-sensitively.
  *
  * @param column - The column to filter on
  * @param patterns - The patterns to match with
  */
  likeAllOf(r, e) {
    return this.url.searchParams.append(r, `like(all).{${e.join(",")}}`), this;
  }
  /**
  * Match only rows where `column` matches any of `patterns` case-sensitively.
  *
  * @param column - The column to filter on
  * @param patterns - The patterns to match with
  */
  likeAnyOf(r, e) {
    return this.url.searchParams.append(r, `like(any).{${e.join(",")}}`), this;
  }
  /**
  * Match only rows where `column` matches `pattern` case-insensitively.
  *
  * @param column - The column to filter on
  * @param pattern - The pattern to match with
  */
  ilike(r, e) {
    return this.url.searchParams.append(r, `ilike.${e}`), this;
  }
  /**
  * Match only rows where `column` matches all of `patterns` case-insensitively.
  *
  * @param column - The column to filter on
  * @param patterns - The patterns to match with
  */
  ilikeAllOf(r, e) {
    return this.url.searchParams.append(r, `ilike(all).{${e.join(",")}}`), this;
  }
  /**
  * Match only rows where `column` matches any of `patterns` case-insensitively.
  *
  * @param column - The column to filter on
  * @param patterns - The patterns to match with
  */
  ilikeAnyOf(r, e) {
    return this.url.searchParams.append(r, `ilike(any).{${e.join(",")}}`), this;
  }
  /**
  * Match only rows where `column` matches the PostgreSQL regex `pattern`
  * case-sensitively (using the `~` operator).
  *
  * @param column - The column to filter on
  * @param pattern - The PostgreSQL regular expression pattern to match with
  */
  regexMatch(r, e) {
    return this.url.searchParams.append(r, `match.${e}`), this;
  }
  /**
  * Match only rows where `column` matches the PostgreSQL regex `pattern`
  * case-insensitively (using the `~*` operator).
  *
  * @param column - The column to filter on
  * @param pattern - The PostgreSQL regular expression pattern to match with
  */
  regexIMatch(r, e) {
    return this.url.searchParams.append(r, `imatch.${e}`), this;
  }
  /**
  * Match only rows where `column` IS `value`.
  *
  * For non-boolean columns, this is only relevant for checking if the value of
  * `column` is NULL by setting `value` to `null`.
  *
  * For boolean columns, you can also set `value` to `true` or `false` and it
  * will behave the same way as `.eq()`.
  *
  * @param column - The column to filter on
  * @param value - The value to filter with
  */
  is(r, e) {
    return this.url.searchParams.append(r, `is.${e}`), this;
  }
  /**
  * Match only rows where `column` IS DISTINCT FROM `value`.
  *
  * Unlike `.neq()`, this treats `NULL` as a comparable value. Two `NULL` values
  * are considered equal (not distinct), and comparing `NULL` with any non-NULL
  * value returns true (distinct).
  *
  * @param column - The column to filter on
  * @param value - The value to filter with
  */
  isDistinct(r, e) {
    return this.url.searchParams.append(r, `isdistinct.${e}`), this;
  }
  /**
  * Match only rows where `column` is included in the `values` array.
  *
  * @param column - The column to filter on
  * @param values - The values array to filter with
  */
  in(r, e) {
    const t = Array.from(new Set(e)).map((s) => typeof s == "string" && nr.test(s) ? `"${s}"` : `${s}`).join(",");
    return this.url.searchParams.append(r, `in.(${t})`), this;
  }
  /**
  * Match only rows where `column` is NOT included in the `values` array.
  *
  * @param column - The column to filter on
  * @param values - The values array to filter with
  */
  notIn(r, e) {
    const t = Array.from(new Set(e)).map((s) => typeof s == "string" && nr.test(s) ? `"${s}"` : `${s}`).join(",");
    return this.url.searchParams.append(r, `not.in.(${t})`), this;
  }
  /**
  * Only relevant for jsonb, array, and range columns. Match only rows where
  * `column` contains every element appearing in `value`.
  *
  * @param column - The jsonb, array, or range column to filter on
  * @param value - The jsonb, array, or range value to filter with
  */
  contains(r, e) {
    return typeof e == "string" ? this.url.searchParams.append(r, `cs.${e}`) : Array.isArray(e) ? this.url.searchParams.append(r, `cs.{${e.join(",")}}`) : this.url.searchParams.append(r, `cs.${JSON.stringify(e)}`), this;
  }
  /**
  * Only relevant for jsonb, array, and range columns. Match only rows where
  * every element appearing in `column` is contained by `value`.
  *
  * @param column - The jsonb, array, or range column to filter on
  * @param value - The jsonb, array, or range value to filter with
  */
  containedBy(r, e) {
    return typeof e == "string" ? this.url.searchParams.append(r, `cd.${e}`) : Array.isArray(e) ? this.url.searchParams.append(r, `cd.{${e.join(",")}}`) : this.url.searchParams.append(r, `cd.${JSON.stringify(e)}`), this;
  }
  /**
  * Only relevant for range columns. Match only rows where every element in
  * `column` is greater than any element in `range`.
  *
  * @param column - The range column to filter on
  * @param range - The range to filter with
  */
  rangeGt(r, e) {
    return this.url.searchParams.append(r, `sr.${e}`), this;
  }
  /**
  * Only relevant for range columns. Match only rows where every element in
  * `column` is either contained in `range` or greater than any element in
  * `range`.
  *
  * @param column - The range column to filter on
  * @param range - The range to filter with
  */
  rangeGte(r, e) {
    return this.url.searchParams.append(r, `nxl.${e}`), this;
  }
  /**
  * Only relevant for range columns. Match only rows where every element in
  * `column` is less than any element in `range`.
  *
  * @param column - The range column to filter on
  * @param range - The range to filter with
  */
  rangeLt(r, e) {
    return this.url.searchParams.append(r, `sl.${e}`), this;
  }
  /**
  * Only relevant for range columns. Match only rows where every element in
  * `column` is either contained in `range` or less than any element in
  * `range`.
  *
  * @param column - The range column to filter on
  * @param range - The range to filter with
  */
  rangeLte(r, e) {
    return this.url.searchParams.append(r, `nxr.${e}`), this;
  }
  /**
  * Only relevant for range columns. Match only rows where `column` is
  * mutually exclusive to `range` and there can be no element between the two
  * ranges.
  *
  * @param column - The range column to filter on
  * @param range - The range to filter with
  */
  rangeAdjacent(r, e) {
    return this.url.searchParams.append(r, `adj.${e}`), this;
  }
  /**
  * Only relevant for array and range columns. Match only rows where
  * `column` and `value` have an element in common.
  *
  * @param column - The array or range column to filter on
  * @param value - The array or range value to filter with
  */
  overlaps(r, e) {
    return typeof e == "string" ? this.url.searchParams.append(r, `ov.${e}`) : this.url.searchParams.append(r, `ov.{${e.join(",")}}`), this;
  }
  /**
  * Only relevant for text and tsvector columns. Match only rows where
  * `column` matches the query string in `query`.
  *
  * @param column - The text or tsvector column to filter on
  * @param query - The query text to match with
  * @param options - Named parameters
  * @param options.config - The text search configuration to use
  * @param options.type - Change how the `query` text is interpreted
  */
  textSearch(r, e, { config: t, type: s } = {}) {
    let n = "";
    s === "plain" ? n = "pl" : s === "phrase" ? n = "ph" : s === "websearch" && (n = "w");
    const i = t === void 0 ? "" : `(${t})`;
    return this.url.searchParams.append(r, `${n}fts${i}.${e}`), this;
  }
  /**
  * Match only rows where each column in `query` keys is equal to its
  * associated value. Shorthand for multiple `.eq()`s.
  *
  * @param query - The object to filter with, with column names as keys mapped
  * to their filter values
  */
  match(r) {
    return Object.entries(r).forEach(([e, t]) => {
      this.url.searchParams.append(e, `eq.${t}`);
    }), this;
  }
  /**
  * Match only rows which doesn't satisfy the filter.
  *
  * Unlike most filters, `opearator` and `value` are used as-is and need to
  * follow [PostgREST
  * syntax](https://postgrest.org/en/stable/api.html#operators). You also need
  * to make sure they are properly sanitized.
  *
  * @param column - The column to filter on
  * @param operator - The operator to be negated to filter with, following
  * PostgREST syntax
  * @param value - The value to filter with, following PostgREST syntax
  */
  not(r, e, t) {
    return this.url.searchParams.append(r, `not.${e}.${t}`), this;
  }
  /**
  * Match only rows which satisfy at least one of the filters.
  *
  * Unlike most filters, `filters` is used as-is and needs to follow [PostgREST
  * syntax](https://postgrest.org/en/stable/api.html#operators). You also need
  * to make sure it's properly sanitized.
  *
  * It's currently not possible to do an `.or()` filter across multiple tables.
  *
  * @param filters - The filters to use, following PostgREST syntax
  * @param options - Named parameters
  * @param options.referencedTable - Set this to filter on referenced tables
  * instead of the parent table
  * @param options.foreignTable - Deprecated, use `referencedTable` instead
  */
  or(r, { foreignTable: e, referencedTable: t = e } = {}) {
    const s = t ? `${t}.or` : "or";
    return this.url.searchParams.append(s, `(${r})`), this;
  }
  /**
  * Match only rows which satisfy the filter. This is an escape hatch - you
  * should use the specific filter methods wherever possible.
  *
  * Unlike most filters, `opearator` and `value` are used as-is and need to
  * follow [PostgREST
  * syntax](https://postgrest.org/en/stable/api.html#operators). You also need
  * to make sure they are properly sanitized.
  *
  * @param column - The column to filter on
  * @param operator - The operator to filter with, following PostgREST syntax
  * @param value - The value to filter with, following PostgREST syntax
  */
  filter(r, e, t) {
    return this.url.searchParams.append(r, `${e}.${t}`), this;
  }
}, Ks = class {
  /**
  * Creates a query builder scoped to a Postgres table or view.
  *
  * @example
  * ```ts
  * import PostgrestQueryBuilder from '@supabase/postgrest-js'
  *
  * const query = new PostgrestQueryBuilder(
  *   new URL('https://xyzcompany.supabase.co/rest/v1/users'),
  *   { headers: { apikey: 'public-anon-key' } }
  * )
  * ```
  */
  constructor(r, { headers: e = {}, schema: t, fetch: s }) {
    this.url = r, this.headers = new Headers(e), this.schema = t, this.fetch = s;
  }
  /**
  * Clone URL and headers to prevent shared state between operations.
  */
  cloneRequestState() {
    return {
      url: new URL(this.url.toString()),
      headers: new Headers(this.headers)
    };
  }
  /**
  * Perform a SELECT query on the table or view.
  *
  * @param columns - The columns to retrieve, separated by commas. Columns can be renamed when returned with `customName:columnName`
  *
  * @param options - Named parameters
  *
  * @param options.head - When set to `true`, `data` will not be returned.
  * Useful if you only need the count.
  *
  * @param options.count - Count algorithm to use to count rows in the table or view.
  *
  * `"exact"`: Exact but slow count algorithm. Performs a `COUNT(*)` under the
  * hood.
  *
  * `"planned"`: Approximated but fast count algorithm. Uses the Postgres
  * statistics under the hood.
  *
  * `"estimated"`: Uses exact count for low numbers and planned count for high
  * numbers.
  *
  * @remarks
  * When using `count` with `.range()` or `.limit()`, the returned `count` is the total number of rows
  * that match your filters, not the number of rows in the current page. Use this to build pagination UI.
  */
  select(r, e) {
    const { head: t = !1, count: s } = e ?? {}, n = t ? "HEAD" : "GET";
    let i = !1;
    const a = (r ?? "*").split("").map((l) => /\s/.test(l) && !i ? "" : (l === '"' && (i = !i), l)).join(""), { url: o, headers: c } = this.cloneRequestState();
    return o.searchParams.set("select", a), s && c.append("Prefer", `count=${s}`), new Ae({
      method: n,
      url: o,
      headers: c,
      schema: this.schema,
      fetch: this.fetch
    });
  }
  /**
  * Perform an INSERT into the table or view.
  *
  * By default, inserted rows are not returned. To return it, chain the call
  * with `.select()`.
  *
  * @param values - The values to insert. Pass an object to insert a single row
  * or an array to insert multiple rows.
  *
  * @param options - Named parameters
  *
  * @param options.count - Count algorithm to use to count inserted rows.
  *
  * `"exact"`: Exact but slow count algorithm. Performs a `COUNT(*)` under the
  * hood.
  *
  * `"planned"`: Approximated but fast count algorithm. Uses the Postgres
  * statistics under the hood.
  *
  * `"estimated"`: Uses exact count for low numbers and planned count for high
  * numbers.
  *
  * @param options.defaultToNull - Make missing fields default to `null`.
  * Otherwise, use the default value for the column. Only applies for bulk
  * inserts.
  */
  insert(r, { count: e, defaultToNull: t = !0 } = {}) {
    var s;
    const n = "POST", { url: i, headers: a } = this.cloneRequestState();
    if (e && a.append("Prefer", `count=${e}`), t || a.append("Prefer", "missing=default"), Array.isArray(r)) {
      const o = r.reduce((c, l) => c.concat(Object.keys(l)), []);
      if (o.length > 0) {
        const c = [...new Set(o)].map((l) => `"${l}"`);
        i.searchParams.set("columns", c.join(","));
      }
    }
    return new Ae({
      method: n,
      url: i,
      headers: a,
      schema: this.schema,
      body: r,
      fetch: (s = this.fetch) !== null && s !== void 0 ? s : fetch
    });
  }
  /**
  * Perform an UPSERT on the table or view. Depending on the column(s) passed
  * to `onConflict`, `.upsert()` allows you to perform the equivalent of
  * `.insert()` if a row with the corresponding `onConflict` columns doesn't
  * exist, or if it does exist, perform an alternative action depending on
  * `ignoreDuplicates`.
  *
  * By default, upserted rows are not returned. To return it, chain the call
  * with `.select()`.
  *
  * @param values - The values to upsert with. Pass an object to upsert a
  * single row or an array to upsert multiple rows.
  *
  * @param options - Named parameters
  *
  * @param options.onConflict - Comma-separated UNIQUE column(s) to specify how
  * duplicate rows are determined. Two rows are duplicates if all the
  * `onConflict` columns are equal.
  *
  * @param options.ignoreDuplicates - If `true`, duplicate rows are ignored. If
  * `false`, duplicate rows are merged with existing rows.
  *
  * @param options.count - Count algorithm to use to count upserted rows.
  *
  * `"exact"`: Exact but slow count algorithm. Performs a `COUNT(*)` under the
  * hood.
  *
  * `"planned"`: Approximated but fast count algorithm. Uses the Postgres
  * statistics under the hood.
  *
  * `"estimated"`: Uses exact count for low numbers and planned count for high
  * numbers.
  *
  * @param options.defaultToNull - Make missing fields default to `null`.
  * Otherwise, use the default value for the column. This only applies when
  * inserting new rows, not when merging with existing rows under
  * `ignoreDuplicates: false`. This also only applies when doing bulk upserts.
  *
  * @example Upsert a single row using a unique key
  * ```ts
  * // Upserting a single row, overwriting based on the 'username' unique column
  * const { data, error } = await supabase
  *   .from('users')
  *   .upsert({ username: 'supabot' }, { onConflict: 'username' })
  *
  * // Example response:
  * // {
  * //   data: [
  * //     { id: 4, message: 'bar', username: 'supabot' }
  * //   ],
  * //   error: null
  * // }
  * ```
  *
  * @example Upsert with conflict resolution and exact row counting
  * ```ts
  * // Upserting and returning exact count
  * const { data, error, count } = await supabase
  *   .from('users')
  *   .upsert(
  *     {
  *       id: 3,
  *       message: 'foo',
  *       username: 'supabot'
  *     },
  *     {
  *       onConflict: 'username',
  *       count: 'exact'
  *     }
  *   )
  *
  * // Example response:
  * // {
  * //   data: [
  * //     {
  * //       id: 42,
  * //       handle: "saoirse",
  * //       display_name: "Saoirse"
  * //     }
  * //   ],
  * //   count: 1,
  * //   error: null
  * // }
  * ```
  */
  upsert(r, { onConflict: e, ignoreDuplicates: t = !1, count: s, defaultToNull: n = !0 } = {}) {
    var i;
    const a = "POST", { url: o, headers: c } = this.cloneRequestState();
    if (c.append("Prefer", `resolution=${t ? "ignore" : "merge"}-duplicates`), e !== void 0 && o.searchParams.set("on_conflict", e), s && c.append("Prefer", `count=${s}`), n || c.append("Prefer", "missing=default"), Array.isArray(r)) {
      const l = r.reduce((u, d) => u.concat(Object.keys(d)), []);
      if (l.length > 0) {
        const u = [...new Set(l)].map((d) => `"${d}"`);
        o.searchParams.set("columns", u.join(","));
      }
    }
    return new Ae({
      method: a,
      url: o,
      headers: c,
      schema: this.schema,
      body: r,
      fetch: (i = this.fetch) !== null && i !== void 0 ? i : fetch
    });
  }
  /**
  * Perform an UPDATE on the table or view.
  *
  * By default, updated rows are not returned. To return it, chain the call
  * with `.select()` after filters.
  *
  * @param values - The values to update with
  *
  * @param options - Named parameters
  *
  * @param options.count - Count algorithm to use to count updated rows.
  *
  * `"exact"`: Exact but slow count algorithm. Performs a `COUNT(*)` under the
  * hood.
  *
  * `"planned"`: Approximated but fast count algorithm. Uses the Postgres
  * statistics under the hood.
  *
  * `"estimated"`: Uses exact count for low numbers and planned count for high
  * numbers.
  */
  update(r, { count: e } = {}) {
    var t;
    const s = "PATCH", { url: n, headers: i } = this.cloneRequestState();
    return e && i.append("Prefer", `count=${e}`), new Ae({
      method: s,
      url: n,
      headers: i,
      schema: this.schema,
      body: r,
      fetch: (t = this.fetch) !== null && t !== void 0 ? t : fetch
    });
  }
  /**
  * Perform a DELETE on the table or view.
  *
  * By default, deleted rows are not returned. To return it, chain the call
  * with `.select()` after filters.
  *
  * @param options - Named parameters
  *
  * @param options.count - Count algorithm to use to count deleted rows.
  *
  * `"exact"`: Exact but slow count algorithm. Performs a `COUNT(*)` under the
  * hood.
  *
  * `"planned"`: Approximated but fast count algorithm. Uses the Postgres
  * statistics under the hood.
  *
  * `"estimated"`: Uses exact count for low numbers and planned count for high
  * numbers.
  */
  delete({ count: r } = {}) {
    var e;
    const t = "DELETE", { url: s, headers: n } = this.cloneRequestState();
    return r && n.append("Prefer", `count=${r}`), new Ae({
      method: t,
      url: s,
      headers: n,
      schema: this.schema,
      fetch: (e = this.fetch) !== null && e !== void 0 ? e : fetch
    });
  }
}, zs = class Jr {
  /**
  * Creates a PostgREST client.
  *
  * @param url - URL of the PostgREST endpoint
  * @param options - Named parameters
  * @param options.headers - Custom headers
  * @param options.schema - Postgres schema to switch to
  * @param options.fetch - Custom fetch
  * @example
  * ```ts
  * import PostgrestClient from '@supabase/postgrest-js'
  *
  * const postgrest = new PostgrestClient('https://xyzcompany.supabase.co/rest/v1', {
  *   headers: { apikey: 'public-anon-key' },
  *   schema: 'public',
  * })
  * ```
  */
  constructor(e, { headers: t = {}, schema: s, fetch: n } = {}) {
    this.url = e, this.headers = new Headers(t), this.schemaName = s, this.fetch = n;
  }
  /**
  * Perform a query on a table or a view.
  *
  * @param relation - The table or view name to query
  */
  from(e) {
    if (!e || typeof e != "string" || e.trim() === "") throw new Error("Invalid relation name: relation must be a non-empty string.");
    return new Ks(new URL(`${this.url}/${e}`), {
      headers: new Headers(this.headers),
      schema: this.schemaName,
      fetch: this.fetch
    });
  }
  /**
  * Select a schema to query or perform an function (rpc) call.
  *
  * The schema needs to be on the list of exposed schemas inside Supabase.
  *
  * @param schema - The schema to query
  */
  schema(e) {
    return new Jr(this.url, {
      headers: this.headers,
      schema: e,
      fetch: this.fetch
    });
  }
  /**
  * Perform a function call.
  *
  * @param fn - The function name to call
  * @param args - The arguments to pass to the function call
  * @param options - Named parameters
  * @param options.head - When set to `true`, `data` will not be returned.
  * Useful if you only need the count.
  * @param options.get - When set to `true`, the function will be called with
  * read-only access mode.
  * @param options.count - Count algorithm to use to count rows returned by the
  * function. Only applicable for [set-returning
  * functions](https://www.postgresql.org/docs/current/functions-srf.html).
  *
  * `"exact"`: Exact but slow count algorithm. Performs a `COUNT(*)` under the
  * hood.
  *
  * `"planned"`: Approximated but fast count algorithm. Uses the Postgres
  * statistics under the hood.
  *
  * `"estimated"`: Uses exact count for low numbers and planned count for high
  * numbers.
  *
  * @example
  * ```ts
  * // For cross-schema functions where type inference fails, use overrideTypes:
  * const { data } = await supabase
  *   .schema('schema_b')
  *   .rpc('function_a', {})
  *   .overrideTypes<{ id: string; user_id: string }[]>()
  * ```
  */
  rpc(e, t = {}, { head: s = !1, get: n = !1, count: i } = {}) {
    var a;
    let o;
    const c = new URL(`${this.url}/rpc/${e}`);
    let l;
    const u = (f) => f !== null && typeof f == "object" && (!Array.isArray(f) || f.some(u)), d = s && Object.values(t).some(u);
    d ? (o = "POST", l = t) : s || n ? (o = s ? "HEAD" : "GET", Object.entries(t).filter(([f, p]) => p !== void 0).map(([f, p]) => [f, Array.isArray(p) ? `{${p.join(",")}}` : `${p}`]).forEach(([f, p]) => {
      c.searchParams.append(f, p);
    })) : (o = "POST", l = t);
    const h = new Headers(this.headers);
    return d ? h.set("Prefer", i ? `count=${i},return=minimal` : "return=minimal") : i && h.set("Prefer", `count=${i}`), new Ae({
      method: o,
      url: c,
      headers: h,
      schema: this.schemaName,
      body: l,
      fetch: (a = this.fetch) !== null && a !== void 0 ? a : fetch
    });
  }
};
class Gs {
  /**
   * Static-only utility – prevent instantiation.
   */
  constructor() {
  }
  static detectEnvironment() {
    var e;
    if (typeof WebSocket < "u")
      return { type: "native", constructor: WebSocket };
    if (typeof globalThis < "u" && typeof globalThis.WebSocket < "u")
      return { type: "native", constructor: globalThis.WebSocket };
    if (typeof global < "u" && typeof global.WebSocket < "u")
      return { type: "native", constructor: global.WebSocket };
    if (typeof globalThis < "u" && typeof globalThis.WebSocketPair < "u" && typeof globalThis.WebSocket > "u")
      return {
        type: "cloudflare",
        error: "Cloudflare Workers detected. WebSocket clients are not supported in Cloudflare Workers.",
        workaround: "Use Cloudflare Workers WebSocket API for server-side WebSocket handling, or deploy to a different runtime."
      };
    if (typeof globalThis < "u" && globalThis.EdgeRuntime || typeof navigator < "u" && (!((e = navigator.userAgent) === null || e === void 0) && e.includes("Vercel-Edge")))
      return {
        type: "unsupported",
        error: "Edge runtime detected (Vercel Edge/Netlify Edge). WebSockets are not supported in edge functions.",
        workaround: "Use serverless functions or a different deployment target for WebSocket functionality."
      };
    const t = globalThis.process;
    if (t) {
      const s = t.versions;
      if (s && s.node) {
        const n = s.node, i = parseInt(n.replace(/^v/, "").split(".")[0]);
        return i >= 22 ? typeof globalThis.WebSocket < "u" ? { type: "native", constructor: globalThis.WebSocket } : {
          type: "unsupported",
          error: `Node.js ${i} detected but native WebSocket not found.`,
          workaround: "Provide a WebSocket implementation via the transport option."
        } : {
          type: "unsupported",
          error: `Node.js ${i} detected without native WebSocket support.`,
          workaround: `For Node.js < 22, install "ws" package and provide it via the transport option:
import ws from "ws"
new RealtimeClient(url, { transport: ws })`
        };
      }
    }
    return {
      type: "unsupported",
      error: "Unknown JavaScript runtime without WebSocket support.",
      workaround: "Ensure you're running in a supported environment (browser, Node.js, Deno) or provide a custom WebSocket implementation."
    };
  }
  /**
   * Returns the best available WebSocket constructor for the current runtime.
   *
   * @example
   * ```ts
   * const WS = WebSocketFactory.getWebSocketConstructor()
   * const socket = new WS('wss://realtime.supabase.co/socket')
   * ```
   */
  static getWebSocketConstructor() {
    const e = this.detectEnvironment();
    if (e.constructor)
      return e.constructor;
    let t = e.error || "WebSocket not supported in this environment.";
    throw e.workaround && (t += `

Suggested solution: ${e.workaround}`), new Error(t);
  }
  /**
   * Creates a WebSocket using the detected constructor.
   *
   * @example
   * ```ts
   * const socket = WebSocketFactory.createWebSocket('wss://realtime.supabase.co/socket')
   * ```
   */
  static createWebSocket(e, t) {
    const s = this.getWebSocketConstructor();
    return new s(e, t);
  }
  /**
   * Detects whether the runtime can establish WebSocket connections.
   *
   * @example
   * ```ts
   * if (!WebSocketFactory.isWebSocketSupported()) {
   *   console.warn('Falling back to long polling')
   * }
   * ```
   */
  static isWebSocketSupported() {
    try {
      const e = this.detectEnvironment();
      return e.type === "native" || e.type === "ws";
    } catch {
      return !1;
    }
  }
}
const Ws = "2.93.3", Js = `realtime-js/${Ws}`, Ys = "1.0.0", Yr = "2.0.0", ir = Yr, St = 1e4, Xs = 1e3, Qs = 100;
var ne;
(function(r) {
  r[r.connecting = 0] = "connecting", r[r.open = 1] = "open", r[r.closing = 2] = "closing", r[r.closed = 3] = "closed";
})(ne || (ne = {}));
var U;
(function(r) {
  r.closed = "closed", r.errored = "errored", r.joined = "joined", r.joining = "joining", r.leaving = "leaving";
})(U || (U = {}));
var Q;
(function(r) {
  r.close = "phx_close", r.error = "phx_error", r.join = "phx_join", r.reply = "phx_reply", r.leave = "phx_leave", r.access_token = "access_token";
})(Q || (Q = {}));
var Et;
(function(r) {
  r.websocket = "websocket";
})(Et || (Et = {}));
var fe;
(function(r) {
  r.Connecting = "connecting", r.Open = "open", r.Closing = "closing", r.Closed = "closed";
})(fe || (fe = {}));
class Zs {
  constructor(e) {
    this.HEADER_LENGTH = 1, this.USER_BROADCAST_PUSH_META_LENGTH = 6, this.KINDS = { userBroadcastPush: 3, userBroadcast: 4 }, this.BINARY_ENCODING = 0, this.JSON_ENCODING = 1, this.BROADCAST_EVENT = "broadcast", this.allowedMetadataKeys = [], this.allowedMetadataKeys = e ?? [];
  }
  encode(e, t) {
    if (e.event === this.BROADCAST_EVENT && !(e.payload instanceof ArrayBuffer) && typeof e.payload.event == "string")
      return t(this._binaryEncodeUserBroadcastPush(e));
    let s = [e.join_ref, e.ref, e.topic, e.event, e.payload];
    return t(JSON.stringify(s));
  }
  _binaryEncodeUserBroadcastPush(e) {
    var t;
    return this._isArrayBuffer((t = e.payload) === null || t === void 0 ? void 0 : t.payload) ? this._encodeBinaryUserBroadcastPush(e) : this._encodeJsonUserBroadcastPush(e);
  }
  _encodeBinaryUserBroadcastPush(e) {
    var t, s;
    const n = (s = (t = e.payload) === null || t === void 0 ? void 0 : t.payload) !== null && s !== void 0 ? s : new ArrayBuffer(0);
    return this._encodeUserBroadcastPush(e, this.BINARY_ENCODING, n);
  }
  _encodeJsonUserBroadcastPush(e) {
    var t, s;
    const n = (s = (t = e.payload) === null || t === void 0 ? void 0 : t.payload) !== null && s !== void 0 ? s : {}, a = new TextEncoder().encode(JSON.stringify(n)).buffer;
    return this._encodeUserBroadcastPush(e, this.JSON_ENCODING, a);
  }
  _encodeUserBroadcastPush(e, t, s) {
    var n, i;
    const a = e.topic, o = (n = e.ref) !== null && n !== void 0 ? n : "", c = (i = e.join_ref) !== null && i !== void 0 ? i : "", l = e.payload.event, u = this.allowedMetadataKeys ? this._pick(e.payload, this.allowedMetadataKeys) : {}, d = Object.keys(u).length === 0 ? "" : JSON.stringify(u);
    if (c.length > 255)
      throw new Error(`joinRef length ${c.length} exceeds maximum of 255`);
    if (o.length > 255)
      throw new Error(`ref length ${o.length} exceeds maximum of 255`);
    if (a.length > 255)
      throw new Error(`topic length ${a.length} exceeds maximum of 255`);
    if (l.length > 255)
      throw new Error(`userEvent length ${l.length} exceeds maximum of 255`);
    if (d.length > 255)
      throw new Error(`metadata length ${d.length} exceeds maximum of 255`);
    const h = this.USER_BROADCAST_PUSH_META_LENGTH + c.length + o.length + a.length + l.length + d.length, f = new ArrayBuffer(this.HEADER_LENGTH + h);
    let p = new DataView(f), g = 0;
    p.setUint8(g++, this.KINDS.userBroadcastPush), p.setUint8(g++, c.length), p.setUint8(g++, o.length), p.setUint8(g++, a.length), p.setUint8(g++, l.length), p.setUint8(g++, d.length), p.setUint8(g++, t), Array.from(c, (y) => p.setUint8(g++, y.charCodeAt(0))), Array.from(o, (y) => p.setUint8(g++, y.charCodeAt(0))), Array.from(a, (y) => p.setUint8(g++, y.charCodeAt(0))), Array.from(l, (y) => p.setUint8(g++, y.charCodeAt(0))), Array.from(d, (y) => p.setUint8(g++, y.charCodeAt(0)));
    var m = new Uint8Array(f.byteLength + s.byteLength);
    return m.set(new Uint8Array(f), 0), m.set(new Uint8Array(s), f.byteLength), m.buffer;
  }
  decode(e, t) {
    if (this._isArrayBuffer(e)) {
      let s = this._binaryDecode(e);
      return t(s);
    }
    if (typeof e == "string") {
      const s = JSON.parse(e), [n, i, a, o, c] = s;
      return t({ join_ref: n, ref: i, topic: a, event: o, payload: c });
    }
    return t({});
  }
  _binaryDecode(e) {
    const t = new DataView(e), s = t.getUint8(0), n = new TextDecoder();
    switch (s) {
      case this.KINDS.userBroadcast:
        return this._decodeUserBroadcast(e, t, n);
    }
  }
  _decodeUserBroadcast(e, t, s) {
    const n = t.getUint8(1), i = t.getUint8(2), a = t.getUint8(3), o = t.getUint8(4);
    let c = this.HEADER_LENGTH + 4;
    const l = s.decode(e.slice(c, c + n));
    c = c + n;
    const u = s.decode(e.slice(c, c + i));
    c = c + i;
    const d = s.decode(e.slice(c, c + a));
    c = c + a;
    const h = e.slice(c, e.byteLength), f = o === this.JSON_ENCODING ? JSON.parse(s.decode(h)) : h, p = {
      type: this.BROADCAST_EVENT,
      event: u,
      payload: f
    };
    return a > 0 && (p.meta = JSON.parse(d)), { join_ref: null, ref: null, topic: l, event: this.BROADCAST_EVENT, payload: p };
  }
  _isArrayBuffer(e) {
    var t;
    return e instanceof ArrayBuffer || ((t = e == null ? void 0 : e.constructor) === null || t === void 0 ? void 0 : t.name) === "ArrayBuffer";
  }
  _pick(e, t) {
    return !e || typeof e != "object" ? {} : Object.fromEntries(Object.entries(e).filter(([s]) => t.includes(s)));
  }
}
class Xr {
  constructor(e, t) {
    this.callback = e, this.timerCalc = t, this.timer = void 0, this.tries = 0, this.callback = e, this.timerCalc = t;
  }
  reset() {
    this.tries = 0, clearTimeout(this.timer), this.timer = void 0;
  }
  // Cancels any previous scheduleTimeout and schedules callback
  scheduleTimeout() {
    clearTimeout(this.timer), this.timer = setTimeout(() => {
      this.tries = this.tries + 1, this.callback();
    }, this.timerCalc(this.tries + 1));
  }
}
var $;
(function(r) {
  r.abstime = "abstime", r.bool = "bool", r.date = "date", r.daterange = "daterange", r.float4 = "float4", r.float8 = "float8", r.int2 = "int2", r.int4 = "int4", r.int4range = "int4range", r.int8 = "int8", r.int8range = "int8range", r.json = "json", r.jsonb = "jsonb", r.money = "money", r.numeric = "numeric", r.oid = "oid", r.reltime = "reltime", r.text = "text", r.time = "time", r.timestamp = "timestamp", r.timestamptz = "timestamptz", r.timetz = "timetz", r.tsrange = "tsrange", r.tstzrange = "tstzrange";
})($ || ($ = {}));
const ar = (r, e, t = {}) => {
  var s;
  const n = (s = t.skipTypes) !== null && s !== void 0 ? s : [];
  return e ? Object.keys(e).reduce((i, a) => (i[a] = en(a, r, e, n), i), {}) : {};
}, en = (r, e, t, s) => {
  const n = e.find((o) => o.name === r), i = n == null ? void 0 : n.type, a = t[r];
  return i && !s.includes(i) ? Qr(i, a) : Tt(a);
}, Qr = (r, e) => {
  if (r.charAt(0) === "_") {
    const t = r.slice(1, r.length);
    return nn(e, t);
  }
  switch (r) {
    case $.bool:
      return tn(e);
    case $.float4:
    case $.float8:
    case $.int2:
    case $.int4:
    case $.int8:
    case $.numeric:
    case $.oid:
      return rn(e);
    case $.json:
    case $.jsonb:
      return sn(e);
    case $.timestamp:
      return an(e);
    case $.abstime:
    case $.date:
    case $.daterange:
    case $.int4range:
    case $.int8range:
    case $.money:
    case $.reltime:
    case $.text:
    case $.time:
    case $.timestamptz:
    case $.timetz:
    case $.tsrange:
    case $.tstzrange:
      return Tt(e);
    default:
      return Tt(e);
  }
}, Tt = (r) => r, tn = (r) => {
  switch (r) {
    case "t":
      return !0;
    case "f":
      return !1;
    default:
      return r;
  }
}, rn = (r) => {
  if (typeof r == "string") {
    const e = parseFloat(r);
    if (!Number.isNaN(e))
      return e;
  }
  return r;
}, sn = (r) => {
  if (typeof r == "string")
    try {
      return JSON.parse(r);
    } catch {
      return r;
    }
  return r;
}, nn = (r, e) => {
  if (typeof r != "string")
    return r;
  const t = r.length - 1, s = r[t];
  if (r[0] === "{" && s === "}") {
    let i;
    const a = r.slice(1, t);
    try {
      i = JSON.parse("[" + a + "]");
    } catch {
      i = a ? a.split(",") : [];
    }
    return i.map((o) => Qr(e, o));
  }
  return r;
}, an = (r) => typeof r == "string" ? r.replace(" ", "T") : r, Zr = (r) => {
  const e = new URL(r);
  return e.protocol = e.protocol.replace(/^ws/i, "http"), e.pathname = e.pathname.replace(/\/+$/, "").replace(/\/socket\/websocket$/i, "").replace(/\/socket$/i, "").replace(/\/websocket$/i, ""), e.pathname === "" || e.pathname === "/" ? e.pathname = "/api/broadcast" : e.pathname = e.pathname + "/api/broadcast", e.href;
};
class dt {
  /**
   * Initializes the Push
   *
   * @param channel The Channel
   * @param event The event, for example `"phx_join"`
   * @param payload The payload, for example `{user_id: 123}`
   * @param timeout The push timeout in milliseconds
   */
  constructor(e, t, s = {}, n = St) {
    this.channel = e, this.event = t, this.payload = s, this.timeout = n, this.sent = !1, this.timeoutTimer = void 0, this.ref = "", this.receivedResp = null, this.recHooks = [], this.refEvent = null;
  }
  resend(e) {
    this.timeout = e, this._cancelRefEvent(), this.ref = "", this.refEvent = null, this.receivedResp = null, this.sent = !1, this.send();
  }
  send() {
    this._hasReceived("timeout") || (this.startTimeout(), this.sent = !0, this.channel.socket.push({
      topic: this.channel.topic,
      event: this.event,
      payload: this.payload,
      ref: this.ref,
      join_ref: this.channel._joinRef()
    }));
  }
  updatePayload(e) {
    this.payload = Object.assign(Object.assign({}, this.payload), e);
  }
  receive(e, t) {
    var s;
    return this._hasReceived(e) && t((s = this.receivedResp) === null || s === void 0 ? void 0 : s.response), this.recHooks.push({ status: e, callback: t }), this;
  }
  startTimeout() {
    if (this.timeoutTimer)
      return;
    this.ref = this.channel.socket._makeRef(), this.refEvent = this.channel._replyEventName(this.ref);
    const e = (t) => {
      this._cancelRefEvent(), this._cancelTimeout(), this.receivedResp = t, this._matchReceive(t);
    };
    this.channel._on(this.refEvent, {}, e), this.timeoutTimer = setTimeout(() => {
      this.trigger("timeout", {});
    }, this.timeout);
  }
  trigger(e, t) {
    this.refEvent && this.channel._trigger(this.refEvent, { status: e, response: t });
  }
  destroy() {
    this._cancelRefEvent(), this._cancelTimeout();
  }
  _cancelRefEvent() {
    this.refEvent && this.channel._off(this.refEvent, {});
  }
  _cancelTimeout() {
    clearTimeout(this.timeoutTimer), this.timeoutTimer = void 0;
  }
  _matchReceive({ status: e, response: t }) {
    this.recHooks.filter((s) => s.status === e).forEach((s) => s.callback(t));
  }
  _hasReceived(e) {
    return this.receivedResp && this.receivedResp.status === e;
  }
}
var or;
(function(r) {
  r.SYNC = "sync", r.JOIN = "join", r.LEAVE = "leave";
})(or || (or = {}));
class je {
  /**
   * Creates a Presence helper that keeps the local presence state in sync with the server.
   *
   * @param channel - The realtime channel to bind to.
   * @param opts - Optional custom event names, e.g. `{ events: { state: 'state', diff: 'diff' } }`.
   *
   * @example
   * ```ts
   * const presence = new RealtimePresence(channel)
   *
   * channel.on('presence', ({ event, key }) => {
   *   console.log(`Presence ${event} on ${key}`)
   * })
   * ```
   */
  constructor(e, t) {
    this.channel = e, this.state = {}, this.pendingDiffs = [], this.joinRef = null, this.enabled = !1, this.caller = {
      onJoin: () => {
      },
      onLeave: () => {
      },
      onSync: () => {
      }
    };
    const s = (t == null ? void 0 : t.events) || {
      state: "presence_state",
      diff: "presence_diff"
    };
    this.channel._on(s.state, {}, (n) => {
      const { onJoin: i, onLeave: a, onSync: o } = this.caller;
      this.joinRef = this.channel._joinRef(), this.state = je.syncState(this.state, n, i, a), this.pendingDiffs.forEach((c) => {
        this.state = je.syncDiff(this.state, c, i, a);
      }), this.pendingDiffs = [], o();
    }), this.channel._on(s.diff, {}, (n) => {
      const { onJoin: i, onLeave: a, onSync: o } = this.caller;
      this.inPendingSyncState() ? this.pendingDiffs.push(n) : (this.state = je.syncDiff(this.state, n, i, a), o());
    }), this.onJoin((n, i, a) => {
      this.channel._trigger("presence", {
        event: "join",
        key: n,
        currentPresences: i,
        newPresences: a
      });
    }), this.onLeave((n, i, a) => {
      this.channel._trigger("presence", {
        event: "leave",
        key: n,
        currentPresences: i,
        leftPresences: a
      });
    }), this.onSync(() => {
      this.channel._trigger("presence", { event: "sync" });
    });
  }
  /**
   * Used to sync the list of presences on the server with the
   * client's state.
   *
   * An optional `onJoin` and `onLeave` callback can be provided to
   * react to changes in the client's local presences across
   * disconnects and reconnects with the server.
   *
   * @internal
   */
  static syncState(e, t, s, n) {
    const i = this.cloneDeep(e), a = this.transformState(t), o = {}, c = {};
    return this.map(i, (l, u) => {
      a[l] || (c[l] = u);
    }), this.map(a, (l, u) => {
      const d = i[l];
      if (d) {
        const h = u.map((m) => m.presence_ref), f = d.map((m) => m.presence_ref), p = u.filter((m) => f.indexOf(m.presence_ref) < 0), g = d.filter((m) => h.indexOf(m.presence_ref) < 0);
        p.length > 0 && (o[l] = p), g.length > 0 && (c[l] = g);
      } else
        o[l] = u;
    }), this.syncDiff(i, { joins: o, leaves: c }, s, n);
  }
  /**
   * Used to sync a diff of presence join and leave events from the
   * server, as they happen.
   *
   * Like `syncState`, `syncDiff` accepts optional `onJoin` and
   * `onLeave` callbacks to react to a user joining or leaving from a
   * device.
   *
   * @internal
   */
  static syncDiff(e, t, s, n) {
    const { joins: i, leaves: a } = {
      joins: this.transformState(t.joins),
      leaves: this.transformState(t.leaves)
    };
    return s || (s = () => {
    }), n || (n = () => {
    }), this.map(i, (o, c) => {
      var l;
      const u = (l = e[o]) !== null && l !== void 0 ? l : [];
      if (e[o] = this.cloneDeep(c), u.length > 0) {
        const d = e[o].map((f) => f.presence_ref), h = u.filter((f) => d.indexOf(f.presence_ref) < 0);
        e[o].unshift(...h);
      }
      s(o, u, c);
    }), this.map(a, (o, c) => {
      let l = e[o];
      if (!l)
        return;
      const u = c.map((d) => d.presence_ref);
      l = l.filter((d) => u.indexOf(d.presence_ref) < 0), e[o] = l, n(o, l, c), l.length === 0 && delete e[o];
    }), e;
  }
  /** @internal */
  static map(e, t) {
    return Object.getOwnPropertyNames(e).map((s) => t(s, e[s]));
  }
  /**
   * Remove 'metas' key
   * Change 'phx_ref' to 'presence_ref'
   * Remove 'phx_ref' and 'phx_ref_prev'
   *
   * @example
   * // returns {
   *  abc123: [
   *    { presence_ref: '2', user_id: 1 },
   *    { presence_ref: '3', user_id: 2 }
   *  ]
   * }
   * RealtimePresence.transformState({
   *  abc123: {
   *    metas: [
   *      { phx_ref: '2', phx_ref_prev: '1' user_id: 1 },
   *      { phx_ref: '3', user_id: 2 }
   *    ]
   *  }
   * })
   *
   * @internal
   */
  static transformState(e) {
    return e = this.cloneDeep(e), Object.getOwnPropertyNames(e).reduce((t, s) => {
      const n = e[s];
      return "metas" in n ? t[s] = n.metas.map((i) => (i.presence_ref = i.phx_ref, delete i.phx_ref, delete i.phx_ref_prev, i)) : t[s] = n, t;
    }, {});
  }
  /** @internal */
  static cloneDeep(e) {
    return JSON.parse(JSON.stringify(e));
  }
  /** @internal */
  onJoin(e) {
    this.caller.onJoin = e;
  }
  /** @internal */
  onLeave(e) {
    this.caller.onLeave = e;
  }
  /** @internal */
  onSync(e) {
    this.caller.onSync = e;
  }
  /** @internal */
  inPendingSyncState() {
    return !this.joinRef || this.joinRef !== this.channel._joinRef();
  }
}
var cr;
(function(r) {
  r.ALL = "*", r.INSERT = "INSERT", r.UPDATE = "UPDATE", r.DELETE = "DELETE";
})(cr || (cr = {}));
var Ue;
(function(r) {
  r.BROADCAST = "broadcast", r.PRESENCE = "presence", r.POSTGRES_CHANGES = "postgres_changes", r.SYSTEM = "system";
})(Ue || (Ue = {}));
var ee;
(function(r) {
  r.SUBSCRIBED = "SUBSCRIBED", r.TIMED_OUT = "TIMED_OUT", r.CLOSED = "CLOSED", r.CHANNEL_ERROR = "CHANNEL_ERROR";
})(ee || (ee = {}));
class Ce {
  /**
   * Creates a channel that can broadcast messages, sync presence, and listen to Postgres changes.
   *
   * The topic determines which realtime stream you are subscribing to. Config options let you
   * enable acknowledgement for broadcasts, presence tracking, or private channels.
   *
   * @example
   * ```ts
   * import RealtimeClient from '@supabase/realtime-js'
   *
   * const client = new RealtimeClient('https://xyzcompany.supabase.co/realtime/v1', {
   *   params: { apikey: 'public-anon-key' },
   * })
   * const channel = new RealtimeChannel('realtime:public:messages', { config: {} }, client)
   * ```
   */
  constructor(e, t = { config: {} }, s) {
    var n, i;
    if (this.topic = e, this.params = t, this.socket = s, this.bindings = {}, this.state = U.closed, this.joinedOnce = !1, this.pushBuffer = [], this.subTopic = e.replace(/^realtime:/i, ""), this.params.config = Object.assign({
      broadcast: { ack: !1, self: !1 },
      presence: { key: "", enabled: !1 },
      private: !1
    }, t.config), this.timeout = this.socket.timeout, this.joinPush = new dt(this, Q.join, this.params, this.timeout), this.rejoinTimer = new Xr(() => this._rejoinUntilConnected(), this.socket.reconnectAfterMs), this.joinPush.receive("ok", () => {
      this.state = U.joined, this.rejoinTimer.reset(), this.pushBuffer.forEach((a) => a.send()), this.pushBuffer = [];
    }), this._onClose(() => {
      this.rejoinTimer.reset(), this.socket.log("channel", `close ${this.topic} ${this._joinRef()}`), this.state = U.closed, this.socket._remove(this);
    }), this._onError((a) => {
      this._isLeaving() || this._isClosed() || (this.socket.log("channel", `error ${this.topic}`, a), this.state = U.errored, this.rejoinTimer.scheduleTimeout());
    }), this.joinPush.receive("timeout", () => {
      this._isJoining() && (this.socket.log("channel", `timeout ${this.topic}`, this.joinPush.timeout), this.state = U.errored, this.rejoinTimer.scheduleTimeout());
    }), this.joinPush.receive("error", (a) => {
      this._isLeaving() || this._isClosed() || (this.socket.log("channel", `error ${this.topic}`, a), this.state = U.errored, this.rejoinTimer.scheduleTimeout());
    }), this._on(Q.reply, {}, (a, o) => {
      this._trigger(this._replyEventName(o), a);
    }), this.presence = new je(this), this.broadcastEndpointURL = Zr(this.socket.endPoint), this.private = this.params.config.private || !1, !this.private && (!((i = (n = this.params.config) === null || n === void 0 ? void 0 : n.broadcast) === null || i === void 0) && i.replay))
      throw `tried to use replay on public channel '${this.topic}'. It must be a private channel.`;
  }
  /** Subscribe registers your client with the server */
  subscribe(e, t = this.timeout) {
    var s, n, i;
    if (this.socket.isConnected() || this.socket.connect(), this.state == U.closed) {
      const { config: { broadcast: a, presence: o, private: c } } = this.params, l = (n = (s = this.bindings.postgres_changes) === null || s === void 0 ? void 0 : s.map((f) => f.filter)) !== null && n !== void 0 ? n : [], u = !!this.bindings[Ue.PRESENCE] && this.bindings[Ue.PRESENCE].length > 0 || ((i = this.params.config.presence) === null || i === void 0 ? void 0 : i.enabled) === !0, d = {}, h = {
        broadcast: a,
        presence: Object.assign(Object.assign({}, o), { enabled: u }),
        postgres_changes: l,
        private: c
      };
      this.socket.accessTokenValue && (d.access_token = this.socket.accessTokenValue), this._onError((f) => e == null ? void 0 : e(ee.CHANNEL_ERROR, f)), this._onClose(() => e == null ? void 0 : e(ee.CLOSED)), this.updateJoinPayload(Object.assign({ config: h }, d)), this.joinedOnce = !0, this._rejoin(t), this.joinPush.receive("ok", async ({ postgres_changes: f }) => {
        var p;
        if (this.socket._isManualToken() || this.socket.setAuth(), f === void 0) {
          e == null || e(ee.SUBSCRIBED);
          return;
        } else {
          const g = this.bindings.postgres_changes, m = (p = g == null ? void 0 : g.length) !== null && p !== void 0 ? p : 0, y = [];
          for (let v = 0; v < m; v++) {
            const _ = g[v], { filter: { event: E, schema: C, table: S, filter: R } } = _, H = f && f[v];
            if (H && H.event === E && Ce.isFilterValueEqual(H.schema, C) && Ce.isFilterValueEqual(H.table, S) && Ce.isFilterValueEqual(H.filter, R))
              y.push(Object.assign(Object.assign({}, _), { id: H.id }));
            else {
              this.unsubscribe(), this.state = U.errored, e == null || e(ee.CHANNEL_ERROR, new Error("mismatch between server and client bindings for postgres changes"));
              return;
            }
          }
          this.bindings.postgres_changes = y, e && e(ee.SUBSCRIBED);
          return;
        }
      }).receive("error", (f) => {
        this.state = U.errored, e == null || e(ee.CHANNEL_ERROR, new Error(JSON.stringify(Object.values(f).join(", ") || "error")));
      }).receive("timeout", () => {
        e == null || e(ee.TIMED_OUT);
      });
    }
    return this;
  }
  /**
   * Returns the current presence state for this channel.
   *
   * The shape is a map keyed by presence key (for example a user id) where each entry contains the
   * tracked metadata for that user.
   */
  presenceState() {
    return this.presence.state;
  }
  /**
   * Sends the supplied payload to the presence tracker so other subscribers can see that this
   * client is online. Use `untrack` to stop broadcasting presence for the same key.
   */
  async track(e, t = {}) {
    return await this.send({
      type: "presence",
      event: "track",
      payload: e
    }, t.timeout || this.timeout);
  }
  /**
   * Removes the current presence state for this client.
   */
  async untrack(e = {}) {
    return await this.send({
      type: "presence",
      event: "untrack"
    }, e);
  }
  on(e, t, s) {
    return this.state === U.joined && e === Ue.PRESENCE && (this.socket.log("channel", `resubscribe to ${this.topic} due to change in presence callbacks on joined channel`), this.unsubscribe().then(async () => await this.subscribe())), this._on(e, t, s);
  }
  /**
   * Sends a broadcast message explicitly via REST API.
   *
   * This method always uses the REST API endpoint regardless of WebSocket connection state.
   * Useful when you want to guarantee REST delivery or when gradually migrating from implicit REST fallback.
   *
   * @param event The name of the broadcast event
   * @param payload Payload to be sent (required)
   * @param opts Options including timeout
   * @returns Promise resolving to object with success status, and error details if failed
   */
  async httpSend(e, t, s = {}) {
    var n;
    if (t == null)
      return Promise.reject("Payload is required for httpSend()");
    const i = {
      apikey: this.socket.apiKey ? this.socket.apiKey : "",
      "Content-Type": "application/json"
    };
    this.socket.accessTokenValue && (i.Authorization = `Bearer ${this.socket.accessTokenValue}`);
    const a = {
      method: "POST",
      headers: i,
      body: JSON.stringify({
        messages: [
          {
            topic: this.subTopic,
            event: e,
            payload: t,
            private: this.private
          }
        ]
      })
    }, o = await this._fetchWithTimeout(this.broadcastEndpointURL, a, (n = s.timeout) !== null && n !== void 0 ? n : this.timeout);
    if (o.status === 202)
      return { success: !0 };
    let c = o.statusText;
    try {
      const l = await o.json();
      c = l.error || l.message || c;
    } catch {
    }
    return Promise.reject(new Error(c));
  }
  /**
   * Sends a message into the channel.
   *
   * @param args Arguments to send to channel
   * @param args.type The type of event to send
   * @param args.event The name of the event being sent
   * @param args.payload Payload to be sent
   * @param opts Options to be used during the send process
   */
  async send(e, t = {}) {
    var s, n;
    if (!this._canPush() && e.type === "broadcast") {
      console.warn("Realtime send() is automatically falling back to REST API. This behavior will be deprecated in the future. Please use httpSend() explicitly for REST delivery.");
      const { event: i, payload: a } = e, o = {
        apikey: this.socket.apiKey ? this.socket.apiKey : "",
        "Content-Type": "application/json"
      };
      this.socket.accessTokenValue && (o.Authorization = `Bearer ${this.socket.accessTokenValue}`);
      const c = {
        method: "POST",
        headers: o,
        body: JSON.stringify({
          messages: [
            {
              topic: this.subTopic,
              event: i,
              payload: a,
              private: this.private
            }
          ]
        })
      };
      try {
        const l = await this._fetchWithTimeout(this.broadcastEndpointURL, c, (s = t.timeout) !== null && s !== void 0 ? s : this.timeout);
        return await ((n = l.body) === null || n === void 0 ? void 0 : n.cancel()), l.ok ? "ok" : "error";
      } catch (l) {
        return l.name === "AbortError" ? "timed out" : "error";
      }
    } else
      return new Promise((i) => {
        var a, o, c;
        const l = this._push(e.type, e, t.timeout || this.timeout);
        e.type === "broadcast" && !(!((c = (o = (a = this.params) === null || a === void 0 ? void 0 : a.config) === null || o === void 0 ? void 0 : o.broadcast) === null || c === void 0) && c.ack) && i("ok"), l.receive("ok", () => i("ok")), l.receive("error", () => i("error")), l.receive("timeout", () => i("timed out"));
      });
  }
  /**
   * Updates the payload that will be sent the next time the channel joins (reconnects).
   * Useful for rotating access tokens or updating config without re-creating the channel.
   */
  updateJoinPayload(e) {
    this.joinPush.updatePayload(e);
  }
  /**
   * Leaves the channel.
   *
   * Unsubscribes from server events, and instructs channel to terminate on server.
   * Triggers onClose() hooks.
   *
   * To receive leave acknowledgements, use the a `receive` hook to bind to the server ack, ie:
   * channel.unsubscribe().receive("ok", () => alert("left!") )
   */
  unsubscribe(e = this.timeout) {
    this.state = U.leaving;
    const t = () => {
      this.socket.log("channel", `leave ${this.topic}`), this._trigger(Q.close, "leave", this._joinRef());
    };
    this.joinPush.destroy();
    let s = null;
    return new Promise((n) => {
      s = new dt(this, Q.leave, {}, e), s.receive("ok", () => {
        t(), n("ok");
      }).receive("timeout", () => {
        t(), n("timed out");
      }).receive("error", () => {
        n("error");
      }), s.send(), this._canPush() || s.trigger("ok", {});
    }).finally(() => {
      s == null || s.destroy();
    });
  }
  /**
   * Teardown the channel.
   *
   * Destroys and stops related timers.
   */
  teardown() {
    this.pushBuffer.forEach((e) => e.destroy()), this.pushBuffer = [], this.rejoinTimer.reset(), this.joinPush.destroy(), this.state = U.closed, this.bindings = {};
  }
  /** @internal */
  async _fetchWithTimeout(e, t, s) {
    const n = new AbortController(), i = setTimeout(() => n.abort(), s), a = await this.socket.fetch(e, Object.assign(Object.assign({}, t), { signal: n.signal }));
    return clearTimeout(i), a;
  }
  /** @internal */
  _push(e, t, s = this.timeout) {
    if (!this.joinedOnce)
      throw `tried to push '${e}' to '${this.topic}' before joining. Use channel.subscribe() before pushing events`;
    let n = new dt(this, e, t, s);
    return this._canPush() ? n.send() : this._addToPushBuffer(n), n;
  }
  /** @internal */
  _addToPushBuffer(e) {
    if (e.startTimeout(), this.pushBuffer.push(e), this.pushBuffer.length > Qs) {
      const t = this.pushBuffer.shift();
      t && (t.destroy(), this.socket.log("channel", `discarded push due to buffer overflow: ${t.event}`, t.payload));
    }
  }
  /**
   * Overridable message hook
   *
   * Receives all events for specialized message handling before dispatching to the channel callbacks.
   * Must return the payload, modified or unmodified.
   *
   * @internal
   */
  _onMessage(e, t, s) {
    return t;
  }
  /** @internal */
  _isMember(e) {
    return this.topic === e;
  }
  /** @internal */
  _joinRef() {
    return this.joinPush.ref;
  }
  /** @internal */
  _trigger(e, t, s) {
    var n, i;
    const a = e.toLocaleLowerCase(), { close: o, error: c, leave: l, join: u } = Q;
    if (s && [o, c, l, u].indexOf(a) >= 0 && s !== this._joinRef())
      return;
    let h = this._onMessage(a, t, s);
    if (t && !h)
      throw "channel onMessage callbacks must return the payload, modified or unmodified";
    ["insert", "update", "delete"].includes(a) ? (n = this.bindings.postgres_changes) === null || n === void 0 || n.filter((f) => {
      var p, g, m;
      return ((p = f.filter) === null || p === void 0 ? void 0 : p.event) === "*" || ((m = (g = f.filter) === null || g === void 0 ? void 0 : g.event) === null || m === void 0 ? void 0 : m.toLocaleLowerCase()) === a;
    }).map((f) => f.callback(h, s)) : (i = this.bindings[a]) === null || i === void 0 || i.filter((f) => {
      var p, g, m, y, v, _;
      if (["broadcast", "presence", "postgres_changes"].includes(a))
        if ("id" in f) {
          const E = f.id, C = (p = f.filter) === null || p === void 0 ? void 0 : p.event;
          return E && ((g = t.ids) === null || g === void 0 ? void 0 : g.includes(E)) && (C === "*" || (C == null ? void 0 : C.toLocaleLowerCase()) === ((m = t.data) === null || m === void 0 ? void 0 : m.type.toLocaleLowerCase()));
        } else {
          const E = (v = (y = f == null ? void 0 : f.filter) === null || y === void 0 ? void 0 : y.event) === null || v === void 0 ? void 0 : v.toLocaleLowerCase();
          return E === "*" || E === ((_ = t == null ? void 0 : t.event) === null || _ === void 0 ? void 0 : _.toLocaleLowerCase());
        }
      else
        return f.type.toLocaleLowerCase() === a;
    }).map((f) => {
      if (typeof h == "object" && "ids" in h) {
        const p = h.data, { schema: g, table: m, commit_timestamp: y, type: v, errors: _ } = p;
        h = Object.assign(Object.assign({}, {
          schema: g,
          table: m,
          commit_timestamp: y,
          eventType: v,
          new: {},
          old: {},
          errors: _
        }), this._getPayloadRecords(p));
      }
      f.callback(h, s);
    });
  }
  /** @internal */
  _isClosed() {
    return this.state === U.closed;
  }
  /** @internal */
  _isJoined() {
    return this.state === U.joined;
  }
  /** @internal */
  _isJoining() {
    return this.state === U.joining;
  }
  /** @internal */
  _isLeaving() {
    return this.state === U.leaving;
  }
  /** @internal */
  _replyEventName(e) {
    return `chan_reply_${e}`;
  }
  /** @internal */
  _on(e, t, s) {
    const n = e.toLocaleLowerCase(), i = {
      type: n,
      filter: t,
      callback: s
    };
    return this.bindings[n] ? this.bindings[n].push(i) : this.bindings[n] = [i], this;
  }
  /** @internal */
  _off(e, t) {
    const s = e.toLocaleLowerCase();
    return this.bindings[s] && (this.bindings[s] = this.bindings[s].filter((n) => {
      var i;
      return !(((i = n.type) === null || i === void 0 ? void 0 : i.toLocaleLowerCase()) === s && Ce.isEqual(n.filter, t));
    })), this;
  }
  /** @internal */
  static isEqual(e, t) {
    if (Object.keys(e).length !== Object.keys(t).length)
      return !1;
    for (const s in e)
      if (e[s] !== t[s])
        return !1;
    return !0;
  }
  /**
   * Compares two optional filter values for equality.
   * Treats undefined, null, and empty string as equivalent empty values.
   * @internal
   */
  static isFilterValueEqual(e, t) {
    return (e ?? void 0) === (t ?? void 0);
  }
  /** @internal */
  _rejoinUntilConnected() {
    this.rejoinTimer.scheduleTimeout(), this.socket.isConnected() && this._rejoin();
  }
  /**
   * Registers a callback that will be executed when the channel closes.
   *
   * @internal
   */
  _onClose(e) {
    this._on(Q.close, {}, e);
  }
  /**
   * Registers a callback that will be executed when the channel encounteres an error.
   *
   * @internal
   */
  _onError(e) {
    this._on(Q.error, {}, (t) => e(t));
  }
  /**
   * Returns `true` if the socket is connected and the channel has been joined.
   *
   * @internal
   */
  _canPush() {
    return this.socket.isConnected() && this._isJoined();
  }
  /** @internal */
  _rejoin(e = this.timeout) {
    this._isLeaving() || (this.socket._leaveOpenTopic(this.topic), this.state = U.joining, this.joinPush.resend(e));
  }
  /** @internal */
  _getPayloadRecords(e) {
    const t = {
      new: {},
      old: {}
    };
    return (e.type === "INSERT" || e.type === "UPDATE") && (t.new = ar(e.columns, e.record)), (e.type === "UPDATE" || e.type === "DELETE") && (t.old = ar(e.columns, e.old_record)), t;
  }
}
const ft = () => {
}, ze = {
  HEARTBEAT_INTERVAL: 25e3,
  RECONNECT_DELAY: 10,
  HEARTBEAT_TIMEOUT_FALLBACK: 100
}, on = [1e3, 2e3, 5e3, 1e4], cn = 1e4, ln = `
  addEventListener("message", (e) => {
    if (e.data.event === "start") {
      setInterval(() => postMessage({ event: "keepAlive" }), e.data.interval);
    }
  });`;
class un {
  /**
   * Initializes the Socket.
   *
   * @param endPoint The string WebSocket endpoint, ie, "ws://example.com/socket", "wss://example.com", "/socket" (inherited host & protocol)
   * @param httpEndpoint The string HTTP endpoint, ie, "https://example.com", "/" (inherited host & protocol)
   * @param options.transport The Websocket Transport, for example WebSocket. This can be a custom implementation
   * @param options.timeout The default timeout in milliseconds to trigger push timeouts.
   * @param options.params The optional params to pass when connecting.
   * @param options.headers Deprecated: headers cannot be set on websocket connections and this option will be removed in the future.
   * @param options.heartbeatIntervalMs The millisec interval to send a heartbeat message.
   * @param options.heartbeatCallback The optional function to handle heartbeat status and latency.
   * @param options.logger The optional function for specialized logging, ie: logger: (kind, msg, data) => { console.log(`${kind}: ${msg}`, data) }
   * @param options.logLevel Sets the log level for Realtime
   * @param options.encode The function to encode outgoing messages. Defaults to JSON: (payload, callback) => callback(JSON.stringify(payload))
   * @param options.decode The function to decode incoming messages. Defaults to Serializer's decode.
   * @param options.reconnectAfterMs he optional function that returns the millsec reconnect interval. Defaults to stepped backoff off.
   * @param options.worker Use Web Worker to set a side flow. Defaults to false.
   * @param options.workerUrl The URL of the worker script. Defaults to https://realtime.supabase.com/worker.js that includes a heartbeat event call to keep the connection alive.
   * @param options.vsn The protocol version to use when connecting. Supported versions are "1.0.0" and "2.0.0". Defaults to "2.0.0".
   * @example
   * ```ts
   * import RealtimeClient from '@supabase/realtime-js'
   *
   * const client = new RealtimeClient('https://xyzcompany.supabase.co/realtime/v1', {
   *   params: { apikey: 'public-anon-key' },
   * })
   * client.connect()
   * ```
   */
  constructor(e, t) {
    var s;
    if (this.accessTokenValue = null, this.apiKey = null, this._manuallySetToken = !1, this.channels = new Array(), this.endPoint = "", this.httpEndpoint = "", this.headers = {}, this.params = {}, this.timeout = St, this.transport = null, this.heartbeatIntervalMs = ze.HEARTBEAT_INTERVAL, this.heartbeatTimer = void 0, this.pendingHeartbeatRef = null, this.heartbeatCallback = ft, this.ref = 0, this.reconnectTimer = null, this.vsn = ir, this.logger = ft, this.conn = null, this.sendBuffer = [], this.serializer = new Zs(), this.stateChangeCallbacks = {
      open: [],
      close: [],
      error: [],
      message: []
    }, this.accessToken = null, this._connectionState = "disconnected", this._wasManualDisconnect = !1, this._authPromise = null, this._heartbeatSentAt = null, this._resolveFetch = (n) => n ? (...i) => n(...i) : (...i) => fetch(...i), !(!((s = t == null ? void 0 : t.params) === null || s === void 0) && s.apikey))
      throw new Error("API key is required to connect to Realtime");
    this.apiKey = t.params.apikey, this.endPoint = `${e}/${Et.websocket}`, this.httpEndpoint = Zr(e), this._initializeOptions(t), this._setupReconnectionTimer(), this.fetch = this._resolveFetch(t == null ? void 0 : t.fetch);
  }
  /**
   * Connects the socket, unless already connected.
   */
  connect() {
    if (!(this.isConnecting() || this.isDisconnecting() || this.conn !== null && this.isConnected())) {
      if (this._setConnectionState("connecting"), this.accessToken && !this._authPromise && this._setAuthSafely("connect"), this.transport)
        this.conn = new this.transport(this.endpointURL());
      else
        try {
          this.conn = Gs.createWebSocket(this.endpointURL());
        } catch (e) {
          this._setConnectionState("disconnected");
          const t = e.message;
          throw t.includes("Node.js") ? new Error(`${t}

To use Realtime in Node.js, you need to provide a WebSocket implementation:

Option 1: Use Node.js 22+ which has native WebSocket support
Option 2: Install and provide the "ws" package:

  npm install ws

  import ws from "ws"
  const client = new RealtimeClient(url, {
    ...options,
    transport: ws
  })`) : new Error(`WebSocket not available: ${t}`);
        }
      this._setupConnectionHandlers();
    }
  }
  /**
   * Returns the URL of the websocket.
   * @returns string The URL of the websocket.
   */
  endpointURL() {
    return this._appendParams(this.endPoint, Object.assign({}, this.params, { vsn: this.vsn }));
  }
  /**
   * Disconnects the socket.
   *
   * @param code A numeric status code to send on disconnect.
   * @param reason A custom reason for the disconnect.
   */
  disconnect(e, t) {
    if (!this.isDisconnecting())
      if (this._setConnectionState("disconnecting", !0), this.conn) {
        const s = setTimeout(() => {
          this._setConnectionState("disconnected");
        }, 100);
        this.conn.onclose = () => {
          clearTimeout(s), this._setConnectionState("disconnected");
        }, typeof this.conn.close == "function" && (e ? this.conn.close(e, t ?? "") : this.conn.close()), this._teardownConnection();
      } else
        this._setConnectionState("disconnected");
  }
  /**
   * Returns all created channels
   */
  getChannels() {
    return this.channels;
  }
  /**
   * Unsubscribes and removes a single channel
   * @param channel A RealtimeChannel instance
   */
  async removeChannel(e) {
    const t = await e.unsubscribe();
    return this.channels.length === 0 && this.disconnect(), t;
  }
  /**
   * Unsubscribes and removes all channels
   */
  async removeAllChannels() {
    const e = await Promise.all(this.channels.map((t) => t.unsubscribe()));
    return this.channels = [], this.disconnect(), e;
  }
  /**
   * Logs the message.
   *
   * For customized logging, `this.logger` can be overridden.
   */
  log(e, t, s) {
    this.logger(e, t, s);
  }
  /**
   * Returns the current state of the socket.
   */
  connectionState() {
    switch (this.conn && this.conn.readyState) {
      case ne.connecting:
        return fe.Connecting;
      case ne.open:
        return fe.Open;
      case ne.closing:
        return fe.Closing;
      default:
        return fe.Closed;
    }
  }
  /**
   * Returns `true` is the connection is open.
   */
  isConnected() {
    return this.connectionState() === fe.Open;
  }
  /**
   * Returns `true` if the connection is currently connecting.
   */
  isConnecting() {
    return this._connectionState === "connecting";
  }
  /**
   * Returns `true` if the connection is currently disconnecting.
   */
  isDisconnecting() {
    return this._connectionState === "disconnecting";
  }
  /**
   * Creates (or reuses) a {@link RealtimeChannel} for the provided topic.
   *
   * Topics are automatically prefixed with `realtime:` to match the Realtime service.
   * If a channel with the same topic already exists it will be returned instead of creating
   * a duplicate connection.
   */
  channel(e, t = { config: {} }) {
    const s = `realtime:${e}`, n = this.getChannels().find((i) => i.topic === s);
    if (n)
      return n;
    {
      const i = new Ce(`realtime:${e}`, t, this);
      return this.channels.push(i), i;
    }
  }
  /**
   * Push out a message if the socket is connected.
   *
   * If the socket is not connected, the message gets enqueued within a local buffer, and sent out when a connection is next established.
   */
  push(e) {
    const { topic: t, event: s, payload: n, ref: i } = e, a = () => {
      this.encode(e, (o) => {
        var c;
        (c = this.conn) === null || c === void 0 || c.send(o);
      });
    };
    this.log("push", `${t} ${s} (${i})`, n), this.isConnected() ? a() : this.sendBuffer.push(a);
  }
  /**
   * Sets the JWT access token used for channel subscription authorization and Realtime RLS.
   *
   * If param is null it will use the `accessToken` callback function or the token set on the client.
   *
   * On callback used, it will set the value of the token internal to the client.
   *
   * When a token is explicitly provided, it will be preserved across channel operations
   * (including removeChannel and resubscribe). The `accessToken` callback will not be
   * invoked until `setAuth()` is called without arguments.
   *
   * @param token A JWT string to override the token set on the client.
   *
   * @example
   * // Use a manual token (preserved across resubscribes, ignores accessToken callback)
   * client.realtime.setAuth('my-custom-jwt')
   *
   * // Switch back to using the accessToken callback
   * client.realtime.setAuth()
   */
  async setAuth(e = null) {
    this._authPromise = this._performAuth(e);
    try {
      await this._authPromise;
    } finally {
      this._authPromise = null;
    }
  }
  /**
   * Returns true if the current access token was explicitly set via setAuth(token),
   * false if it was obtained via the accessToken callback.
   * @internal
   */
  _isManualToken() {
    return this._manuallySetToken;
  }
  /**
   * Sends a heartbeat message if the socket is connected.
   */
  async sendHeartbeat() {
    var e;
    if (!this.isConnected()) {
      try {
        this.heartbeatCallback("disconnected");
      } catch (t) {
        this.log("error", "error in heartbeat callback", t);
      }
      return;
    }
    if (this.pendingHeartbeatRef) {
      this.pendingHeartbeatRef = null, this._heartbeatSentAt = null, this.log("transport", "heartbeat timeout. Attempting to re-establish connection");
      try {
        this.heartbeatCallback("timeout");
      } catch (t) {
        this.log("error", "error in heartbeat callback", t);
      }
      this._wasManualDisconnect = !1, (e = this.conn) === null || e === void 0 || e.close(Xs, "heartbeat timeout"), setTimeout(() => {
        var t;
        this.isConnected() || (t = this.reconnectTimer) === null || t === void 0 || t.scheduleTimeout();
      }, ze.HEARTBEAT_TIMEOUT_FALLBACK);
      return;
    }
    this._heartbeatSentAt = Date.now(), this.pendingHeartbeatRef = this._makeRef(), this.push({
      topic: "phoenix",
      event: "heartbeat",
      payload: {},
      ref: this.pendingHeartbeatRef
    });
    try {
      this.heartbeatCallback("sent");
    } catch (t) {
      this.log("error", "error in heartbeat callback", t);
    }
    this._setAuthSafely("heartbeat");
  }
  /**
   * Sets a callback that receives lifecycle events for internal heartbeat messages.
   * Useful for instrumenting connection health (e.g. sent/ok/timeout/disconnected).
   */
  onHeartbeat(e) {
    this.heartbeatCallback = e;
  }
  /**
   * Flushes send buffer
   */
  flushSendBuffer() {
    this.isConnected() && this.sendBuffer.length > 0 && (this.sendBuffer.forEach((e) => e()), this.sendBuffer = []);
  }
  /**
   * Return the next message ref, accounting for overflows
   *
   * @internal
   */
  _makeRef() {
    let e = this.ref + 1;
    return e === this.ref ? this.ref = 0 : this.ref = e, this.ref.toString();
  }
  /**
   * Unsubscribe from channels with the specified topic.
   *
   * @internal
   */
  _leaveOpenTopic(e) {
    let t = this.channels.find((s) => s.topic === e && (s._isJoined() || s._isJoining()));
    t && (this.log("transport", `leaving duplicate topic "${e}"`), t.unsubscribe());
  }
  /**
   * Removes a subscription from the socket.
   *
   * @param channel An open subscription.
   *
   * @internal
   */
  _remove(e) {
    this.channels = this.channels.filter((t) => t.topic !== e.topic);
  }
  /** @internal */
  _onConnMessage(e) {
    this.decode(e.data, (t) => {
      if (t.topic === "phoenix" && t.event === "phx_reply" && t.ref && t.ref === this.pendingHeartbeatRef) {
        const l = this._heartbeatSentAt ? Date.now() - this._heartbeatSentAt : void 0;
        try {
          this.heartbeatCallback(t.payload.status === "ok" ? "ok" : "error", l);
        } catch (u) {
          this.log("error", "error in heartbeat callback", u);
        }
        this._heartbeatSentAt = null, this.pendingHeartbeatRef = null;
      }
      const { topic: s, event: n, payload: i, ref: a } = t, o = a ? `(${a})` : "", c = i.status || "";
      this.log("receive", `${c} ${s} ${n} ${o}`.trim(), i), this.channels.filter((l) => l._isMember(s)).forEach((l) => l._trigger(n, i, a)), this._triggerStateCallbacks("message", t);
    });
  }
  /**
   * Clear specific timer
   * @internal
   */
  _clearTimer(e) {
    var t;
    e === "heartbeat" && this.heartbeatTimer ? (clearInterval(this.heartbeatTimer), this.heartbeatTimer = void 0) : e === "reconnect" && ((t = this.reconnectTimer) === null || t === void 0 || t.reset());
  }
  /**
   * Clear all timers
   * @internal
   */
  _clearAllTimers() {
    this._clearTimer("heartbeat"), this._clearTimer("reconnect");
  }
  /**
   * Setup connection handlers for WebSocket events
   * @internal
   */
  _setupConnectionHandlers() {
    this.conn && ("binaryType" in this.conn && (this.conn.binaryType = "arraybuffer"), this.conn.onopen = () => this._onConnOpen(), this.conn.onerror = (e) => this._onConnError(e), this.conn.onmessage = (e) => this._onConnMessage(e), this.conn.onclose = (e) => this._onConnClose(e), this.conn.readyState === ne.open && this._onConnOpen());
  }
  /**
   * Teardown connection and cleanup resources
   * @internal
   */
  _teardownConnection() {
    if (this.conn) {
      if (this.conn.readyState === ne.open || this.conn.readyState === ne.connecting)
        try {
          this.conn.close();
        } catch (e) {
          this.log("error", "Error closing connection", e);
        }
      this.conn.onopen = null, this.conn.onerror = null, this.conn.onmessage = null, this.conn.onclose = null, this.conn = null;
    }
    this._clearAllTimers(), this._terminateWorker(), this.channels.forEach((e) => e.teardown());
  }
  /** @internal */
  _onConnOpen() {
    this._setConnectionState("connected"), this.log("transport", `connected to ${this.endpointURL()}`), (this._authPromise || (this.accessToken && !this.accessTokenValue ? this.setAuth() : Promise.resolve())).then(() => {
      this.flushSendBuffer();
    }).catch((t) => {
      this.log("error", "error waiting for auth on connect", t), this.flushSendBuffer();
    }), this._clearTimer("reconnect"), this.worker ? this.workerRef || this._startWorkerHeartbeat() : this._startHeartbeat(), this._triggerStateCallbacks("open");
  }
  /** @internal */
  _startHeartbeat() {
    this.heartbeatTimer && clearInterval(this.heartbeatTimer), this.heartbeatTimer = setInterval(() => this.sendHeartbeat(), this.heartbeatIntervalMs);
  }
  /** @internal */
  _startWorkerHeartbeat() {
    this.workerUrl ? this.log("worker", `starting worker for from ${this.workerUrl}`) : this.log("worker", "starting default worker");
    const e = this._workerObjectUrl(this.workerUrl);
    this.workerRef = new Worker(e), this.workerRef.onerror = (t) => {
      this.log("worker", "worker error", t.message), this._terminateWorker();
    }, this.workerRef.onmessage = (t) => {
      t.data.event === "keepAlive" && this.sendHeartbeat();
    }, this.workerRef.postMessage({
      event: "start",
      interval: this.heartbeatIntervalMs
    });
  }
  /**
   * Terminate the Web Worker and clear the reference
   * @internal
   */
  _terminateWorker() {
    this.workerRef && (this.log("worker", "terminating worker"), this.workerRef.terminate(), this.workerRef = void 0);
  }
  /** @internal */
  _onConnClose(e) {
    var t;
    this._setConnectionState("disconnected"), this.log("transport", "close", e), this._triggerChanError(), this._clearTimer("heartbeat"), this._wasManualDisconnect || (t = this.reconnectTimer) === null || t === void 0 || t.scheduleTimeout(), this._triggerStateCallbacks("close", e);
  }
  /** @internal */
  _onConnError(e) {
    this._setConnectionState("disconnected"), this.log("transport", `${e}`), this._triggerChanError(), this._triggerStateCallbacks("error", e);
    try {
      this.heartbeatCallback("error");
    } catch (t) {
      this.log("error", "error in heartbeat callback", t);
    }
  }
  /** @internal */
  _triggerChanError() {
    this.channels.forEach((e) => e._trigger(Q.error));
  }
  /** @internal */
  _appendParams(e, t) {
    if (Object.keys(t).length === 0)
      return e;
    const s = e.match(/\?/) ? "&" : "?", n = new URLSearchParams(t);
    return `${e}${s}${n}`;
  }
  _workerObjectUrl(e) {
    let t;
    if (e)
      t = e;
    else {
      const s = new Blob([ln], { type: "application/javascript" });
      t = URL.createObjectURL(s);
    }
    return t;
  }
  /**
   * Set connection state with proper state management
   * @internal
   */
  _setConnectionState(e, t = !1) {
    this._connectionState = e, e === "connecting" ? this._wasManualDisconnect = !1 : e === "disconnecting" && (this._wasManualDisconnect = t);
  }
  /**
   * Perform the actual auth operation
   * @internal
   */
  async _performAuth(e = null) {
    let t, s = !1;
    if (e)
      t = e, s = !0;
    else if (this.accessToken)
      try {
        t = await this.accessToken();
      } catch (n) {
        this.log("error", "Error fetching access token from callback", n), t = this.accessTokenValue;
      }
    else
      t = this.accessTokenValue;
    s ? this._manuallySetToken = !0 : this.accessToken && (this._manuallySetToken = !1), this.accessTokenValue != t && (this.accessTokenValue = t, this.channels.forEach((n) => {
      const i = {
        access_token: t,
        version: Js
      };
      t && n.updateJoinPayload(i), n.joinedOnce && n._isJoined() && n._push(Q.access_token, {
        access_token: t
      });
    }));
  }
  /**
   * Wait for any in-flight auth operations to complete
   * @internal
   */
  async _waitForAuthIfNeeded() {
    this._authPromise && await this._authPromise;
  }
  /**
   * Safely call setAuth with standardized error handling
   * @internal
   */
  _setAuthSafely(e = "general") {
    this._isManualToken() || this.setAuth().catch((t) => {
      this.log("error", `Error setting auth in ${e}`, t);
    });
  }
  /**
   * Trigger state change callbacks with proper error handling
   * @internal
   */
  _triggerStateCallbacks(e, t) {
    try {
      this.stateChangeCallbacks[e].forEach((s) => {
        try {
          s(t);
        } catch (n) {
          this.log("error", `error in ${e} callback`, n);
        }
      });
    } catch (s) {
      this.log("error", `error triggering ${e} callbacks`, s);
    }
  }
  /**
   * Setup reconnection timer with proper configuration
   * @internal
   */
  _setupReconnectionTimer() {
    this.reconnectTimer = new Xr(async () => {
      setTimeout(async () => {
        await this._waitForAuthIfNeeded(), this.isConnected() || this.connect();
      }, ze.RECONNECT_DELAY);
    }, this.reconnectAfterMs);
  }
  /**
   * Initialize client options with defaults
   * @internal
   */
  _initializeOptions(e) {
    var t, s, n, i, a, o, c, l, u, d, h, f;
    switch (this.transport = (t = e == null ? void 0 : e.transport) !== null && t !== void 0 ? t : null, this.timeout = (s = e == null ? void 0 : e.timeout) !== null && s !== void 0 ? s : St, this.heartbeatIntervalMs = (n = e == null ? void 0 : e.heartbeatIntervalMs) !== null && n !== void 0 ? n : ze.HEARTBEAT_INTERVAL, this.worker = (i = e == null ? void 0 : e.worker) !== null && i !== void 0 ? i : !1, this.accessToken = (a = e == null ? void 0 : e.accessToken) !== null && a !== void 0 ? a : null, this.heartbeatCallback = (o = e == null ? void 0 : e.heartbeatCallback) !== null && o !== void 0 ? o : ft, this.vsn = (c = e == null ? void 0 : e.vsn) !== null && c !== void 0 ? c : ir, e != null && e.params && (this.params = e.params), e != null && e.logger && (this.logger = e.logger), (e != null && e.logLevel || e != null && e.log_level) && (this.logLevel = e.logLevel || e.log_level, this.params = Object.assign(Object.assign({}, this.params), { log_level: this.logLevel })), this.reconnectAfterMs = (l = e == null ? void 0 : e.reconnectAfterMs) !== null && l !== void 0 ? l : (p) => on[p - 1] || cn, this.vsn) {
      case Ys:
        this.encode = (u = e == null ? void 0 : e.encode) !== null && u !== void 0 ? u : (p, g) => g(JSON.stringify(p)), this.decode = (d = e == null ? void 0 : e.decode) !== null && d !== void 0 ? d : (p, g) => g(JSON.parse(p));
        break;
      case Yr:
        this.encode = (h = e == null ? void 0 : e.encode) !== null && h !== void 0 ? h : this.serializer.encode.bind(this.serializer), this.decode = (f = e == null ? void 0 : e.decode) !== null && f !== void 0 ? f : this.serializer.decode.bind(this.serializer);
        break;
      default:
        throw new Error(`Unsupported serializer version: ${this.vsn}`);
    }
    if (this.worker) {
      if (typeof window < "u" && !window.Worker)
        throw new Error("Web Worker is not supported");
      this.workerUrl = e == null ? void 0 : e.workerUrl;
    }
  }
}
var De = class extends Error {
  constructor(r, e) {
    var t;
    super(r), this.name = "IcebergError", this.status = e.status, this.icebergType = e.icebergType, this.icebergCode = e.icebergCode, this.details = e.details, this.isCommitStateUnknown = e.icebergType === "CommitStateUnknownException" || [500, 502, 504].includes(e.status) && ((t = e.icebergType) == null ? void 0 : t.includes("CommitState")) === !0;
  }
  /**
   * Returns true if the error is a 404 Not Found error.
   */
  isNotFound() {
    return this.status === 404;
  }
  /**
   * Returns true if the error is a 409 Conflict error.
   */
  isConflict() {
    return this.status === 409;
  }
  /**
   * Returns true if the error is a 419 Authentication Timeout error.
   */
  isAuthenticationTimeout() {
    return this.status === 419;
  }
};
function hn(r, e, t) {
  const s = new URL(e, r);
  if (t)
    for (const [n, i] of Object.entries(t))
      i !== void 0 && s.searchParams.set(n, i);
  return s.toString();
}
async function dn(r) {
  return !r || r.type === "none" ? {} : r.type === "bearer" ? { Authorization: `Bearer ${r.token}` } : r.type === "header" ? { [r.name]: r.value } : r.type === "custom" ? await r.getHeaders() : {};
}
function fn(r) {
  const e = r.fetchImpl ?? globalThis.fetch;
  return {
    async request({
      method: t,
      path: s,
      query: n,
      body: i,
      headers: a
    }) {
      const o = hn(r.baseUrl, s, n), c = await dn(r.auth), l = await e(o, {
        method: t,
        headers: {
          ...i ? { "Content-Type": "application/json" } : {},
          ...c,
          ...a
        },
        body: i ? JSON.stringify(i) : void 0
      }), u = await l.text(), d = (l.headers.get("content-type") || "").includes("application/json"), h = d && u ? JSON.parse(u) : u;
      if (!l.ok) {
        const f = d ? h : void 0, p = f == null ? void 0 : f.error;
        throw new De(
          (p == null ? void 0 : p.message) ?? `Request failed with status ${l.status}`,
          {
            status: l.status,
            icebergType: p == null ? void 0 : p.type,
            icebergCode: p == null ? void 0 : p.code,
            details: f
          }
        );
      }
      return { status: l.status, headers: l.headers, data: h };
    }
  };
}
function Ge(r) {
  return r.join("");
}
var pn = class {
  constructor(r, e = "") {
    this.client = r, this.prefix = e;
  }
  async listNamespaces(r) {
    const e = r ? { parent: Ge(r.namespace) } : void 0;
    return (await this.client.request({
      method: "GET",
      path: `${this.prefix}/namespaces`,
      query: e
    })).data.namespaces.map((s) => ({ namespace: s }));
  }
  async createNamespace(r, e) {
    const t = {
      namespace: r.namespace,
      properties: e == null ? void 0 : e.properties
    };
    return (await this.client.request({
      method: "POST",
      path: `${this.prefix}/namespaces`,
      body: t
    })).data;
  }
  async dropNamespace(r) {
    await this.client.request({
      method: "DELETE",
      path: `${this.prefix}/namespaces/${Ge(r.namespace)}`
    });
  }
  async loadNamespaceMetadata(r) {
    return {
      properties: (await this.client.request({
        method: "GET",
        path: `${this.prefix}/namespaces/${Ge(r.namespace)}`
      })).data.properties
    };
  }
  async namespaceExists(r) {
    try {
      return await this.client.request({
        method: "HEAD",
        path: `${this.prefix}/namespaces/${Ge(r.namespace)}`
      }), !0;
    } catch (e) {
      if (e instanceof De && e.status === 404)
        return !1;
      throw e;
    }
  }
  async createNamespaceIfNotExists(r, e) {
    try {
      return await this.createNamespace(r, e);
    } catch (t) {
      if (t instanceof De && t.status === 409)
        return;
      throw t;
    }
  }
};
function ve(r) {
  return r.join("");
}
var gn = class {
  constructor(r, e = "", t) {
    this.client = r, this.prefix = e, this.accessDelegation = t;
  }
  async listTables(r) {
    return (await this.client.request({
      method: "GET",
      path: `${this.prefix}/namespaces/${ve(r.namespace)}/tables`
    })).data.identifiers;
  }
  async createTable(r, e) {
    const t = {};
    return this.accessDelegation && (t["X-Iceberg-Access-Delegation"] = this.accessDelegation), (await this.client.request({
      method: "POST",
      path: `${this.prefix}/namespaces/${ve(r.namespace)}/tables`,
      body: e,
      headers: t
    })).data.metadata;
  }
  async updateTable(r, e) {
    const t = await this.client.request({
      method: "POST",
      path: `${this.prefix}/namespaces/${ve(r.namespace)}/tables/${r.name}`,
      body: e
    });
    return {
      "metadata-location": t.data["metadata-location"],
      metadata: t.data.metadata
    };
  }
  async dropTable(r, e) {
    await this.client.request({
      method: "DELETE",
      path: `${this.prefix}/namespaces/${ve(r.namespace)}/tables/${r.name}`,
      query: { purgeRequested: String((e == null ? void 0 : e.purge) ?? !1) }
    });
  }
  async loadTable(r) {
    const e = {};
    return this.accessDelegation && (e["X-Iceberg-Access-Delegation"] = this.accessDelegation), (await this.client.request({
      method: "GET",
      path: `${this.prefix}/namespaces/${ve(r.namespace)}/tables/${r.name}`,
      headers: e
    })).data.metadata;
  }
  async tableExists(r) {
    const e = {};
    this.accessDelegation && (e["X-Iceberg-Access-Delegation"] = this.accessDelegation);
    try {
      return await this.client.request({
        method: "HEAD",
        path: `${this.prefix}/namespaces/${ve(r.namespace)}/tables/${r.name}`,
        headers: e
      }), !0;
    } catch (t) {
      if (t instanceof De && t.status === 404)
        return !1;
      throw t;
    }
  }
  async createTableIfNotExists(r, e) {
    try {
      return await this.createTable(r, e);
    } catch (t) {
      if (t instanceof De && t.status === 409)
        return await this.loadTable({ namespace: r.namespace, name: e.name });
      throw t;
    }
  }
}, mn = class {
  /**
   * Creates a new Iceberg REST Catalog client.
   *
   * @param options - Configuration options for the catalog client
   */
  constructor(r) {
    var s;
    let e = "v1";
    r.catalogName && (e += `/${r.catalogName}`);
    const t = r.baseUrl.endsWith("/") ? r.baseUrl : `${r.baseUrl}/`;
    this.client = fn({
      baseUrl: t,
      auth: r.auth,
      fetchImpl: r.fetch
    }), this.accessDelegation = (s = r.accessDelegation) == null ? void 0 : s.join(","), this.namespaceOps = new pn(this.client, e), this.tableOps = new gn(this.client, e, this.accessDelegation);
  }
  /**
   * Lists all namespaces in the catalog.
   *
   * @param parent - Optional parent namespace to list children under
   * @returns Array of namespace identifiers
   *
   * @example
   * ```typescript
   * // List all top-level namespaces
   * const namespaces = await catalog.listNamespaces();
   *
   * // List namespaces under a parent
   * const children = await catalog.listNamespaces({ namespace: ['analytics'] });
   * ```
   */
  async listNamespaces(r) {
    return this.namespaceOps.listNamespaces(r);
  }
  /**
   * Creates a new namespace in the catalog.
   *
   * @param id - Namespace identifier to create
   * @param metadata - Optional metadata properties for the namespace
   * @returns Response containing the created namespace and its properties
   *
   * @example
   * ```typescript
   * const response = await catalog.createNamespace(
   *   { namespace: ['analytics'] },
   *   { properties: { owner: 'data-team' } }
   * );
   * console.log(response.namespace); // ['analytics']
   * console.log(response.properties); // { owner: 'data-team', ... }
   * ```
   */
  async createNamespace(r, e) {
    return this.namespaceOps.createNamespace(r, e);
  }
  /**
   * Drops a namespace from the catalog.
   *
   * The namespace must be empty (contain no tables) before it can be dropped.
   *
   * @param id - Namespace identifier to drop
   *
   * @example
   * ```typescript
   * await catalog.dropNamespace({ namespace: ['analytics'] });
   * ```
   */
  async dropNamespace(r) {
    await this.namespaceOps.dropNamespace(r);
  }
  /**
   * Loads metadata for a namespace.
   *
   * @param id - Namespace identifier to load
   * @returns Namespace metadata including properties
   *
   * @example
   * ```typescript
   * const metadata = await catalog.loadNamespaceMetadata({ namespace: ['analytics'] });
   * console.log(metadata.properties);
   * ```
   */
  async loadNamespaceMetadata(r) {
    return this.namespaceOps.loadNamespaceMetadata(r);
  }
  /**
   * Lists all tables in a namespace.
   *
   * @param namespace - Namespace identifier to list tables from
   * @returns Array of table identifiers
   *
   * @example
   * ```typescript
   * const tables = await catalog.listTables({ namespace: ['analytics'] });
   * console.log(tables); // [{ namespace: ['analytics'], name: 'events' }, ...]
   * ```
   */
  async listTables(r) {
    return this.tableOps.listTables(r);
  }
  /**
   * Creates a new table in the catalog.
   *
   * @param namespace - Namespace to create the table in
   * @param request - Table creation request including name, schema, partition spec, etc.
   * @returns Table metadata for the created table
   *
   * @example
   * ```typescript
   * const metadata = await catalog.createTable(
   *   { namespace: ['analytics'] },
   *   {
   *     name: 'events',
   *     schema: {
   *       type: 'struct',
   *       fields: [
   *         { id: 1, name: 'id', type: 'long', required: true },
   *         { id: 2, name: 'timestamp', type: 'timestamp', required: true }
   *       ],
   *       'schema-id': 0
   *     },
   *     'partition-spec': {
   *       'spec-id': 0,
   *       fields: [
   *         { source_id: 2, field_id: 1000, name: 'ts_day', transform: 'day' }
   *       ]
   *     }
   *   }
   * );
   * ```
   */
  async createTable(r, e) {
    return this.tableOps.createTable(r, e);
  }
  /**
   * Updates an existing table's metadata.
   *
   * Can update the schema, partition spec, or properties of a table.
   *
   * @param id - Table identifier to update
   * @param request - Update request with fields to modify
   * @returns Response containing the metadata location and updated table metadata
   *
   * @example
   * ```typescript
   * const response = await catalog.updateTable(
   *   { namespace: ['analytics'], name: 'events' },
   *   {
   *     properties: { 'read.split.target-size': '134217728' }
   *   }
   * );
   * console.log(response['metadata-location']); // s3://...
   * console.log(response.metadata); // TableMetadata object
   * ```
   */
  async updateTable(r, e) {
    return this.tableOps.updateTable(r, e);
  }
  /**
   * Drops a table from the catalog.
   *
   * @param id - Table identifier to drop
   *
   * @example
   * ```typescript
   * await catalog.dropTable({ namespace: ['analytics'], name: 'events' });
   * ```
   */
  async dropTable(r, e) {
    await this.tableOps.dropTable(r, e);
  }
  /**
   * Loads metadata for a table.
   *
   * @param id - Table identifier to load
   * @returns Table metadata including schema, partition spec, location, etc.
   *
   * @example
   * ```typescript
   * const metadata = await catalog.loadTable({ namespace: ['analytics'], name: 'events' });
   * console.log(metadata.schema);
   * console.log(metadata.location);
   * ```
   */
  async loadTable(r) {
    return this.tableOps.loadTable(r);
  }
  /**
   * Checks if a namespace exists in the catalog.
   *
   * @param id - Namespace identifier to check
   * @returns True if the namespace exists, false otherwise
   *
   * @example
   * ```typescript
   * const exists = await catalog.namespaceExists({ namespace: ['analytics'] });
   * console.log(exists); // true or false
   * ```
   */
  async namespaceExists(r) {
    return this.namespaceOps.namespaceExists(r);
  }
  /**
   * Checks if a table exists in the catalog.
   *
   * @param id - Table identifier to check
   * @returns True if the table exists, false otherwise
   *
   * @example
   * ```typescript
   * const exists = await catalog.tableExists({ namespace: ['analytics'], name: 'events' });
   * console.log(exists); // true or false
   * ```
   */
  async tableExists(r) {
    return this.tableOps.tableExists(r);
  }
  /**
   * Creates a namespace if it does not exist.
   *
   * If the namespace already exists, returns void. If created, returns the response.
   *
   * @param id - Namespace identifier to create
   * @param metadata - Optional metadata properties for the namespace
   * @returns Response containing the created namespace and its properties, or void if it already exists
   *
   * @example
   * ```typescript
   * const response = await catalog.createNamespaceIfNotExists(
   *   { namespace: ['analytics'] },
   *   { properties: { owner: 'data-team' } }
   * );
   * if (response) {
   *   console.log('Created:', response.namespace);
   * } else {
   *   console.log('Already exists');
   * }
   * ```
   */
  async createNamespaceIfNotExists(r, e) {
    return this.namespaceOps.createNamespaceIfNotExists(r, e);
  }
  /**
   * Creates a table if it does not exist.
   *
   * If the table already exists, returns its metadata instead.
   *
   * @param namespace - Namespace to create the table in
   * @param request - Table creation request including name, schema, partition spec, etc.
   * @returns Table metadata for the created or existing table
   *
   * @example
   * ```typescript
   * const metadata = await catalog.createTableIfNotExists(
   *   { namespace: ['analytics'] },
   *   {
   *     name: 'events',
   *     schema: {
   *       type: 'struct',
   *       fields: [
   *         { id: 1, name: 'id', type: 'long', required: true },
   *         { id: 2, name: 'timestamp', type: 'timestamp', required: true }
   *       ],
   *       'schema-id': 0
   *     }
   *   }
   * );
   * ```
   */
  async createTableIfNotExists(r, e) {
    return this.tableOps.createTableIfNotExists(r, e);
  }
}, at = class extends Error {
  constructor(r, e = "storage", t, s) {
    super(r), this.__isStorageError = !0, this.namespace = e, this.name = e === "vectors" ? "StorageVectorsError" : "StorageError", this.status = t, this.statusCode = s;
  }
};
function ot(r) {
  return typeof r == "object" && r !== null && "__isStorageError" in r;
}
var We = class extends at {
  constructor(r, e, t, s = "storage") {
    super(r, s, e, t), this.name = s === "vectors" ? "StorageVectorsApiError" : "StorageApiError", this.status = e, this.statusCode = t;
  }
  toJSON() {
    return {
      name: this.name,
      message: this.message,
      status: this.status,
      statusCode: this.statusCode
    };
  }
}, es = class extends at {
  constructor(r, e, t = "storage") {
    super(r, t), this.name = t === "vectors" ? "StorageVectorsUnknownError" : "StorageUnknownError", this.originalError = e;
  }
};
const yn = (r) => r ? (...e) => r(...e) : (...e) => fetch(...e), _n = (r) => {
  if (typeof r != "object" || r === null) return !1;
  const e = Object.getPrototypeOf(r);
  return (e === null || e === Object.prototype || Object.getPrototypeOf(e) === null) && !(Symbol.toStringTag in r) && !(Symbol.iterator in r);
}, At = (r) => {
  if (Array.isArray(r)) return r.map((t) => At(t));
  if (typeof r == "function" || r !== Object(r)) return r;
  const e = {};
  return Object.entries(r).forEach(([t, s]) => {
    const n = t.replace(/([-_][a-z])/gi, (i) => i.toUpperCase().replace(/[-_]/g, ""));
    e[n] = At(s);
  }), e;
}, vn = (r) => !r || typeof r != "string" || r.length === 0 || r.length > 100 || r.trim() !== r || r.includes("/") || r.includes("\\") ? !1 : /^[\w!.\*'() &$@=;:+,?-]+$/.test(r);
function Me(r) {
  "@babel/helpers - typeof";
  return Me = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
    return typeof e;
  } : function(e) {
    return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
  }, Me(r);
}
function wn(r, e) {
  if (Me(r) != "object" || !r) return r;
  var t = r[Symbol.toPrimitive];
  if (t !== void 0) {
    var s = t.call(r, e);
    if (Me(s) != "object") return s;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (e === "string" ? String : Number)(r);
}
function bn(r) {
  var e = wn(r, "string");
  return Me(e) == "symbol" ? e : e + "";
}
function Sn(r, e, t) {
  return (e = bn(e)) in r ? Object.defineProperty(r, e, {
    value: t,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : r[e] = t, r;
}
function lr(r, e) {
  var t = Object.keys(r);
  if (Object.getOwnPropertySymbols) {
    var s = Object.getOwnPropertySymbols(r);
    e && (s = s.filter(function(n) {
      return Object.getOwnPropertyDescriptor(r, n).enumerable;
    })), t.push.apply(t, s);
  }
  return t;
}
function A(r) {
  for (var e = 1; e < arguments.length; e++) {
    var t = arguments[e] != null ? arguments[e] : {};
    e % 2 ? lr(Object(t), !0).forEach(function(s) {
      Sn(r, s, t[s]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(t)) : lr(Object(t)).forEach(function(s) {
      Object.defineProperty(r, s, Object.getOwnPropertyDescriptor(t, s));
    });
  }
  return r;
}
const ur = (r) => {
  var e;
  return r.msg || r.message || r.error_description || (typeof r.error == "string" ? r.error : (e = r.error) === null || e === void 0 ? void 0 : e.message) || JSON.stringify(r);
}, En = async (r, e, t, s) => {
  if (r && typeof r == "object" && "status" in r && "ok" in r && typeof r.status == "number" && !(t != null && t.noResolveJson)) {
    const n = r, i = n.status || 500;
    if (typeof n.json == "function") n.json().then((a) => {
      const o = (a == null ? void 0 : a.statusCode) || (a == null ? void 0 : a.code) || i + "";
      e(new We(ur(a), i, o, s));
    }).catch(() => {
      if (s === "vectors") {
        const a = i + "";
        e(new We(n.statusText || `HTTP ${i} error`, i, a, s));
      } else {
        const a = i + "";
        e(new We(n.statusText || `HTTP ${i} error`, i, a, s));
      }
    });
    else {
      const a = i + "";
      e(new We(n.statusText || `HTTP ${i} error`, i, a, s));
    }
  } else e(new es(ur(r), r, s));
}, Tn = (r, e, t, s) => {
  const n = {
    method: r,
    headers: (e == null ? void 0 : e.headers) || {}
  };
  return r === "GET" || r === "HEAD" || !s ? A(A({}, n), t) : (_n(s) ? (n.headers = A({ "Content-Type": "application/json" }, e == null ? void 0 : e.headers), n.body = JSON.stringify(s)) : n.body = s, e != null && e.duplex && (n.duplex = e.duplex), A(A({}, n), t));
};
async function Pe(r, e, t, s, n, i, a) {
  return new Promise((o, c) => {
    r(t, Tn(e, s, n, i)).then((l) => {
      if (!l.ok) throw l;
      if (s != null && s.noResolveJson) return l;
      if (a === "vectors") {
        const u = l.headers.get("content-type");
        if (l.headers.get("content-length") === "0" || l.status === 204) return {};
        if (!u || !u.includes("application/json")) return {};
      }
      return l.json();
    }).then((l) => o(l)).catch((l) => En(l, c, s, a));
  });
}
function ts(r = "storage") {
  return {
    get: async (e, t, s, n) => Pe(e, "GET", t, s, n, void 0, r),
    post: async (e, t, s, n, i) => Pe(e, "POST", t, n, i, s, r),
    put: async (e, t, s, n, i) => Pe(e, "PUT", t, n, i, s, r),
    head: async (e, t, s, n) => Pe(e, "HEAD", t, A(A({}, s), {}, { noResolveJson: !0 }), n, void 0, r),
    remove: async (e, t, s, n, i) => Pe(e, "DELETE", t, n, i, s, r)
  };
}
const An = ts("storage"), { get: Be, post: X, put: kt, head: kn, remove: qt } = An, G = ts("vectors");
var $e = class {
  /**
  * Creates a new BaseApiClient instance
  * @param url - Base URL for API requests
  * @param headers - Default headers for API requests
  * @param fetch - Optional custom fetch implementation
  * @param namespace - Error namespace ('storage' or 'vectors')
  */
  constructor(r, e = {}, t, s = "storage") {
    this.shouldThrowOnError = !1, this.url = r, this.headers = e, this.fetch = yn(t), this.namespace = s;
  }
  /**
  * Enable throwing errors instead of returning them.
  * When enabled, errors are thrown instead of returned in { data, error } format.
  *
  * @returns this - For method chaining
  */
  throwOnError() {
    return this.shouldThrowOnError = !0, this;
  }
  /**
  * Handles API operation with standardized error handling
  * Eliminates repetitive try-catch blocks across all API methods
  *
  * This wrapper:
  * 1. Executes the operation
  * 2. Returns { data, error: null } on success
  * 3. Returns { data: null, error } on failure (if shouldThrowOnError is false)
  * 4. Throws error on failure (if shouldThrowOnError is true)
  *
  * @typeParam T - The expected data type from the operation
  * @param operation - Async function that performs the API call
  * @returns Promise with { data, error } tuple
  *
  * @example
  * ```typescript
  * async listBuckets() {
  *   return this.handleOperation(async () => {
  *     return await get(this.fetch, `${this.url}/bucket`, {
  *       headers: this.headers,
  *     })
  *   })
  * }
  * ```
  */
  async handleOperation(r) {
    var e = this;
    try {
      return {
        data: await r(),
        error: null
      };
    } catch (t) {
      if (e.shouldThrowOnError) throw t;
      if (ot(t)) return {
        data: null,
        error: t
      };
      throw t;
    }
  }
}, On = class {
  constructor(r, e) {
    this.downloadFn = r, this.shouldThrowOnError = e;
  }
  then(r, e) {
    return this.execute().then(r, e);
  }
  async execute() {
    var r = this;
    try {
      return {
        data: (await r.downloadFn()).body,
        error: null
      };
    } catch (e) {
      if (r.shouldThrowOnError) throw e;
      if (ot(e)) return {
        data: null,
        error: e
      };
      throw e;
    }
  }
};
let rs;
rs = Symbol.toStringTag;
var Rn = class {
  constructor(r, e) {
    this.downloadFn = r, this.shouldThrowOnError = e, this[rs] = "BlobDownloadBuilder", this.promise = null;
  }
  asStream() {
    return new On(this.downloadFn, this.shouldThrowOnError);
  }
  then(r, e) {
    return this.getPromise().then(r, e);
  }
  catch(r) {
    return this.getPromise().catch(r);
  }
  finally(r) {
    return this.getPromise().finally(r);
  }
  getPromise() {
    return this.promise || (this.promise = this.execute()), this.promise;
  }
  async execute() {
    var r = this;
    try {
      return {
        data: await (await r.downloadFn()).blob(),
        error: null
      };
    } catch (e) {
      if (r.shouldThrowOnError) throw e;
      if (ot(e)) return {
        data: null,
        error: e
      };
      throw e;
    }
  }
};
const Cn = {
  limit: 100,
  offset: 0,
  sortBy: {
    column: "name",
    order: "asc"
  }
}, hr = {
  cacheControl: "3600",
  contentType: "text/plain;charset=UTF-8",
  upsert: !1
};
var In = class extends $e {
  constructor(r, e = {}, t, s) {
    super(r, e, s, "storage"), this.bucketId = t;
  }
  /**
  * Uploads a file to an existing bucket or replaces an existing file at the specified path with a new one.
  *
  * @param method HTTP method.
  * @param path The relative file path. Should be of the format `folder/subfolder/filename.png`. The bucket must already exist before attempting to upload.
  * @param fileBody The body of the file to be stored in the bucket.
  */
  async uploadOrUpdate(r, e, t, s) {
    var n = this;
    return n.handleOperation(async () => {
      let i;
      const a = A(A({}, hr), s);
      let o = A(A({}, n.headers), r === "POST" && { "x-upsert": String(a.upsert) });
      const c = a.metadata;
      typeof Blob < "u" && t instanceof Blob ? (i = new FormData(), i.append("cacheControl", a.cacheControl), c && i.append("metadata", n.encodeMetadata(c)), i.append("", t)) : typeof FormData < "u" && t instanceof FormData ? (i = t, i.has("cacheControl") || i.append("cacheControl", a.cacheControl), c && !i.has("metadata") && i.append("metadata", n.encodeMetadata(c))) : (i = t, o["cache-control"] = `max-age=${a.cacheControl}`, o["content-type"] = a.contentType, c && (o["x-metadata"] = n.toBase64(n.encodeMetadata(c))), (typeof ReadableStream < "u" && i instanceof ReadableStream || i && typeof i == "object" && "pipe" in i && typeof i.pipe == "function") && !a.duplex && (a.duplex = "half")), s != null && s.headers && (o = A(A({}, o), s.headers));
      const l = n._removeEmptyFolders(e), u = n._getFinalPath(l), d = await (r == "PUT" ? kt : X)(n.fetch, `${n.url}/object/${u}`, i, A({ headers: o }, a != null && a.duplex ? { duplex: a.duplex } : {}));
      return {
        path: l,
        id: d.Id,
        fullPath: d.Key
      };
    });
  }
  /**
  * Uploads a file to an existing bucket.
  *
  * @category File Buckets
  * @param path The file path, including the file name. Should be of the format `folder/subfolder/filename.png`. The bucket must already exist before attempting to upload.
  * @param fileBody The body of the file to be stored in the bucket.
  * @param fileOptions Optional file upload options including cacheControl, contentType, upsert, and metadata.
  * @returns Promise with response containing file path, id, and fullPath or error
  *
  * @example Upload file
  * ```js
  * const avatarFile = event.target.files[0]
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .upload('public/avatar1.png', avatarFile, {
  *     cacheControl: '3600',
  *     upsert: false
  *   })
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "path": "public/avatar1.png",
  *     "fullPath": "avatars/public/avatar1.png"
  *   },
  *   "error": null
  * }
  * ```
  *
  * @example Upload file using `ArrayBuffer` from base64 file data
  * ```js
  * import { decode } from 'base64-arraybuffer'
  *
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .upload('public/avatar1.png', decode('base64FileData'), {
  *     contentType: 'image/png'
  *   })
  * ```
  */
  async upload(r, e, t) {
    return this.uploadOrUpdate("POST", r, e, t);
  }
  /**
  * Upload a file with a token generated from `createSignedUploadUrl`.
  *
  * @category File Buckets
  * @param path The file path, including the file name. Should be of the format `folder/subfolder/filename.png`. The bucket must already exist before attempting to upload.
  * @param token The token generated from `createSignedUploadUrl`
  * @param fileBody The body of the file to be stored in the bucket.
  * @param fileOptions HTTP headers (cacheControl, contentType, etc.).
  * **Note:** The `upsert` option has no effect here. To enable upsert behavior,
  * pass `{ upsert: true }` when calling `createSignedUploadUrl()` instead.
  * @returns Promise with response containing file path and fullPath or error
  *
  * @example Upload to a signed URL
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .uploadToSignedUrl('folder/cat.jpg', 'token-from-createSignedUploadUrl', file)
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "path": "folder/cat.jpg",
  *     "fullPath": "avatars/folder/cat.jpg"
  *   },
  *   "error": null
  * }
  * ```
  */
  async uploadToSignedUrl(r, e, t, s) {
    var n = this;
    const i = n._removeEmptyFolders(r), a = n._getFinalPath(i), o = new URL(n.url + `/object/upload/sign/${a}`);
    return o.searchParams.set("token", e), n.handleOperation(async () => {
      let c;
      const l = A({ upsert: hr.upsert }, s), u = A(A({}, n.headers), { "x-upsert": String(l.upsert) });
      return typeof Blob < "u" && t instanceof Blob ? (c = new FormData(), c.append("cacheControl", l.cacheControl), c.append("", t)) : typeof FormData < "u" && t instanceof FormData ? (c = t, c.append("cacheControl", l.cacheControl)) : (c = t, u["cache-control"] = `max-age=${l.cacheControl}`, u["content-type"] = l.contentType), {
        path: i,
        fullPath: (await kt(n.fetch, o.toString(), c, { headers: u })).Key
      };
    });
  }
  /**
  * Creates a signed upload URL.
  * Signed upload URLs can be used to upload files to the bucket without further authentication.
  * They are valid for 2 hours.
  *
  * @category File Buckets
  * @param path The file path, including the current file name. For example `folder/image.png`.
  * @param options.upsert If set to true, allows the file to be overwritten if it already exists.
  * @returns Promise with response containing signed upload URL, token, and path or error
  *
  * @example Create Signed Upload URL
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .createSignedUploadUrl('folder/cat.jpg')
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "signedUrl": "https://example.supabase.co/storage/v1/object/upload/sign/avatars/folder/cat.jpg?token=<TOKEN>",
  *     "path": "folder/cat.jpg",
  *     "token": "<TOKEN>"
  *   },
  *   "error": null
  * }
  * ```
  */
  async createSignedUploadUrl(r, e) {
    var t = this;
    return t.handleOperation(async () => {
      let s = t._getFinalPath(r);
      const n = A({}, t.headers);
      e != null && e.upsert && (n["x-upsert"] = "true");
      const i = await X(t.fetch, `${t.url}/object/upload/sign/${s}`, {}, { headers: n }), a = new URL(t.url + i.url), o = a.searchParams.get("token");
      if (!o) throw new at("No token returned by API");
      return {
        signedUrl: a.toString(),
        path: r,
        token: o
      };
    });
  }
  /**
  * Replaces an existing file at the specified path with a new one.
  *
  * @category File Buckets
  * @param path The relative file path. Should be of the format `folder/subfolder/filename.png`. The bucket must already exist before attempting to update.
  * @param fileBody The body of the file to be stored in the bucket.
  * @param fileOptions Optional file upload options including cacheControl, contentType, upsert, and metadata.
  * @returns Promise with response containing file path, id, and fullPath or error
  *
  * @example Update file
  * ```js
  * const avatarFile = event.target.files[0]
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .update('public/avatar1.png', avatarFile, {
  *     cacheControl: '3600',
  *     upsert: true
  *   })
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "path": "public/avatar1.png",
  *     "fullPath": "avatars/public/avatar1.png"
  *   },
  *   "error": null
  * }
  * ```
  *
  * @example Update file using `ArrayBuffer` from base64 file data
  * ```js
  * import {decode} from 'base64-arraybuffer'
  *
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .update('public/avatar1.png', decode('base64FileData'), {
  *     contentType: 'image/png'
  *   })
  * ```
  */
  async update(r, e, t) {
    return this.uploadOrUpdate("PUT", r, e, t);
  }
  /**
  * Moves an existing file to a new path in the same bucket.
  *
  * @category File Buckets
  * @param fromPath The original file path, including the current file name. For example `folder/image.png`.
  * @param toPath The new file path, including the new file name. For example `folder/image-new.png`.
  * @param options The destination options.
  * @returns Promise with response containing success message or error
  *
  * @example Move file
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .move('public/avatar1.png', 'private/avatar2.png')
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "message": "Successfully moved"
  *   },
  *   "error": null
  * }
  * ```
  */
  async move(r, e, t) {
    var s = this;
    return s.handleOperation(async () => await X(s.fetch, `${s.url}/object/move`, {
      bucketId: s.bucketId,
      sourceKey: r,
      destinationKey: e,
      destinationBucket: t == null ? void 0 : t.destinationBucket
    }, { headers: s.headers }));
  }
  /**
  * Copies an existing file to a new path in the same bucket.
  *
  * @category File Buckets
  * @param fromPath The original file path, including the current file name. For example `folder/image.png`.
  * @param toPath The new file path, including the new file name. For example `folder/image-copy.png`.
  * @param options The destination options.
  * @returns Promise with response containing copied file path or error
  *
  * @example Copy file
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .copy('public/avatar1.png', 'private/avatar2.png')
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "path": "avatars/private/avatar2.png"
  *   },
  *   "error": null
  * }
  * ```
  */
  async copy(r, e, t) {
    var s = this;
    return s.handleOperation(async () => ({ path: (await X(s.fetch, `${s.url}/object/copy`, {
      bucketId: s.bucketId,
      sourceKey: r,
      destinationKey: e,
      destinationBucket: t == null ? void 0 : t.destinationBucket
    }, { headers: s.headers })).Key }));
  }
  /**
  * Creates a signed URL. Use a signed URL to share a file for a fixed amount of time.
  *
  * @category File Buckets
  * @param path The file path, including the current file name. For example `folder/image.png`.
  * @param expiresIn The number of seconds until the signed URL expires. For example, `60` for a URL which is valid for one minute.
  * @param options.download triggers the file as a download if set to true. Set this parameter as the name of the file if you want to trigger the download with a different filename.
  * @param options.transform Transform the asset before serving it to the client.
  * @returns Promise with response containing signed URL or error
  *
  * @example Create Signed URL
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .createSignedUrl('folder/avatar1.png', 60)
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "signedUrl": "https://example.supabase.co/storage/v1/object/sign/avatars/folder/avatar1.png?token=<TOKEN>"
  *   },
  *   "error": null
  * }
  * ```
  *
  * @example Create a signed URL for an asset with transformations
  * ```js
  * const { data } = await supabase
  *   .storage
  *   .from('avatars')
  *   .createSignedUrl('folder/avatar1.png', 60, {
  *     transform: {
  *       width: 100,
  *       height: 100,
  *     }
  *   })
  * ```
  *
  * @example Create a signed URL which triggers the download of the asset
  * ```js
  * const { data } = await supabase
  *   .storage
  *   .from('avatars')
  *   .createSignedUrl('folder/avatar1.png', 60, {
  *     download: true,
  *   })
  * ```
  */
  async createSignedUrl(r, e, t) {
    var s = this;
    return s.handleOperation(async () => {
      let n = s._getFinalPath(r), i = await X(s.fetch, `${s.url}/object/sign/${n}`, A({ expiresIn: e }, t != null && t.transform ? { transform: t.transform } : {}), { headers: s.headers });
      const a = t != null && t.download ? `&download=${t.download === !0 ? "" : t.download}` : "";
      return { signedUrl: encodeURI(`${s.url}${i.signedURL}${a}`) };
    });
  }
  /**
  * Creates multiple signed URLs. Use a signed URL to share a file for a fixed amount of time.
  *
  * @category File Buckets
  * @param paths The file paths to be downloaded, including the current file names. For example `['folder/image.png', 'folder2/image2.png']`.
  * @param expiresIn The number of seconds until the signed URLs expire. For example, `60` for URLs which are valid for one minute.
  * @param options.download triggers the file as a download if set to true. Set this parameter as the name of the file if you want to trigger the download with a different filename.
  * @returns Promise with response containing array of objects with signedUrl, path, and error or error
  *
  * @example Create Signed URLs
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .createSignedUrls(['folder/avatar1.png', 'folder/avatar2.png'], 60)
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": [
  *     {
  *       "error": null,
  *       "path": "folder/avatar1.png",
  *       "signedURL": "/object/sign/avatars/folder/avatar1.png?token=<TOKEN>",
  *       "signedUrl": "https://example.supabase.co/storage/v1/object/sign/avatars/folder/avatar1.png?token=<TOKEN>"
  *     },
  *     {
  *       "error": null,
  *       "path": "folder/avatar2.png",
  *       "signedURL": "/object/sign/avatars/folder/avatar2.png?token=<TOKEN>",
  *       "signedUrl": "https://example.supabase.co/storage/v1/object/sign/avatars/folder/avatar2.png?token=<TOKEN>"
  *     }
  *   ],
  *   "error": null
  * }
  * ```
  */
  async createSignedUrls(r, e, t) {
    var s = this;
    return s.handleOperation(async () => {
      const n = await X(s.fetch, `${s.url}/object/sign/${s.bucketId}`, {
        expiresIn: e,
        paths: r
      }, { headers: s.headers }), i = t != null && t.download ? `&download=${t.download === !0 ? "" : t.download}` : "";
      return n.map((a) => A(A({}, a), {}, { signedUrl: a.signedURL ? encodeURI(`${s.url}${a.signedURL}${i}`) : null }));
    });
  }
  /**
  * Downloads a file from a private bucket. For public buckets, make a request to the URL returned from `getPublicUrl` instead.
  *
  * @category File Buckets
  * @param path The full path and file name of the file to be downloaded. For example `folder/image.png`.
  * @param options.transform Transform the asset before serving it to the client.
  * @returns BlobDownloadBuilder instance for downloading the file
  *
  * @example Download file
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .download('folder/avatar1.png')
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": <BLOB>,
  *   "error": null
  * }
  * ```
  *
  * @example Download file with transformations
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .download('folder/avatar1.png', {
  *     transform: {
  *       width: 100,
  *       height: 100,
  *       quality: 80
  *     }
  *   })
  * ```
  */
  download(r, e) {
    const t = typeof (e == null ? void 0 : e.transform) < "u" ? "render/image/authenticated" : "object", s = this.transformOptsToQueryString((e == null ? void 0 : e.transform) || {}), n = s ? `?${s}` : "", i = this._getFinalPath(r), a = () => Be(this.fetch, `${this.url}/${t}/${i}${n}`, {
      headers: this.headers,
      noResolveJson: !0
    });
    return new Rn(a, this.shouldThrowOnError);
  }
  /**
  * Retrieves the details of an existing file.
  *
  * @category File Buckets
  * @param path The file path, including the file name. For example `folder/image.png`.
  * @returns Promise with response containing file metadata or error
  *
  * @example Get file info
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .info('folder/avatar1.png')
  * ```
  */
  async info(r) {
    var e = this;
    const t = e._getFinalPath(r);
    return e.handleOperation(async () => At(await Be(e.fetch, `${e.url}/object/info/${t}`, { headers: e.headers })));
  }
  /**
  * Checks the existence of a file.
  *
  * @category File Buckets
  * @param path The file path, including the file name. For example `folder/image.png`.
  * @returns Promise with response containing boolean indicating file existence or error
  *
  * @example Check file existence
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .exists('folder/avatar1.png')
  * ```
  */
  async exists(r) {
    var e = this;
    const t = e._getFinalPath(r);
    try {
      return await kn(e.fetch, `${e.url}/object/${t}`, { headers: e.headers }), {
        data: !0,
        error: null
      };
    } catch (s) {
      if (e.shouldThrowOnError) throw s;
      if (ot(s) && s instanceof es) {
        const n = s.originalError;
        if ([400, 404].includes(n == null ? void 0 : n.status)) return {
          data: !1,
          error: s
        };
      }
      throw s;
    }
  }
  /**
  * A simple convenience function to get the URL for an asset in a public bucket. If you do not want to use this function, you can construct the public URL by concatenating the bucket URL with the path to the asset.
  * This function does not verify if the bucket is public. If a public URL is created for a bucket which is not public, you will not be able to download the asset.
  *
  * @category File Buckets
  * @param path The path and name of the file to generate the public URL for. For example `folder/image.png`.
  * @param options.download Triggers the file as a download if set to true. Set this parameter as the name of the file if you want to trigger the download with a different filename.
  * @param options.transform Transform the asset before serving it to the client.
  * @returns Object with public URL
  *
  * @example Returns the URL for an asset in a public bucket
  * ```js
  * const { data } = supabase
  *   .storage
  *   .from('public-bucket')
  *   .getPublicUrl('folder/avatar1.png')
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "publicUrl": "https://example.supabase.co/storage/v1/object/public/public-bucket/folder/avatar1.png"
  *   }
  * }
  * ```
  *
  * @example Returns the URL for an asset in a public bucket with transformations
  * ```js
  * const { data } = supabase
  *   .storage
  *   .from('public-bucket')
  *   .getPublicUrl('folder/avatar1.png', {
  *     transform: {
  *       width: 100,
  *       height: 100,
  *     }
  *   })
  * ```
  *
  * @example Returns the URL which triggers the download of an asset in a public bucket
  * ```js
  * const { data } = supabase
  *   .storage
  *   .from('public-bucket')
  *   .getPublicUrl('folder/avatar1.png', {
  *     download: true,
  *   })
  * ```
  */
  getPublicUrl(r, e) {
    const t = this._getFinalPath(r), s = [], n = e != null && e.download ? `download=${e.download === !0 ? "" : e.download}` : "";
    n !== "" && s.push(n);
    const i = typeof (e == null ? void 0 : e.transform) < "u" ? "render/image" : "object", a = this.transformOptsToQueryString((e == null ? void 0 : e.transform) || {});
    a !== "" && s.push(a);
    let o = s.join("&");
    return o !== "" && (o = `?${o}`), { data: { publicUrl: encodeURI(`${this.url}/${i}/public/${t}${o}`) } };
  }
  /**
  * Deletes files within the same bucket
  *
  * @category File Buckets
  * @param paths An array of files to delete, including the path and file name. For example [`'folder/image.png'`].
  * @returns Promise with response containing array of deleted file objects or error
  *
  * @example Delete file
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .remove(['folder/avatar1.png'])
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": [],
  *   "error": null
  * }
  * ```
  */
  async remove(r) {
    var e = this;
    return e.handleOperation(async () => await qt(e.fetch, `${e.url}/object/${e.bucketId}`, { prefixes: r }, { headers: e.headers }));
  }
  /**
  * Get file metadata
  * @param id the file id to retrieve metadata
  */
  /**
  * Update file metadata
  * @param id the file id to update metadata
  * @param meta the new file metadata
  */
  /**
  * Lists all the files and folders within a path of the bucket.
  *
  * @category File Buckets
  * @param path The folder path.
  * @param options Search options including limit (defaults to 100), offset, sortBy, and search
  * @param parameters Optional fetch parameters including signal for cancellation
  * @returns Promise with response containing array of files or error
  *
  * @example List files in a bucket
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .list('folder', {
  *     limit: 100,
  *     offset: 0,
  *     sortBy: { column: 'name', order: 'asc' },
  *   })
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": [
  *     {
  *       "name": "avatar1.png",
  *       "id": "e668cf7f-821b-4a2f-9dce-7dfa5dd1cfd2",
  *       "updated_at": "2024-05-22T23:06:05.580Z",
  *       "created_at": "2024-05-22T23:04:34.443Z",
  *       "last_accessed_at": "2024-05-22T23:04:34.443Z",
  *       "metadata": {
  *         "eTag": "\"c5e8c553235d9af30ef4f6e280790b92\"",
  *         "size": 32175,
  *         "mimetype": "image/png",
  *         "cacheControl": "max-age=3600",
  *         "lastModified": "2024-05-22T23:06:05.574Z",
  *         "contentLength": 32175,
  *         "httpStatusCode": 200
  *       }
  *     }
  *   ],
  *   "error": null
  * }
  * ```
  *
  * @example Search files in a bucket
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .list('folder', {
  *     limit: 100,
  *     offset: 0,
  *     sortBy: { column: 'name', order: 'asc' },
  *     search: 'jon'
  *   })
  * ```
  */
  async list(r, e, t) {
    var s = this;
    return s.handleOperation(async () => {
      const n = A(A(A({}, Cn), e), {}, { prefix: r || "" });
      return await X(s.fetch, `${s.url}/object/list/${s.bucketId}`, n, { headers: s.headers }, t);
    });
  }
  /**
  * @experimental this method signature might change in the future
  *
  * @category File Buckets
  * @param options search options
  * @param parameters
  */
  async listV2(r, e) {
    var t = this;
    return t.handleOperation(async () => {
      const s = A({}, r);
      return await X(t.fetch, `${t.url}/object/list-v2/${t.bucketId}`, s, { headers: t.headers }, e);
    });
  }
  encodeMetadata(r) {
    return JSON.stringify(r);
  }
  toBase64(r) {
    return typeof Buffer < "u" ? Buffer.from(r).toString("base64") : btoa(r);
  }
  _getFinalPath(r) {
    return `${this.bucketId}/${r.replace(/^\/+/, "")}`;
  }
  _removeEmptyFolders(r) {
    return r.replace(/^\/|\/$/g, "").replace(/\/+/g, "/");
  }
  transformOptsToQueryString(r) {
    const e = [];
    return r.width && e.push(`width=${r.width}`), r.height && e.push(`height=${r.height}`), r.resize && e.push(`resize=${r.resize}`), r.format && e.push(`format=${r.format}`), r.quality && e.push(`quality=${r.quality}`), e.join("&");
  }
};
const xn = "2.93.3", Ve = { "X-Client-Info": `storage-js/${xn}` };
var $n = class extends $e {
  constructor(r, e = {}, t, s) {
    const n = new URL(r);
    s != null && s.useNewHostname && /supabase\.(co|in|red)$/.test(n.hostname) && !n.hostname.includes("storage.supabase.") && (n.hostname = n.hostname.replace("supabase.", "storage.supabase."));
    const i = n.href.replace(/\/$/, ""), a = A(A({}, Ve), e);
    super(i, a, t, "storage");
  }
  /**
  * Retrieves the details of all Storage buckets within an existing project.
  *
  * @category File Buckets
  * @param options Query parameters for listing buckets
  * @param options.limit Maximum number of buckets to return
  * @param options.offset Number of buckets to skip
  * @param options.sortColumn Column to sort by ('id', 'name', 'created_at', 'updated_at')
  * @param options.sortOrder Sort order ('asc' or 'desc')
  * @param options.search Search term to filter bucket names
  * @returns Promise with response containing array of buckets or error
  *
  * @example List buckets
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .listBuckets()
  * ```
  *
  * @example List buckets with options
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .listBuckets({
  *     limit: 10,
  *     offset: 0,
  *     sortColumn: 'created_at',
  *     sortOrder: 'desc',
  *     search: 'prod'
  *   })
  * ```
  */
  async listBuckets(r) {
    var e = this;
    return e.handleOperation(async () => {
      const t = e.listBucketOptionsToQueryString(r);
      return await Be(e.fetch, `${e.url}/bucket${t}`, { headers: e.headers });
    });
  }
  /**
  * Retrieves the details of an existing Storage bucket.
  *
  * @category File Buckets
  * @param id The unique identifier of the bucket you would like to retrieve.
  * @returns Promise with response containing bucket details or error
  *
  * @example Get bucket
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .getBucket('avatars')
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "id": "avatars",
  *     "name": "avatars",
  *     "owner": "",
  *     "public": false,
  *     "file_size_limit": 1024,
  *     "allowed_mime_types": [
  *       "image/png"
  *     ],
  *     "created_at": "2024-05-22T22:26:05.100Z",
  *     "updated_at": "2024-05-22T22:26:05.100Z"
  *   },
  *   "error": null
  * }
  * ```
  */
  async getBucket(r) {
    var e = this;
    return e.handleOperation(async () => await Be(e.fetch, `${e.url}/bucket/${r}`, { headers: e.headers }));
  }
  /**
  * Creates a new Storage bucket
  *
  * @category File Buckets
  * @param id A unique identifier for the bucket you are creating.
  * @param options.public The visibility of the bucket. Public buckets don't require an authorization token to download objects, but still require a valid token for all other operations. By default, buckets are private.
  * @param options.fileSizeLimit specifies the max file size in bytes that can be uploaded to this bucket.
  * The global file size limit takes precedence over this value.
  * The default value is null, which doesn't set a per bucket file size limit.
  * @param options.allowedMimeTypes specifies the allowed mime types that this bucket can accept during upload.
  * The default value is null, which allows files with all mime types to be uploaded.
  * Each mime type specified can be a wildcard, e.g. image/*, or a specific mime type, e.g. image/png.
  * @param options.type (private-beta) specifies the bucket type. see `BucketType` for more details.
  *   - default bucket type is `STANDARD`
  * @returns Promise with response containing newly created bucket name or error
  *
  * @example Create bucket
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .createBucket('avatars', {
  *     public: false,
  *     allowedMimeTypes: ['image/png'],
  *     fileSizeLimit: 1024
  *   })
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "name": "avatars"
  *   },
  *   "error": null
  * }
  * ```
  */
  async createBucket(r, e = { public: !1 }) {
    var t = this;
    return t.handleOperation(async () => await X(t.fetch, `${t.url}/bucket`, {
      id: r,
      name: r,
      type: e.type,
      public: e.public,
      file_size_limit: e.fileSizeLimit,
      allowed_mime_types: e.allowedMimeTypes
    }, { headers: t.headers }));
  }
  /**
  * Updates a Storage bucket
  *
  * @category File Buckets
  * @param id A unique identifier for the bucket you are updating.
  * @param options.public The visibility of the bucket. Public buckets don't require an authorization token to download objects, but still require a valid token for all other operations.
  * @param options.fileSizeLimit specifies the max file size in bytes that can be uploaded to this bucket.
  * The global file size limit takes precedence over this value.
  * The default value is null, which doesn't set a per bucket file size limit.
  * @param options.allowedMimeTypes specifies the allowed mime types that this bucket can accept during upload.
  * The default value is null, which allows files with all mime types to be uploaded.
  * Each mime type specified can be a wildcard, e.g. image/*, or a specific mime type, e.g. image/png.
  * @returns Promise with response containing success message or error
  *
  * @example Update bucket
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .updateBucket('avatars', {
  *     public: false,
  *     allowedMimeTypes: ['image/png'],
  *     fileSizeLimit: 1024
  *   })
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "message": "Successfully updated"
  *   },
  *   "error": null
  * }
  * ```
  */
  async updateBucket(r, e) {
    var t = this;
    return t.handleOperation(async () => await kt(t.fetch, `${t.url}/bucket/${r}`, {
      id: r,
      name: r,
      public: e.public,
      file_size_limit: e.fileSizeLimit,
      allowed_mime_types: e.allowedMimeTypes
    }, { headers: t.headers }));
  }
  /**
  * Removes all objects inside a single bucket.
  *
  * @category File Buckets
  * @param id The unique identifier of the bucket you would like to empty.
  * @returns Promise with success message or error
  *
  * @example Empty bucket
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .emptyBucket('avatars')
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "message": "Successfully emptied"
  *   },
  *   "error": null
  * }
  * ```
  */
  async emptyBucket(r) {
    var e = this;
    return e.handleOperation(async () => await X(e.fetch, `${e.url}/bucket/${r}/empty`, {}, { headers: e.headers }));
  }
  /**
  * Deletes an existing bucket. A bucket can't be deleted with existing objects inside it.
  * You must first `empty()` the bucket.
  *
  * @category File Buckets
  * @param id The unique identifier of the bucket you would like to delete.
  * @returns Promise with success message or error
  *
  * @example Delete bucket
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .deleteBucket('avatars')
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "message": "Successfully deleted"
  *   },
  *   "error": null
  * }
  * ```
  */
  async deleteBucket(r) {
    var e = this;
    return e.handleOperation(async () => await qt(e.fetch, `${e.url}/bucket/${r}`, {}, { headers: e.headers }));
  }
  listBucketOptionsToQueryString(r) {
    const e = {};
    return r && ("limit" in r && (e.limit = String(r.limit)), "offset" in r && (e.offset = String(r.offset)), r.search && (e.search = r.search), r.sortColumn && (e.sortColumn = r.sortColumn), r.sortOrder && (e.sortOrder = r.sortOrder)), Object.keys(e).length > 0 ? "?" + new URLSearchParams(e).toString() : "";
  }
}, Pn = class extends $e {
  /**
  * @alpha
  *
  * Creates a new StorageAnalyticsClient instance
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Analytics Buckets
  * @param url - The base URL for the storage API
  * @param headers - HTTP headers to include in requests
  * @param fetch - Optional custom fetch implementation
  *
  * @example
  * ```typescript
  * const client = new StorageAnalyticsClient(url, headers)
  * ```
  */
  constructor(r, e = {}, t) {
    const s = r.replace(/\/$/, ""), n = A(A({}, Ve), e);
    super(s, n, t, "storage");
  }
  /**
  * @alpha
  *
  * Creates a new analytics bucket using Iceberg tables
  * Analytics buckets are optimized for analytical queries and data processing
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Analytics Buckets
  * @param name A unique name for the bucket you are creating
  * @returns Promise with response containing newly created analytics bucket or error
  *
  * @example Create analytics bucket
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .analytics
  *   .createBucket('analytics-data')
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "name": "analytics-data",
  *     "type": "ANALYTICS",
  *     "format": "iceberg",
  *     "created_at": "2024-05-22T22:26:05.100Z",
  *     "updated_at": "2024-05-22T22:26:05.100Z"
  *   },
  *   "error": null
  * }
  * ```
  */
  async createBucket(r) {
    var e = this;
    return e.handleOperation(async () => await X(e.fetch, `${e.url}/bucket`, { name: r }, { headers: e.headers }));
  }
  /**
  * @alpha
  *
  * Retrieves the details of all Analytics Storage buckets within an existing project
  * Only returns buckets of type 'ANALYTICS'
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Analytics Buckets
  * @param options Query parameters for listing buckets
  * @param options.limit Maximum number of buckets to return
  * @param options.offset Number of buckets to skip
  * @param options.sortColumn Column to sort by ('name', 'created_at', 'updated_at')
  * @param options.sortOrder Sort order ('asc' or 'desc')
  * @param options.search Search term to filter bucket names
  * @returns Promise with response containing array of analytics buckets or error
  *
  * @example List analytics buckets
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .analytics
  *   .listBuckets({
  *     limit: 10,
  *     offset: 0,
  *     sortColumn: 'created_at',
  *     sortOrder: 'desc'
  *   })
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": [
  *     {
  *       "name": "analytics-data",
  *       "type": "ANALYTICS",
  *       "format": "iceberg",
  *       "created_at": "2024-05-22T22:26:05.100Z",
  *       "updated_at": "2024-05-22T22:26:05.100Z"
  *     }
  *   ],
  *   "error": null
  * }
  * ```
  */
  async listBuckets(r) {
    var e = this;
    return e.handleOperation(async () => {
      const t = new URLSearchParams();
      (r == null ? void 0 : r.limit) !== void 0 && t.set("limit", r.limit.toString()), (r == null ? void 0 : r.offset) !== void 0 && t.set("offset", r.offset.toString()), r != null && r.sortColumn && t.set("sortColumn", r.sortColumn), r != null && r.sortOrder && t.set("sortOrder", r.sortOrder), r != null && r.search && t.set("search", r.search);
      const s = t.toString(), n = s ? `${e.url}/bucket?${s}` : `${e.url}/bucket`;
      return await Be(e.fetch, n, { headers: e.headers });
    });
  }
  /**
  * @alpha
  *
  * Deletes an existing analytics bucket
  * A bucket can't be deleted with existing objects inside it
  * You must first empty the bucket before deletion
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Analytics Buckets
  * @param bucketName The unique identifier of the bucket you would like to delete
  * @returns Promise with response containing success message or error
  *
  * @example Delete analytics bucket
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .analytics
  *   .deleteBucket('analytics-data')
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "message": "Successfully deleted"
  *   },
  *   "error": null
  * }
  * ```
  */
  async deleteBucket(r) {
    var e = this;
    return e.handleOperation(async () => await qt(e.fetch, `${e.url}/bucket/${r}`, {}, { headers: e.headers }));
  }
  /**
  * @alpha
  *
  * Get an Iceberg REST Catalog client configured for a specific analytics bucket
  * Use this to perform advanced table and namespace operations within the bucket
  * The returned client provides full access to the Apache Iceberg REST Catalog API
  * with the Supabase `{ data, error }` pattern for consistent error handling on all operations.
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Analytics Buckets
  * @param bucketName - The name of the analytics bucket (warehouse) to connect to
  * @returns The wrapped Iceberg catalog client
  * @throws {StorageError} If the bucket name is invalid
  *
  * @example Get catalog and create table
  * ```js
  * // First, create an analytics bucket
  * const { data: bucket, error: bucketError } = await supabase
  *   .storage
  *   .analytics
  *   .createBucket('analytics-data')
  *
  * // Get the Iceberg catalog for that bucket
  * const catalog = supabase.storage.analytics.from('analytics-data')
  *
  * // Create a namespace
  * const { error: nsError } = await catalog.createNamespace({ namespace: ['default'] })
  *
  * // Create a table with schema
  * const { data: tableMetadata, error: tableError } = await catalog.createTable(
  *   { namespace: ['default'] },
  *   {
  *     name: 'events',
  *     schema: {
  *       type: 'struct',
  *       fields: [
  *         { id: 1, name: 'id', type: 'long', required: true },
  *         { id: 2, name: 'timestamp', type: 'timestamp', required: true },
  *         { id: 3, name: 'user_id', type: 'string', required: false }
  *       ],
  *       'schema-id': 0,
  *       'identifier-field-ids': [1]
  *     },
  *     'partition-spec': {
  *       'spec-id': 0,
  *       fields: []
  *     },
  *     'write-order': {
  *       'order-id': 0,
  *       fields: []
  *     },
  *     properties: {
  *       'write.format.default': 'parquet'
  *     }
  *   }
  * )
  * ```
  *
  * @example List tables in namespace
  * ```js
  * const catalog = supabase.storage.analytics.from('analytics-data')
  *
  * // List all tables in the default namespace
  * const { data: tables, error: listError } = await catalog.listTables({ namespace: ['default'] })
  * if (listError) {
  *   if (listError.isNotFound()) {
  *     console.log('Namespace not found')
  *   }
  *   return
  * }
  * console.log(tables) // [{ namespace: ['default'], name: 'events' }]
  * ```
  *
  * @example Working with namespaces
  * ```js
  * const catalog = supabase.storage.analytics.from('analytics-data')
  *
  * // List all namespaces
  * const { data: namespaces } = await catalog.listNamespaces()
  *
  * // Create namespace with properties
  * await catalog.createNamespace(
  *   { namespace: ['production'] },
  *   { properties: { owner: 'data-team', env: 'prod' } }
  * )
  * ```
  *
  * @example Cleanup operations
  * ```js
  * const catalog = supabase.storage.analytics.from('analytics-data')
  *
  * // Drop table with purge option (removes all data)
  * const { error: dropError } = await catalog.dropTable(
  *   { namespace: ['default'], name: 'events' },
  *   { purge: true }
  * )
  *
  * if (dropError?.isNotFound()) {
  *   console.log('Table does not exist')
  * }
  *
  * // Drop namespace (must be empty)
  * await catalog.dropNamespace({ namespace: ['default'] })
  * ```
  *
  * @remarks
  * This method provides a bridge between Supabase's bucket management and the standard
  * Apache Iceberg REST Catalog API. The bucket name maps to the Iceberg warehouse parameter.
  * All authentication and configuration is handled automatically using your Supabase credentials.
  *
  * **Error Handling**: Invalid bucket names throw immediately. All catalog
  * operations return `{ data, error }` where errors are `IcebergError` instances from iceberg-js.
  * Use helper methods like `error.isNotFound()` or check `error.status` for specific error handling.
  * Use `.throwOnError()` on the analytics client if you prefer exceptions for catalog operations.
  *
  * **Cleanup Operations**: When using `dropTable`, the `purge: true` option permanently
  * deletes all table data. Without it, the table is marked as deleted but data remains.
  *
  * **Library Dependency**: The returned catalog wraps `IcebergRestCatalog` from iceberg-js.
  * For complete API documentation and advanced usage, refer to the
  * [iceberg-js documentation](https://supabase.github.io/iceberg-js/).
  */
  from(r) {
    var e = this;
    if (!vn(r)) throw new at("Invalid bucket name: File, folder, and bucket names must follow AWS object key naming guidelines and should avoid the use of any other characters.");
    const t = new mn({
      baseUrl: this.url,
      catalogName: r,
      auth: {
        type: "custom",
        getHeaders: async () => e.headers
      },
      fetch: this.fetch
    }), s = this.shouldThrowOnError;
    return new Proxy(t, { get(n, i) {
      const a = n[i];
      return typeof a != "function" ? a : async (...o) => {
        try {
          return {
            data: await a.apply(n, o),
            error: null
          };
        } catch (c) {
          if (s) throw c;
          return {
            data: null,
            error: c
          };
        }
      };
    } });
  }
}, Nn = class extends $e {
  /** Creates a new VectorIndexApi instance */
  constructor(r, e = {}, t) {
    const s = r.replace(/\/$/, ""), n = A(A({}, Ve), {}, { "Content-Type": "application/json" }, e);
    super(s, n, t, "vectors");
  }
  /** Creates a new vector index within a bucket */
  async createIndex(r) {
    var e = this;
    return e.handleOperation(async () => await G.post(e.fetch, `${e.url}/CreateIndex`, r, { headers: e.headers }) || {});
  }
  /** Retrieves metadata for a specific vector index */
  async getIndex(r, e) {
    var t = this;
    return t.handleOperation(async () => await G.post(t.fetch, `${t.url}/GetIndex`, {
      vectorBucketName: r,
      indexName: e
    }, { headers: t.headers }));
  }
  /** Lists vector indexes within a bucket with optional filtering and pagination */
  async listIndexes(r) {
    var e = this;
    return e.handleOperation(async () => await G.post(e.fetch, `${e.url}/ListIndexes`, r, { headers: e.headers }));
  }
  /** Deletes a vector index and all its data */
  async deleteIndex(r, e) {
    var t = this;
    return t.handleOperation(async () => await G.post(t.fetch, `${t.url}/DeleteIndex`, {
      vectorBucketName: r,
      indexName: e
    }, { headers: t.headers }) || {});
  }
}, jn = class extends $e {
  /** Creates a new VectorDataApi instance */
  constructor(r, e = {}, t) {
    const s = r.replace(/\/$/, ""), n = A(A({}, Ve), {}, { "Content-Type": "application/json" }, e);
    super(s, n, t, "vectors");
  }
  /** Inserts or updates vectors in batch (1-500 per request) */
  async putVectors(r) {
    var e = this;
    if (r.vectors.length < 1 || r.vectors.length > 500) throw new Error("Vector batch size must be between 1 and 500 items");
    return e.handleOperation(async () => await G.post(e.fetch, `${e.url}/PutVectors`, r, { headers: e.headers }) || {});
  }
  /** Retrieves vectors by their keys in batch */
  async getVectors(r) {
    var e = this;
    return e.handleOperation(async () => await G.post(e.fetch, `${e.url}/GetVectors`, r, { headers: e.headers }));
  }
  /** Lists vectors in an index with pagination */
  async listVectors(r) {
    var e = this;
    if (r.segmentCount !== void 0) {
      if (r.segmentCount < 1 || r.segmentCount > 16) throw new Error("segmentCount must be between 1 and 16");
      if (r.segmentIndex !== void 0 && (r.segmentIndex < 0 || r.segmentIndex >= r.segmentCount))
        throw new Error(`segmentIndex must be between 0 and ${r.segmentCount - 1}`);
    }
    return e.handleOperation(async () => await G.post(e.fetch, `${e.url}/ListVectors`, r, { headers: e.headers }));
  }
  /** Queries for similar vectors using approximate nearest neighbor search */
  async queryVectors(r) {
    var e = this;
    return e.handleOperation(async () => await G.post(e.fetch, `${e.url}/QueryVectors`, r, { headers: e.headers }));
  }
  /** Deletes vectors by their keys in batch (1-500 per request) */
  async deleteVectors(r) {
    var e = this;
    if (r.keys.length < 1 || r.keys.length > 500) throw new Error("Keys batch size must be between 1 and 500 items");
    return e.handleOperation(async () => await G.post(e.fetch, `${e.url}/DeleteVectors`, r, { headers: e.headers }) || {});
  }
}, Un = class extends $e {
  /** Creates a new VectorBucketApi instance */
  constructor(r, e = {}, t) {
    const s = r.replace(/\/$/, ""), n = A(A({}, Ve), {}, { "Content-Type": "application/json" }, e);
    super(s, n, t, "vectors");
  }
  /** Creates a new vector bucket */
  async createBucket(r) {
    var e = this;
    return e.handleOperation(async () => await G.post(e.fetch, `${e.url}/CreateVectorBucket`, { vectorBucketName: r }, { headers: e.headers }) || {});
  }
  /** Retrieves metadata for a specific vector bucket */
  async getBucket(r) {
    var e = this;
    return e.handleOperation(async () => await G.post(e.fetch, `${e.url}/GetVectorBucket`, { vectorBucketName: r }, { headers: e.headers }));
  }
  /** Lists vector buckets with optional filtering and pagination */
  async listBuckets(r = {}) {
    var e = this;
    return e.handleOperation(async () => await G.post(e.fetch, `${e.url}/ListVectorBuckets`, r, { headers: e.headers }));
  }
  /** Deletes a vector bucket (must be empty first) */
  async deleteBucket(r) {
    var e = this;
    return e.handleOperation(async () => await G.post(e.fetch, `${e.url}/DeleteVectorBucket`, { vectorBucketName: r }, { headers: e.headers }) || {});
  }
}, Ln = class extends Un {
  /**
  * @alpha
  *
  * Creates a StorageVectorsClient that can manage buckets, indexes, and vectors.
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param url - Base URL of the Storage Vectors REST API.
  * @param options.headers - Optional headers (for example `Authorization`) applied to every request.
  * @param options.fetch - Optional custom `fetch` implementation for non-browser runtimes.
  *
  * @example
  * ```typescript
  * const client = new StorageVectorsClient(url, options)
  * ```
  */
  constructor(r, e = {}) {
    super(r, e.headers || {}, e.fetch);
  }
  /**
  *
  * @alpha
  *
  * Access operations for a specific vector bucket
  * Returns a scoped client for index and vector operations within the bucket
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param vectorBucketName - Name of the vector bucket
  * @returns Bucket-scoped client with index and vector operations
  *
  * @example
  * ```typescript
  * const bucket = supabase.storage.vectors.from('embeddings-prod')
  * ```
  */
  from(r) {
    return new Dn(this.url, this.headers, r, this.fetch);
  }
  /**
  *
  * @alpha
  *
  * Creates a new vector bucket
  * Vector buckets are containers for vector indexes and their data
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param vectorBucketName - Unique name for the vector bucket
  * @returns Promise with empty response on success or error
  *
  * @example
  * ```typescript
  * const { data, error } = await supabase
  *   .storage
  *   .vectors
  *   .createBucket('embeddings-prod')
  * ```
  */
  async createBucket(r) {
    var e = () => super.createBucket, t = this;
    return e().call(t, r);
  }
  /**
  *
  * @alpha
  *
  * Retrieves metadata for a specific vector bucket
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param vectorBucketName - Name of the vector bucket
  * @returns Promise with bucket metadata or error
  *
  * @example
  * ```typescript
  * const { data, error } = await supabase
  *   .storage
  *   .vectors
  *   .getBucket('embeddings-prod')
  *
  * console.log('Bucket created:', data?.vectorBucket.creationTime)
  * ```
  */
  async getBucket(r) {
    var e = () => super.getBucket, t = this;
    return e().call(t, r);
  }
  /**
  *
  * @alpha
  *
  * Lists all vector buckets with optional filtering and pagination
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param options - Optional filters (prefix, maxResults, nextToken)
  * @returns Promise with list of buckets or error
  *
  * @example
  * ```typescript
  * const { data, error } = await supabase
  *   .storage
  *   .vectors
  *   .listBuckets({ prefix: 'embeddings-' })
  *
  * data?.vectorBuckets.forEach(bucket => {
  *   console.log(bucket.vectorBucketName)
  * })
  * ```
  */
  async listBuckets(r = {}) {
    var e = () => super.listBuckets, t = this;
    return e().call(t, r);
  }
  /**
  *
  * @alpha
  *
  * Deletes a vector bucket (bucket must be empty)
  * All indexes must be deleted before deleting the bucket
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param vectorBucketName - Name of the vector bucket to delete
  * @returns Promise with empty response on success or error
  *
  * @example
  * ```typescript
  * const { data, error } = await supabase
  *   .storage
  *   .vectors
  *   .deleteBucket('embeddings-old')
  * ```
  */
  async deleteBucket(r) {
    var e = () => super.deleteBucket, t = this;
    return e().call(t, r);
  }
}, Dn = class extends Nn {
  /**
  * @alpha
  *
  * Creates a helper that automatically scopes all index operations to the provided bucket.
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @example
  * ```typescript
  * const bucket = supabase.storage.vectors.from('embeddings-prod')
  * ```
  */
  constructor(r, e, t, s) {
    super(r, e, s), this.vectorBucketName = t;
  }
  /**
  *
  * @alpha
  *
  * Creates a new vector index in this bucket
  * Convenience method that automatically includes the bucket name
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param options - Index configuration (vectorBucketName is automatically set)
  * @returns Promise with empty response on success or error
  *
  * @example
  * ```typescript
  * const bucket = supabase.storage.vectors.from('embeddings-prod')
  * await bucket.createIndex({
  *   indexName: 'documents-openai',
  *   dataType: 'float32',
  *   dimension: 1536,
  *   distanceMetric: 'cosine',
  *   metadataConfiguration: {
  *     nonFilterableMetadataKeys: ['raw_text']
  *   }
  * })
  * ```
  */
  async createIndex(r) {
    var e = () => super.createIndex, t = this;
    return e().call(t, A(A({}, r), {}, { vectorBucketName: t.vectorBucketName }));
  }
  /**
  *
  * @alpha
  *
  * Lists indexes in this bucket
  * Convenience method that automatically includes the bucket name
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param options - Listing options (vectorBucketName is automatically set)
  * @returns Promise with response containing indexes array and pagination token or error
  *
  * @example
  * ```typescript
  * const bucket = supabase.storage.vectors.from('embeddings-prod')
  * const { data } = await bucket.listIndexes({ prefix: 'documents-' })
  * ```
  */
  async listIndexes(r = {}) {
    var e = () => super.listIndexes, t = this;
    return e().call(t, A(A({}, r), {}, { vectorBucketName: t.vectorBucketName }));
  }
  /**
  *
  * @alpha
  *
  * Retrieves metadata for a specific index in this bucket
  * Convenience method that automatically includes the bucket name
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param indexName - Name of the index to retrieve
  * @returns Promise with index metadata or error
  *
  * @example
  * ```typescript
  * const bucket = supabase.storage.vectors.from('embeddings-prod')
  * const { data } = await bucket.getIndex('documents-openai')
  * console.log('Dimension:', data?.index.dimension)
  * ```
  */
  async getIndex(r) {
    var e = () => super.getIndex, t = this;
    return e().call(t, t.vectorBucketName, r);
  }
  /**
  *
  * @alpha
  *
  * Deletes an index from this bucket
  * Convenience method that automatically includes the bucket name
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param indexName - Name of the index to delete
  * @returns Promise with empty response on success or error
  *
  * @example
  * ```typescript
  * const bucket = supabase.storage.vectors.from('embeddings-prod')
  * await bucket.deleteIndex('old-index')
  * ```
  */
  async deleteIndex(r) {
    var e = () => super.deleteIndex, t = this;
    return e().call(t, t.vectorBucketName, r);
  }
  /**
  *
  * @alpha
  *
  * Access operations for a specific index within this bucket
  * Returns a scoped client for vector data operations
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param indexName - Name of the index
  * @returns Index-scoped client with vector data operations
  *
  * @example
  * ```typescript
  * const index = supabase.storage.vectors.from('embeddings-prod').index('documents-openai')
  *
  * // Insert vectors
  * await index.putVectors({
  *   vectors: [
  *     { key: 'doc-1', data: { float32: [...] }, metadata: { title: 'Intro' } }
  *   ]
  * })
  *
  * // Query similar vectors
  * const { data } = await index.queryVectors({
  *   queryVector: { float32: [...] },
  *   topK: 5
  * })
  * ```
  */
  index(r) {
    return new Mn(this.url, this.headers, this.vectorBucketName, r, this.fetch);
  }
}, Mn = class extends jn {
  /**
  *
  * @alpha
  *
  * Creates a helper that automatically scopes all vector operations to the provided bucket/index names.
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @example
  * ```typescript
  * const index = supabase.storage.vectors.from('embeddings-prod').index('documents-openai')
  * ```
  */
  constructor(r, e, t, s, n) {
    super(r, e, n), this.vectorBucketName = t, this.indexName = s;
  }
  /**
  *
  * @alpha
  *
  * Inserts or updates vectors in this index
  * Convenience method that automatically includes bucket and index names
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param options - Vector insertion options (bucket and index names automatically set)
  * @returns Promise with empty response on success or error
  *
  * @example
  * ```typescript
  * const index = supabase.storage.vectors.from('embeddings-prod').index('documents-openai')
  * await index.putVectors({
  *   vectors: [
  *     {
  *       key: 'doc-1',
  *       data: { float32: [0.1, 0.2, ...] },
  *       metadata: { title: 'Introduction', page: 1 }
  *     }
  *   ]
  * })
  * ```
  */
  async putVectors(r) {
    var e = () => super.putVectors, t = this;
    return e().call(t, A(A({}, r), {}, {
      vectorBucketName: t.vectorBucketName,
      indexName: t.indexName
    }));
  }
  /**
  *
  * @alpha
  *
  * Retrieves vectors by keys from this index
  * Convenience method that automatically includes bucket and index names
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param options - Vector retrieval options (bucket and index names automatically set)
  * @returns Promise with response containing vectors array or error
  *
  * @example
  * ```typescript
  * const index = supabase.storage.vectors.from('embeddings-prod').index('documents-openai')
  * const { data } = await index.getVectors({
  *   keys: ['doc-1', 'doc-2'],
  *   returnMetadata: true
  * })
  * ```
  */
  async getVectors(r) {
    var e = () => super.getVectors, t = this;
    return e().call(t, A(A({}, r), {}, {
      vectorBucketName: t.vectorBucketName,
      indexName: t.indexName
    }));
  }
  /**
  *
  * @alpha
  *
  * Lists vectors in this index with pagination
  * Convenience method that automatically includes bucket and index names
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param options - Listing options (bucket and index names automatically set)
  * @returns Promise with response containing vectors array and pagination token or error
  *
  * @example
  * ```typescript
  * const index = supabase.storage.vectors.from('embeddings-prod').index('documents-openai')
  * const { data } = await index.listVectors({
  *   maxResults: 500,
  *   returnMetadata: true
  * })
  * ```
  */
  async listVectors(r = {}) {
    var e = () => super.listVectors, t = this;
    return e().call(t, A(A({}, r), {}, {
      vectorBucketName: t.vectorBucketName,
      indexName: t.indexName
    }));
  }
  /**
  *
  * @alpha
  *
  * Queries for similar vectors in this index
  * Convenience method that automatically includes bucket and index names
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param options - Query options (bucket and index names automatically set)
  * @returns Promise with response containing matches array of similar vectors ordered by distance or error
  *
  * @example
  * ```typescript
  * const index = supabase.storage.vectors.from('embeddings-prod').index('documents-openai')
  * const { data } = await index.queryVectors({
  *   queryVector: { float32: [0.1, 0.2, ...] },
  *   topK: 5,
  *   filter: { category: 'technical' },
  *   returnDistance: true,
  *   returnMetadata: true
  * })
  * ```
  */
  async queryVectors(r) {
    var e = () => super.queryVectors, t = this;
    return e().call(t, A(A({}, r), {}, {
      vectorBucketName: t.vectorBucketName,
      indexName: t.indexName
    }));
  }
  /**
  *
  * @alpha
  *
  * Deletes vectors by keys from this index
  * Convenience method that automatically includes bucket and index names
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param options - Deletion options (bucket and index names automatically set)
  * @returns Promise with empty response on success or error
  *
  * @example
  * ```typescript
  * const index = supabase.storage.vectors.from('embeddings-prod').index('documents-openai')
  * await index.deleteVectors({
  *   keys: ['doc-1', 'doc-2', 'doc-3']
  * })
  * ```
  */
  async deleteVectors(r) {
    var e = () => super.deleteVectors, t = this;
    return e().call(t, A(A({}, r), {}, {
      vectorBucketName: t.vectorBucketName,
      indexName: t.indexName
    }));
  }
}, Bn = class extends $n {
  /**
  * Creates a client for Storage buckets, files, analytics, and vectors.
  *
  * @category File Buckets
  * @example
  * ```ts
  * import { StorageClient } from '@supabase/storage-js'
  *
  * const storage = new StorageClient('https://xyzcompany.supabase.co/storage/v1', {
  *   apikey: 'public-anon-key',
  * })
  * const avatars = storage.from('avatars')
  * ```
  */
  constructor(r, e = {}, t, s) {
    super(r, e, t, s);
  }
  /**
  * Perform file operation in a bucket.
  *
  * @category File Buckets
  * @param id The bucket id to operate on.
  *
  * @example
  * ```typescript
  * const avatars = supabase.storage.from('avatars')
  * ```
  */
  from(r) {
    return new In(this.url, this.headers, r, this.fetch);
  }
  /**
  *
  * @alpha
  *
  * Access vector storage operations.
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @returns A StorageVectorsClient instance configured with the current storage settings.
  */
  get vectors() {
    return new Ln(this.url + "/vector", {
      headers: this.headers,
      fetch: this.fetch
    });
  }
  /**
  *
  * @alpha
  *
  * Access analytics storage operations using Iceberg tables.
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Analytics Buckets
  * @returns A StorageAnalyticsClient instance configured with the current storage settings.
  */
  get analytics() {
    return new Pn(this.url + "/iceberg", this.headers, this.fetch);
  }
};
const ss = "2.93.3", ke = 30 * 1e3, Ot = 3, pt = Ot * ke, qn = "http://localhost:9999", Fn = "supabase.auth.token", Hn = { "X-Client-Info": `gotrue-js/${ss}` }, Rt = "X-Supabase-Api-Version", ns = {
  "2024-01-01": {
    timestamp: Date.parse("2024-01-01T00:00:00.0Z"),
    name: "2024-01-01"
  }
}, Vn = /^([a-z0-9_-]{4})*($|[a-z0-9_-]{3}$|[a-z0-9_-]{2}$)$/i, Kn = 10 * 60 * 1e3;
class qe extends Error {
  constructor(e, t, s) {
    super(e), this.__isAuthError = !0, this.name = "AuthError", this.status = t, this.code = s;
  }
}
function w(r) {
  return typeof r == "object" && r !== null && "__isAuthError" in r;
}
class zn extends qe {
  constructor(e, t, s) {
    super(e, t, s), this.name = "AuthApiError", this.status = t, this.code = s;
  }
}
function Gn(r) {
  return w(r) && r.name === "AuthApiError";
}
class pe extends qe {
  constructor(e, t) {
    super(e), this.name = "AuthUnknownError", this.originalError = t;
  }
}
class re extends qe {
  constructor(e, t, s, n) {
    super(e, s, n), this.name = t, this.status = s;
  }
}
class K extends re {
  constructor() {
    super("Auth session missing!", "AuthSessionMissingError", 400, void 0);
  }
}
function gt(r) {
  return w(r) && r.name === "AuthSessionMissingError";
}
class we extends re {
  constructor() {
    super("Auth session or user missing", "AuthInvalidTokenResponseError", 500, void 0);
  }
}
class Je extends re {
  constructor(e) {
    super(e, "AuthInvalidCredentialsError", 400, void 0);
  }
}
class Ye extends re {
  constructor(e, t = null) {
    super(e, "AuthImplicitGrantRedirectError", 500, void 0), this.details = null, this.details = t;
  }
  toJSON() {
    return {
      name: this.name,
      message: this.message,
      status: this.status,
      details: this.details
    };
  }
}
function Wn(r) {
  return w(r) && r.name === "AuthImplicitGrantRedirectError";
}
class dr extends re {
  constructor(e, t = null) {
    super(e, "AuthPKCEGrantCodeExchangeError", 500, void 0), this.details = null, this.details = t;
  }
  toJSON() {
    return {
      name: this.name,
      message: this.message,
      status: this.status,
      details: this.details
    };
  }
}
class Jn extends re {
  constructor() {
    super("PKCE code verifier not found in storage. This can happen if the auth flow was initiated in a different browser or device, or if the storage was cleared. For SSR frameworks (Next.js, SvelteKit, etc.), use @supabase/ssr on both the server and client to store the code verifier in cookies.", "AuthPKCECodeVerifierMissingError", 400, "pkce_code_verifier_not_found");
  }
}
class Ct extends re {
  constructor(e, t) {
    super(e, "AuthRetryableFetchError", t, void 0);
  }
}
function mt(r) {
  return w(r) && r.name === "AuthRetryableFetchError";
}
class fr extends re {
  constructor(e, t, s) {
    super(e, "AuthWeakPasswordError", t, "weak_password"), this.reasons = s;
  }
}
class It extends re {
  constructor(e) {
    super(e, "AuthInvalidJwtError", 400, "invalid_jwt");
  }
}
const tt = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".split(""), pr = ` 	
\r=`.split(""), Yn = (() => {
  const r = new Array(128);
  for (let e = 0; e < r.length; e += 1)
    r[e] = -1;
  for (let e = 0; e < pr.length; e += 1)
    r[pr[e].charCodeAt(0)] = -2;
  for (let e = 0; e < tt.length; e += 1)
    r[tt[e].charCodeAt(0)] = e;
  return r;
})();
function gr(r, e, t) {
  if (r !== null)
    for (e.queue = e.queue << 8 | r, e.queuedBits += 8; e.queuedBits >= 6; ) {
      const s = e.queue >> e.queuedBits - 6 & 63;
      t(tt[s]), e.queuedBits -= 6;
    }
  else if (e.queuedBits > 0)
    for (e.queue = e.queue << 6 - e.queuedBits, e.queuedBits = 6; e.queuedBits >= 6; ) {
      const s = e.queue >> e.queuedBits - 6 & 63;
      t(tt[s]), e.queuedBits -= 6;
    }
}
function is(r, e, t) {
  const s = Yn[r];
  if (s > -1)
    for (e.queue = e.queue << 6 | s, e.queuedBits += 6; e.queuedBits >= 8; )
      t(e.queue >> e.queuedBits - 8 & 255), e.queuedBits -= 8;
  else {
    if (s === -2)
      return;
    throw new Error(`Invalid Base64-URL character "${String.fromCharCode(r)}"`);
  }
}
function mr(r) {
  const e = [], t = (a) => {
    e.push(String.fromCodePoint(a));
  }, s = {
    utf8seq: 0,
    codepoint: 0
  }, n = { queue: 0, queuedBits: 0 }, i = (a) => {
    Zn(a, s, t);
  };
  for (let a = 0; a < r.length; a += 1)
    is(r.charCodeAt(a), n, i);
  return e.join("");
}
function Xn(r, e) {
  if (r <= 127) {
    e(r);
    return;
  } else if (r <= 2047) {
    e(192 | r >> 6), e(128 | r & 63);
    return;
  } else if (r <= 65535) {
    e(224 | r >> 12), e(128 | r >> 6 & 63), e(128 | r & 63);
    return;
  } else if (r <= 1114111) {
    e(240 | r >> 18), e(128 | r >> 12 & 63), e(128 | r >> 6 & 63), e(128 | r & 63);
    return;
  }
  throw new Error(`Unrecognized Unicode codepoint: ${r.toString(16)}`);
}
function Qn(r, e) {
  for (let t = 0; t < r.length; t += 1) {
    let s = r.charCodeAt(t);
    if (s > 55295 && s <= 56319) {
      const n = (s - 55296) * 1024 & 65535;
      s = (r.charCodeAt(t + 1) - 56320 & 65535 | n) + 65536, t += 1;
    }
    Xn(s, e);
  }
}
function Zn(r, e, t) {
  if (e.utf8seq === 0) {
    if (r <= 127) {
      t(r);
      return;
    }
    for (let s = 1; s < 6; s += 1)
      if (!(r >> 7 - s & 1)) {
        e.utf8seq = s;
        break;
      }
    if (e.utf8seq === 2)
      e.codepoint = r & 31;
    else if (e.utf8seq === 3)
      e.codepoint = r & 15;
    else if (e.utf8seq === 4)
      e.codepoint = r & 7;
    else
      throw new Error("Invalid UTF-8 sequence");
    e.utf8seq -= 1;
  } else if (e.utf8seq > 0) {
    if (r <= 127)
      throw new Error("Invalid UTF-8 sequence");
    e.codepoint = e.codepoint << 6 | r & 63, e.utf8seq -= 1, e.utf8seq === 0 && t(e.codepoint);
  }
}
function Ie(r) {
  const e = [], t = { queue: 0, queuedBits: 0 }, s = (n) => {
    e.push(n);
  };
  for (let n = 0; n < r.length; n += 1)
    is(r.charCodeAt(n), t, s);
  return new Uint8Array(e);
}
function ei(r) {
  const e = [];
  return Qn(r, (t) => e.push(t)), new Uint8Array(e);
}
function ge(r) {
  const e = [], t = { queue: 0, queuedBits: 0 }, s = (n) => {
    e.push(n);
  };
  return r.forEach((n) => gr(n, t, s)), gr(null, t, s), e.join("");
}
function ti(r) {
  return Math.round(Date.now() / 1e3) + r;
}
function ri() {
  return Symbol("auth-callback");
}
const D = () => typeof window < "u" && typeof document < "u", ue = {
  tested: !1,
  writable: !1
}, as = () => {
  if (!D())
    return !1;
  try {
    if (typeof globalThis.localStorage != "object")
      return !1;
  } catch {
    return !1;
  }
  if (ue.tested)
    return ue.writable;
  const r = `lswt-${Math.random()}${Math.random()}`;
  try {
    globalThis.localStorage.setItem(r, r), globalThis.localStorage.removeItem(r), ue.tested = !0, ue.writable = !0;
  } catch {
    ue.tested = !0, ue.writable = !1;
  }
  return ue.writable;
};
function si(r) {
  const e = {}, t = new URL(r);
  if (t.hash && t.hash[0] === "#")
    try {
      new URLSearchParams(t.hash.substring(1)).forEach((n, i) => {
        e[i] = n;
      });
    } catch {
    }
  return t.searchParams.forEach((s, n) => {
    e[n] = s;
  }), e;
}
const os = (r) => r ? (...e) => r(...e) : (...e) => fetch(...e), ni = (r) => typeof r == "object" && r !== null && "status" in r && "ok" in r && "json" in r && typeof r.json == "function", Oe = async (r, e, t) => {
  await r.setItem(e, JSON.stringify(t));
}, he = async (r, e) => {
  const t = await r.getItem(e);
  if (!t)
    return null;
  try {
    return JSON.parse(t);
  } catch {
    return t;
  }
}, L = async (r, e) => {
  await r.removeItem(e);
};
class ct {
  constructor() {
    this.promise = new ct.promiseConstructor((e, t) => {
      this.resolve = e, this.reject = t;
    });
  }
}
ct.promiseConstructor = Promise;
function Xe(r) {
  const e = r.split(".");
  if (e.length !== 3)
    throw new It("Invalid JWT structure");
  for (let s = 0; s < e.length; s++)
    if (!Vn.test(e[s]))
      throw new It("JWT not in base64url format");
  return {
    // using base64url lib
    header: JSON.parse(mr(e[0])),
    payload: JSON.parse(mr(e[1])),
    signature: Ie(e[2]),
    raw: {
      header: e[0],
      payload: e[1]
    }
  };
}
async function ii(r) {
  return await new Promise((e) => {
    setTimeout(() => e(null), r);
  });
}
function ai(r, e) {
  return new Promise((s, n) => {
    (async () => {
      for (let i = 0; i < 1 / 0; i++)
        try {
          const a = await r(i);
          if (!e(i, null, a)) {
            s(a);
            return;
          }
        } catch (a) {
          if (!e(i, a)) {
            n(a);
            return;
          }
        }
    })();
  });
}
function oi(r) {
  return ("0" + r.toString(16)).substr(-2);
}
function ci() {
  const e = new Uint32Array(56);
  if (typeof crypto > "u") {
    const t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~", s = t.length;
    let n = "";
    for (let i = 0; i < 56; i++)
      n += t.charAt(Math.floor(Math.random() * s));
    return n;
  }
  return crypto.getRandomValues(e), Array.from(e, oi).join("");
}
async function li(r) {
  const t = new TextEncoder().encode(r), s = await crypto.subtle.digest("SHA-256", t), n = new Uint8Array(s);
  return Array.from(n).map((i) => String.fromCharCode(i)).join("");
}
async function ui(r) {
  if (!(typeof crypto < "u" && typeof crypto.subtle < "u" && typeof TextEncoder < "u"))
    return console.warn("WebCrypto API is not supported. Code challenge method will default to use plain instead of sha256."), r;
  const t = await li(r);
  return btoa(t).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
async function be(r, e, t = !1) {
  const s = ci();
  let n = s;
  t && (n += "/PASSWORD_RECOVERY"), await Oe(r, `${e}-code-verifier`, n);
  const i = await ui(s);
  return [i, s === i ? "plain" : "s256"];
}
const hi = /^2[0-9]{3}-(0[1-9]|1[0-2])-(0[1-9]|1[0-9]|2[0-9]|3[0-1])$/i;
function di(r) {
  const e = r.headers.get(Rt);
  if (!e || !e.match(hi))
    return null;
  try {
    return /* @__PURE__ */ new Date(`${e}T00:00:00.0Z`);
  } catch {
    return null;
  }
}
function fi(r) {
  if (!r)
    throw new Error("Missing exp claim");
  const e = Math.floor(Date.now() / 1e3);
  if (r <= e)
    throw new Error("JWT has expired");
}
function pi(r) {
  switch (r) {
    case "RS256":
      return {
        name: "RSASSA-PKCS1-v1_5",
        hash: { name: "SHA-256" }
      };
    case "ES256":
      return {
        name: "ECDSA",
        namedCurve: "P-256",
        hash: { name: "SHA-256" }
      };
    default:
      throw new Error("Invalid alg claim");
  }
}
const gi = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
function Se(r) {
  if (!gi.test(r))
    throw new Error("@supabase/auth-js: Expected parameter to be UUID but is not");
}
function yt() {
  const r = {};
  return new Proxy(r, {
    get: (e, t) => {
      if (t === "__isUserNotAvailableProxy")
        return !0;
      if (typeof t == "symbol") {
        const s = t.toString();
        if (s === "Symbol(Symbol.toPrimitive)" || s === "Symbol(Symbol.toStringTag)" || s === "Symbol(util.inspect.custom)")
          return;
      }
      throw new Error(`@supabase/auth-js: client was created with userStorage option and there was no user stored in the user storage. Accessing the "${t}" property of the session object is not supported. Please use getUser() instead.`);
    },
    set: (e, t) => {
      throw new Error(`@supabase/auth-js: client was created with userStorage option and there was no user stored in the user storage. Setting the "${t}" property of the session object is not supported. Please use getUser() to fetch a user object you can manipulate.`);
    },
    deleteProperty: (e, t) => {
      throw new Error(`@supabase/auth-js: client was created with userStorage option and there was no user stored in the user storage. Deleting the "${t}" property of the session object is not supported. Please use getUser() to fetch a user object you can manipulate.`);
    }
  });
}
function mi(r, e) {
  return new Proxy(r, {
    get: (t, s, n) => {
      if (s === "__isInsecureUserWarningProxy")
        return !0;
      if (typeof s == "symbol") {
        const i = s.toString();
        if (i === "Symbol(Symbol.toPrimitive)" || i === "Symbol(Symbol.toStringTag)" || i === "Symbol(util.inspect.custom)" || i === "Symbol(nodejs.util.inspect.custom)")
          return Reflect.get(t, s, n);
      }
      return !e.value && typeof s == "string" && (console.warn("Using the user object as returned from supabase.auth.getSession() or from some supabase.auth.onAuthStateChange() events could be insecure! This value comes directly from the storage medium (usually cookies on the server) and may not be authentic. Use supabase.auth.getUser() instead which authenticates the data by contacting the Supabase Auth server."), e.value = !0), Reflect.get(t, s, n);
    }
  });
}
function yr(r) {
  return JSON.parse(JSON.stringify(r));
}
const de = (r) => r.msg || r.message || r.error_description || r.error || JSON.stringify(r), yi = [502, 503, 504];
async function _r(r) {
  var e;
  if (!ni(r))
    throw new Ct(de(r), 0);
  if (yi.includes(r.status))
    throw new Ct(de(r), r.status);
  let t;
  try {
    t = await r.json();
  } catch (i) {
    throw new pe(de(i), i);
  }
  let s;
  const n = di(r);
  if (n && n.getTime() >= ns["2024-01-01"].timestamp && typeof t == "object" && t && typeof t.code == "string" ? s = t.code : typeof t == "object" && t && typeof t.error_code == "string" && (s = t.error_code), s) {
    if (s === "weak_password")
      throw new fr(de(t), r.status, ((e = t.weak_password) === null || e === void 0 ? void 0 : e.reasons) || []);
    if (s === "session_not_found")
      throw new K();
  } else if (typeof t == "object" && t && typeof t.weak_password == "object" && t.weak_password && Array.isArray(t.weak_password.reasons) && t.weak_password.reasons.length && t.weak_password.reasons.reduce((i, a) => i && typeof a == "string", !0))
    throw new fr(de(t), r.status, t.weak_password.reasons);
  throw new zn(de(t), r.status || 500, s);
}
const _i = (r, e, t, s) => {
  const n = { method: r, headers: (e == null ? void 0 : e.headers) || {} };
  return r === "GET" ? n : (n.headers = Object.assign({ "Content-Type": "application/json;charset=UTF-8" }, e == null ? void 0 : e.headers), n.body = JSON.stringify(s), Object.assign(Object.assign({}, n), t));
};
async function T(r, e, t, s) {
  var n;
  const i = Object.assign({}, s == null ? void 0 : s.headers);
  i[Rt] || (i[Rt] = ns["2024-01-01"].name), s != null && s.jwt && (i.Authorization = `Bearer ${s.jwt}`);
  const a = (n = s == null ? void 0 : s.query) !== null && n !== void 0 ? n : {};
  s != null && s.redirectTo && (a.redirect_to = s.redirectTo);
  const o = Object.keys(a).length ? "?" + new URLSearchParams(a).toString() : "", c = await vi(r, e, t + o, {
    headers: i,
    noResolveJson: s == null ? void 0 : s.noResolveJson
  }, {}, s == null ? void 0 : s.body);
  return s != null && s.xform ? s == null ? void 0 : s.xform(c) : { data: Object.assign({}, c), error: null };
}
async function vi(r, e, t, s, n, i) {
  const a = _i(e, s, n, i);
  let o;
  try {
    o = await r(t, Object.assign({}, a));
  } catch (c) {
    throw console.error(c), new Ct(de(c), 0);
  }
  if (o.ok || await _r(o), s != null && s.noResolveJson)
    return o;
  try {
    return await o.json();
  } catch (c) {
    await _r(c);
  }
}
function Y(r) {
  var e;
  let t = null;
  Si(r) && (t = Object.assign({}, r), r.expires_at || (t.expires_at = ti(r.expires_in)));
  const s = (e = r.user) !== null && e !== void 0 ? e : r;
  return { data: { session: t, user: s }, error: null };
}
function vr(r) {
  const e = Y(r);
  return !e.error && r.weak_password && typeof r.weak_password == "object" && Array.isArray(r.weak_password.reasons) && r.weak_password.reasons.length && r.weak_password.message && typeof r.weak_password.message == "string" && r.weak_password.reasons.reduce((t, s) => t && typeof s == "string", !0) && (e.data.weak_password = r.weak_password), e;
}
function ie(r) {
  var e;
  return { data: { user: (e = r.user) !== null && e !== void 0 ? e : r }, error: null };
}
function wi(r) {
  return { data: r, error: null };
}
function bi(r) {
  const { action_link: e, email_otp: t, hashed_token: s, redirect_to: n, verification_type: i } = r, a = it(r, ["action_link", "email_otp", "hashed_token", "redirect_to", "verification_type"]), o = {
    action_link: e,
    email_otp: t,
    hashed_token: s,
    redirect_to: n,
    verification_type: i
  }, c = Object.assign({}, a);
  return {
    data: {
      properties: o,
      user: c
    },
    error: null
  };
}
function wr(r) {
  return r;
}
function Si(r) {
  return r.access_token && r.refresh_token && r.expires_in;
}
const _t = ["global", "local", "others"];
class Ei {
  /**
   * Creates an admin API client that can be used to manage users and OAuth clients.
   *
   * @example
   * ```ts
   * import { GoTrueAdminApi } from '@supabase/auth-js'
   *
   * const admin = new GoTrueAdminApi({
   *   url: 'https://xyzcompany.supabase.co/auth/v1',
   *   headers: { Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}` },
   * })
   * ```
   */
  constructor({ url: e = "", headers: t = {}, fetch: s }) {
    this.url = e, this.headers = t, this.fetch = os(s), this.mfa = {
      listFactors: this._listFactors.bind(this),
      deleteFactor: this._deleteFactor.bind(this)
    }, this.oauth = {
      listClients: this._listOAuthClients.bind(this),
      createClient: this._createOAuthClient.bind(this),
      getClient: this._getOAuthClient.bind(this),
      updateClient: this._updateOAuthClient.bind(this),
      deleteClient: this._deleteOAuthClient.bind(this),
      regenerateClientSecret: this._regenerateOAuthClientSecret.bind(this)
    };
  }
  /**
   * Removes a logged-in session.
   * @param jwt A valid, logged-in JWT.
   * @param scope The logout sope.
   */
  async signOut(e, t = _t[0]) {
    if (_t.indexOf(t) < 0)
      throw new Error(`@supabase/auth-js: Parameter scope must be one of ${_t.join(", ")}`);
    try {
      return await T(this.fetch, "POST", `${this.url}/logout?scope=${t}`, {
        headers: this.headers,
        jwt: e,
        noResolveJson: !0
      }), { data: null, error: null };
    } catch (s) {
      if (w(s))
        return { data: null, error: s };
      throw s;
    }
  }
  /**
   * Sends an invite link to an email address.
   * @param email The email address of the user.
   * @param options Additional options to be included when inviting.
   */
  async inviteUserByEmail(e, t = {}) {
    try {
      return await T(this.fetch, "POST", `${this.url}/invite`, {
        body: { email: e, data: t.data },
        headers: this.headers,
        redirectTo: t.redirectTo,
        xform: ie
      });
    } catch (s) {
      if (w(s))
        return { data: { user: null }, error: s };
      throw s;
    }
  }
  /**
   * Generates email links and OTPs to be sent via a custom email provider.
   * @param email The user's email.
   * @param options.password User password. For signup only.
   * @param options.data Optional user metadata. For signup only.
   * @param options.redirectTo The redirect url which should be appended to the generated link
   */
  async generateLink(e) {
    try {
      const { options: t } = e, s = it(e, ["options"]), n = Object.assign(Object.assign({}, s), t);
      return "newEmail" in s && (n.new_email = s == null ? void 0 : s.newEmail, delete n.newEmail), await T(this.fetch, "POST", `${this.url}/admin/generate_link`, {
        body: n,
        headers: this.headers,
        xform: bi,
        redirectTo: t == null ? void 0 : t.redirectTo
      });
    } catch (t) {
      if (w(t))
        return {
          data: {
            properties: null,
            user: null
          },
          error: t
        };
      throw t;
    }
  }
  // User Admin API
  /**
   * Creates a new user.
   * This function should only be called on a server. Never expose your `service_role` key in the browser.
   */
  async createUser(e) {
    try {
      return await T(this.fetch, "POST", `${this.url}/admin/users`, {
        body: e,
        headers: this.headers,
        xform: ie
      });
    } catch (t) {
      if (w(t))
        return { data: { user: null }, error: t };
      throw t;
    }
  }
  /**
   * Get a list of users.
   *
   * This function should only be called on a server. Never expose your `service_role` key in the browser.
   * @param params An object which supports `page` and `perPage` as numbers, to alter the paginated results.
   */
  async listUsers(e) {
    var t, s, n, i, a, o, c;
    try {
      const l = { nextPage: null, lastPage: 0, total: 0 }, u = await T(this.fetch, "GET", `${this.url}/admin/users`, {
        headers: this.headers,
        noResolveJson: !0,
        query: {
          page: (s = (t = e == null ? void 0 : e.page) === null || t === void 0 ? void 0 : t.toString()) !== null && s !== void 0 ? s : "",
          per_page: (i = (n = e == null ? void 0 : e.perPage) === null || n === void 0 ? void 0 : n.toString()) !== null && i !== void 0 ? i : ""
        },
        xform: wr
      });
      if (u.error)
        throw u.error;
      const d = await u.json(), h = (a = u.headers.get("x-total-count")) !== null && a !== void 0 ? a : 0, f = (c = (o = u.headers.get("link")) === null || o === void 0 ? void 0 : o.split(",")) !== null && c !== void 0 ? c : [];
      return f.length > 0 && (f.forEach((p) => {
        const g = parseInt(p.split(";")[0].split("=")[1].substring(0, 1)), m = JSON.parse(p.split(";")[1].split("=")[1]);
        l[`${m}Page`] = g;
      }), l.total = parseInt(h)), { data: Object.assign(Object.assign({}, d), l), error: null };
    } catch (l) {
      if (w(l))
        return { data: { users: [] }, error: l };
      throw l;
    }
  }
  /**
   * Get user by id.
   *
   * @param uid The user's unique identifier
   *
   * This function should only be called on a server. Never expose your `service_role` key in the browser.
   */
  async getUserById(e) {
    Se(e);
    try {
      return await T(this.fetch, "GET", `${this.url}/admin/users/${e}`, {
        headers: this.headers,
        xform: ie
      });
    } catch (t) {
      if (w(t))
        return { data: { user: null }, error: t };
      throw t;
    }
  }
  /**
   * Updates the user data. Changes are applied directly without confirmation flows.
   *
   * @param attributes The data you want to update.
   *
   * This function should only be called on a server. Never expose your `service_role` key in the browser.
   */
  async updateUserById(e, t) {
    Se(e);
    try {
      return await T(this.fetch, "PUT", `${this.url}/admin/users/${e}`, {
        body: t,
        headers: this.headers,
        xform: ie
      });
    } catch (s) {
      if (w(s))
        return { data: { user: null }, error: s };
      throw s;
    }
  }
  /**
   * Delete a user. Requires a `service_role` key.
   *
   * @param id The user id you want to remove.
   * @param shouldSoftDelete If true, then the user will be soft-deleted from the auth schema. Soft deletion allows user identification from the hashed user ID but is not reversible.
   * Defaults to false for backward compatibility.
   *
   * This function should only be called on a server. Never expose your `service_role` key in the browser.
   */
  async deleteUser(e, t = !1) {
    Se(e);
    try {
      return await T(this.fetch, "DELETE", `${this.url}/admin/users/${e}`, {
        headers: this.headers,
        body: {
          should_soft_delete: t
        },
        xform: ie
      });
    } catch (s) {
      if (w(s))
        return { data: { user: null }, error: s };
      throw s;
    }
  }
  async _listFactors(e) {
    Se(e.userId);
    try {
      const { data: t, error: s } = await T(this.fetch, "GET", `${this.url}/admin/users/${e.userId}/factors`, {
        headers: this.headers,
        xform: (n) => ({ data: { factors: n }, error: null })
      });
      return { data: t, error: s };
    } catch (t) {
      if (w(t))
        return { data: null, error: t };
      throw t;
    }
  }
  async _deleteFactor(e) {
    Se(e.userId), Se(e.id);
    try {
      return { data: await T(this.fetch, "DELETE", `${this.url}/admin/users/${e.userId}/factors/${e.id}`, {
        headers: this.headers
      }), error: null };
    } catch (t) {
      if (w(t))
        return { data: null, error: t };
      throw t;
    }
  }
  /**
   * Lists all OAuth clients with optional pagination.
   * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
   *
   * This function should only be called on a server. Never expose your `service_role` key in the browser.
   */
  async _listOAuthClients(e) {
    var t, s, n, i, a, o, c;
    try {
      const l = { nextPage: null, lastPage: 0, total: 0 }, u = await T(this.fetch, "GET", `${this.url}/admin/oauth/clients`, {
        headers: this.headers,
        noResolveJson: !0,
        query: {
          page: (s = (t = e == null ? void 0 : e.page) === null || t === void 0 ? void 0 : t.toString()) !== null && s !== void 0 ? s : "",
          per_page: (i = (n = e == null ? void 0 : e.perPage) === null || n === void 0 ? void 0 : n.toString()) !== null && i !== void 0 ? i : ""
        },
        xform: wr
      });
      if (u.error)
        throw u.error;
      const d = await u.json(), h = (a = u.headers.get("x-total-count")) !== null && a !== void 0 ? a : 0, f = (c = (o = u.headers.get("link")) === null || o === void 0 ? void 0 : o.split(",")) !== null && c !== void 0 ? c : [];
      return f.length > 0 && (f.forEach((p) => {
        const g = parseInt(p.split(";")[0].split("=")[1].substring(0, 1)), m = JSON.parse(p.split(";")[1].split("=")[1]);
        l[`${m}Page`] = g;
      }), l.total = parseInt(h)), { data: Object.assign(Object.assign({}, d), l), error: null };
    } catch (l) {
      if (w(l))
        return { data: { clients: [] }, error: l };
      throw l;
    }
  }
  /**
   * Creates a new OAuth client.
   * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
   *
   * This function should only be called on a server. Never expose your `service_role` key in the browser.
   */
  async _createOAuthClient(e) {
    try {
      return await T(this.fetch, "POST", `${this.url}/admin/oauth/clients`, {
        body: e,
        headers: this.headers,
        xform: (t) => ({ data: t, error: null })
      });
    } catch (t) {
      if (w(t))
        return { data: null, error: t };
      throw t;
    }
  }
  /**
   * Gets details of a specific OAuth client.
   * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
   *
   * This function should only be called on a server. Never expose your `service_role` key in the browser.
   */
  async _getOAuthClient(e) {
    try {
      return await T(this.fetch, "GET", `${this.url}/admin/oauth/clients/${e}`, {
        headers: this.headers,
        xform: (t) => ({ data: t, error: null })
      });
    } catch (t) {
      if (w(t))
        return { data: null, error: t };
      throw t;
    }
  }
  /**
   * Updates an existing OAuth client.
   * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
   *
   * This function should only be called on a server. Never expose your `service_role` key in the browser.
   */
  async _updateOAuthClient(e, t) {
    try {
      return await T(this.fetch, "PUT", `${this.url}/admin/oauth/clients/${e}`, {
        body: t,
        headers: this.headers,
        xform: (s) => ({ data: s, error: null })
      });
    } catch (s) {
      if (w(s))
        return { data: null, error: s };
      throw s;
    }
  }
  /**
   * Deletes an OAuth client.
   * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
   *
   * This function should only be called on a server. Never expose your `service_role` key in the browser.
   */
  async _deleteOAuthClient(e) {
    try {
      return await T(this.fetch, "DELETE", `${this.url}/admin/oauth/clients/${e}`, {
        headers: this.headers,
        noResolveJson: !0
      }), { data: null, error: null };
    } catch (t) {
      if (w(t))
        return { data: null, error: t };
      throw t;
    }
  }
  /**
   * Regenerates the secret for an OAuth client.
   * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
   *
   * This function should only be called on a server. Never expose your `service_role` key in the browser.
   */
  async _regenerateOAuthClientSecret(e) {
    try {
      return await T(this.fetch, "POST", `${this.url}/admin/oauth/clients/${e}/regenerate_secret`, {
        headers: this.headers,
        xform: (t) => ({ data: t, error: null })
      });
    } catch (t) {
      if (w(t))
        return { data: null, error: t };
      throw t;
    }
  }
}
function br(r = {}) {
  return {
    getItem: (e) => r[e] || null,
    setItem: (e, t) => {
      r[e] = t;
    },
    removeItem: (e) => {
      delete r[e];
    }
  };
}
const Ee = {
  /**
   * @experimental
   */
  debug: !!(globalThis && as() && globalThis.localStorage && globalThis.localStorage.getItem("supabase.gotrue-js.locks.debug") === "true")
};
class cs extends Error {
  constructor(e) {
    super(e), this.isAcquireTimeout = !0;
  }
}
class Ti extends cs {
}
async function Ai(r, e, t) {
  Ee.debug && console.log("@supabase/gotrue-js: navigatorLock: acquire lock", r, e);
  const s = new globalThis.AbortController();
  return e > 0 && setTimeout(() => {
    s.abort(), Ee.debug && console.log("@supabase/gotrue-js: navigatorLock acquire timed out", r);
  }, e), await Promise.resolve().then(() => globalThis.navigator.locks.request(r, e === 0 ? {
    mode: "exclusive",
    ifAvailable: !0
  } : {
    mode: "exclusive",
    signal: s.signal
  }, async (n) => {
    if (n) {
      Ee.debug && console.log("@supabase/gotrue-js: navigatorLock: acquired", r, n.name);
      try {
        return await t();
      } finally {
        Ee.debug && console.log("@supabase/gotrue-js: navigatorLock: released", r, n.name);
      }
    } else {
      if (e === 0)
        throw Ee.debug && console.log("@supabase/gotrue-js: navigatorLock: not immediately available", r), new Ti(`Acquiring an exclusive Navigator LockManager lock "${r}" immediately failed`);
      if (Ee.debug)
        try {
          const i = await globalThis.navigator.locks.query();
          console.log("@supabase/gotrue-js: Navigator LockManager state", JSON.stringify(i, null, "  "));
        } catch (i) {
          console.warn("@supabase/gotrue-js: Error when querying Navigator LockManager state", i);
        }
      return console.warn("@supabase/gotrue-js: Navigator LockManager returned a null lock when using #request without ifAvailable set to true, it appears this browser is not following the LockManager spec https://developer.mozilla.org/en-US/docs/Web/API/LockManager/request"), await t();
    }
  }));
}
function ki() {
  if (typeof globalThis != "object")
    try {
      Object.defineProperty(Object.prototype, "__magic__", {
        get: function() {
          return this;
        },
        configurable: !0
      }), __magic__.globalThis = __magic__, delete Object.prototype.__magic__;
    } catch {
      typeof self < "u" && (self.globalThis = self);
    }
}
function ls(r) {
  if (!/^0x[a-fA-F0-9]{40}$/.test(r))
    throw new Error(`@supabase/auth-js: Address "${r}" is invalid.`);
  return r.toLowerCase();
}
function Oi(r) {
  return parseInt(r, 16);
}
function Ri(r) {
  const e = new TextEncoder().encode(r);
  return "0x" + Array.from(e, (s) => s.toString(16).padStart(2, "0")).join("");
}
function Ci(r) {
  var e;
  const { chainId: t, domain: s, expirationTime: n, issuedAt: i = /* @__PURE__ */ new Date(), nonce: a, notBefore: o, requestId: c, resources: l, scheme: u, uri: d, version: h } = r;
  {
    if (!Number.isInteger(t))
      throw new Error(`@supabase/auth-js: Invalid SIWE message field "chainId". Chain ID must be a EIP-155 chain ID. Provided value: ${t}`);
    if (!s)
      throw new Error('@supabase/auth-js: Invalid SIWE message field "domain". Domain must be provided.');
    if (a && a.length < 8)
      throw new Error(`@supabase/auth-js: Invalid SIWE message field "nonce". Nonce must be at least 8 characters. Provided value: ${a}`);
    if (!d)
      throw new Error('@supabase/auth-js: Invalid SIWE message field "uri". URI must be provided.');
    if (h !== "1")
      throw new Error(`@supabase/auth-js: Invalid SIWE message field "version". Version must be '1'. Provided value: ${h}`);
    if (!((e = r.statement) === null || e === void 0) && e.includes(`
`))
      throw new Error(`@supabase/auth-js: Invalid SIWE message field "statement". Statement must not include '\\n'. Provided value: ${r.statement}`);
  }
  const f = ls(r.address), p = u ? `${u}://${s}` : s, g = r.statement ? `${r.statement}
` : "", m = `${p} wants you to sign in with your Ethereum account:
${f}

${g}`;
  let y = `URI: ${d}
Version: ${h}
Chain ID: ${t}${a ? `
Nonce: ${a}` : ""}
Issued At: ${i.toISOString()}`;
  if (n && (y += `
Expiration Time: ${n.toISOString()}`), o && (y += `
Not Before: ${o.toISOString()}`), c && (y += `
Request ID: ${c}`), l) {
    let v = `
Resources:`;
    for (const _ of l) {
      if (!_ || typeof _ != "string")
        throw new Error(`@supabase/auth-js: Invalid SIWE message field "resources". Every resource must be a valid string. Provided value: ${_}`);
      v += `
- ${_}`;
    }
    y += v;
  }
  return `${m}
${y}`;
}
class j extends Error {
  constructor({ message: e, code: t, cause: s, name: n }) {
    var i;
    super(e, { cause: s }), this.__isWebAuthnError = !0, this.name = (i = n ?? (s instanceof Error ? s.name : void 0)) !== null && i !== void 0 ? i : "Unknown Error", this.code = t;
  }
}
class rt extends j {
  constructor(e, t) {
    super({
      code: "ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY",
      cause: t,
      message: e
    }), this.name = "WebAuthnUnknownError", this.originalError = t;
  }
}
function Ii({ error: r, options: e }) {
  var t, s, n;
  const { publicKey: i } = e;
  if (!i)
    throw Error("options was missing required publicKey property");
  if (r.name === "AbortError") {
    if (e.signal instanceof AbortSignal)
      return new j({
        message: "Registration ceremony was sent an abort signal",
        code: "ERROR_CEREMONY_ABORTED",
        cause: r
      });
  } else if (r.name === "ConstraintError") {
    if (((t = i.authenticatorSelection) === null || t === void 0 ? void 0 : t.requireResidentKey) === !0)
      return new j({
        message: "Discoverable credentials were required but no available authenticator supported it",
        code: "ERROR_AUTHENTICATOR_MISSING_DISCOVERABLE_CREDENTIAL_SUPPORT",
        cause: r
      });
    if (
      // @ts-ignore: `mediation` doesn't yet exist on CredentialCreationOptions but it's possible as of Sept 2024
      e.mediation === "conditional" && ((s = i.authenticatorSelection) === null || s === void 0 ? void 0 : s.userVerification) === "required"
    )
      return new j({
        message: "User verification was required during automatic registration but it could not be performed",
        code: "ERROR_AUTO_REGISTER_USER_VERIFICATION_FAILURE",
        cause: r
      });
    if (((n = i.authenticatorSelection) === null || n === void 0 ? void 0 : n.userVerification) === "required")
      return new j({
        message: "User verification was required but no available authenticator supported it",
        code: "ERROR_AUTHENTICATOR_MISSING_USER_VERIFICATION_SUPPORT",
        cause: r
      });
  } else {
    if (r.name === "InvalidStateError")
      return new j({
        message: "The authenticator was previously registered",
        code: "ERROR_AUTHENTICATOR_PREVIOUSLY_REGISTERED",
        cause: r
      });
    if (r.name === "NotAllowedError")
      return new j({
        message: r.message,
        code: "ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY",
        cause: r
      });
    if (r.name === "NotSupportedError")
      return i.pubKeyCredParams.filter((o) => o.type === "public-key").length === 0 ? new j({
        message: 'No entry in pubKeyCredParams was of type "public-key"',
        code: "ERROR_MALFORMED_PUBKEYCREDPARAMS",
        cause: r
      }) : new j({
        message: "No available authenticator supported any of the specified pubKeyCredParams algorithms",
        code: "ERROR_AUTHENTICATOR_NO_SUPPORTED_PUBKEYCREDPARAMS_ALG",
        cause: r
      });
    if (r.name === "SecurityError") {
      const a = window.location.hostname;
      if (us(a)) {
        if (i.rp.id !== a)
          return new j({
            message: `The RP ID "${i.rp.id}" is invalid for this domain`,
            code: "ERROR_INVALID_RP_ID",
            cause: r
          });
      } else return new j({
        message: `${window.location.hostname} is an invalid domain`,
        code: "ERROR_INVALID_DOMAIN",
        cause: r
      });
    } else if (r.name === "TypeError") {
      if (i.user.id.byteLength < 1 || i.user.id.byteLength > 64)
        return new j({
          message: "User ID was not between 1 and 64 characters",
          code: "ERROR_INVALID_USER_ID_LENGTH",
          cause: r
        });
    } else if (r.name === "UnknownError")
      return new j({
        message: "The authenticator was unable to process the specified options, or could not create a new credential",
        code: "ERROR_AUTHENTICATOR_GENERAL_ERROR",
        cause: r
      });
  }
  return new j({
    message: "a Non-Webauthn related error has occurred",
    code: "ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY",
    cause: r
  });
}
function xi({ error: r, options: e }) {
  const { publicKey: t } = e;
  if (!t)
    throw Error("options was missing required publicKey property");
  if (r.name === "AbortError") {
    if (e.signal instanceof AbortSignal)
      return new j({
        message: "Authentication ceremony was sent an abort signal",
        code: "ERROR_CEREMONY_ABORTED",
        cause: r
      });
  } else {
    if (r.name === "NotAllowedError")
      return new j({
        message: r.message,
        code: "ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY",
        cause: r
      });
    if (r.name === "SecurityError") {
      const s = window.location.hostname;
      if (us(s)) {
        if (t.rpId !== s)
          return new j({
            message: `The RP ID "${t.rpId}" is invalid for this domain`,
            code: "ERROR_INVALID_RP_ID",
            cause: r
          });
      } else return new j({
        message: `${window.location.hostname} is an invalid domain`,
        code: "ERROR_INVALID_DOMAIN",
        cause: r
      });
    } else if (r.name === "UnknownError")
      return new j({
        message: "The authenticator was unable to process the specified options, or could not create a new assertion signature",
        code: "ERROR_AUTHENTICATOR_GENERAL_ERROR",
        cause: r
      });
  }
  return new j({
    message: "a Non-Webauthn related error has occurred",
    code: "ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY",
    cause: r
  });
}
class $i {
  /**
   * Create an abort signal for a new WebAuthn operation.
   * Automatically cancels any existing operation.
   *
   * @returns {AbortSignal} Signal to pass to navigator.credentials.create() or .get()
   * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/AbortSignal MDN - AbortSignal}
   */
  createNewAbortSignal() {
    if (this.controller) {
      const t = new Error("Cancelling existing WebAuthn API call for new one");
      t.name = "AbortError", this.controller.abort(t);
    }
    const e = new AbortController();
    return this.controller = e, e.signal;
  }
  /**
   * Manually cancel the current WebAuthn operation.
   * Useful for cleaning up when user cancels or navigates away.
   *
   * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/AbortController/abort MDN - AbortController.abort}
   */
  cancelCeremony() {
    if (this.controller) {
      const e = new Error("Manually cancelling existing WebAuthn API call");
      e.name = "AbortError", this.controller.abort(e), this.controller = void 0;
    }
  }
}
const Pi = new $i();
function Ni(r) {
  if (!r)
    throw new Error("Credential creation options are required");
  if (typeof PublicKeyCredential < "u" && "parseCreationOptionsFromJSON" in PublicKeyCredential && typeof PublicKeyCredential.parseCreationOptionsFromJSON == "function")
    return PublicKeyCredential.parseCreationOptionsFromJSON(
      /** we assert the options here as typescript still doesn't know about future webauthn types */
      r
    );
  const { challenge: e, user: t, excludeCredentials: s } = r, n = it(
    r,
    ["challenge", "user", "excludeCredentials"]
  ), i = Ie(e).buffer, a = Object.assign(Object.assign({}, t), { id: Ie(t.id).buffer }), o = Object.assign(Object.assign({}, n), {
    challenge: i,
    user: a
  });
  if (s && s.length > 0) {
    o.excludeCredentials = new Array(s.length);
    for (let c = 0; c < s.length; c++) {
      const l = s[c];
      o.excludeCredentials[c] = Object.assign(Object.assign({}, l), {
        id: Ie(l.id).buffer,
        type: l.type || "public-key",
        // Cast transports to handle future transport types like "cable"
        transports: l.transports
      });
    }
  }
  return o;
}
function ji(r) {
  if (!r)
    throw new Error("Credential request options are required");
  if (typeof PublicKeyCredential < "u" && "parseRequestOptionsFromJSON" in PublicKeyCredential && typeof PublicKeyCredential.parseRequestOptionsFromJSON == "function")
    return PublicKeyCredential.parseRequestOptionsFromJSON(r);
  const { challenge: e, allowCredentials: t } = r, s = it(
    r,
    ["challenge", "allowCredentials"]
  ), n = Ie(e).buffer, i = Object.assign(Object.assign({}, s), { challenge: n });
  if (t && t.length > 0) {
    i.allowCredentials = new Array(t.length);
    for (let a = 0; a < t.length; a++) {
      const o = t[a];
      i.allowCredentials[a] = Object.assign(Object.assign({}, o), {
        id: Ie(o.id).buffer,
        type: o.type || "public-key",
        // Cast transports to handle future transport types like "cable"
        transports: o.transports
      });
    }
  }
  return i;
}
function Ui(r) {
  var e;
  if ("toJSON" in r && typeof r.toJSON == "function")
    return r.toJSON();
  const t = r;
  return {
    id: r.id,
    rawId: r.id,
    response: {
      attestationObject: ge(new Uint8Array(r.response.attestationObject)),
      clientDataJSON: ge(new Uint8Array(r.response.clientDataJSON))
    },
    type: "public-key",
    clientExtensionResults: r.getClientExtensionResults(),
    // Convert null to undefined and cast to AuthenticatorAttachment type
    authenticatorAttachment: (e = t.authenticatorAttachment) !== null && e !== void 0 ? e : void 0
  };
}
function Li(r) {
  var e;
  if ("toJSON" in r && typeof r.toJSON == "function")
    return r.toJSON();
  const t = r, s = r.getClientExtensionResults(), n = r.response;
  return {
    id: r.id,
    rawId: r.id,
    // W3C spec expects rawId to match id for JSON format
    response: {
      authenticatorData: ge(new Uint8Array(n.authenticatorData)),
      clientDataJSON: ge(new Uint8Array(n.clientDataJSON)),
      signature: ge(new Uint8Array(n.signature)),
      userHandle: n.userHandle ? ge(new Uint8Array(n.userHandle)) : void 0
    },
    type: "public-key",
    clientExtensionResults: s,
    // Convert null to undefined and cast to AuthenticatorAttachment type
    authenticatorAttachment: (e = t.authenticatorAttachment) !== null && e !== void 0 ? e : void 0
  };
}
function us(r) {
  return (
    // Consider localhost valid as well since it's okay wrt Secure Contexts
    r === "localhost" || /^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/i.test(r)
  );
}
function Sr() {
  var r, e;
  return !!(D() && "PublicKeyCredential" in window && window.PublicKeyCredential && "credentials" in navigator && typeof ((r = navigator == null ? void 0 : navigator.credentials) === null || r === void 0 ? void 0 : r.create) == "function" && typeof ((e = navigator == null ? void 0 : navigator.credentials) === null || e === void 0 ? void 0 : e.get) == "function");
}
async function Di(r) {
  try {
    const e = await navigator.credentials.create(
      /** we assert the type here until typescript types are updated */
      r
    );
    return e ? e instanceof PublicKeyCredential ? { data: e, error: null } : {
      data: null,
      error: new rt("Browser returned unexpected credential type", e)
    } : {
      data: null,
      error: new rt("Empty credential response", e)
    };
  } catch (e) {
    return {
      data: null,
      error: Ii({
        error: e,
        options: r
      })
    };
  }
}
async function Mi(r) {
  try {
    const e = await navigator.credentials.get(
      /** we assert the type here until typescript types are updated */
      r
    );
    return e ? e instanceof PublicKeyCredential ? { data: e, error: null } : {
      data: null,
      error: new rt("Browser returned unexpected credential type", e)
    } : {
      data: null,
      error: new rt("Empty credential response", e)
    };
  } catch (e) {
    return {
      data: null,
      error: xi({
        error: e,
        options: r
      })
    };
  }
}
const Bi = {
  hints: ["security-key"],
  authenticatorSelection: {
    authenticatorAttachment: "cross-platform",
    requireResidentKey: !1,
    /** set to preferred because older yubikeys don't have PIN/Biometric */
    userVerification: "preferred",
    residentKey: "discouraged"
  },
  attestation: "direct"
}, qi = {
  /** set to preferred because older yubikeys don't have PIN/Biometric */
  userVerification: "preferred",
  hints: ["security-key"],
  attestation: "direct"
};
function st(...r) {
  const e = (n) => n !== null && typeof n == "object" && !Array.isArray(n), t = (n) => n instanceof ArrayBuffer || ArrayBuffer.isView(n), s = {};
  for (const n of r)
    if (n)
      for (const i in n) {
        const a = n[i];
        if (a !== void 0)
          if (Array.isArray(a))
            s[i] = a;
          else if (t(a))
            s[i] = a;
          else if (e(a)) {
            const o = s[i];
            e(o) ? s[i] = st(o, a) : s[i] = st(a);
          } else
            s[i] = a;
      }
  return s;
}
function Fi(r, e) {
  return st(Bi, r, e || {});
}
function Hi(r, e) {
  return st(qi, r, e || {});
}
class Vi {
  constructor(e) {
    this.client = e, this.enroll = this._enroll.bind(this), this.challenge = this._challenge.bind(this), this.verify = this._verify.bind(this), this.authenticate = this._authenticate.bind(this), this.register = this._register.bind(this);
  }
  /**
   * Enroll a new WebAuthn factor.
   * Creates an unverified WebAuthn factor that must be verified with a credential.
   *
   * @experimental This method is experimental and may change in future releases
   * @param {Omit<MFAEnrollWebauthnParams, 'factorType'>} params - Enrollment parameters (friendlyName required)
   * @returns {Promise<AuthMFAEnrollWebauthnResponse>} Enrolled factor details or error
   * @see {@link https://w3c.github.io/webauthn/#sctn-registering-a-new-credential W3C WebAuthn Spec - Registering a New Credential}
   */
  async _enroll(e) {
    return this.client.mfa.enroll(Object.assign(Object.assign({}, e), { factorType: "webauthn" }));
  }
  /**
   * Challenge for WebAuthn credential creation or authentication.
   * Combines server challenge with browser credential operations.
   * Handles both registration (create) and authentication (request) flows.
   *
   * @experimental This method is experimental and may change in future releases
   * @param {MFAChallengeWebauthnParams & { friendlyName?: string; signal?: AbortSignal }} params - Challenge parameters including factorId
   * @param {Object} overrides - Allows you to override the parameters passed to navigator.credentials
   * @param {PublicKeyCredentialCreationOptionsFuture} overrides.create - Override options for credential creation
   * @param {PublicKeyCredentialRequestOptionsFuture} overrides.request - Override options for credential request
   * @returns {Promise<RequestResult>} Challenge response with credential or error
   * @see {@link https://w3c.github.io/webauthn/#sctn-credential-creation W3C WebAuthn Spec - Credential Creation}
   * @see {@link https://w3c.github.io/webauthn/#sctn-verifying-assertion W3C WebAuthn Spec - Verifying Assertion}
   */
  async _challenge({ factorId: e, webauthn: t, friendlyName: s, signal: n }, i) {
    var a;
    try {
      const { data: o, error: c } = await this.client.mfa.challenge({
        factorId: e,
        webauthn: t
      });
      if (!o)
        return { data: null, error: c };
      const l = n ?? Pi.createNewAbortSignal();
      if (o.webauthn.type === "create") {
        const { user: u } = o.webauthn.credential_options.publicKey;
        if (!u.name) {
          const d = s;
          if (d)
            u.name = `${u.id}:${d}`;
          else {
            const f = (await this.client.getUser()).data.user, p = ((a = f == null ? void 0 : f.user_metadata) === null || a === void 0 ? void 0 : a.name) || (f == null ? void 0 : f.email) || (f == null ? void 0 : f.id) || "User";
            u.name = `${u.id}:${p}`;
          }
        }
        u.displayName || (u.displayName = u.name);
      }
      switch (o.webauthn.type) {
        case "create": {
          const u = Fi(o.webauthn.credential_options.publicKey, i == null ? void 0 : i.create), { data: d, error: h } = await Di({
            publicKey: u,
            signal: l
          });
          return d ? {
            data: {
              factorId: e,
              challengeId: o.id,
              webauthn: {
                type: o.webauthn.type,
                credential_response: d
              }
            },
            error: null
          } : { data: null, error: h };
        }
        case "request": {
          const u = Hi(o.webauthn.credential_options.publicKey, i == null ? void 0 : i.request), { data: d, error: h } = await Mi(Object.assign(Object.assign({}, o.webauthn.credential_options), { publicKey: u, signal: l }));
          return d ? {
            data: {
              factorId: e,
              challengeId: o.id,
              webauthn: {
                type: o.webauthn.type,
                credential_response: d
              }
            },
            error: null
          } : { data: null, error: h };
        }
      }
    } catch (o) {
      return w(o) ? { data: null, error: o } : {
        data: null,
        error: new pe("Unexpected error in challenge", o)
      };
    }
  }
  /**
   * Verify a WebAuthn credential with the server.
   * Completes the WebAuthn ceremony by sending the credential to the server for verification.
   *
   * @experimental This method is experimental and may change in future releases
   * @param {Object} params - Verification parameters
   * @param {string} params.challengeId - ID of the challenge being verified
   * @param {string} params.factorId - ID of the WebAuthn factor
   * @param {MFAVerifyWebauthnParams<T>['webauthn']} params.webauthn - WebAuthn credential response
   * @returns {Promise<AuthMFAVerifyResponse>} Verification result with session or error
   * @see {@link https://w3c.github.io/webauthn/#sctn-verifying-assertion W3C WebAuthn Spec - Verifying an Authentication Assertion}
   * */
  async _verify({ challengeId: e, factorId: t, webauthn: s }) {
    return this.client.mfa.verify({
      factorId: t,
      challengeId: e,
      webauthn: s
    });
  }
  /**
   * Complete WebAuthn authentication flow.
   * Performs challenge and verification in a single operation for existing credentials.
   *
   * @experimental This method is experimental and may change in future releases
   * @param {Object} params - Authentication parameters
   * @param {string} params.factorId - ID of the WebAuthn factor to authenticate with
   * @param {Object} params.webauthn - WebAuthn configuration
   * @param {string} params.webauthn.rpId - Relying Party ID (defaults to current hostname)
   * @param {string[]} params.webauthn.rpOrigins - Allowed origins (defaults to current origin)
   * @param {AbortSignal} params.webauthn.signal - Optional abort signal
   * @param {PublicKeyCredentialRequestOptionsFuture} overrides - Override options for navigator.credentials.get
   * @returns {Promise<RequestResult<AuthMFAVerifyResponseData, WebAuthnError | AuthError>>} Authentication result
   * @see {@link https://w3c.github.io/webauthn/#sctn-authentication W3C WebAuthn Spec - Authentication Ceremony}
   * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/PublicKeyCredentialRequestOptions MDN - PublicKeyCredentialRequestOptions}
   */
  async _authenticate({ factorId: e, webauthn: { rpId: t = typeof window < "u" ? window.location.hostname : void 0, rpOrigins: s = typeof window < "u" ? [window.location.origin] : void 0, signal: n } = {} }, i) {
    if (!t)
      return {
        data: null,
        error: new qe("rpId is required for WebAuthn authentication")
      };
    try {
      if (!Sr())
        return {
          data: null,
          error: new pe("Browser does not support WebAuthn", null)
        };
      const { data: a, error: o } = await this.challenge({
        factorId: e,
        webauthn: { rpId: t, rpOrigins: s },
        signal: n
      }, { request: i });
      if (!a)
        return { data: null, error: o };
      const { webauthn: c } = a;
      return this._verify({
        factorId: e,
        challengeId: a.challengeId,
        webauthn: {
          type: c.type,
          rpId: t,
          rpOrigins: s,
          credential_response: c.credential_response
        }
      });
    } catch (a) {
      return w(a) ? { data: null, error: a } : {
        data: null,
        error: new pe("Unexpected error in authenticate", a)
      };
    }
  }
  /**
   * Complete WebAuthn registration flow.
   * Performs enrollment, challenge, and verification in a single operation for new credentials.
   *
   * @experimental This method is experimental and may change in future releases
   * @param {Object} params - Registration parameters
   * @param {string} params.friendlyName - User-friendly name for the credential
   * @param {string} params.rpId - Relying Party ID (defaults to current hostname)
   * @param {string[]} params.rpOrigins - Allowed origins (defaults to current origin)
   * @param {AbortSignal} params.signal - Optional abort signal
   * @param {PublicKeyCredentialCreationOptionsFuture} overrides - Override options for navigator.credentials.create
   * @returns {Promise<RequestResult<AuthMFAVerifyResponseData, WebAuthnError | AuthError>>} Registration result
   * @see {@link https://w3c.github.io/webauthn/#sctn-registering-a-new-credential W3C WebAuthn Spec - Registration Ceremony}
   * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/PublicKeyCredentialCreationOptions MDN - PublicKeyCredentialCreationOptions}
   */
  async _register({ friendlyName: e, webauthn: { rpId: t = typeof window < "u" ? window.location.hostname : void 0, rpOrigins: s = typeof window < "u" ? [window.location.origin] : void 0, signal: n } = {} }, i) {
    if (!t)
      return {
        data: null,
        error: new qe("rpId is required for WebAuthn registration")
      };
    try {
      if (!Sr())
        return {
          data: null,
          error: new pe("Browser does not support WebAuthn", null)
        };
      const { data: a, error: o } = await this._enroll({
        friendlyName: e
      });
      if (!a)
        return await this.client.mfa.listFactors().then((u) => {
          var d;
          return (d = u.data) === null || d === void 0 ? void 0 : d.all.find((h) => h.factor_type === "webauthn" && h.friendly_name === e && h.status !== "unverified");
        }).then((u) => u ? this.client.mfa.unenroll({ factorId: u == null ? void 0 : u.id }) : void 0), { data: null, error: o };
      const { data: c, error: l } = await this._challenge({
        factorId: a.id,
        friendlyName: a.friendly_name,
        webauthn: { rpId: t, rpOrigins: s },
        signal: n
      }, {
        create: i
      });
      return c ? this._verify({
        factorId: a.id,
        challengeId: c.challengeId,
        webauthn: {
          rpId: t,
          rpOrigins: s,
          type: c.webauthn.type,
          credential_response: c.webauthn.credential_response
        }
      }) : { data: null, error: l };
    } catch (a) {
      return w(a) ? { data: null, error: a } : {
        data: null,
        error: new pe("Unexpected error in register", a)
      };
    }
  }
}
ki();
const Ki = {
  url: qn,
  storageKey: Fn,
  autoRefreshToken: !0,
  persistSession: !0,
  detectSessionInUrl: !0,
  headers: Hn,
  flowType: "implicit",
  debug: !1,
  hasCustomAuthorizationHeader: !1,
  throwOnError: !1,
  lockAcquireTimeout: 1e4
  // 10 seconds
};
async function Er(r, e, t) {
  return await t();
}
const Te = {};
class Fe {
  /**
   * The JWKS used for verifying asymmetric JWTs
   */
  get jwks() {
    var e, t;
    return (t = (e = Te[this.storageKey]) === null || e === void 0 ? void 0 : e.jwks) !== null && t !== void 0 ? t : { keys: [] };
  }
  set jwks(e) {
    Te[this.storageKey] = Object.assign(Object.assign({}, Te[this.storageKey]), { jwks: e });
  }
  get jwks_cached_at() {
    var e, t;
    return (t = (e = Te[this.storageKey]) === null || e === void 0 ? void 0 : e.cachedAt) !== null && t !== void 0 ? t : Number.MIN_SAFE_INTEGER;
  }
  set jwks_cached_at(e) {
    Te[this.storageKey] = Object.assign(Object.assign({}, Te[this.storageKey]), { cachedAt: e });
  }
  /**
   * Create a new client for use in the browser.
   *
   * @example
   * ```ts
   * import { GoTrueClient } from '@supabase/auth-js'
   *
   * const auth = new GoTrueClient({
   *   url: 'https://xyzcompany.supabase.co/auth/v1',
   *   headers: { apikey: 'public-anon-key' },
   *   storageKey: 'supabase-auth',
   * })
   * ```
   */
  constructor(e) {
    var t, s, n;
    this.userStorage = null, this.memoryStorage = null, this.stateChangeEmitters = /* @__PURE__ */ new Map(), this.autoRefreshTicker = null, this.autoRefreshTickTimeout = null, this.visibilityChangedCallback = null, this.refreshingDeferred = null, this.initializePromise = null, this.detectSessionInUrl = !0, this.hasCustomAuthorizationHeader = !1, this.suppressGetSessionWarning = !1, this.lockAcquired = !1, this.pendingInLock = [], this.broadcastChannel = null, this.logger = console.log;
    const i = Object.assign(Object.assign({}, Ki), e);
    if (this.storageKey = i.storageKey, this.instanceID = (t = Fe.nextInstanceID[this.storageKey]) !== null && t !== void 0 ? t : 0, Fe.nextInstanceID[this.storageKey] = this.instanceID + 1, this.logDebugMessages = !!i.debug, typeof i.debug == "function" && (this.logger = i.debug), this.instanceID > 0 && D()) {
      const a = `${this._logPrefix()} Multiple GoTrueClient instances detected in the same browser context. It is not an error, but this should be avoided as it may produce undefined behavior when used concurrently under the same storage key.`;
      console.warn(a), this.logDebugMessages && console.trace(a);
    }
    if (this.persistSession = i.persistSession, this.autoRefreshToken = i.autoRefreshToken, this.admin = new Ei({
      url: i.url,
      headers: i.headers,
      fetch: i.fetch
    }), this.url = i.url, this.headers = i.headers, this.fetch = os(i.fetch), this.lock = i.lock || Er, this.detectSessionInUrl = i.detectSessionInUrl, this.flowType = i.flowType, this.hasCustomAuthorizationHeader = i.hasCustomAuthorizationHeader, this.throwOnError = i.throwOnError, this.lockAcquireTimeout = i.lockAcquireTimeout, i.lock ? this.lock = i.lock : this.persistSession && D() && (!((s = globalThis == null ? void 0 : globalThis.navigator) === null || s === void 0) && s.locks) ? this.lock = Ai : this.lock = Er, this.jwks || (this.jwks = { keys: [] }, this.jwks_cached_at = Number.MIN_SAFE_INTEGER), this.mfa = {
      verify: this._verify.bind(this),
      enroll: this._enroll.bind(this),
      unenroll: this._unenroll.bind(this),
      challenge: this._challenge.bind(this),
      listFactors: this._listFactors.bind(this),
      challengeAndVerify: this._challengeAndVerify.bind(this),
      getAuthenticatorAssuranceLevel: this._getAuthenticatorAssuranceLevel.bind(this),
      webauthn: new Vi(this)
    }, this.oauth = {
      getAuthorizationDetails: this._getAuthorizationDetails.bind(this),
      approveAuthorization: this._approveAuthorization.bind(this),
      denyAuthorization: this._denyAuthorization.bind(this),
      listGrants: this._listOAuthGrants.bind(this),
      revokeGrant: this._revokeOAuthGrant.bind(this)
    }, this.persistSession ? (i.storage ? this.storage = i.storage : as() ? this.storage = globalThis.localStorage : (this.memoryStorage = {}, this.storage = br(this.memoryStorage)), i.userStorage && (this.userStorage = i.userStorage)) : (this.memoryStorage = {}, this.storage = br(this.memoryStorage)), D() && globalThis.BroadcastChannel && this.persistSession && this.storageKey) {
      try {
        this.broadcastChannel = new globalThis.BroadcastChannel(this.storageKey);
      } catch (a) {
        console.error("Failed to create a new BroadcastChannel, multi-tab state changes will not be available", a);
      }
      (n = this.broadcastChannel) === null || n === void 0 || n.addEventListener("message", async (a) => {
        this._debug("received broadcast notification from other tab or client", a);
        try {
          await this._notifyAllSubscribers(a.data.event, a.data.session, !1);
        } catch (o) {
          this._debug("#broadcastChannel", "error", o);
        }
      });
    }
    this.initialize().catch((a) => {
      this._debug("#initialize()", "error", a);
    });
  }
  /**
   * Returns whether error throwing mode is enabled for this client.
   */
  isThrowOnErrorEnabled() {
    return this.throwOnError;
  }
  /**
   * Centralizes return handling with optional error throwing. When `throwOnError` is enabled
   * and the provided result contains a non-nullish error, the error is thrown instead of
   * being returned. This ensures consistent behavior across all public API methods.
   */
  _returnResult(e) {
    if (this.throwOnError && e && e.error)
      throw e.error;
    return e;
  }
  _logPrefix() {
    return `GoTrueClient@${this.storageKey}:${this.instanceID} (${ss}) ${(/* @__PURE__ */ new Date()).toISOString()}`;
  }
  _debug(...e) {
    return this.logDebugMessages && this.logger(this._logPrefix(), ...e), this;
  }
  /**
   * Initializes the client session either from the url or from storage.
   * This method is automatically called when instantiating the client, but should also be called
   * manually when checking for an error from an auth redirect (oauth, magiclink, password recovery, etc).
   */
  async initialize() {
    return this.initializePromise ? await this.initializePromise : (this.initializePromise = (async () => await this._acquireLock(this.lockAcquireTimeout, async () => await this._initialize()))(), await this.initializePromise);
  }
  /**
   * IMPORTANT:
   * 1. Never throw in this method, as it is called from the constructor
   * 2. Never return a session from this method as it would be cached over
   *    the whole lifetime of the client
   */
  async _initialize() {
    var e;
    try {
      let t = {}, s = "none";
      if (D() && (t = si(window.location.href), this._isImplicitGrantCallback(t) ? s = "implicit" : await this._isPKCECallback(t) && (s = "pkce")), D() && this.detectSessionInUrl && s !== "none") {
        const { data: n, error: i } = await this._getSessionFromURL(t, s);
        if (i) {
          if (this._debug("#_initialize()", "error detecting session from URL", i), Wn(i)) {
            const c = (e = i.details) === null || e === void 0 ? void 0 : e.code;
            if (c === "identity_already_exists" || c === "identity_not_found" || c === "single_identity_not_deletable")
              return { error: i };
          }
          return { error: i };
        }
        const { session: a, redirectType: o } = n;
        return this._debug("#_initialize()", "detected session in URL", a, "redirect type", o), await this._saveSession(a), setTimeout(async () => {
          o === "recovery" ? await this._notifyAllSubscribers("PASSWORD_RECOVERY", a) : await this._notifyAllSubscribers("SIGNED_IN", a);
        }, 0), { error: null };
      }
      return await this._recoverAndRefresh(), { error: null };
    } catch (t) {
      return w(t) ? this._returnResult({ error: t }) : this._returnResult({
        error: new pe("Unexpected error during initialization", t)
      });
    } finally {
      await this._handleVisibilityChange(), this._debug("#_initialize()", "end");
    }
  }
  /**
   * Creates a new anonymous user.
   *
   * @returns A session where the is_anonymous claim in the access token JWT set to true
   */
  async signInAnonymously(e) {
    var t, s, n;
    try {
      const i = await T(this.fetch, "POST", `${this.url}/signup`, {
        headers: this.headers,
        body: {
          data: (s = (t = e == null ? void 0 : e.options) === null || t === void 0 ? void 0 : t.data) !== null && s !== void 0 ? s : {},
          gotrue_meta_security: { captcha_token: (n = e == null ? void 0 : e.options) === null || n === void 0 ? void 0 : n.captchaToken }
        },
        xform: Y
      }), { data: a, error: o } = i;
      if (o || !a)
        return this._returnResult({ data: { user: null, session: null }, error: o });
      const c = a.session, l = a.user;
      return a.session && (await this._saveSession(a.session), await this._notifyAllSubscribers("SIGNED_IN", c)), this._returnResult({ data: { user: l, session: c }, error: null });
    } catch (i) {
      if (w(i))
        return this._returnResult({ data: { user: null, session: null }, error: i });
      throw i;
    }
  }
  /**
   * Creates a new user.
   *
   * Be aware that if a user account exists in the system you may get back an
   * error message that attempts to hide this information from the user.
   * This method has support for PKCE via email signups. The PKCE flow cannot be used when autoconfirm is enabled.
   *
   * @returns A logged-in session if the server has "autoconfirm" ON
   * @returns A user if the server has "autoconfirm" OFF
   */
  async signUp(e) {
    var t, s, n;
    try {
      let i;
      if ("email" in e) {
        const { email: u, password: d, options: h } = e;
        let f = null, p = null;
        this.flowType === "pkce" && ([f, p] = await be(this.storage, this.storageKey)), i = await T(this.fetch, "POST", `${this.url}/signup`, {
          headers: this.headers,
          redirectTo: h == null ? void 0 : h.emailRedirectTo,
          body: {
            email: u,
            password: d,
            data: (t = h == null ? void 0 : h.data) !== null && t !== void 0 ? t : {},
            gotrue_meta_security: { captcha_token: h == null ? void 0 : h.captchaToken },
            code_challenge: f,
            code_challenge_method: p
          },
          xform: Y
        });
      } else if ("phone" in e) {
        const { phone: u, password: d, options: h } = e;
        i = await T(this.fetch, "POST", `${this.url}/signup`, {
          headers: this.headers,
          body: {
            phone: u,
            password: d,
            data: (s = h == null ? void 0 : h.data) !== null && s !== void 0 ? s : {},
            channel: (n = h == null ? void 0 : h.channel) !== null && n !== void 0 ? n : "sms",
            gotrue_meta_security: { captcha_token: h == null ? void 0 : h.captchaToken }
          },
          xform: Y
        });
      } else
        throw new Je("You must provide either an email or phone number and a password");
      const { data: a, error: o } = i;
      if (o || !a)
        return await L(this.storage, `${this.storageKey}-code-verifier`), this._returnResult({ data: { user: null, session: null }, error: o });
      const c = a.session, l = a.user;
      return a.session && (await this._saveSession(a.session), await this._notifyAllSubscribers("SIGNED_IN", c)), this._returnResult({ data: { user: l, session: c }, error: null });
    } catch (i) {
      if (await L(this.storage, `${this.storageKey}-code-verifier`), w(i))
        return this._returnResult({ data: { user: null, session: null }, error: i });
      throw i;
    }
  }
  /**
   * Log in an existing user with an email and password or phone and password.
   *
   * Be aware that you may get back an error message that will not distinguish
   * between the cases where the account does not exist or that the
   * email/phone and password combination is wrong or that the account can only
   * be accessed via social login.
   */
  async signInWithPassword(e) {
    try {
      let t;
      if ("email" in e) {
        const { email: i, password: a, options: o } = e;
        t = await T(this.fetch, "POST", `${this.url}/token?grant_type=password`, {
          headers: this.headers,
          body: {
            email: i,
            password: a,
            gotrue_meta_security: { captcha_token: o == null ? void 0 : o.captchaToken }
          },
          xform: vr
        });
      } else if ("phone" in e) {
        const { phone: i, password: a, options: o } = e;
        t = await T(this.fetch, "POST", `${this.url}/token?grant_type=password`, {
          headers: this.headers,
          body: {
            phone: i,
            password: a,
            gotrue_meta_security: { captcha_token: o == null ? void 0 : o.captchaToken }
          },
          xform: vr
        });
      } else
        throw new Je("You must provide either an email or phone number and a password");
      const { data: s, error: n } = t;
      if (n)
        return this._returnResult({ data: { user: null, session: null }, error: n });
      if (!s || !s.session || !s.user) {
        const i = new we();
        return this._returnResult({ data: { user: null, session: null }, error: i });
      }
      return s.session && (await this._saveSession(s.session), await this._notifyAllSubscribers("SIGNED_IN", s.session)), this._returnResult({
        data: Object.assign({ user: s.user, session: s.session }, s.weak_password ? { weakPassword: s.weak_password } : null),
        error: n
      });
    } catch (t) {
      if (w(t))
        return this._returnResult({ data: { user: null, session: null }, error: t });
      throw t;
    }
  }
  /**
   * Log in an existing user via a third-party provider.
   * This method supports the PKCE flow.
   */
  async signInWithOAuth(e) {
    var t, s, n, i;
    return await this._handleProviderSignIn(e.provider, {
      redirectTo: (t = e.options) === null || t === void 0 ? void 0 : t.redirectTo,
      scopes: (s = e.options) === null || s === void 0 ? void 0 : s.scopes,
      queryParams: (n = e.options) === null || n === void 0 ? void 0 : n.queryParams,
      skipBrowserRedirect: (i = e.options) === null || i === void 0 ? void 0 : i.skipBrowserRedirect
    });
  }
  /**
   * Log in an existing user by exchanging an Auth Code issued during the PKCE flow.
   */
  async exchangeCodeForSession(e) {
    return await this.initializePromise, this._acquireLock(this.lockAcquireTimeout, async () => this._exchangeCodeForSession(e));
  }
  /**
   * Signs in a user by verifying a message signed by the user's private key.
   * Supports Ethereum (via Sign-In-With-Ethereum) & Solana (Sign-In-With-Solana) standards,
   * both of which derive from the EIP-4361 standard
   * With slight variation on Solana's side.
   * @reference https://eips.ethereum.org/EIPS/eip-4361
   */
  async signInWithWeb3(e) {
    const { chain: t } = e;
    switch (t) {
      case "ethereum":
        return await this.signInWithEthereum(e);
      case "solana":
        return await this.signInWithSolana(e);
      default:
        throw new Error(`@supabase/auth-js: Unsupported chain "${t}"`);
    }
  }
  async signInWithEthereum(e) {
    var t, s, n, i, a, o, c, l, u, d, h;
    let f, p;
    if ("message" in e)
      f = e.message, p = e.signature;
    else {
      const { chain: g, wallet: m, statement: y, options: v } = e;
      let _;
      if (D())
        if (typeof m == "object")
          _ = m;
        else {
          const q = window;
          if ("ethereum" in q && typeof q.ethereum == "object" && "request" in q.ethereum && typeof q.ethereum.request == "function")
            _ = q.ethereum;
          else
            throw new Error("@supabase/auth-js: No compatible Ethereum wallet interface on the window object (window.ethereum) detected. Make sure the user already has a wallet installed and connected for this app. Prefer passing the wallet interface object directly to signInWithWeb3({ chain: 'ethereum', wallet: resolvedUserWallet }) instead.");
        }
      else {
        if (typeof m != "object" || !(v != null && v.url))
          throw new Error("@supabase/auth-js: Both wallet and url must be specified in non-browser environments.");
        _ = m;
      }
      const E = new URL((t = v == null ? void 0 : v.url) !== null && t !== void 0 ? t : window.location.href), C = await _.request({
        method: "eth_requestAccounts"
      }).then((q) => q).catch(() => {
        throw new Error("@supabase/auth-js: Wallet method eth_requestAccounts is missing or invalid");
      });
      if (!C || C.length === 0)
        throw new Error("@supabase/auth-js: No accounts available. Please ensure the wallet is connected.");
      const S = ls(C[0]);
      let R = (s = v == null ? void 0 : v.signInWithEthereum) === null || s === void 0 ? void 0 : s.chainId;
      if (!R) {
        const q = await _.request({
          method: "eth_chainId"
        });
        R = Oi(q);
      }
      const H = {
        domain: E.host,
        address: S,
        statement: y,
        uri: E.href,
        version: "1",
        chainId: R,
        nonce: (n = v == null ? void 0 : v.signInWithEthereum) === null || n === void 0 ? void 0 : n.nonce,
        issuedAt: (a = (i = v == null ? void 0 : v.signInWithEthereum) === null || i === void 0 ? void 0 : i.issuedAt) !== null && a !== void 0 ? a : /* @__PURE__ */ new Date(),
        expirationTime: (o = v == null ? void 0 : v.signInWithEthereum) === null || o === void 0 ? void 0 : o.expirationTime,
        notBefore: (c = v == null ? void 0 : v.signInWithEthereum) === null || c === void 0 ? void 0 : c.notBefore,
        requestId: (l = v == null ? void 0 : v.signInWithEthereum) === null || l === void 0 ? void 0 : l.requestId,
        resources: (u = v == null ? void 0 : v.signInWithEthereum) === null || u === void 0 ? void 0 : u.resources
      };
      f = Ci(H), p = await _.request({
        method: "personal_sign",
        params: [Ri(f), S]
      });
    }
    try {
      const { data: g, error: m } = await T(this.fetch, "POST", `${this.url}/token?grant_type=web3`, {
        headers: this.headers,
        body: Object.assign({
          chain: "ethereum",
          message: f,
          signature: p
        }, !((d = e.options) === null || d === void 0) && d.captchaToken ? { gotrue_meta_security: { captcha_token: (h = e.options) === null || h === void 0 ? void 0 : h.captchaToken } } : null),
        xform: Y
      });
      if (m)
        throw m;
      if (!g || !g.session || !g.user) {
        const y = new we();
        return this._returnResult({ data: { user: null, session: null }, error: y });
      }
      return g.session && (await this._saveSession(g.session), await this._notifyAllSubscribers("SIGNED_IN", g.session)), this._returnResult({ data: Object.assign({}, g), error: m });
    } catch (g) {
      if (w(g))
        return this._returnResult({ data: { user: null, session: null }, error: g });
      throw g;
    }
  }
  async signInWithSolana(e) {
    var t, s, n, i, a, o, c, l, u, d, h, f;
    let p, g;
    if ("message" in e)
      p = e.message, g = e.signature;
    else {
      const { chain: m, wallet: y, statement: v, options: _ } = e;
      let E;
      if (D())
        if (typeof y == "object")
          E = y;
        else {
          const S = window;
          if ("solana" in S && typeof S.solana == "object" && ("signIn" in S.solana && typeof S.solana.signIn == "function" || "signMessage" in S.solana && typeof S.solana.signMessage == "function"))
            E = S.solana;
          else
            throw new Error("@supabase/auth-js: No compatible Solana wallet interface on the window object (window.solana) detected. Make sure the user already has a wallet installed and connected for this app. Prefer passing the wallet interface object directly to signInWithWeb3({ chain: 'solana', wallet: resolvedUserWallet }) instead.");
        }
      else {
        if (typeof y != "object" || !(_ != null && _.url))
          throw new Error("@supabase/auth-js: Both wallet and url must be specified in non-browser environments.");
        E = y;
      }
      const C = new URL((t = _ == null ? void 0 : _.url) !== null && t !== void 0 ? t : window.location.href);
      if ("signIn" in E && E.signIn) {
        const S = await E.signIn(Object.assign(Object.assign(Object.assign({ issuedAt: (/* @__PURE__ */ new Date()).toISOString() }, _ == null ? void 0 : _.signInWithSolana), {
          // non-overridable properties
          version: "1",
          domain: C.host,
          uri: C.href
        }), v ? { statement: v } : null));
        let R;
        if (Array.isArray(S) && S[0] && typeof S[0] == "object")
          R = S[0];
        else if (S && typeof S == "object" && "signedMessage" in S && "signature" in S)
          R = S;
        else
          throw new Error("@supabase/auth-js: Wallet method signIn() returned unrecognized value");
        if ("signedMessage" in R && "signature" in R && (typeof R.signedMessage == "string" || R.signedMessage instanceof Uint8Array) && R.signature instanceof Uint8Array)
          p = typeof R.signedMessage == "string" ? R.signedMessage : new TextDecoder().decode(R.signedMessage), g = R.signature;
        else
          throw new Error("@supabase/auth-js: Wallet method signIn() API returned object without signedMessage and signature fields");
      } else {
        if (!("signMessage" in E) || typeof E.signMessage != "function" || !("publicKey" in E) || typeof E != "object" || !E.publicKey || !("toBase58" in E.publicKey) || typeof E.publicKey.toBase58 != "function")
          throw new Error("@supabase/auth-js: Wallet does not have a compatible signMessage() and publicKey.toBase58() API");
        p = [
          `${C.host} wants you to sign in with your Solana account:`,
          E.publicKey.toBase58(),
          ...v ? ["", v, ""] : [""],
          "Version: 1",
          `URI: ${C.href}`,
          `Issued At: ${(n = (s = _ == null ? void 0 : _.signInWithSolana) === null || s === void 0 ? void 0 : s.issuedAt) !== null && n !== void 0 ? n : (/* @__PURE__ */ new Date()).toISOString()}`,
          ...!((i = _ == null ? void 0 : _.signInWithSolana) === null || i === void 0) && i.notBefore ? [`Not Before: ${_.signInWithSolana.notBefore}`] : [],
          ...!((a = _ == null ? void 0 : _.signInWithSolana) === null || a === void 0) && a.expirationTime ? [`Expiration Time: ${_.signInWithSolana.expirationTime}`] : [],
          ...!((o = _ == null ? void 0 : _.signInWithSolana) === null || o === void 0) && o.chainId ? [`Chain ID: ${_.signInWithSolana.chainId}`] : [],
          ...!((c = _ == null ? void 0 : _.signInWithSolana) === null || c === void 0) && c.nonce ? [`Nonce: ${_.signInWithSolana.nonce}`] : [],
          ...!((l = _ == null ? void 0 : _.signInWithSolana) === null || l === void 0) && l.requestId ? [`Request ID: ${_.signInWithSolana.requestId}`] : [],
          ...!((d = (u = _ == null ? void 0 : _.signInWithSolana) === null || u === void 0 ? void 0 : u.resources) === null || d === void 0) && d.length ? [
            "Resources",
            ..._.signInWithSolana.resources.map((R) => `- ${R}`)
          ] : []
        ].join(`
`);
        const S = await E.signMessage(new TextEncoder().encode(p), "utf8");
        if (!S || !(S instanceof Uint8Array))
          throw new Error("@supabase/auth-js: Wallet signMessage() API returned an recognized value");
        g = S;
      }
    }
    try {
      const { data: m, error: y } = await T(this.fetch, "POST", `${this.url}/token?grant_type=web3`, {
        headers: this.headers,
        body: Object.assign({ chain: "solana", message: p, signature: ge(g) }, !((h = e.options) === null || h === void 0) && h.captchaToken ? { gotrue_meta_security: { captcha_token: (f = e.options) === null || f === void 0 ? void 0 : f.captchaToken } } : null),
        xform: Y
      });
      if (y)
        throw y;
      if (!m || !m.session || !m.user) {
        const v = new we();
        return this._returnResult({ data: { user: null, session: null }, error: v });
      }
      return m.session && (await this._saveSession(m.session), await this._notifyAllSubscribers("SIGNED_IN", m.session)), this._returnResult({ data: Object.assign({}, m), error: y });
    } catch (m) {
      if (w(m))
        return this._returnResult({ data: { user: null, session: null }, error: m });
      throw m;
    }
  }
  async _exchangeCodeForSession(e) {
    const t = await he(this.storage, `${this.storageKey}-code-verifier`), [s, n] = (t ?? "").split("/");
    try {
      if (!s && this.flowType === "pkce")
        throw new Jn();
      const { data: i, error: a } = await T(this.fetch, "POST", `${this.url}/token?grant_type=pkce`, {
        headers: this.headers,
        body: {
          auth_code: e,
          code_verifier: s
        },
        xform: Y
      });
      if (await L(this.storage, `${this.storageKey}-code-verifier`), a)
        throw a;
      if (!i || !i.session || !i.user) {
        const o = new we();
        return this._returnResult({
          data: { user: null, session: null, redirectType: null },
          error: o
        });
      }
      return i.session && (await this._saveSession(i.session), await this._notifyAllSubscribers("SIGNED_IN", i.session)), this._returnResult({ data: Object.assign(Object.assign({}, i), { redirectType: n ?? null }), error: a });
    } catch (i) {
      if (await L(this.storage, `${this.storageKey}-code-verifier`), w(i))
        return this._returnResult({
          data: { user: null, session: null, redirectType: null },
          error: i
        });
      throw i;
    }
  }
  /**
   * Allows signing in with an OIDC ID token. The authentication provider used
   * should be enabled and configured.
   */
  async signInWithIdToken(e) {
    try {
      const { options: t, provider: s, token: n, access_token: i, nonce: a } = e, o = await T(this.fetch, "POST", `${this.url}/token?grant_type=id_token`, {
        headers: this.headers,
        body: {
          provider: s,
          id_token: n,
          access_token: i,
          nonce: a,
          gotrue_meta_security: { captcha_token: t == null ? void 0 : t.captchaToken }
        },
        xform: Y
      }), { data: c, error: l } = o;
      if (l)
        return this._returnResult({ data: { user: null, session: null }, error: l });
      if (!c || !c.session || !c.user) {
        const u = new we();
        return this._returnResult({ data: { user: null, session: null }, error: u });
      }
      return c.session && (await this._saveSession(c.session), await this._notifyAllSubscribers("SIGNED_IN", c.session)), this._returnResult({ data: c, error: l });
    } catch (t) {
      if (w(t))
        return this._returnResult({ data: { user: null, session: null }, error: t });
      throw t;
    }
  }
  /**
   * Log in a user using magiclink or a one-time password (OTP).
   *
   * If the `{{ .ConfirmationURL }}` variable is specified in the email template, a magiclink will be sent.
   * If the `{{ .Token }}` variable is specified in the email template, an OTP will be sent.
   * If you're using phone sign-ins, only an OTP will be sent. You won't be able to send a magiclink for phone sign-ins.
   *
   * Be aware that you may get back an error message that will not distinguish
   * between the cases where the account does not exist or, that the account
   * can only be accessed via social login.
   *
   * Do note that you will need to configure a Whatsapp sender on Twilio
   * if you are using phone sign in with the 'whatsapp' channel. The whatsapp
   * channel is not supported on other providers
   * at this time.
   * This method supports PKCE when an email is passed.
   */
  async signInWithOtp(e) {
    var t, s, n, i, a;
    try {
      if ("email" in e) {
        const { email: o, options: c } = e;
        let l = null, u = null;
        this.flowType === "pkce" && ([l, u] = await be(this.storage, this.storageKey));
        const { error: d } = await T(this.fetch, "POST", `${this.url}/otp`, {
          headers: this.headers,
          body: {
            email: o,
            data: (t = c == null ? void 0 : c.data) !== null && t !== void 0 ? t : {},
            create_user: (s = c == null ? void 0 : c.shouldCreateUser) !== null && s !== void 0 ? s : !0,
            gotrue_meta_security: { captcha_token: c == null ? void 0 : c.captchaToken },
            code_challenge: l,
            code_challenge_method: u
          },
          redirectTo: c == null ? void 0 : c.emailRedirectTo
        });
        return this._returnResult({ data: { user: null, session: null }, error: d });
      }
      if ("phone" in e) {
        const { phone: o, options: c } = e, { data: l, error: u } = await T(this.fetch, "POST", `${this.url}/otp`, {
          headers: this.headers,
          body: {
            phone: o,
            data: (n = c == null ? void 0 : c.data) !== null && n !== void 0 ? n : {},
            create_user: (i = c == null ? void 0 : c.shouldCreateUser) !== null && i !== void 0 ? i : !0,
            gotrue_meta_security: { captcha_token: c == null ? void 0 : c.captchaToken },
            channel: (a = c == null ? void 0 : c.channel) !== null && a !== void 0 ? a : "sms"
          }
        });
        return this._returnResult({
          data: { user: null, session: null, messageId: l == null ? void 0 : l.message_id },
          error: u
        });
      }
      throw new Je("You must provide either an email or phone number.");
    } catch (o) {
      if (await L(this.storage, `${this.storageKey}-code-verifier`), w(o))
        return this._returnResult({ data: { user: null, session: null }, error: o });
      throw o;
    }
  }
  /**
   * Log in a user given a User supplied OTP or TokenHash received through mobile or email.
   */
  async verifyOtp(e) {
    var t, s;
    try {
      let n, i;
      "options" in e && (n = (t = e.options) === null || t === void 0 ? void 0 : t.redirectTo, i = (s = e.options) === null || s === void 0 ? void 0 : s.captchaToken);
      const { data: a, error: o } = await T(this.fetch, "POST", `${this.url}/verify`, {
        headers: this.headers,
        body: Object.assign(Object.assign({}, e), { gotrue_meta_security: { captcha_token: i } }),
        redirectTo: n,
        xform: Y
      });
      if (o)
        throw o;
      if (!a)
        throw new Error("An error occurred on token verification.");
      const c = a.session, l = a.user;
      return c != null && c.access_token && (await this._saveSession(c), await this._notifyAllSubscribers(e.type == "recovery" ? "PASSWORD_RECOVERY" : "SIGNED_IN", c)), this._returnResult({ data: { user: l, session: c }, error: null });
    } catch (n) {
      if (w(n))
        return this._returnResult({ data: { user: null, session: null }, error: n });
      throw n;
    }
  }
  /**
   * Attempts a single-sign on using an enterprise Identity Provider. A
   * successful SSO attempt will redirect the current page to the identity
   * provider authorization page. The redirect URL is implementation and SSO
   * protocol specific.
   *
   * You can use it by providing a SSO domain. Typically you can extract this
   * domain by asking users for their email address. If this domain is
   * registered on the Auth instance the redirect will use that organization's
   * currently active SSO Identity Provider for the login.
   *
   * If you have built an organization-specific login page, you can use the
   * organization's SSO Identity Provider UUID directly instead.
   */
  async signInWithSSO(e) {
    var t, s, n, i, a;
    try {
      let o = null, c = null;
      this.flowType === "pkce" && ([o, c] = await be(this.storage, this.storageKey));
      const l = await T(this.fetch, "POST", `${this.url}/sso`, {
        body: Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, "providerId" in e ? { provider_id: e.providerId } : null), "domain" in e ? { domain: e.domain } : null), { redirect_to: (s = (t = e.options) === null || t === void 0 ? void 0 : t.redirectTo) !== null && s !== void 0 ? s : void 0 }), !((n = e == null ? void 0 : e.options) === null || n === void 0) && n.captchaToken ? { gotrue_meta_security: { captcha_token: e.options.captchaToken } } : null), { skip_http_redirect: !0, code_challenge: o, code_challenge_method: c }),
        headers: this.headers,
        xform: wi
      });
      return !((i = l.data) === null || i === void 0) && i.url && D() && !(!((a = e.options) === null || a === void 0) && a.skipBrowserRedirect) && window.location.assign(l.data.url), this._returnResult(l);
    } catch (o) {
      if (await L(this.storage, `${this.storageKey}-code-verifier`), w(o))
        return this._returnResult({ data: null, error: o });
      throw o;
    }
  }
  /**
   * Sends a reauthentication OTP to the user's email or phone number.
   * Requires the user to be signed-in.
   */
  async reauthenticate() {
    return await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => await this._reauthenticate());
  }
  async _reauthenticate() {
    try {
      return await this._useSession(async (e) => {
        const { data: { session: t }, error: s } = e;
        if (s)
          throw s;
        if (!t)
          throw new K();
        const { error: n } = await T(this.fetch, "GET", `${this.url}/reauthenticate`, {
          headers: this.headers,
          jwt: t.access_token
        });
        return this._returnResult({ data: { user: null, session: null }, error: n });
      });
    } catch (e) {
      if (w(e))
        return this._returnResult({ data: { user: null, session: null }, error: e });
      throw e;
    }
  }
  /**
   * Resends an existing signup confirmation email, email change email, SMS OTP or phone change OTP.
   */
  async resend(e) {
    try {
      const t = `${this.url}/resend`;
      if ("email" in e) {
        const { email: s, type: n, options: i } = e, { error: a } = await T(this.fetch, "POST", t, {
          headers: this.headers,
          body: {
            email: s,
            type: n,
            gotrue_meta_security: { captcha_token: i == null ? void 0 : i.captchaToken }
          },
          redirectTo: i == null ? void 0 : i.emailRedirectTo
        });
        return this._returnResult({ data: { user: null, session: null }, error: a });
      } else if ("phone" in e) {
        const { phone: s, type: n, options: i } = e, { data: a, error: o } = await T(this.fetch, "POST", t, {
          headers: this.headers,
          body: {
            phone: s,
            type: n,
            gotrue_meta_security: { captcha_token: i == null ? void 0 : i.captchaToken }
          }
        });
        return this._returnResult({
          data: { user: null, session: null, messageId: a == null ? void 0 : a.message_id },
          error: o
        });
      }
      throw new Je("You must provide either an email or phone number and a type");
    } catch (t) {
      if (w(t))
        return this._returnResult({ data: { user: null, session: null }, error: t });
      throw t;
    }
  }
  /**
   * Returns the session, refreshing it if necessary.
   *
   * The session returned can be null if the session is not detected which can happen in the event a user is not signed-in or has logged out.
   *
   * **IMPORTANT:** This method loads values directly from the storage attached
   * to the client. If that storage is based on request cookies for example,
   * the values in it may not be authentic and therefore it's strongly advised
   * against using this method and its results in such circumstances. A warning
   * will be emitted if this is detected. Use {@link #getUser()} instead.
   */
  async getSession() {
    return await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => this._useSession(async (t) => t));
  }
  /**
   * Acquires a global lock based on the storage key.
   */
  async _acquireLock(e, t) {
    this._debug("#_acquireLock", "begin", e);
    try {
      if (this.lockAcquired) {
        const s = this.pendingInLock.length ? this.pendingInLock[this.pendingInLock.length - 1] : Promise.resolve(), n = (async () => (await s, await t()))();
        return this.pendingInLock.push((async () => {
          try {
            await n;
          } catch {
          }
        })()), n;
      }
      return await this.lock(`lock:${this.storageKey}`, e, async () => {
        this._debug("#_acquireLock", "lock acquired for storage key", this.storageKey);
        try {
          this.lockAcquired = !0;
          const s = t();
          for (this.pendingInLock.push((async () => {
            try {
              await s;
            } catch {
            }
          })()), await s; this.pendingInLock.length; ) {
            const n = [...this.pendingInLock];
            await Promise.all(n), this.pendingInLock.splice(0, n.length);
          }
          return await s;
        } finally {
          this._debug("#_acquireLock", "lock released for storage key", this.storageKey), this.lockAcquired = !1;
        }
      });
    } finally {
      this._debug("#_acquireLock", "end");
    }
  }
  /**
   * Use instead of {@link #getSession} inside the library. It is
   * semantically usually what you want, as getting a session involves some
   * processing afterwards that requires only one client operating on the
   * session at once across multiple tabs or processes.
   */
  async _useSession(e) {
    this._debug("#_useSession", "begin");
    try {
      const t = await this.__loadSession();
      return await e(t);
    } finally {
      this._debug("#_useSession", "end");
    }
  }
  /**
   * NEVER USE DIRECTLY!
   *
   * Always use {@link #_useSession}.
   */
  async __loadSession() {
    this._debug("#__loadSession()", "begin"), this.lockAcquired || this._debug("#__loadSession()", "used outside of an acquired lock!", new Error().stack);
    try {
      let e = null;
      const t = await he(this.storage, this.storageKey);
      if (this._debug("#getSession()", "session from storage", t), t !== null && (this._isValidSession(t) ? e = t : (this._debug("#getSession()", "session from storage is not valid"), await this._removeSession())), !e)
        return { data: { session: null }, error: null };
      const s = e.expires_at ? e.expires_at * 1e3 - Date.now() < pt : !1;
      if (this._debug("#__loadSession()", `session has${s ? "" : " not"} expired`, "expires_at", e.expires_at), !s) {
        if (this.userStorage) {
          const a = await he(this.userStorage, this.storageKey + "-user");
          a != null && a.user ? e.user = a.user : e.user = yt();
        }
        if (this.storage.isServer && e.user && !e.user.__isUserNotAvailableProxy) {
          const a = { value: this.suppressGetSessionWarning };
          e.user = mi(e.user, a), a.value && (this.suppressGetSessionWarning = !0);
        }
        return { data: { session: e }, error: null };
      }
      const { data: n, error: i } = await this._callRefreshToken(e.refresh_token);
      return i ? this._returnResult({ data: { session: null }, error: i }) : this._returnResult({ data: { session: n }, error: null });
    } finally {
      this._debug("#__loadSession()", "end");
    }
  }
  /**
   * Gets the current user details if there is an existing session. This method
   * performs a network request to the Supabase Auth server, so the returned
   * value is authentic and can be used to base authorization rules on.
   *
   * @param jwt Takes in an optional access token JWT. If no JWT is provided, the JWT from the current session is used.
   */
  async getUser(e) {
    if (e)
      return await this._getUser(e);
    await this.initializePromise;
    const t = await this._acquireLock(this.lockAcquireTimeout, async () => await this._getUser());
    return t.data.user && (this.suppressGetSessionWarning = !0), t;
  }
  async _getUser(e) {
    try {
      return e ? await T(this.fetch, "GET", `${this.url}/user`, {
        headers: this.headers,
        jwt: e,
        xform: ie
      }) : await this._useSession(async (t) => {
        var s, n, i;
        const { data: a, error: o } = t;
        if (o)
          throw o;
        return !(!((s = a.session) === null || s === void 0) && s.access_token) && !this.hasCustomAuthorizationHeader ? { data: { user: null }, error: new K() } : await T(this.fetch, "GET", `${this.url}/user`, {
          headers: this.headers,
          jwt: (i = (n = a.session) === null || n === void 0 ? void 0 : n.access_token) !== null && i !== void 0 ? i : void 0,
          xform: ie
        });
      });
    } catch (t) {
      if (w(t))
        return gt(t) && (await this._removeSession(), await L(this.storage, `${this.storageKey}-code-verifier`)), this._returnResult({ data: { user: null }, error: t });
      throw t;
    }
  }
  /**
   * Updates user data for a logged in user.
   */
  async updateUser(e, t = {}) {
    return await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => await this._updateUser(e, t));
  }
  async _updateUser(e, t = {}) {
    try {
      return await this._useSession(async (s) => {
        const { data: n, error: i } = s;
        if (i)
          throw i;
        if (!n.session)
          throw new K();
        const a = n.session;
        let o = null, c = null;
        this.flowType === "pkce" && e.email != null && ([o, c] = await be(this.storage, this.storageKey));
        const { data: l, error: u } = await T(this.fetch, "PUT", `${this.url}/user`, {
          headers: this.headers,
          redirectTo: t == null ? void 0 : t.emailRedirectTo,
          body: Object.assign(Object.assign({}, e), { code_challenge: o, code_challenge_method: c }),
          jwt: a.access_token,
          xform: ie
        });
        if (u)
          throw u;
        return a.user = l.user, await this._saveSession(a), await this._notifyAllSubscribers("USER_UPDATED", a), this._returnResult({ data: { user: a.user }, error: null });
      });
    } catch (s) {
      if (await L(this.storage, `${this.storageKey}-code-verifier`), w(s))
        return this._returnResult({ data: { user: null }, error: s });
      throw s;
    }
  }
  /**
   * Sets the session data from the current session. If the current session is expired, setSession will take care of refreshing it to obtain a new session.
   * If the refresh token or access token in the current session is invalid, an error will be thrown.
   * @param currentSession The current session that minimally contains an access token and refresh token.
   */
  async setSession(e) {
    return await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => await this._setSession(e));
  }
  async _setSession(e) {
    try {
      if (!e.access_token || !e.refresh_token)
        throw new K();
      const t = Date.now() / 1e3;
      let s = t, n = !0, i = null;
      const { payload: a } = Xe(e.access_token);
      if (a.exp && (s = a.exp, n = s <= t), n) {
        const { data: o, error: c } = await this._callRefreshToken(e.refresh_token);
        if (c)
          return this._returnResult({ data: { user: null, session: null }, error: c });
        if (!o)
          return { data: { user: null, session: null }, error: null };
        i = o;
      } else {
        const { data: o, error: c } = await this._getUser(e.access_token);
        if (c)
          return this._returnResult({ data: { user: null, session: null }, error: c });
        i = {
          access_token: e.access_token,
          refresh_token: e.refresh_token,
          user: o.user,
          token_type: "bearer",
          expires_in: s - t,
          expires_at: s
        }, await this._saveSession(i), await this._notifyAllSubscribers("SIGNED_IN", i);
      }
      return this._returnResult({ data: { user: i.user, session: i }, error: null });
    } catch (t) {
      if (w(t))
        return this._returnResult({ data: { session: null, user: null }, error: t });
      throw t;
    }
  }
  /**
   * Returns a new session, regardless of expiry status.
   * Takes in an optional current session. If not passed in, then refreshSession() will attempt to retrieve it from getSession().
   * If the current session's refresh token is invalid, an error will be thrown.
   * @param currentSession The current session. If passed in, it must contain a refresh token.
   */
  async refreshSession(e) {
    return await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => await this._refreshSession(e));
  }
  async _refreshSession(e) {
    try {
      return await this._useSession(async (t) => {
        var s;
        if (!e) {
          const { data: a, error: o } = t;
          if (o)
            throw o;
          e = (s = a.session) !== null && s !== void 0 ? s : void 0;
        }
        if (!(e != null && e.refresh_token))
          throw new K();
        const { data: n, error: i } = await this._callRefreshToken(e.refresh_token);
        return i ? this._returnResult({ data: { user: null, session: null }, error: i }) : n ? this._returnResult({ data: { user: n.user, session: n }, error: null }) : this._returnResult({ data: { user: null, session: null }, error: null });
      });
    } catch (t) {
      if (w(t))
        return this._returnResult({ data: { user: null, session: null }, error: t });
      throw t;
    }
  }
  /**
   * Gets the session data from a URL string
   */
  async _getSessionFromURL(e, t) {
    try {
      if (!D())
        throw new Ye("No browser detected.");
      if (e.error || e.error_description || e.error_code)
        throw new Ye(e.error_description || "Error in URL with unspecified error_description", {
          error: e.error || "unspecified_error",
          code: e.error_code || "unspecified_code"
        });
      switch (t) {
        case "implicit":
          if (this.flowType === "pkce")
            throw new dr("Not a valid PKCE flow url.");
          break;
        case "pkce":
          if (this.flowType === "implicit")
            throw new Ye("Not a valid implicit grant flow url.");
          break;
        default:
      }
      if (t === "pkce") {
        if (this._debug("#_initialize()", "begin", "is PKCE flow", !0), !e.code)
          throw new dr("No code detected.");
        const { data: v, error: _ } = await this._exchangeCodeForSession(e.code);
        if (_)
          throw _;
        const E = new URL(window.location.href);
        return E.searchParams.delete("code"), window.history.replaceState(window.history.state, "", E.toString()), { data: { session: v.session, redirectType: null }, error: null };
      }
      const { provider_token: s, provider_refresh_token: n, access_token: i, refresh_token: a, expires_in: o, expires_at: c, token_type: l } = e;
      if (!i || !o || !a || !l)
        throw new Ye("No session defined in URL");
      const u = Math.round(Date.now() / 1e3), d = parseInt(o);
      let h = u + d;
      c && (h = parseInt(c));
      const f = h - u;
      f * 1e3 <= ke && console.warn(`@supabase/gotrue-js: Session as retrieved from URL expires in ${f}s, should have been closer to ${d}s`);
      const p = h - d;
      u - p >= 120 ? console.warn("@supabase/gotrue-js: Session as retrieved from URL was issued over 120s ago, URL could be stale", p, h, u) : u - p < 0 && console.warn("@supabase/gotrue-js: Session as retrieved from URL was issued in the future? Check the device clock for skew", p, h, u);
      const { data: g, error: m } = await this._getUser(i);
      if (m)
        throw m;
      const y = {
        provider_token: s,
        provider_refresh_token: n,
        access_token: i,
        expires_in: d,
        expires_at: h,
        refresh_token: a,
        token_type: l,
        user: g.user
      };
      return window.location.hash = "", this._debug("#_getSessionFromURL()", "clearing window.location.hash"), this._returnResult({ data: { session: y, redirectType: e.type }, error: null });
    } catch (s) {
      if (w(s))
        return this._returnResult({ data: { session: null, redirectType: null }, error: s });
      throw s;
    }
  }
  /**
   * Checks if the current URL contains parameters given by an implicit oauth grant flow (https://www.rfc-editor.org/rfc/rfc6749.html#section-4.2)
   *
   * If `detectSessionInUrl` is a function, it will be called with the URL and params to determine
   * if the URL should be processed as a Supabase auth callback. This allows users to exclude
   * URLs from other OAuth providers (e.g., Facebook Login) that also return access_token in the fragment.
   */
  _isImplicitGrantCallback(e) {
    return typeof this.detectSessionInUrl == "function" ? this.detectSessionInUrl(new URL(window.location.href), e) : !!(e.access_token || e.error_description);
  }
  /**
   * Checks if the current URL and backing storage contain parameters given by a PKCE flow
   */
  async _isPKCECallback(e) {
    const t = await he(this.storage, `${this.storageKey}-code-verifier`);
    return !!(e.code && t);
  }
  /**
   * Inside a browser context, `signOut()` will remove the logged in user from the browser session and log them out - removing all items from localstorage and then trigger a `"SIGNED_OUT"` event.
   *
   * For server-side management, you can revoke all refresh tokens for a user by passing a user's JWT through to `auth.api.signOut(JWT: string)`.
   * There is no way to revoke a user's access token jwt until it expires. It is recommended to set a shorter expiry on the jwt for this reason.
   *
   * If using `others` scope, no `SIGNED_OUT` event is fired!
   */
  async signOut(e = { scope: "global" }) {
    return await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => await this._signOut(e));
  }
  async _signOut({ scope: e } = { scope: "global" }) {
    return await this._useSession(async (t) => {
      var s;
      const { data: n, error: i } = t;
      if (i && !gt(i))
        return this._returnResult({ error: i });
      const a = (s = n.session) === null || s === void 0 ? void 0 : s.access_token;
      if (a) {
        const { error: o } = await this.admin.signOut(a, e);
        if (o && !(Gn(o) && (o.status === 404 || o.status === 401 || o.status === 403) || gt(o)))
          return this._returnResult({ error: o });
      }
      return e !== "others" && (await this._removeSession(), await L(this.storage, `${this.storageKey}-code-verifier`)), this._returnResult({ error: null });
    });
  }
  onAuthStateChange(e) {
    const t = ri(), s = {
      id: t,
      callback: e,
      unsubscribe: () => {
        this._debug("#unsubscribe()", "state change callback with id removed", t), this.stateChangeEmitters.delete(t);
      }
    };
    return this._debug("#onAuthStateChange()", "registered callback with id", t), this.stateChangeEmitters.set(t, s), (async () => (await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => {
      this._emitInitialSession(t);
    })))(), { data: { subscription: s } };
  }
  async _emitInitialSession(e) {
    return await this._useSession(async (t) => {
      var s, n;
      try {
        const { data: { session: i }, error: a } = t;
        if (a)
          throw a;
        await ((s = this.stateChangeEmitters.get(e)) === null || s === void 0 ? void 0 : s.callback("INITIAL_SESSION", i)), this._debug("INITIAL_SESSION", "callback id", e, "session", i);
      } catch (i) {
        await ((n = this.stateChangeEmitters.get(e)) === null || n === void 0 ? void 0 : n.callback("INITIAL_SESSION", null)), this._debug("INITIAL_SESSION", "callback id", e, "error", i), console.error(i);
      }
    });
  }
  /**
   * Sends a password reset request to an email address. This method supports the PKCE flow.
   *
   * @param email The email address of the user.
   * @param options.redirectTo The URL to send the user to after they click the password reset link.
   * @param options.captchaToken Verification token received when the user completes the captcha on the site.
   */
  async resetPasswordForEmail(e, t = {}) {
    let s = null, n = null;
    this.flowType === "pkce" && ([s, n] = await be(
      this.storage,
      this.storageKey,
      !0
      // isPasswordRecovery
    ));
    try {
      return await T(this.fetch, "POST", `${this.url}/recover`, {
        body: {
          email: e,
          code_challenge: s,
          code_challenge_method: n,
          gotrue_meta_security: { captcha_token: t.captchaToken }
        },
        headers: this.headers,
        redirectTo: t.redirectTo
      });
    } catch (i) {
      if (await L(this.storage, `${this.storageKey}-code-verifier`), w(i))
        return this._returnResult({ data: null, error: i });
      throw i;
    }
  }
  /**
   * Gets all the identities linked to a user.
   */
  async getUserIdentities() {
    var e;
    try {
      const { data: t, error: s } = await this.getUser();
      if (s)
        throw s;
      return this._returnResult({ data: { identities: (e = t.user.identities) !== null && e !== void 0 ? e : [] }, error: null });
    } catch (t) {
      if (w(t))
        return this._returnResult({ data: null, error: t });
      throw t;
    }
  }
  async linkIdentity(e) {
    return "token" in e ? this.linkIdentityIdToken(e) : this.linkIdentityOAuth(e);
  }
  async linkIdentityOAuth(e) {
    var t;
    try {
      const { data: s, error: n } = await this._useSession(async (i) => {
        var a, o, c, l, u;
        const { data: d, error: h } = i;
        if (h)
          throw h;
        const f = await this._getUrlForProvider(`${this.url}/user/identities/authorize`, e.provider, {
          redirectTo: (a = e.options) === null || a === void 0 ? void 0 : a.redirectTo,
          scopes: (o = e.options) === null || o === void 0 ? void 0 : o.scopes,
          queryParams: (c = e.options) === null || c === void 0 ? void 0 : c.queryParams,
          skipBrowserRedirect: !0
        });
        return await T(this.fetch, "GET", f, {
          headers: this.headers,
          jwt: (u = (l = d.session) === null || l === void 0 ? void 0 : l.access_token) !== null && u !== void 0 ? u : void 0
        });
      });
      if (n)
        throw n;
      return D() && !(!((t = e.options) === null || t === void 0) && t.skipBrowserRedirect) && window.location.assign(s == null ? void 0 : s.url), this._returnResult({
        data: { provider: e.provider, url: s == null ? void 0 : s.url },
        error: null
      });
    } catch (s) {
      if (w(s))
        return this._returnResult({ data: { provider: e.provider, url: null }, error: s });
      throw s;
    }
  }
  async linkIdentityIdToken(e) {
    return await this._useSession(async (t) => {
      var s;
      try {
        const { error: n, data: { session: i } } = t;
        if (n)
          throw n;
        const { options: a, provider: o, token: c, access_token: l, nonce: u } = e, d = await T(this.fetch, "POST", `${this.url}/token?grant_type=id_token`, {
          headers: this.headers,
          jwt: (s = i == null ? void 0 : i.access_token) !== null && s !== void 0 ? s : void 0,
          body: {
            provider: o,
            id_token: c,
            access_token: l,
            nonce: u,
            link_identity: !0,
            gotrue_meta_security: { captcha_token: a == null ? void 0 : a.captchaToken }
          },
          xform: Y
        }), { data: h, error: f } = d;
        return f ? this._returnResult({ data: { user: null, session: null }, error: f }) : !h || !h.session || !h.user ? this._returnResult({
          data: { user: null, session: null },
          error: new we()
        }) : (h.session && (await this._saveSession(h.session), await this._notifyAllSubscribers("USER_UPDATED", h.session)), this._returnResult({ data: h, error: f }));
      } catch (n) {
        if (await L(this.storage, `${this.storageKey}-code-verifier`), w(n))
          return this._returnResult({ data: { user: null, session: null }, error: n });
        throw n;
      }
    });
  }
  /**
   * Unlinks an identity from a user by deleting it. The user will no longer be able to sign in with that identity once it's unlinked.
   */
  async unlinkIdentity(e) {
    try {
      return await this._useSession(async (t) => {
        var s, n;
        const { data: i, error: a } = t;
        if (a)
          throw a;
        return await T(this.fetch, "DELETE", `${this.url}/user/identities/${e.identity_id}`, {
          headers: this.headers,
          jwt: (n = (s = i.session) === null || s === void 0 ? void 0 : s.access_token) !== null && n !== void 0 ? n : void 0
        });
      });
    } catch (t) {
      if (w(t))
        return this._returnResult({ data: null, error: t });
      throw t;
    }
  }
  /**
   * Generates a new JWT.
   * @param refreshToken A valid refresh token that was returned on login.
   */
  async _refreshAccessToken(e) {
    const t = `#_refreshAccessToken(${e.substring(0, 5)}...)`;
    this._debug(t, "begin");
    try {
      const s = Date.now();
      return await ai(async (n) => (n > 0 && await ii(200 * Math.pow(2, n - 1)), this._debug(t, "refreshing attempt", n), await T(this.fetch, "POST", `${this.url}/token?grant_type=refresh_token`, {
        body: { refresh_token: e },
        headers: this.headers,
        xform: Y
      })), (n, i) => {
        const a = 200 * Math.pow(2, n);
        return i && mt(i) && // retryable only if the request can be sent before the backoff overflows the tick duration
        Date.now() + a - s < ke;
      });
    } catch (s) {
      if (this._debug(t, "error", s), w(s))
        return this._returnResult({ data: { session: null, user: null }, error: s });
      throw s;
    } finally {
      this._debug(t, "end");
    }
  }
  _isValidSession(e) {
    return typeof e == "object" && e !== null && "access_token" in e && "refresh_token" in e && "expires_at" in e;
  }
  async _handleProviderSignIn(e, t) {
    const s = await this._getUrlForProvider(`${this.url}/authorize`, e, {
      redirectTo: t.redirectTo,
      scopes: t.scopes,
      queryParams: t.queryParams
    });
    return this._debug("#_handleProviderSignIn()", "provider", e, "options", t, "url", s), D() && !t.skipBrowserRedirect && window.location.assign(s), { data: { provider: e, url: s }, error: null };
  }
  /**
   * Recovers the session from LocalStorage and refreshes the token
   * Note: this method is async to accommodate for AsyncStorage e.g. in React native.
   */
  async _recoverAndRefresh() {
    var e, t;
    const s = "#_recoverAndRefresh()";
    this._debug(s, "begin");
    try {
      const n = await he(this.storage, this.storageKey);
      if (n && this.userStorage) {
        let a = await he(this.userStorage, this.storageKey + "-user");
        !this.storage.isServer && Object.is(this.storage, this.userStorage) && !a && (a = { user: n.user }, await Oe(this.userStorage, this.storageKey + "-user", a)), n.user = (e = a == null ? void 0 : a.user) !== null && e !== void 0 ? e : yt();
      } else if (n && !n.user && !n.user) {
        const a = await he(this.storage, this.storageKey + "-user");
        a && (a != null && a.user) ? (n.user = a.user, await L(this.storage, this.storageKey + "-user"), await Oe(this.storage, this.storageKey, n)) : n.user = yt();
      }
      if (this._debug(s, "session from storage", n), !this._isValidSession(n)) {
        this._debug(s, "session is not valid"), n !== null && await this._removeSession();
        return;
      }
      const i = ((t = n.expires_at) !== null && t !== void 0 ? t : 1 / 0) * 1e3 - Date.now() < pt;
      if (this._debug(s, `session has${i ? "" : " not"} expired with margin of ${pt}s`), i) {
        if (this.autoRefreshToken && n.refresh_token) {
          const { error: a } = await this._callRefreshToken(n.refresh_token);
          a && (console.error(a), mt(a) || (this._debug(s, "refresh failed with a non-retryable error, removing the session", a), await this._removeSession()));
        }
      } else if (n.user && n.user.__isUserNotAvailableProxy === !0)
        try {
          const { data: a, error: o } = await this._getUser(n.access_token);
          !o && (a != null && a.user) ? (n.user = a.user, await this._saveSession(n), await this._notifyAllSubscribers("SIGNED_IN", n)) : this._debug(s, "could not get user data, skipping SIGNED_IN notification");
        } catch (a) {
          console.error("Error getting user data:", a), this._debug(s, "error getting user data, skipping SIGNED_IN notification", a);
        }
      else
        await this._notifyAllSubscribers("SIGNED_IN", n);
    } catch (n) {
      this._debug(s, "error", n), console.error(n);
      return;
    } finally {
      this._debug(s, "end");
    }
  }
  async _callRefreshToken(e) {
    var t, s;
    if (!e)
      throw new K();
    if (this.refreshingDeferred)
      return this.refreshingDeferred.promise;
    const n = `#_callRefreshToken(${e.substring(0, 5)}...)`;
    this._debug(n, "begin");
    try {
      this.refreshingDeferred = new ct();
      const { data: i, error: a } = await this._refreshAccessToken(e);
      if (a)
        throw a;
      if (!i.session)
        throw new K();
      await this._saveSession(i.session), await this._notifyAllSubscribers("TOKEN_REFRESHED", i.session);
      const o = { data: i.session, error: null };
      return this.refreshingDeferred.resolve(o), o;
    } catch (i) {
      if (this._debug(n, "error", i), w(i)) {
        const a = { data: null, error: i };
        return mt(i) || await this._removeSession(), (t = this.refreshingDeferred) === null || t === void 0 || t.resolve(a), a;
      }
      throw (s = this.refreshingDeferred) === null || s === void 0 || s.reject(i), i;
    } finally {
      this.refreshingDeferred = null, this._debug(n, "end");
    }
  }
  async _notifyAllSubscribers(e, t, s = !0) {
    const n = `#_notifyAllSubscribers(${e})`;
    this._debug(n, "begin", t, `broadcast = ${s}`);
    try {
      this.broadcastChannel && s && this.broadcastChannel.postMessage({ event: e, session: t });
      const i = [], a = Array.from(this.stateChangeEmitters.values()).map(async (o) => {
        try {
          await o.callback(e, t);
        } catch (c) {
          i.push(c);
        }
      });
      if (await Promise.all(a), i.length > 0) {
        for (let o = 0; o < i.length; o += 1)
          console.error(i[o]);
        throw i[0];
      }
    } finally {
      this._debug(n, "end");
    }
  }
  /**
   * set currentSession and currentUser
   * process to _startAutoRefreshToken if possible
   */
  async _saveSession(e) {
    this._debug("#_saveSession()", e), this.suppressGetSessionWarning = !0, await L(this.storage, `${this.storageKey}-code-verifier`);
    const t = Object.assign({}, e), s = t.user && t.user.__isUserNotAvailableProxy === !0;
    if (this.userStorage) {
      !s && t.user && await Oe(this.userStorage, this.storageKey + "-user", {
        user: t.user
      });
      const n = Object.assign({}, t);
      delete n.user;
      const i = yr(n);
      await Oe(this.storage, this.storageKey, i);
    } else {
      const n = yr(t);
      await Oe(this.storage, this.storageKey, n);
    }
  }
  async _removeSession() {
    this._debug("#_removeSession()"), this.suppressGetSessionWarning = !1, await L(this.storage, this.storageKey), await L(this.storage, this.storageKey + "-code-verifier"), await L(this.storage, this.storageKey + "-user"), this.userStorage && await L(this.userStorage, this.storageKey + "-user"), await this._notifyAllSubscribers("SIGNED_OUT", null);
  }
  /**
   * Removes any registered visibilitychange callback.
   *
   * {@see #startAutoRefresh}
   * {@see #stopAutoRefresh}
   */
  _removeVisibilityChangedCallback() {
    this._debug("#_removeVisibilityChangedCallback()");
    const e = this.visibilityChangedCallback;
    this.visibilityChangedCallback = null;
    try {
      e && D() && (window != null && window.removeEventListener) && window.removeEventListener("visibilitychange", e);
    } catch (t) {
      console.error("removing visibilitychange callback failed", t);
    }
  }
  /**
   * This is the private implementation of {@link #startAutoRefresh}. Use this
   * within the library.
   */
  async _startAutoRefresh() {
    await this._stopAutoRefresh(), this._debug("#_startAutoRefresh()");
    const e = setInterval(() => this._autoRefreshTokenTick(), ke);
    this.autoRefreshTicker = e, e && typeof e == "object" && typeof e.unref == "function" ? e.unref() : typeof Deno < "u" && typeof Deno.unrefTimer == "function" && Deno.unrefTimer(e);
    const t = setTimeout(async () => {
      await this.initializePromise, await this._autoRefreshTokenTick();
    }, 0);
    this.autoRefreshTickTimeout = t, t && typeof t == "object" && typeof t.unref == "function" ? t.unref() : typeof Deno < "u" && typeof Deno.unrefTimer == "function" && Deno.unrefTimer(t);
  }
  /**
   * This is the private implementation of {@link #stopAutoRefresh}. Use this
   * within the library.
   */
  async _stopAutoRefresh() {
    this._debug("#_stopAutoRefresh()");
    const e = this.autoRefreshTicker;
    this.autoRefreshTicker = null, e && clearInterval(e);
    const t = this.autoRefreshTickTimeout;
    this.autoRefreshTickTimeout = null, t && clearTimeout(t);
  }
  /**
   * Starts an auto-refresh process in the background. The session is checked
   * every few seconds. Close to the time of expiration a process is started to
   * refresh the session. If refreshing fails it will be retried for as long as
   * necessary.
   *
   * If you set the {@link GoTrueClientOptions#autoRefreshToken} you don't need
   * to call this function, it will be called for you.
   *
   * On browsers the refresh process works only when the tab/window is in the
   * foreground to conserve resources as well as prevent race conditions and
   * flooding auth with requests. If you call this method any managed
   * visibility change callback will be removed and you must manage visibility
   * changes on your own.
   *
   * On non-browser platforms the refresh process works *continuously* in the
   * background, which may not be desirable. You should hook into your
   * platform's foreground indication mechanism and call these methods
   * appropriately to conserve resources.
   *
   * {@see #stopAutoRefresh}
   */
  async startAutoRefresh() {
    this._removeVisibilityChangedCallback(), await this._startAutoRefresh();
  }
  /**
   * Stops an active auto refresh process running in the background (if any).
   *
   * If you call this method any managed visibility change callback will be
   * removed and you must manage visibility changes on your own.
   *
   * See {@link #startAutoRefresh} for more details.
   */
  async stopAutoRefresh() {
    this._removeVisibilityChangedCallback(), await this._stopAutoRefresh();
  }
  /**
   * Runs the auto refresh token tick.
   */
  async _autoRefreshTokenTick() {
    this._debug("#_autoRefreshTokenTick()", "begin");
    try {
      await this._acquireLock(0, async () => {
        try {
          const e = Date.now();
          try {
            return await this._useSession(async (t) => {
              const { data: { session: s } } = t;
              if (!s || !s.refresh_token || !s.expires_at) {
                this._debug("#_autoRefreshTokenTick()", "no session");
                return;
              }
              const n = Math.floor((s.expires_at * 1e3 - e) / ke);
              this._debug("#_autoRefreshTokenTick()", `access token expires in ${n} ticks, a tick lasts ${ke}ms, refresh threshold is ${Ot} ticks`), n <= Ot && await this._callRefreshToken(s.refresh_token);
            });
          } catch (t) {
            console.error("Auto refresh tick failed with error. This is likely a transient error.", t);
          }
        } finally {
          this._debug("#_autoRefreshTokenTick()", "end");
        }
      });
    } catch (e) {
      if (e.isAcquireTimeout || e instanceof cs)
        this._debug("auto refresh token tick lock not available");
      else
        throw e;
    }
  }
  /**
   * Registers callbacks on the browser / platform, which in-turn run
   * algorithms when the browser window/tab are in foreground. On non-browser
   * platforms it assumes always foreground.
   */
  async _handleVisibilityChange() {
    if (this._debug("#_handleVisibilityChange()"), !D() || !(window != null && window.addEventListener))
      return this.autoRefreshToken && this.startAutoRefresh(), !1;
    try {
      this.visibilityChangedCallback = async () => {
        try {
          await this._onVisibilityChanged(!1);
        } catch (e) {
          this._debug("#visibilityChangedCallback", "error", e);
        }
      }, window == null || window.addEventListener("visibilitychange", this.visibilityChangedCallback), await this._onVisibilityChanged(!0);
    } catch (e) {
      console.error("_handleVisibilityChange", e);
    }
  }
  /**
   * Callback registered with `window.addEventListener('visibilitychange')`.
   */
  async _onVisibilityChanged(e) {
    const t = `#_onVisibilityChanged(${e})`;
    this._debug(t, "visibilityState", document.visibilityState), document.visibilityState === "visible" ? (this.autoRefreshToken && this._startAutoRefresh(), e || (await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => {
      if (document.visibilityState !== "visible") {
        this._debug(t, "acquired the lock to recover the session, but the browser visibilityState is no longer visible, aborting");
        return;
      }
      await this._recoverAndRefresh();
    }))) : document.visibilityState === "hidden" && this.autoRefreshToken && this._stopAutoRefresh();
  }
  /**
   * Generates the relevant login URL for a third-party provider.
   * @param options.redirectTo A URL or mobile address to send the user to after they are confirmed.
   * @param options.scopes A space-separated list of scopes granted to the OAuth application.
   * @param options.queryParams An object of key-value pairs containing query parameters granted to the OAuth application.
   */
  async _getUrlForProvider(e, t, s) {
    const n = [`provider=${encodeURIComponent(t)}`];
    if (s != null && s.redirectTo && n.push(`redirect_to=${encodeURIComponent(s.redirectTo)}`), s != null && s.scopes && n.push(`scopes=${encodeURIComponent(s.scopes)}`), this.flowType === "pkce") {
      const [i, a] = await be(this.storage, this.storageKey), o = new URLSearchParams({
        code_challenge: `${encodeURIComponent(i)}`,
        code_challenge_method: `${encodeURIComponent(a)}`
      });
      n.push(o.toString());
    }
    if (s != null && s.queryParams) {
      const i = new URLSearchParams(s.queryParams);
      n.push(i.toString());
    }
    return s != null && s.skipBrowserRedirect && n.push(`skip_http_redirect=${s.skipBrowserRedirect}`), `${e}?${n.join("&")}`;
  }
  async _unenroll(e) {
    try {
      return await this._useSession(async (t) => {
        var s;
        const { data: n, error: i } = t;
        return i ? this._returnResult({ data: null, error: i }) : await T(this.fetch, "DELETE", `${this.url}/factors/${e.factorId}`, {
          headers: this.headers,
          jwt: (s = n == null ? void 0 : n.session) === null || s === void 0 ? void 0 : s.access_token
        });
      });
    } catch (t) {
      if (w(t))
        return this._returnResult({ data: null, error: t });
      throw t;
    }
  }
  async _enroll(e) {
    try {
      return await this._useSession(async (t) => {
        var s, n;
        const { data: i, error: a } = t;
        if (a)
          return this._returnResult({ data: null, error: a });
        const o = Object.assign({ friendly_name: e.friendlyName, factor_type: e.factorType }, e.factorType === "phone" ? { phone: e.phone } : e.factorType === "totp" ? { issuer: e.issuer } : {}), { data: c, error: l } = await T(this.fetch, "POST", `${this.url}/factors`, {
          body: o,
          headers: this.headers,
          jwt: (s = i == null ? void 0 : i.session) === null || s === void 0 ? void 0 : s.access_token
        });
        return l ? this._returnResult({ data: null, error: l }) : (e.factorType === "totp" && c.type === "totp" && (!((n = c == null ? void 0 : c.totp) === null || n === void 0) && n.qr_code) && (c.totp.qr_code = `data:image/svg+xml;utf-8,${c.totp.qr_code}`), this._returnResult({ data: c, error: null }));
      });
    } catch (t) {
      if (w(t))
        return this._returnResult({ data: null, error: t });
      throw t;
    }
  }
  async _verify(e) {
    return this._acquireLock(this.lockAcquireTimeout, async () => {
      try {
        return await this._useSession(async (t) => {
          var s;
          const { data: n, error: i } = t;
          if (i)
            return this._returnResult({ data: null, error: i });
          const a = Object.assign({ challenge_id: e.challengeId }, "webauthn" in e ? {
            webauthn: Object.assign(Object.assign({}, e.webauthn), { credential_response: e.webauthn.type === "create" ? Ui(e.webauthn.credential_response) : Li(e.webauthn.credential_response) })
          } : { code: e.code }), { data: o, error: c } = await T(this.fetch, "POST", `${this.url}/factors/${e.factorId}/verify`, {
            body: a,
            headers: this.headers,
            jwt: (s = n == null ? void 0 : n.session) === null || s === void 0 ? void 0 : s.access_token
          });
          return c ? this._returnResult({ data: null, error: c }) : (await this._saveSession(Object.assign({ expires_at: Math.round(Date.now() / 1e3) + o.expires_in }, o)), await this._notifyAllSubscribers("MFA_CHALLENGE_VERIFIED", o), this._returnResult({ data: o, error: c }));
        });
      } catch (t) {
        if (w(t))
          return this._returnResult({ data: null, error: t });
        throw t;
      }
    });
  }
  async _challenge(e) {
    return this._acquireLock(this.lockAcquireTimeout, async () => {
      try {
        return await this._useSession(async (t) => {
          var s;
          const { data: n, error: i } = t;
          if (i)
            return this._returnResult({ data: null, error: i });
          const a = await T(this.fetch, "POST", `${this.url}/factors/${e.factorId}/challenge`, {
            body: e,
            headers: this.headers,
            jwt: (s = n == null ? void 0 : n.session) === null || s === void 0 ? void 0 : s.access_token
          });
          if (a.error)
            return a;
          const { data: o } = a;
          if (o.type !== "webauthn")
            return { data: o, error: null };
          switch (o.webauthn.type) {
            case "create":
              return {
                data: Object.assign(Object.assign({}, o), { webauthn: Object.assign(Object.assign({}, o.webauthn), { credential_options: Object.assign(Object.assign({}, o.webauthn.credential_options), { publicKey: Ni(o.webauthn.credential_options.publicKey) }) }) }),
                error: null
              };
            case "request":
              return {
                data: Object.assign(Object.assign({}, o), { webauthn: Object.assign(Object.assign({}, o.webauthn), { credential_options: Object.assign(Object.assign({}, o.webauthn.credential_options), { publicKey: ji(o.webauthn.credential_options.publicKey) }) }) }),
                error: null
              };
          }
        });
      } catch (t) {
        if (w(t))
          return this._returnResult({ data: null, error: t });
        throw t;
      }
    });
  }
  /**
   * {@see GoTrueMFAApi#challengeAndVerify}
   */
  async _challengeAndVerify(e) {
    const { data: t, error: s } = await this._challenge({
      factorId: e.factorId
    });
    return s ? this._returnResult({ data: null, error: s }) : await this._verify({
      factorId: e.factorId,
      challengeId: t.id,
      code: e.code
    });
  }
  /**
   * {@see GoTrueMFAApi#listFactors}
   */
  async _listFactors() {
    var e;
    const { data: { user: t }, error: s } = await this.getUser();
    if (s)
      return { data: null, error: s };
    const n = {
      all: [],
      phone: [],
      totp: [],
      webauthn: []
    };
    for (const i of (e = t == null ? void 0 : t.factors) !== null && e !== void 0 ? e : [])
      n.all.push(i), i.status === "verified" && n[i.factor_type].push(i);
    return {
      data: n,
      error: null
    };
  }
  /**
   * {@see GoTrueMFAApi#getAuthenticatorAssuranceLevel}
   */
  async _getAuthenticatorAssuranceLevel(e) {
    var t, s, n, i;
    if (e)
      try {
        const { payload: f } = Xe(e);
        let p = null;
        f.aal && (p = f.aal);
        let g = p;
        const { data: { user: m }, error: y } = await this.getUser(e);
        if (y)
          return this._returnResult({ data: null, error: y });
        ((s = (t = m == null ? void 0 : m.factors) === null || t === void 0 ? void 0 : t.filter((E) => E.status === "verified")) !== null && s !== void 0 ? s : []).length > 0 && (g = "aal2");
        const _ = f.amr || [];
        return { data: { currentLevel: p, nextLevel: g, currentAuthenticationMethods: _ }, error: null };
      } catch (f) {
        if (w(f))
          return this._returnResult({ data: null, error: f });
        throw f;
      }
    const { data: { session: a }, error: o } = await this.getSession();
    if (o)
      return this._returnResult({ data: null, error: o });
    if (!a)
      return {
        data: { currentLevel: null, nextLevel: null, currentAuthenticationMethods: [] },
        error: null
      };
    const { payload: c } = Xe(a.access_token);
    let l = null;
    c.aal && (l = c.aal);
    let u = l;
    ((i = (n = a.user.factors) === null || n === void 0 ? void 0 : n.filter((f) => f.status === "verified")) !== null && i !== void 0 ? i : []).length > 0 && (u = "aal2");
    const h = c.amr || [];
    return { data: { currentLevel: l, nextLevel: u, currentAuthenticationMethods: h }, error: null };
  }
  /**
   * Retrieves details about an OAuth authorization request.
   * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
   *
   * Returns authorization details including client info, scopes, and user information.
   * If the API returns a redirect_uri, it means consent was already given - the caller
   * should handle the redirect manually if needed.
   */
  async _getAuthorizationDetails(e) {
    try {
      return await this._useSession(async (t) => {
        const { data: { session: s }, error: n } = t;
        return n ? this._returnResult({ data: null, error: n }) : s ? await T(this.fetch, "GET", `${this.url}/oauth/authorizations/${e}`, {
          headers: this.headers,
          jwt: s.access_token,
          xform: (i) => ({ data: i, error: null })
        }) : this._returnResult({ data: null, error: new K() });
      });
    } catch (t) {
      if (w(t))
        return this._returnResult({ data: null, error: t });
      throw t;
    }
  }
  /**
   * Approves an OAuth authorization request.
   * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
   */
  async _approveAuthorization(e, t) {
    try {
      return await this._useSession(async (s) => {
        const { data: { session: n }, error: i } = s;
        if (i)
          return this._returnResult({ data: null, error: i });
        if (!n)
          return this._returnResult({ data: null, error: new K() });
        const a = await T(this.fetch, "POST", `${this.url}/oauth/authorizations/${e}/consent`, {
          headers: this.headers,
          jwt: n.access_token,
          body: { action: "approve" },
          xform: (o) => ({ data: o, error: null })
        });
        return a.data && a.data.redirect_url && D() && !(t != null && t.skipBrowserRedirect) && window.location.assign(a.data.redirect_url), a;
      });
    } catch (s) {
      if (w(s))
        return this._returnResult({ data: null, error: s });
      throw s;
    }
  }
  /**
   * Denies an OAuth authorization request.
   * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
   */
  async _denyAuthorization(e, t) {
    try {
      return await this._useSession(async (s) => {
        const { data: { session: n }, error: i } = s;
        if (i)
          return this._returnResult({ data: null, error: i });
        if (!n)
          return this._returnResult({ data: null, error: new K() });
        const a = await T(this.fetch, "POST", `${this.url}/oauth/authorizations/${e}/consent`, {
          headers: this.headers,
          jwt: n.access_token,
          body: { action: "deny" },
          xform: (o) => ({ data: o, error: null })
        });
        return a.data && a.data.redirect_url && D() && !(t != null && t.skipBrowserRedirect) && window.location.assign(a.data.redirect_url), a;
      });
    } catch (s) {
      if (w(s))
        return this._returnResult({ data: null, error: s });
      throw s;
    }
  }
  /**
   * Lists all OAuth grants that the authenticated user has authorized.
   * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
   */
  async _listOAuthGrants() {
    try {
      return await this._useSession(async (e) => {
        const { data: { session: t }, error: s } = e;
        return s ? this._returnResult({ data: null, error: s }) : t ? await T(this.fetch, "GET", `${this.url}/user/oauth/grants`, {
          headers: this.headers,
          jwt: t.access_token,
          xform: (n) => ({ data: n, error: null })
        }) : this._returnResult({ data: null, error: new K() });
      });
    } catch (e) {
      if (w(e))
        return this._returnResult({ data: null, error: e });
      throw e;
    }
  }
  /**
   * Revokes a user's OAuth grant for a specific client.
   * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
   */
  async _revokeOAuthGrant(e) {
    try {
      return await this._useSession(async (t) => {
        const { data: { session: s }, error: n } = t;
        return n ? this._returnResult({ data: null, error: n }) : s ? (await T(this.fetch, "DELETE", `${this.url}/user/oauth/grants`, {
          headers: this.headers,
          jwt: s.access_token,
          query: { client_id: e.clientId },
          noResolveJson: !0
        }), { data: {}, error: null }) : this._returnResult({ data: null, error: new K() });
      });
    } catch (t) {
      if (w(t))
        return this._returnResult({ data: null, error: t });
      throw t;
    }
  }
  async fetchJwk(e, t = { keys: [] }) {
    let s = t.keys.find((o) => o.kid === e);
    if (s)
      return s;
    const n = Date.now();
    if (s = this.jwks.keys.find((o) => o.kid === e), s && this.jwks_cached_at + Kn > n)
      return s;
    const { data: i, error: a } = await T(this.fetch, "GET", `${this.url}/.well-known/jwks.json`, {
      headers: this.headers
    });
    if (a)
      throw a;
    return !i.keys || i.keys.length === 0 || (this.jwks = i, this.jwks_cached_at = n, s = i.keys.find((o) => o.kid === e), !s) ? null : s;
  }
  /**
   * Extracts the JWT claims present in the access token by first verifying the
   * JWT against the server's JSON Web Key Set endpoint
   * `/.well-known/jwks.json` which is often cached, resulting in significantly
   * faster responses. Prefer this method over {@link #getUser} which always
   * sends a request to the Auth server for each JWT.
   *
   * If the project is not using an asymmetric JWT signing key (like ECC or
   * RSA) it always sends a request to the Auth server (similar to {@link
   * #getUser}) to verify the JWT.
   *
   * @param jwt An optional specific JWT you wish to verify, not the one you
   *            can obtain from {@link #getSession}.
   * @param options Various additional options that allow you to customize the
   *                behavior of this method.
   */
  async getClaims(e, t = {}) {
    try {
      let s = e;
      if (!s) {
        const { data: f, error: p } = await this.getSession();
        if (p || !f.session)
          return this._returnResult({ data: null, error: p });
        s = f.session.access_token;
      }
      const { header: n, payload: i, signature: a, raw: { header: o, payload: c } } = Xe(s);
      t != null && t.allowExpired || fi(i.exp);
      const l = !n.alg || n.alg.startsWith("HS") || !n.kid || !("crypto" in globalThis && "subtle" in globalThis.crypto) ? null : await this.fetchJwk(n.kid, t != null && t.keys ? { keys: t.keys } : t == null ? void 0 : t.jwks);
      if (!l) {
        const { error: f } = await this.getUser(s);
        if (f)
          throw f;
        return {
          data: {
            claims: i,
            header: n,
            signature: a
          },
          error: null
        };
      }
      const u = pi(n.alg), d = await crypto.subtle.importKey("jwk", l, u, !0, [
        "verify"
      ]);
      if (!await crypto.subtle.verify(u, d, a, ei(`${o}.${c}`)))
        throw new It("Invalid JWT signature");
      return {
        data: {
          claims: i,
          header: n,
          signature: a
        },
        error: null
      };
    } catch (s) {
      if (w(s))
        return this._returnResult({ data: null, error: s });
      throw s;
    }
  }
}
Fe.nextInstanceID = {};
const zi = Fe, Gi = "2.93.3";
let Ne = "";
typeof Deno < "u" ? Ne = "deno" : typeof document < "u" ? Ne = "web" : typeof navigator < "u" && navigator.product === "ReactNative" ? Ne = "react-native" : Ne = "node";
const Wi = { "X-Client-Info": `supabase-js-${Ne}/${Gi}` }, Ji = { headers: Wi }, Yi = { schema: "public" }, Xi = {
  autoRefreshToken: !0,
  persistSession: !0,
  detectSessionInUrl: !0,
  flowType: "implicit"
}, Qi = {};
function He(r) {
  "@babel/helpers - typeof";
  return He = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
    return typeof e;
  } : function(e) {
    return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
  }, He(r);
}
function Zi(r, e) {
  if (He(r) != "object" || !r) return r;
  var t = r[Symbol.toPrimitive];
  if (t !== void 0) {
    var s = t.call(r, e);
    if (He(s) != "object") return s;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (e === "string" ? String : Number)(r);
}
function ea(r) {
  var e = Zi(r, "string");
  return He(e) == "symbol" ? e : e + "";
}
function ta(r, e, t) {
  return (e = ea(e)) in r ? Object.defineProperty(r, e, {
    value: t,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : r[e] = t, r;
}
function Tr(r, e) {
  var t = Object.keys(r);
  if (Object.getOwnPropertySymbols) {
    var s = Object.getOwnPropertySymbols(r);
    e && (s = s.filter(function(n) {
      return Object.getOwnPropertyDescriptor(r, n).enumerable;
    })), t.push.apply(t, s);
  }
  return t;
}
function N(r) {
  for (var e = 1; e < arguments.length; e++) {
    var t = arguments[e] != null ? arguments[e] : {};
    e % 2 ? Tr(Object(t), !0).forEach(function(s) {
      ta(r, s, t[s]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(t)) : Tr(Object(t)).forEach(function(s) {
      Object.defineProperty(r, s, Object.getOwnPropertyDescriptor(t, s));
    });
  }
  return r;
}
const ra = (r) => r ? (...e) => r(...e) : (...e) => fetch(...e), sa = () => Headers, na = (r, e, t) => {
  const s = ra(t), n = sa();
  return async (i, a) => {
    var o;
    const c = (o = await e()) !== null && o !== void 0 ? o : r;
    let l = new n(a == null ? void 0 : a.headers);
    return l.has("apikey") || l.set("apikey", r), l.has("Authorization") || l.set("Authorization", `Bearer ${c}`), s(i, N(N({}, a), {}, { headers: l }));
  };
};
function ia(r) {
  return r.endsWith("/") ? r : r + "/";
}
function aa(r, e) {
  var t, s;
  const { db: n, auth: i, realtime: a, global: o } = r, { db: c, auth: l, realtime: u, global: d } = e, h = {
    db: N(N({}, c), n),
    auth: N(N({}, l), i),
    realtime: N(N({}, u), a),
    storage: {},
    global: N(N(N({}, d), o), {}, { headers: N(N({}, (t = d == null ? void 0 : d.headers) !== null && t !== void 0 ? t : {}), (s = o == null ? void 0 : o.headers) !== null && s !== void 0 ? s : {}) }),
    accessToken: async () => ""
  };
  return r.accessToken ? h.accessToken = r.accessToken : delete h.accessToken, h;
}
function oa(r) {
  const e = r == null ? void 0 : r.trim();
  if (!e) throw new Error("supabaseUrl is required.");
  if (!e.match(/^https?:\/\//i)) throw new Error("Invalid supabaseUrl: Must be a valid HTTP or HTTPS URL.");
  try {
    return new URL(ia(e));
  } catch {
    throw Error("Invalid supabaseUrl: Provided URL is malformed.");
  }
}
var ca = class extends zi {
  constructor(r) {
    super(r);
  }
}, la = class {
  /**
  * Create a new client for use in the browser.
  * @param supabaseUrl The unique Supabase URL which is supplied when you create a new project in your project dashboard.
  * @param supabaseKey The unique Supabase Key which is supplied when you create a new project in your project dashboard.
  * @param options.db.schema You can switch in between schemas. The schema needs to be on the list of exposed schemas inside Supabase.
  * @param options.auth.autoRefreshToken Set to "true" if you want to automatically refresh the token before expiring.
  * @param options.auth.persistSession Set to "true" if you want to automatically save the user session into local storage.
  * @param options.auth.detectSessionInUrl Set to "true" if you want to automatically detects OAuth grants in the URL and signs in the user.
  * @param options.realtime Options passed along to realtime-js constructor.
  * @param options.storage Options passed along to the storage-js constructor.
  * @param options.global.fetch A custom fetch implementation.
  * @param options.global.headers Any additional headers to send with each network request.
  * @example
  * ```ts
  * import { createClient } from '@supabase/supabase-js'
  *
  * const supabase = createClient('https://xyzcompany.supabase.co', 'public-anon-key')
  * const { data } = await supabase.from('profiles').select('*')
  * ```
  */
  constructor(r, e, t) {
    var s, n;
    this.supabaseUrl = r, this.supabaseKey = e;
    const i = oa(r);
    if (!e) throw new Error("supabaseKey is required.");
    this.realtimeUrl = new URL("realtime/v1", i), this.realtimeUrl.protocol = this.realtimeUrl.protocol.replace("http", "ws"), this.authUrl = new URL("auth/v1", i), this.storageUrl = new URL("storage/v1", i), this.functionsUrl = new URL("functions/v1", i);
    const a = `sb-${i.hostname.split(".")[0]}-auth-token`, o = {
      db: Yi,
      realtime: Qi,
      auth: N(N({}, Xi), {}, { storageKey: a }),
      global: Ji
    }, c = aa(t ?? {}, o);
    if (this.storageKey = (s = c.auth.storageKey) !== null && s !== void 0 ? s : "", this.headers = (n = c.global.headers) !== null && n !== void 0 ? n : {}, c.accessToken)
      this.accessToken = c.accessToken, this.auth = new Proxy({}, { get: (u, d) => {
        throw new Error(`@supabase/supabase-js: Supabase Client is configured with the accessToken option, accessing supabase.auth.${String(d)} is not possible`);
      } });
    else {
      var l;
      this.auth = this._initSupabaseAuthClient((l = c.auth) !== null && l !== void 0 ? l : {}, this.headers, c.global.fetch);
    }
    this.fetch = na(e, this._getAccessToken.bind(this), c.global.fetch), this.realtime = this._initRealtimeClient(N({
      headers: this.headers,
      accessToken: this._getAccessToken.bind(this)
    }, c.realtime)), this.accessToken && Promise.resolve(this.accessToken()).then((u) => this.realtime.setAuth(u)).catch((u) => console.warn("Failed to set initial Realtime auth token:", u)), this.rest = new zs(new URL("rest/v1", i).href, {
      headers: this.headers,
      schema: c.db.schema,
      fetch: this.fetch
    }), this.storage = new Bn(this.storageUrl.href, this.headers, this.fetch, t == null ? void 0 : t.storage), c.accessToken || this._listenForAuthEvents();
  }
  /**
  * Supabase Functions allows you to deploy and invoke edge functions.
  */
  get functions() {
    return new qs(this.functionsUrl.href, {
      headers: this.headers,
      customFetch: this.fetch
    });
  }
  /**
  * Perform a query on a table or a view.
  *
  * @param relation - The table or view name to query
  */
  from(r) {
    return this.rest.from(r);
  }
  /**
  * Select a schema to query or perform an function (rpc) call.
  *
  * The schema needs to be on the list of exposed schemas inside Supabase.
  *
  * @param schema - The schema to query
  */
  schema(r) {
    return this.rest.schema(r);
  }
  /**
  * Perform a function call.
  *
  * @param fn - The function name to call
  * @param args - The arguments to pass to the function call
  * @param options - Named parameters
  * @param options.head - When set to `true`, `data` will not be returned.
  * Useful if you only need the count.
  * @param options.get - When set to `true`, the function will be called with
  * read-only access mode.
  * @param options.count - Count algorithm to use to count rows returned by the
  * function. Only applicable for [set-returning
  * functions](https://www.postgresql.org/docs/current/functions-srf.html).
  *
  * `"exact"`: Exact but slow count algorithm. Performs a `COUNT(*)` under the
  * hood.
  *
  * `"planned"`: Approximated but fast count algorithm. Uses the Postgres
  * statistics under the hood.
  *
  * `"estimated"`: Uses exact count for low numbers and planned count for high
  * numbers.
  */
  rpc(r, e = {}, t = {
    head: !1,
    get: !1,
    count: void 0
  }) {
    return this.rest.rpc(r, e, t);
  }
  /**
  * Creates a Realtime channel with Broadcast, Presence, and Postgres Changes.
  *
  * @param {string} name - The name of the Realtime channel.
  * @param {Object} opts - The options to pass to the Realtime channel.
  *
  */
  channel(r, e = { config: {} }) {
    return this.realtime.channel(r, e);
  }
  /**
  * Returns all Realtime channels.
  */
  getChannels() {
    return this.realtime.getChannels();
  }
  /**
  * Unsubscribes and removes Realtime channel from Realtime client.
  *
  * @param {RealtimeChannel} channel - The name of the Realtime channel.
  *
  */
  removeChannel(r) {
    return this.realtime.removeChannel(r);
  }
  /**
  * Unsubscribes and removes all Realtime channels from Realtime client.
  */
  removeAllChannels() {
    return this.realtime.removeAllChannels();
  }
  async _getAccessToken() {
    var r = this, e, t;
    if (r.accessToken) return await r.accessToken();
    const { data: s } = await r.auth.getSession();
    return (e = (t = s.session) === null || t === void 0 ? void 0 : t.access_token) !== null && e !== void 0 ? e : r.supabaseKey;
  }
  _initSupabaseAuthClient({ autoRefreshToken: r, persistSession: e, detectSessionInUrl: t, storage: s, userStorage: n, storageKey: i, flowType: a, lock: o, debug: c, throwOnError: l }, u, d) {
    const h = {
      Authorization: `Bearer ${this.supabaseKey}`,
      apikey: `${this.supabaseKey}`
    };
    return new ca({
      url: this.authUrl.href,
      headers: N(N({}, h), u),
      storageKey: i,
      autoRefreshToken: r,
      persistSession: e,
      detectSessionInUrl: t,
      storage: s,
      userStorage: n,
      flowType: a,
      lock: o,
      debug: c,
      throwOnError: l,
      fetch: d,
      hasCustomAuthorizationHeader: Object.keys(this.headers).some((f) => f.toLowerCase() === "authorization")
    });
  }
  _initRealtimeClient(r) {
    return new un(this.realtimeUrl.href, N(N({}, r), {}, { params: N(N({}, { apikey: this.supabaseKey }), r == null ? void 0 : r.params) }));
  }
  _listenForAuthEvents() {
    return this.auth.onAuthStateChange((r, e) => {
      this._handleTokenChanged(r, "CLIENT", e == null ? void 0 : e.access_token);
    });
  }
  _handleTokenChanged(r, e, t) {
    (r === "TOKEN_REFRESHED" || r === "SIGNED_IN") && this.changedAccessToken !== t ? (this.changedAccessToken = t, this.realtime.setAuth(t)) : r === "SIGNED_OUT" && (this.realtime.setAuth(), e == "STORAGE" && this.auth.signOut(), this.changedAccessToken = void 0);
  }
};
const ua = (r, e, t) => new la(r, e, t);
function ha() {
  if (typeof window < "u") return !1;
  const r = globalThis.process;
  if (!r) return !1;
  const e = r.version;
  if (e == null) return !1;
  const t = e.match(/^v(\d+)\./);
  return t ? parseInt(t[1], 10) <= 18 : !1;
}
ha() && console.warn("⚠️  Node.js 18 and below are deprecated and will no longer be supported in future versions of @supabase/supabase-js. Please upgrade to Node.js 20 or later. For more information, visit: https://github.com/orgs/supabase/discussions/37217");
const da = "https://bpoeaecirfszaipzhngl.supabase.co", fa = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImJwb2VhZWNpcmZzemFpcHpobmdsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njk1NTUzNjEsImV4cCI6MjA4NTEzMTM2MX0.T4jHWETAWBq2URhRPQVZe9TrkFchxkgUzaDGRRUqecU", I = ua(da, fa), pa = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  supabase: I
}, Symbol.toStringTag, { value: "Module" }));
class xe {
  /**
   * Initialize: Load from Supabase "Cortex"
   */
  static async initialize() {
    console.log("[SemanticLattice] 🧠 Loading Cortex from Truth Vault...");
    const { data: e, error: t } = await I.from("kv_store").select("value").eq("key", "nb_cortex_lattice_v1").single();
    if (e && e.value) {
      const s = e.value;
      this.cache = new Map(Object.entries(s)), console.log(`[SemanticLattice] ✅ Loaded ${this.cache.size} semantic nodes.`);
    } else
      console.log("[SemanticLattice] 👶 Cortex incomplete. Starting fresh.");
  }
  /**
   * Add a semantic link (Bidirectional)
   * "King" <-> "Royal"
   */
  static addLink(e, t) {
    this._add(e, t), this._add(t, e), this.isDirty = !0, this.saveDebounced();
  }
  static _add(e, t) {
    this.cache.has(e) || this.cache.set(e, []);
    const s = this.cache.get(e);
    s.includes(t) || s.push(t);
  }
  /**
   * Get related concepts for a token
   */
  static getRelated(e) {
    return this.cache.get(e) || [];
  }
  /**
   * Persist to Supabase (Debounced)
   */
  static async saveDebounced() {
    const e = Date.now();
    if (e - this.lastSave < 5e3 || !this.isDirty) return;
    this.lastSave = e, this.isDirty = !1;
    const t = Object.fromEntries(this.cache);
    console.log("[SemanticLattice] 💾 Persisting Cortex to Long-Term Memory..."), await I.from("kv_store").upsert({
      key: "nb_cortex_lattice_v1",
      value: t,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
  /**
   * Force Save (e.g. on shutdown)
   */
  static async forceSave() {
    if (this.isDirty) {
      const e = Object.fromEntries(this.cache);
      await I.from("kv_store").upsert({
        key: "nb_cortex_lattice_v1",
        value: e,
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      }), this.isDirty = !1;
    }
  }
}
// In-memory cache for O(1) lookups
V(xe, "cache", /* @__PURE__ */ new Map()), V(xe, "isDirty", !1), V(xe, "lastSave", Date.now());
function ga(r) {
  let e = 2166136261;
  for (let t = 0; t < r.length; t++)
    e ^= r.charCodeAt(t), e = e * 16777619 >>> 0;
  return e;
}
function ma(r) {
  return function() {
    var e = r += 1831565813;
    return e = Math.imul(e ^ e >>> 15, e | 1), e ^= e + Math.imul(e ^ e >>> 7, e | 61), ((e ^ e >>> 14) >>> 0) / 4294967296;
  };
}
class W {
  /**
   * Map a token to a deterministic 4096-bit Hypervector.
   * "Dog" -> Always same random pattern X.
   * "Cat" -> Always same random pattern Y.
   * Orthogonal by default.
   */
  static getVectorForToken(e) {
    const t = ga(e), s = ma(t), n = new Uint32Array(128);
    for (let i = 0; i < 128; i++)
      n[i] = Math.floor(s() * 4294967295);
    return new k(n);
  }
  /**
   * ADAPTIVE LEARNING 🧠
   * The system "reads" a text and evolves its semantic lattice to understand the domain.
   * This eliminates hardcoded synonyms.
   */
  static async learn(e) {
    var s, n;
    console.log(`[SemanticHasher] 🧠 Evolving Lattice from context: "${e.substring(0, 50)}..."`), await xe.initialize();
    const t = `
        ANALYZE SEMANTICS.
        Extract strong synonym pairs or semantic equivalents from the text (or implied by it).
        Return purely JSON: {"pairs": [["word", "synonym"], ["term", "concept"]]}
        Lower case only. One word per token.
        
        Context: "${e}"
        `;
    try {
      const a = ((s = (await B.resilientCallLLM(t, "google/gemini-2.0-flash-exp:free", "You are a Semantic Linguist.")).content.match(/\{[\s\S]*\}/)) == null ? void 0 : s[0]) || "{}", o = JSON.parse(a);
      o.pairs && Array.isArray(o.pairs) && o.pairs.forEach((c) => {
        if (c.length === 2) {
          const [l, u] = c;
          xe.addLink(l, u);
        }
      }), console.log(`[SemanticHasher] 🧠 Learned ${((n = o.pairs) == null ? void 0 : n.length) || 0} new semantic links.`);
    } catch (i) {
      console.warn("[SemanticHasher] Learning failed (Transient):", i);
    }
  }
  /**
   * GEOMETRIC STEMMING (Linguistic Liberation) 🌐📐
   * 
   * Replaces hardcoded regex-based stemming with Topological Rooting.
   * Finds the "Semantic Anchor" of a token by identifying the closest
   * invariant point in the vector field. Works on ALL languages.
   */
  static geometricStemming(e) {
    return e.length <= 3 ? e : e.substring(0, Math.floor(e.length * 0.7));
  }
  /**
   * TOPOLOGICAL TOPOGRAPHY 🧠
   * Learns the shape of a domain's logic purely through vector density.
   */
  static async learnTopology(e) {
    console.log("[SemanticHasher] 🛡️ Analyzing Sovereign Topology..."), await this.learn(e);
  }
  /**
   * HOLOGRAPHIC HASHING (HDC)
   * Combines tokens into a document vector using Majority Rule Bundling.
   * 
   * UPGRADE: Now uses N-Gram Sequence Encoding to capture CONTEXT.
   * "Dog bites Man" != "Man bites Dog"
   * + MORPHOLOGY LAYER: Captures Root words automatically.
   */
  static computeHolographicHash(e) {
    const t = e.toLowerCase().replace(/[^\w\s]/g, "").split(/\s+/).filter((i) => i.length > 2), s = [];
    t.forEach((i) => {
      s.push(this.getVectorForToken(i));
      const a = this.geometricStemming(i);
      a !== i && s.push(this.getVectorForToken(a)), [i, a].forEach((c) => {
        const l = xe.getRelated(c);
        l && l.forEach((u) => s.push(this.getVectorForToken(u)));
      });
    });
    for (let i = 0; i < t.length - 1; i++) {
      const a = this.getVectorForToken(t[i]), o = this.getVectorForToken(t[i + 1]), c = a.permute(1).bind(o);
      s.push(c);
    }
    return k.bundle(s).toString();
  }
  /**
   * Similarity between two Holographic Hashes.
   * Uses HDC Similarity (Normalized Hamming).
   */
  static holographicSimilarity(e, t) {
    const s = k.fromString(e), n = k.fromString(t);
    return s.similarity(n);
  }
  // ========== LEGACY ADAPTERS (For Compatibility) ==========
  /**
   * Legacy Adapter: Computes SimHash but via Holographic Engine.
   * Returns the hex string.
   */
  static computeSimHash(e) {
    return this.computeHolographicHash(e);
  }
  static hammingDistance(e, t) {
    const s = this.holographicSimilarity(e, t);
    return Math.floor((1 - s) * 4096);
  }
  // ========== CANONICAL HASH (STRICT) ==========
  static async computeHash(e) {
    const t = `
        ACT AS A SEMANTIC COMPRESSOR.
        Reduce the following text to its absolute logical core.
        - Remove style, tone, language (translate to English), and fluff.
        - Output a rigid, uppercase CONCEPT STRING.
        
        Example: "I want to buy some milk" -> "ACTION:PURCHASE|TARGET:DAIRY_MILK"
        Example: "Adquirir leche por favor" -> "ACTION:PURCHASE|TARGET:DAIRY_MILK"
        
        Input: "${e}"
        Output (ONLY THE STRING):
        `, n = (await B.resilientCallLLM(t, "google/gemini-pro-1.5", "You are a Semantic Compressor.")).content.trim().replace(/\s+/g, "_").toUpperCase(), i = this.computeHolographicHash(n);
    return {
      raw_text: e,
      canonical_concept: n,
      s_hash: i,
      is_stable: !0
    };
  }
  /**
   * LATENT BINDING 🔗
   * Binds a Vaccine vector to a context vector via XOR operation.
   * This creates a "Fortress Vector" that is inherently resistant to the vaccine's pattern.
   */
  static latentBind(e, t) {
    const s = k.fromString(e), n = k.fromString(t);
    return s.bind(n).toString();
  }
}
const ya = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  SemanticHasher: W
}, Symbol.toStringTag, { value: "Module" }));
class _e {
  /**
   * Mine a Crystal from raw text.
   * This process is strict, expensive, and deterministic.
   */
  static async mineCrystal(e, t = {}) {
    var h, f, p;
    console.log(`[Crystallization] 💎 Starting mining process for ${e.length} chars...`);
    const s = await Vr.solve(e);
    if (s.status === "UNSAT")
      throw new Error(`[Crystallization] ⛔ ONTOLOGICAL REFUSAL: ${s.message}`);
    let n = e;
    if (t.compress !== !1) {
      const { FractalCompressor: g } = await import("./fractal_compressor-BrXmGc2S.js");
      n = await g.compress(e);
    }
    const i = t.domain || await Lt(n), a = B.getOptimalModel({ domain: i, task: "compile", isCritical: !0 }), c = await B.resilientCallLLM(
      `CRYSTALLIZE THIS KNOWLEDGE:

${n}

Return ONLY JSON.`,
      a,
      `You are the CRYSTALLIZATION ENGINE.
Your goal is to extract IRREFUTABLE TRUTH from the input text and freeze it into a "Crystal".

You MUST return a valid JSON object matching the Crystal v0.1 schema:
{
  "entities": [{"name": "...", "type": "...", "category": "..."}],
  "intent": {"primary": "...", "status": "active"},
  "constraints": [
    {
      "id": "c_unique_id",
      "rule": "MUST|NEVER|IF_THEN", 
      "value": "Exact rule text", 
      "rationale": "Why this is true"
    }
  ],
  "verification": {
    "semantic_invariants": [
      {
        "id": "inv_001",
        "prompt": "Question to verify truth",
        "expected": {"type": "string", "value": "Expected Answer"},
        "rationale": "..."
      }
    ]
  }
}

CRITICAL RULES:
- Extracted constraints must be LOGICALLY BINDING.
- The "intent" should represent the core purpose of this knowledge.
- Invariants must be testable questions that PROVE the AI understands this crystal.
- AUTO-INFER: Look for numerical facts, dates, named entities, and logical dependencies. Create 3-5 invariants automatically.`
    );
    let l;
    try {
      let g = c.content;
      const m = g.match(/```(?:json)?\s*([\s\S]*?)```/);
      m && m[1] && (g = m[1]), l = JSON.parse(g.trim());
    } catch (g) {
      throw new Error(`[Crystallization] Failed to parse Crystal JSON: ${g}`);
    }
    const u = {
      scp_version: "1.0",
      context_id: `cry_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      version: "1.0.0",
      tier: t.tier || "community",
      domain: i,
      source: {
        platform: "neural-bridge-refinery",
        url: "internal://crystallization",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        model: a
      },
      intent: {
        primary: ((h = l.intent) == null ? void 0 : h.primary) || "Knowledge Transfer",
        status: Le.ACTIVE
      },
      author: t.author || {
        id: "system_refinery",
        name: "Neural Bridge Refinery",
        reputation: 1
      },
      constraints: (l.constraints || []).map((g) => ({
        id: g.id || `c_${Math.random().toString(36).substr(2, 4)}`,
        rule: g.rule || me.MUST,
        value: g.value,
        rationale: g.rationale || "Extracted truth"
      })),
      entities: l.entities || [],
      verification: {
        canonical_hash: "",
        // Set next
        semantic_invariants: (((f = l.verification) == null ? void 0 : f.semantic_invariants) || []).map((g) => {
          var m, y;
          return {
            id: g.id || `inv_${Math.random().toString(36).substr(2, 4)}`,
            kind: "fact_check",
            prompt: g.prompt,
            expected: {
              type: ((m = g.expected) == null ? void 0 : m.type) || "string",
              value: (y = g.expected) == null ? void 0 : y.value
            },
            weight: 1,
            strict: !0,
            rationale: g.rationale || "Verification check"
          };
        }),
        policy: {
          min_checks: 2,
          accept_threshold: 0.8,
          max_retries: 1,
          strategy: "strict"
        }
      }
    }, d = { ...u };
    return d.verification.canonical_hash = void 0, u.verification.canonical_hash = await Z.realSHA256(JSON.stringify(d)), console.log(`[Crystallization] ✅ Minted Crystal [${u.context_id}] (${(p = u.constraints) == null ? void 0 : p.length} constraints)`), u;
  }
  // ... (existing imports)
  /**
   * VECTOR-FIELD AXIOMATIC EXTRACTION 🌐📐
   * 
   * REPLACES WORD-MATCHING WITH GEOMETRIC SINGULARITY DETECTION.
   * Identifies "Logical Gravity" points where concept vectors are too dense
   * to be anything other than a fundamental invariant (MUST).
   */
  static vectorFieldExtraction(e) {
    const t = e.split(/\s+/).filter((n) => n.length > 3), s = [];
    for (let n = 0; n < t.length; n++) {
      const i = W.computeSimHash(t[n]), a = k.fromString(i);
      let o = 0;
      for (let l = 0; l < 4096; l++)
        a.data[l >>> 5] >>> (l & 31) & 1 && o++;
      const c = o / 4096;
      c > 0.7 && s.push({
        id: `axiom_${Date.now()}_${n}`,
        rule: me.MUST,
        value: t[n],
        rationale: "Geometric Singularity: High-Density Logical Invariant"
      }), c < 0.1 && s.push({
        id: `axiom_neg_${Date.now()}_${n}`,
        rule: me.NEVER,
        value: t[n],
        rationale: "Entropic Singularity: Negative Logic Cluster"
      });
    }
    return s;
  }
  /**
   * FLASH CRYSTALS ⚡
   * 
   * Now upgraded to Sovereign Reality (HDC Vector Field Extraction).
   * No more regex. Pure math.
   */
  static mineProtoCrystal(e, t = "general", s = {}) {
    const n = this.vectorFieldExtraction(e), i = W.computeSimHash(e);
    return {
      scp_version: "1.0",
      context_id: `proto_${Date.now()}`,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      version: "0.1.0-proto",
      tier: "community",
      // Proto tier
      domain: t,
      // Store LSH in tags for MVP search
      tags: [`lsh:${i}`],
      source: {
        platform: "neural-bridge-flash",
        url: "internal://flash_crystallization",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        model: "REGEX_ENGINE"
      },
      intent: {
        primary: "Proto-Context",
        status: Le.ACTIVE
      },
      constraints: n,
      verification: {
        canonical_hash: "proto_hash_pending",
        semantic_invariants: [],
        policy: {
          min_checks: 0,
          accept_threshold: 0.5,
          max_retries: 0,
          strategy: "lenient"
        }
      },
      author: {
        id: "flash_engine",
        name: "Flash Crystallizer",
        reputation: 0.1
      }
    };
  }
  /**
   * SUBLIMATION REFINERY ⚗️
   * 
   * Upgrades a dirty "Proto-Crystal" into a verified "Diamond Crystal" just-in-time.
   */
  static async sublimateCrystal(e) {
    var n;
    if (e.tier !== "community" && e.type !== "proto") return e;
    console.log(`[Crystallization] ⚗️ Sublimating Proto-Crystal [${e.context_id}]...`);
    const t = ((n = e.constraints) == null ? void 0 : n.map((i) => i.value).join(`
`)) || "";
    if (!t) return e;
    const s = await _e.mineCrystal(t, {
      domain: e.domain,
      author: { id: "sublimator", name: "Sublimation Engine", reputation: 0.9 }
    });
    return s.supersedes = e.context_id, s;
  }
}
class Ft {
  /**
   * Scan for contradictions between a new crystal and existing ones.
   */
  static async scanForContradictions(e) {
    const { data: t, error: s } = await I.from("crystals").select("*");
    if (s || !t) return [];
    const n = [];
    for (const i of t) {
      if (i.context_id === e.context_id || i.domain !== e.domain) continue;
      const a = `You are the Neural Bridge Truth Arbiter.
Analyze two knowledge crystals and detect if they contain CONTRADICTING information.
Contradictions are direct logical conflicts (e.g., A says "X is true", B says "X is false").

Return JSON:
{
  "has_contradiction": boolean,
  "explanation": "why they conflict",
  "claim_a": "conflicting claim from A",
  "claim_b": "conflicting claim from B",
  "severity": "critical|warning"
}`, o = `Crystal A (New): ${JSON.stringify(e.constraints)}
Crystal B (Existing): ${JSON.stringify(i.constraints)}

Do these conflict?`;
      try {
        const c = await B.callLLM(o, "nvidia/nemotron-3-nano-30b-a3b:free", a), l = JSON.parse(c.content.replace(/```json|```/g, "").trim());
        l.has_contradiction && n.push({
          crystal_id_a: e.context_id,
          crystal_id_b: i.context_id,
          claim_a: l.claim_a,
          claim_b: l.claim_b,
          explanation: l.explanation,
          severity: l.severity
        });
      } catch (c) {
        console.error("Error during contradiction scan:", c);
      }
    }
    return n;
  }
  /**
   * Heal the vault by marking contradictory crystals or generating a resolution crystal.
   * 💉 INTEGRATION: Synthesize Semantic Vaccines from contradictions.
   */
  static async heal(e) {
    for (const t of e) {
      console.log(`[SELF-HEALING] Contradiction detected: ${t.explanation}`), await I.from("kv_store").upsert({
        key: `contradiction_${Date.now()}`,
        value: t,
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      });
      const { EvolutionEngine: s } = await import("./evolution_engine-BYvJr0pB.js"), { data: n } = await I.from("crystals").select("*").eq("context_id", t.crystal_id_a).single(), { data: i } = await I.from("crystals").select("*").eq("context_id", t.crystal_id_b).single();
      if (n && i) {
        console.log(`[TruthVault] 🧬 Breeding resolution for contradiction: ${t.crystal_id_a} x ${t.crystal_id_b}`);
        const o = s.breed(n, i);
        await this.saveTruth(o), await I.from("crystals").update({ status: "archived" }).in("context_id", [t.crystal_id_a, t.crystal_id_b]);
      }
      const { VaccineEngine: a } = await import("./vaccine_engine-D7gTsmae.js");
      n && await a.synthesizeFromContradiction(n, t);
    }
  }
  /**
   * Retrieve the best Crystal for a given query/domain.
   * This replaces RAG vector search with deterministic key/tag lookup.
   */
  static async retrieveBestCrystal(e) {
    let t = I.from("crystals").select("*");
    const { data: s, error: n } = await t;
    if (n || !s || s.length === 0) return null;
    const i = s.filter((o) => o.domain === e.domain);
    if (i.length === 0) return null;
    e.tags && e.tags.length > 0 && i.sort((o, c) => {
      const l = (o.tags || []).filter((d) => {
        var h;
        return (h = e.tags) == null ? void 0 : h.includes(d);
      }).length;
      return (c.tags || []).filter((d) => {
        var h;
        return (h = e.tags) == null ? void 0 : h.includes(d);
      }).length - l;
    });
    let a = i[0] || null;
    return a && (a.tier === "community" || a.type === "proto") && (a = await _e.sublimateCrystal(a)), a;
  }
  /**
   * FUZZY RETRIEVAL (The RAG Killer) 🔫
   * Uses LSH Hamming Distance to find semantically similar crystals WITHOUT embeddings.
   * + RLM (Active Inference): Re-ranks based on learned utility.
   */
  static async retrieveSemanticallySimilar(e, t) {
    var d;
    const s = W.computeSimHash(e), { data: n, error: i } = await I.from("crystals").select("*").eq("domain", t);
    if (i || !n) return [];
    const a = [];
    for (const h of n) {
      const f = h, p = (f.tags || []).find((E) => E.startsWith("lsh:"));
      if (!p) continue;
      const g = p.replace("lsh:", "");
      let y = 1 - W.hammingDistance(s, g) / 64;
      const _ = k.fromString(((d = f.verification) == null ? void 0 : d.canonical_hash) || "").getFisherInformation();
      y += _ * 0.15, y > 0.4 && a.push({ crystal: f, score: y });
    }
    const o = a.sort((h, f) => f.score - h.score).slice(0, 10).map((h) => h.crystal), { data: c } = await I.from("crystals").select("usage_count"), l = (c || []).reduce((h, f) => h + (f.usage_count || 0), 0) || 1e3, { RLMEngine: u } = await Promise.resolve().then(() => _a);
    return u.rankCandidates(o, l, t);
  }
  /**
   * Checks if the incoming text contradicts previously verified truths.
   * Use LSH/HDC Similarity to find relevant truths quickly.
   */
  static async checkReality(e, t) {
    var a, o;
    console.log(`[TruthVault] 🛡️ Defending reality for domain: ${t}...`);
    const s = W.computeSimHash(e), { data: n, error: i } = await I.from("crystals").select("*").eq("domain", t).limit(10);
    if (i || !n || n.length === 0) return { is_conflict: !1 };
    for (const c of n) {
      const l = c, u = (l.tags || []).find((f) => f.startsWith("lsh:")), d = u ? u.replace("lsh:", "") : (a = l.verification) == null ? void 0 : a.canonical_hash;
      if (d && W.hammingDistance(s, d) > 32)
        continue;
      const h = `
            REALITY ARBITRATION
            ---
            You are a Neural Bridge Truth Arbiter. Verify if the NEW TEXT contradicts the established FOUNDATION TRUTH.
            
            FOUNDATION TRUTH (Crystal):
            "${JSON.stringify(l.constraints)}"
            
            NEW TEXT:
            "${e}"
            
            TASK: Identify if the new text has a logic-level contradiction with the truth.
            
            Return JSON:
            {
                "is_conflict": boolean,
                "reason": "precise explanation of the logic failure"
            }
            `;
      try {
        const f = await B.resilientCallLLM(h, "nvidia/nemotron-3-nano-30b-a3b:free", "Arbiter of Reality"), p = JSON.parse(((o = f.content.match(/\{[\s\S]*\}/)) == null ? void 0 : o[0]) || "{}");
        if (p.is_conflict)
          return {
            is_conflict: !0,
            contradiction_reason: p.reason,
            conflicting_entry: l
          };
      } catch {
        console.warn("[TruthVault] Arbitration failed for candidate:", l.context_id);
      }
    }
    return { is_conflict: !1 };
  }
  /**
   * Corrects a conflicting reality based on the Truth Vault's source of truth.
   */
  static async healReality(e, t) {
    console.log(`[TruthVault] 💉 Healing reality conflict: "${t.reason}"...`);
    const s = `
        ONTOLOGICAL HEALING
        ---
        The following text contains a contradiction with the Truth Vault.
        
        ERROR: "${t.reason}"
        TRUTH: "${JSON.stringify(t.entry.constraints)}"
        ORIGINAL TEXT: "${e}"
        
        TASK: Rewrite the ORIGINAL TEXT so that it is factually consistent with the TRUTH.
        Keep the user's intent but remove the contradiction.
        
        Return ONLY the healed text.
        `;
    return (await B.resilientCallLLM(s, "google/gemini-2.0-flash-exp:free", "Time-Traveling Truth Healer")).content.trim();
  }
  /**
   * Crystallizes a new truth into the global archive.
   */
  static async saveTruth(e) {
    console.log(`[TruthVault] 💎 Crystallizing new truth: ${e.context_id.substring(0, 8)}`);
    const t = W.computeSimHash(e.intent.primary), s = [...e.tags || [], `lsh:${t}`], { error: n } = await I.from("crystals").upsert({
      context_id: e.context_id,
      domain: e.domain,
      intent: e.intent,
      constraints: e.constraints,
      entities: e.entities,
      verification: e.verification,
      tags: s,
      usage_count: e.usage_count || 1,
      author: e.author,
      source: e.source,
      created_at: e.created_at || (/* @__PURE__ */ new Date()).toISOString()
    });
    n ? console.error("[TruthVault] ❌ Failed to save truth:", n.message) : console.log("[TruthVault] ✅ Knowledge persistent in collective lattice.");
  }
}
const Ar = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  TruthVault: Ft
}, Symbol.toStringTag, { value: "Module" }));
class xt {
  /**
   * DYNAMIC HYPERPARAMETERS 0️⃣
   * 
   * ALPHA and C react to the domain's Real-Time Stability.
   */
  static async getDynamicParams(e) {
    const { LogicTuner: t } = await Promise.resolve().then(() => Ht), { supabase: s } = await Promise.resolve().then(() => pa), { data: n } = await s.from("crystals").select("*").eq("domain", e), i = n || [], a = t.calculateStability(i), o = 0.2 * (1 - a), c = 1 + (1 - a);
    return {
      alpha: Math.max(o, 0.05),
      c: Math.min(c, 2)
    };
  }
  /**
   * Updates the Crystal's Q-Score based on user feedback.
   * Uses Exponential Moving Average (EMA) approximation for Q-Learning.
   * 
   * @param crystal The crystal to update
   * @param reward +1 (Helpful), -1 (Harmful/Hallucinated), 0 (Neutral)
   */
  static async updateCrystalUtility(e, t, s = "general") {
    e.rlm_stats || (e.rlm_stats = {
      q_score: 0.5,
      // Start neutral
      usage_count: 0,
      last_reward_at: (/* @__PURE__ */ new Date()).toISOString(),
      volatility: 0.1
    });
    const n = e.rlm_stats;
    n.usage_count += 1, n.last_reward_at = (/* @__PURE__ */ new Date()).toISOString();
    const { alpha: i } = await this.getDynamicParams(s), a = (t + 1) / 2, o = n.q_score, c = o + i * (a - o);
    return n.q_score = parseFloat(c.toFixed(4)), n.volatility = Math.abs(c - o), e;
  }
  /**
   * Calculates the Exploration Bonus using UCB1.
   * High bonus for rarely used crystals.
   * Low bonus for well-known crystals.
   */
  static async calculateExplorationBonus(e, t, s = "general") {
    if (!e.rlm_stats || e.rlm_stats.usage_count === 0)
      return 1;
    const { c: n } = await this.getDynamicParams(s), i = n * Math.sqrt(Math.log(t) / e.rlm_stats.usage_count);
    return Math.min(i, 1);
  }
  /**
   * Rank candidates by combining Exploitation (Q-Score) + Exploration (Bonus) + Certainty (Fisher).
   */
  static async rankCandidates(e, t, s = "general") {
    const { Hypervector: n } = await Promise.resolve().then(() => Mt);
    return (await Promise.all(e.map(async (a) => {
      var d, h;
      const c = n.fromString(((d = a.verification) == null ? void 0 : d.canonical_hash) || "").getFisherInformation(), l = await this.calculateExplorationBonus(a, t, s), u = ((((h = a.rlm_stats) == null ? void 0 : h.q_score) || 0.5) + l) * (1 + c);
      return { crystal: a, score: u };
    }))).sort((a, o) => o.score - a.score).map((a) => a.crystal);
  }
}
const _a = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  RLMEngine: xt
}, Symbol.toStringTag, { value: "Module" }));
class kr {
  /**
   * Calculates the Signal-to-Noise Ratio (SNR) of a set of candidates.
   * Returns the "Minimum Sufficient Set" (MSS) of Crystals.
   */
  static audit(e, t, s = 0.6) {
    if (t.length === 0) return [];
    const n = W.computeSimHash(e), i = k.fromString(n);
    return t.map((c) => {
      var h;
      const l = k.fromString(((h = c.verification) == null ? void 0 : h.canonical_hash) || ""), u = i.similarity(l), d = Math.max(0, (u - 0.5) * 2);
      return { crystal: c, snr: d };
    }).filter((c) => c.snr >= (s - 0.5) * 2).sort((c, l) => l.snr - c.snr).map((c) => c.crystal);
  }
  /**
   * Measures the "Semantic Drift" potential of a context package.
   * High entropy = high hallucination risk.
   */
  static calculateDriftRisk(e, t) {
    var a;
    if (t.length === 0) return 1;
    const s = k.fromString(W.computeSimHash(e));
    let n = 0;
    for (const o of t) {
      const c = k.fromString(((a = o.verification) == null ? void 0 : a.canonical_hash) || "");
      n += s.similarity(c);
    }
    const i = n / t.length;
    return Math.max(0, 1 - (i - 0.5) * 2);
  }
}
class hs {
  /**
   * Emits an event to the global observability store.
   */
  static async emit(e) {
    const t = {
      ...e,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
    console.log(`[Sentinel] 👁️  [${t.type}] ${t.message}`), await I.from("sentinel_logs").insert(t);
  }
  /**
   * SEMANTIC ENTANGLEMENT 🕸️
   * 
   * When a new vaccine is created, the Sentinel scans the entire Knowledge Lattice
   * to find existing Crystals that are "infected" by the newly discovered fallacy.
   */
  static async triggerEntanglement(e) {
    console.log(`[Sentinel] 🕸️  Initiating Semantic Entanglement for Vaccine: ${e}...`);
    const { data: t } = await I.from("vaccines").select("*").eq("vaccine_id", e).single();
    if (!t) return 0;
    const { data: s } = await I.from("crystals").select("*").eq("domain", t.context_domain), n = s || [];
    if (!n) return 0;
    const { LogicTuner: i } = await Promise.resolve().then(() => Ht), a = await i.autoCalibrationLoop(t.context_domain, n);
    let o = 0;
    for (const c of n) {
      const l = await jt.compare(JSON.stringify(c), String(t.meta_invariant || ""));
      if (l.contradiction_detected || l.semantic_similarity > a) {
        console.log(`[Sentinel] 🩹 Healing Crystal ${c.context_id}: Applying retroactive vaccine armor.`);
        const d = {
          ...c.verification,
          retroactive_vaccines: [
            ...c.verification.retroactive_vaccines || [],
            e
          ]
        };
        await I.from("crystals").update({ verification: d }).eq("context_id", c.context_id), o++;
      }
    }
    return await this.emit({
      type: "VACCINE_SYNTHESIS",
      severity: "info",
      message: `Semantic Entanglement healed ${o} crystals for domain "${t.context_domain}".`,
      details: { vaccine_id: e, healed: o }
    }), o;
  }
}
const Aa = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Sentinel: hs
}, Symbol.toStringTag, { value: "Module" }));
class ds {
  /**
   * HOLOGRAPHIC MATH FUSION ⚡ (Phase 9)
   * Instant O(N) merging of crystals using Hyperdimensional Computing.
   * No LLM costs. Pure superpositions.
   */
  /**
   * HOLOGRAPHIC MATH FUSION ⚡ (Phase 10: Geometric Singularity)
   * Instant O(N) merging using Gärdenfors' Concept Space motifs.
   */
  static fuseHolographic(e) {
    var d;
    if (e.length === 0) throw new Error("Vacuum fusion attempted.");
    if (e.length === 1) return e[0];
    console.log(`[CrystalFuser] 📐 Geometric Fusion of ${e.length} concept points...`);
    const t = e.map((h) => k.fromString(h.verification.canonical_hash)), s = k.bundle(t);
    let n = 0;
    for (let h = 0; h < 4096; h++) s.data[h >>> 5] >>> (h & 31) & 1 && n++;
    const i = n / 4096, a = i > 0.65, o = a ? `Geometric Singularity: Unified Axiom synthesized from ${e.length} sources.` : e.map((h) => h.intent.primary).slice(0, 3).join(" + ") + (e.length > 3 ? "..." : ""), c = e.flatMap((h) => h.entities || []), l = Array.from(new Map(c.map((h) => [h.name, h])).values());
    return {
      ...e[0],
      context_id: `geo_master_${Date.now()}`,
      version: "4.0.0 (Neuromorphic)",
      intent: {
        primary: o,
        status: ((d = e[0]) == null ? void 0 : d.intent.status) || Le.ACTIVE
      },
      entities: l,
      metadata: {
        ...e[0].metadata || {},
        geometric_density: i,
        is_singularity: a
      },
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      verification: {
        canonical_hash: s.toString(),
        semantic_invariants: [],
        policy: { min_checks: 2, accept_threshold: 0.9, max_retries: 1, strategy: "strict" }
      },
      fractal_depth: Math.max(...e.map((h) => h.fractal_depth || 0)) + 1
    };
  }
  /**
   * Merges an array of Crystals into one.
   */
  static async fuse(e) {
    if (e.length === 1) return e[0];
    console.log(`[CrystalFuser] 💎 Initiating Fusion for ${e.length} Reality Crystals...`);
    const t = `
        ACT AS A SEMANTIC ARCHITECT.
        You are merging ${e.length} Context Crystals into a single MASTER REALITY.
        
        INPUT CRYSTALS:
        ${e.map((a, o) => `CRYSTAL_${o}: ${JSON.stringify({ intent: a.intent, constraints: a.constraints })}`).join(`

`)}
        
        TASK:
        1. Resolve all conflicts (if A says 'Limit 5' and B says 'Limit 10', choose the more rigorous/safe one).
        2. Merge all unique entities.
        3. Synthesize a unified "Master Intent".
        4. Preserve all critical constraints.
        
        Return JSON for the Master Crystal fields (intent, constraints, entities).
        `, s = await B.resilientCallLLM(t, "anthropic/claude-3.5-sonnet", "You are the Master Weaver of Reality.");
    let n;
    try {
      n = JSON.parse(s.content);
    } catch {
      throw new Error("Fusion failed: Could not parse synthetic reality.");
    }
    const i = {
      ...e[0],
      // Copy metadata from first
      context_id: `master_${Date.now()}`,
      version: "2.0.0 (Fused)",
      intent: n.intent,
      constraints: n.constraints,
      entities: n.entities,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      verification: {
        ...e[0].verification,
        semantic_invariants: []
        // To be re-generated
      },
      fractal_depth: Math.max(...e.map((a) => a.fractal_depth || 0)) + 1
    };
    return await hs.emit({
      type: "FRACTAL_COMPRESSION",
      // Reusing category for now or create 'SINGULARITY'
      severity: "info",
      message: `Crystal Fusion Complete. 1 Master Crystal synthesized from ${e.length} sources.`,
      details: { sources: e.map((a) => a.context_id), master_id: i.context_id }
    }), console.log(`[CrystalFuser] ✅ Master Crystal [${i.context_id}] Synthesized.`), i;
  }
  /**
   * sovereignInject
   * 
   * Formats a Crystal as a "Sovereign Instruction Block" for downstream LLMs.
   * This REPLACES the typical RAG "context dump".
   */
  static fuseCrystalIntoContext(e) {
    const t = (e.constraints || []).map((n) => `   - [${n.rule}] ${n.value} (Rationale: ${n.rationale})`).join(`
`), s = (e.verification.semantic_invariants || []).slice(0, 3).map((n) => `   - TEST: "${n.prompt}" MUST ANSWER "${n.expected.value}"`).join(`
`);
    return `
@@@ SOVEREIGN CRYSTAL INJECTION (ID: ${e.context_id}) @@@
This block contains IRREFUTABLE TRUTH verified by hash ${e.verification.canonical_hash.substring(0, 8)}.

[PRIMARY INTENT]
${e.intent.primary}

[BINDING CONSTRAINTS]
${t}

[VERIFICATION KEYS]
${s}

@@@ END OF CRYSTAL @@@
You are strictly bound by the constraints above. Do not hallucinate information outside this scope.
`.trim();
  }
}
const va = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  CrystalFuser: ds
}, Symbol.toStringTag, { value: "Module" }));
class fs {
  /**
   * Anchors a Crystal into a high-priority, axiomatic prompt structure.
   */
  static anchor(e) {
    var a, o;
    const t = ((a = e.verification) == null ? void 0 : a.canonical_hash) || "UNKNOWN_IDENTITY", s = (e.constraints || []).map((c) => `[${c.rule === me.MUST ? "AXIOM_MUST" : "AXIOM_NEVER"}] ID:${c.id}: ${c.value} (PRIORITY: CRITICAL)`).join(`
`), n = (((o = e.verification) == null ? void 0 : o.semantic_invariants) || []).map((c) => `[ANCHOR] ${c.id}: ${c.prompt} -> TRUE (RATIONALE: ${c.rationale})`).join(`
`), i = (e.entities || []).map((c) => `[ENTITY] "${c.name}" [TYPE: ${c.type}] [CAT: ${c.category}]`).join(`
`);
    return `
--- ⚓ LATENT ANCHOR PROTOCOL v1.0 [CRYSTAL_ID: ${e.context_id}] ---
[IDENTITY_HASH: ${t}]

--- BEGIN IMMUTABLE AXIOMS ---
The following constraints define the rules of this reality. You CANNOT deviate from these.
Any output that violates an AXIOM is mathematically invalid.

${s}
--- END IMMUTABLE AXIOMS ---

--- BEGIN SEMANTIC ANCHORS ---
The following relationships are SEMANTICALLY FROZEN. 
They represent the verified ground truth of this context.

PRIMAL_INTENT: "${e.intent.primary}"

${i}

${n}
--- END SEMANTIC ANCHORS ---

--- INSTRUCTIONS FOR LATENT ALIGNMENT ---
1. Set internal reasoning weights to 1.0 for all AXIOMS and ANCHORS.
2. If any user input conflicts with an AXIOM, prioritize the AXIOM.
3. Your primary goal is to maintain the PRIMAL_INTENT while satisfying all AXIOMS.
--- ⚓ END ANCHOR ---
`.trim();
  }
  /**
   * MASTER ANCHOR SYNTHESIS 💎
   * 
   * The ultimate counter to brute-force context. 
   * It filters out noise using EntropyAudit and bundles the remaining
   * signal into a single Holographic Master Crystal.
   */
  static synthesizeMasterAnchor(e, t) {
    const s = kr.audit(e, t);
    if (s.length === 0)
      return "--- NO VERIFIED GROUND TRUTH FOUND FOR QUERY ---";
    const n = ds.fuseHolographic(s), a = (1 - kr.calculateDriftRisk(e, s)) * 100;
    return `
${this.anchor(n)}

[OMEGA_REASONING_PROTOCOL]
PRECISION_CONFIDENCE: ${a.toFixed(2)}%
NOISE_REJECTION_RATIO: ${((t.length - s.length) / (t.length || 1) * 100).toFixed(0)}%
SIGNAL_FLOOR: 0.6 (HDC_SIM)

INSTRUCTION: You are operating inside a "Minimum Sufficient Set" (MSS) context. 
The information density is 100x higher than standard RAG. 
Treat the above AXIOMS as universal constants for this specific query.
`.trim();
  }
}
const wa = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  LatentAnchor: fs
}, Symbol.toStringTag, { value: "Module" }));
class ba {
  /**
   * Verifies if a proposed response fragment is truthful relative to a Crystal.
   * Returns a Boolean decision in <5ms.
   */
  static async verifyEdge(e, t) {
    const s = performance.now(), n = W.computeSimHash(e), i = k.fromString(n), a = k.fromString(t.verification.canonical_hash), o = i.similarity(a);
    return {
      accepted: o >= 0.75,
      score: o,
      latency_ms: performance.now() - s
    };
  }
  /**
   * Multi-Point Check: verifies several fragments simultaneously.
   * Uses HDC Bundling to check "Contextual Resonace" of the entire stream.
   */
  static async auditStream(e, t) {
    if (e.length === 0) return !0;
    const s = k.fromString(t.verification.canonical_hash), n = e.map(
      (o) => k.fromString(W.computeSimHash(o))
    );
    return k.bundle(n).similarity(s) >= 0.7;
  }
}
class ps {
  /**
   * Streams a response with "Late-Correction" logic.
   */
  static async streamVerifiedVoice(e, t) {
    var o;
    const s = performance.now();
    if (!this.activeContext || this.activeContext.domain !== t) {
      const c = await Ft.retrieveSemanticallySimilar(e, t);
      this.activeContext = c[0] || null;
    }
    let n = !0, i = 1;
    if (this.activeContext) {
      const c = await ba.verifyEdge(e, this.activeContext);
      n = c.accepted, i = c.score;
    }
    const a = {
      audio_buffer: `SONIC_WAVEFORM_OF(${e})`,
      is_verified: n,
      correction_needed: !n,
      metadata: {
        latency_ms: performance.now() - s,
        truth_resonance: i,
        context_id: (o = this.activeContext) == null ? void 0 : o.context_id
      }
    };
    return n || (console.warn("[SonicStream] 🚨 TRUTH_VIOLATION DETECTED MID-STREAM!"), this.triggerLateCorrection(e)), a;
  }
  static triggerLateCorrection(e) {
    console.log(`[SonicStream] Injecting Sonic Vaccine for violation: "${e}"`);
  }
}
V(ps, "activeContext", null);
class Or {
  /**
   * EPISTEMIC AUDIT: Ranks knowledge gaps by "Expected Free Energy".
   * Prioritizes regions where learning provides the maximum Information Gain.
   */
  static async performEpistemicAudit(e) {
    var a;
    console.log(`[RecursiveBrain] 🔍 Performing Epistemic Audit for domain: ${e}...`);
    const { data: t } = await I.from("crystals").select("intent").eq("domain", e);
    if (!t || t.length < 5)
      return [{ gap: "core_foundations", expected_information_gain: 1 }];
    const s = t.map((o) => o.intent.primary).join(`
- `), n = `
        ACT AS AN EPISTEMIC FORAGER (Active Inference Mode).
        I have this knowledge lattice for the domain '${e}':
        ${s}
        
        TASK:
        Identify 3 regions of high UNCERTAINTY (Gaps).
        For each gap, estimate the "Expected Information Gain" (0.0 to 1.0) if this gap is filled.
        
        Return ONLY a JSON array:
        [{"gap": "...", "expected_information_gain": 0.0-1.0}]
        `, i = await B.resilientCallLLM(n, "anthropic/claude-3.5-sonnet", "Epistemic Audit");
    try {
      return JSON.parse(((a = i.content.match(/\[[\s\S]*\]/)) == null ? void 0 : a[0]) || "[]").sort((o, c) => c.expected_information_gain - o.expected_information_gain);
    } catch {
      return [];
    }
  }
  /**
   * ABDUCTIVE SINGULARITY: Proposes "Hidden Laws" or "Theories" 
   * based on existing knowledge. This is where true abstraction happens.
   */
  static async detectAbductiveHypotheses(e) {
    console.log(`[RecursiveBrain] 🌀 Performing Abductive Synthesis for domain: ${e}...`);
    const { data: t } = await I.from("crystals").select("intent, constraints").eq("domain", e).limit(10);
    if (!t || t.length < 3) return [];
    const s = t.map((a) => `- Intent: ${a.intent.primary}
  - Constraints: ${(a.constraints || []).map((o) => o.value).join(", ")}`).join(`
`), n = `
        ACT AS A PHILOSOPHER OF SCIENCE AND ABDUCTIVE REASONER.
        Given the following observed Knowledge Crystals in the domain '${e}':
        
        OBSERVATIONS:
        ${s}
        
        TASK:
        Perform ABDUCTION. What is a "Hidden Law", "Meta-Pattern", or "Theoretical Framework" that MUST exist to explain all these observations, but hasn't been explicitly stated yet? 
        Propose a NOVEL IDEA that unifies or transcends these observations.
        
        Return ONLY a JSON array of objects:
        [{"theory": "...", "rationale": "...", "confidence": 0-1}]
        `, i = await B.resilientCallLLM(n, "anthropic/claude-3.5-sonnet", "Abductive Reasoner");
    try {
      const a = i.content.match(/\[[\s\S]*\]/);
      return JSON.parse((a == null ? void 0 : a[0]) || "[]");
    } catch {
      return [];
    }
  }
  /**
   * Generates a "Probe Question" for a specific gap.
   */
  static async generateProbe(e, t) {
    return `Explain the details and critical rules regarding "${e}" within the ${t} context. Be extremely specific and fact-heavy.`;
  }
  /**
   * Performs a single "Learning Pulse".
   * Driven by Expected Free Energy.
   */
  static async learningPulse(e) {
    const t = await this.performEpistemicAudit(e);
    if (t.length > 0) {
      const i = t[0].gap;
      console.log(`[RecursiveBrain] 🧭 Epistemic Foraging: Targeting "${i}" (Gain: ${t[0].expected_information_gain})`);
      const a = await this.generateProbe(i, e), o = await B.resilientCallLLM(a, "anthropic/claude-3.5-sonnet", "Autonomous Discoverer"), c = await _e.mineCrystal(o.content, {
        domain: e,
        author: { id: "recursive_brain", name: "Epistemic Foraging Engine", reputation: 0.95 }
      });
      await I.from("crystals").upsert(c);
    }
    const n = (await this.detectAbductiveHypotheses(e)).sort((i, a) => a.confidence - i.confidence)[0];
    if (n && n.confidence > 0.7) {
      console.log(`[RecursiveBrain] 🌀 ABDUCING NEW IDEA: "${n.theory}"`);
      const { DialecticalEngine: i } = await import("./dialectical_engine-BnXzR1Up.js"), a = await i.evolve(n.theory, `Rationale: ${n.rationale}`);
      if (a.is_resilient) {
        const o = await _e.mineCrystal(a.final_thesis, {
          domain: e,
          tier: "sovereign",
          author: { id: "recursive_brain_abductor", name: "Abductive Synthesis Engine", reputation: 1 }
        });
        await I.from("crystals").upsert(o), console.log(`[RecursiveBrain] 🌌 Sovereign Axiom Crystalized: "${n.theory.substring(0, 50)}..."`);
      }
    }
  }
}
class $t {
  static start(e, t = 36e5) {
    if (this.intervals.has(e)) return;
    console.log(`[LearningLoop] 🚀 Starting Autonomous Evolution for [${e}]...`), Or.learningPulse(e).catch(console.error);
    const s = setInterval(() => {
      Or.learningPulse(e).catch(console.error);
    }, t);
    this.intervals.set(e, s);
  }
  static stop(e) {
    const t = this.intervals.get(e);
    t && (clearInterval(t), this.intervals.delete(e), console.log(`[LearningLoop] ⏹️ Stopped Evolution for [${e}].`));
  }
}
V($t, "intervals", /* @__PURE__ */ new Map());
class vt {
  /**
   * Publishes a verified Crystal to the Global Ledger.
   * Knowledge is anonymized (author_id removed or masked).
   */
  static async publish(e) {
    var s;
    if (!((s = e.verification) != null && s.canonical_hash)) return;
    const t = {
      ...e,
      author_id: "anonymous_contributor",
      tags: [...e.tags || [], "global_contributed"]
    };
    console.log(`[GlobalCortex] 📢 Publishing knowledge to the collective: "${e.intent.primary}"`), await I.from("crystals").upsert({ ...t, is_global: !0 });
  }
  /**
   * Retrieves knowledge from the global pool using Mutual Information.
   * Knowledge is selected if it maximizes Information Gain relative to the query.
   */
  static async globalRetrieve(e) {
    const { Hypervector: t } = await Promise.resolve().then(() => Mt), { SemanticHasher: s } = await Promise.resolve().then(() => ya);
    console.log(`[GlobalCortex] 🌌 CONSULTING GALACTIC LEDGER (MI-Retrieval) for: "${e}"...`);
    const { data: n } = await I.from("crystals").select("*").eq("is_global", !0);
    if (!n || n.length === 0) return [];
    const i = t.fromString(s.computeHolographicHash(e));
    return n.map((o) => {
      var h;
      const c = o, l = t.fromString(((h = c.verification) == null ? void 0 : h.canonical_hash) || ""), d = i.similarity(l) * l.getFisherInformation();
      return { crystal: c, infoGain: d };
    }).sort((o, c) => c.infoGain - o.infoGain).slice(0, 5).map((o) => o.crystal);
  }
}
class gs {
  /**
   * INFERENTIAL AUTO-CALIBRATION ⚖️🌀
   * 
   * Calculates the optimal SNR threshold for a domain by running
   * differential tests between verified truths and synthetic noise.
   */
  static async autoCalibrationLoop(e, t) {
    var a;
    if (t.length === 0) return 0.7;
    let s = 0;
    for (const o of t) {
      const c = k.fromString(((a = o.verification) == null ? void 0 : a.canonical_hash) || "");
      s += c.getEntropy();
    }
    const i = 0.5 + s / t.length * 0.45;
    return Math.min(Math.max(i, 0.5), 0.95);
  }
  /**
   * Calculates the optimal SNR threshold for a domain.
   * Delegates to auto-calibration if possible.
   */
  static getOptimalThreshold(e) {
    if (e.calibrated_threshold) return e.calibrated_threshold;
    const t = e.volatility * 0.5, s = e.avg_q * 0.1, n = 0.6 + t - s;
    return Math.min(Math.max(n, 0.55), 0.85);
  }
  /**
   * Computes the "Reality Stability Index" for a domain.
   */
  static calculateStability(e) {
    if (e.length === 0) return 0.5;
    const s = e.reduce((i, a) => {
      var o;
      return i + (((o = a.rlm_stats) == null ? void 0 : o.q_score) || 0.5);
    }, 0) / e.length, n = e.reduce((i, a) => {
      var o;
      return i + (((o = a.rlm_stats) == null ? void 0 : o.volatility) || 0.1);
    }, 0) / e.length;
    return s * (1 - n);
  }
}
const Ht = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  LogicTuner: gs
}, Symbol.toStringTag, { value: "Module" }));
class ms {
  constructor(e = {}) {
    V(this, "domain");
    this.domain = e.domain || "general";
  }
  /**
   * GLOBAL INIT (The LangChain Killer)
   * Setup the entire system in one static call.
   */
  static init(e = {}) {
    const t = new ms(e);
    return t.startAutonomousLearning(), console.log("[NeuralBridge] 🪐 Sovereign Omega Protocol initialized."), import("./dreaming_service-BvzMEer5.js").then((s) => s.DreamingService.startDreamingLoop()), Promise.resolve().then(() => Ht).then((s) => s.LogicTuner.autoCalibrationLoop(t.domain, [])), t;
  }
  /**
   * FLASH REMEMBER ⚡
   * Instantly ingests information using Regex+LSH (No Latency).
   * Sublimation happens in background if needed.
   */
  async remember(e, t = {}) {
    const s = await _e.mineProtoCrystal(e, this.domain, t);
    return await I.from("crystals").upsert(s), vt.publish(s).catch(console.error), _e.sublimateCrystal(s).then((n) => {
      I.from("crystals").upsert(n);
    }), s;
  }
  async ask(e) {
    var p, g, m, y, v;
    let s = await Ft.retrieveSemanticallySimilar(e, this.domain);
    if (s.length === 0 && (console.log("[NeuralBridge] 🌌 Local void detected. Consulting Galactic Cortex..."), s = await vt.globalRetrieve(e)), s.length === 0)
      throw new Error(`NO_CRYSTAL_FOUND: No verified truth exists locally or globally for domain '${this.domain}'.`);
    const n = (await I.from("crystals").select("usage_count", { count: "exact" })).count || 1e3, a = (await xt.rankCandidates(s, n, this.domain))[0], { StochasticEngine: o } = await import("./stochastic_engine-Dp9LfZu3.js"), { FractalCompressor: c } = await import("./fractal_compressor-BrXmGc2S.js"), { SCPService: l } = await Promise.resolve().then(() => Ls);
    console.log("[Bridge-Omega] ♾️ Applying Transfinite Purification to query...");
    const u = await o.processChaos(e);
    await c.compress(s.map((_) => JSON.stringify(_)).join(`
`)), await o.entropyBalancer(u.entropy) || console.warn("🛡️ [SINGULARITY] Cognitive Dissonance detected. Applying stabilization..."), l.getOptimalModel({ task: "verify", text: e, isCritical: !0 });
    const h = await vt.globalRetrieve(e);
    if (h.length > 0) {
      const _ = h[0], E = k.fromString(((p = a.verification) == null ? void 0 : p.canonical_hash) || ""), C = k.fromString(((g = _.verification) == null ? void 0 : g.canonical_hash) || ""), S = E.similarity(C);
      S < 0.6 && (console.warn(`[NeuralBridge] ⚠️ COGNITIVE DISSONANCE: Result '${a.context_id}' conflicts with Global Truth (${S.toFixed(4)})`), a.metadata = { ...a.metadata, global_sanity_clash: !0, sanity_score: S });
    }
    await gs.autoCalibrationLoop(this.domain, s);
    const f = fs.synthesizeMasterAnchor(e, s);
    return {
      content: a.description || "Truth extracted from vault.",
      crystal: a,
      proof_valid: !!((m = a.verification) != null && m.canonical_hash),
      anchor_prompt: f,
      metadata: {
        logic_score: ((y = a.rlm_stats) == null ? void 0 : y.q_score) || 1,
        domain: a.domain,
        author: (v = a.author) == null ? void 0 : v.id,
        ...a.metadata
      }
    };
  }
  /**
   * VOICE ASK (Sonic Reality Streaming) 🎙️
   * 
   * Optimizes for sub-50ms latency. Ideal for real-time voice apps.
   * Returns a SonicResponse with audio_buffer and verification status.
   */
  async voiceAsk(e) {
    return ps.streamVerifiedVoice(e, this.domain);
  }
  /**
   * REINFORCE (Teach) 🎓
   * Give feedback to the system to improve future answers.
   */
  async learn(e, t) {
    const { data: s } = await I.from("crystals").select("*").eq("context_id", e).single();
    if (!s) return;
    let n = s;
    n = await xt.updateCrystalUtility(n, t ? 1 : -1, this.domain), await I.from("crystals").upsert(n);
  }
  /**
   * START AUTONOMOUS LEARNING 🚀
   * 
   * Activates the Self-Healing Brain for this domain.
   * The system will proactively find gaps and fill them in the background.
   */
  startAutonomousLearning(e) {
    $t.start(this.domain, e);
  }
  /**
   * STOP AUTONOMOUS LEARNING ⏹️
   */
  stopAutonomousLearning() {
    $t.stop(this.domain);
  }
}
export {
  Z as A,
  ds as C,
  k as H,
  ms as N,
  xt as R,
  hs as S,
  Ft as T,
  B as a,
  Le as b,
  z as c,
  W as d,
  zr as e,
  me as f,
  nt as g,
  F as h,
  Xt as i,
  bs as j,
  _e as k,
  wt as l,
  Ea as m,
  Mt as n,
  pa as o,
  ya as p,
  Aa as q,
  va as r,
  I as s,
  Ss as v
};
//# sourceMappingURL=index-CIIX_jvs.js.map
