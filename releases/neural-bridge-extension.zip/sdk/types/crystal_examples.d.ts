import { type Crystal } from './crystal_format';
/**
 * EXAMPLE 1: Medical Domain - Drug Interaction
 *
 * This demonstrates a critical-safety Crystal for healthcare
 */
export declare const MedicalDrugInteractionCrystal: Crystal;
/**
 * EXAMPLE 2: Legal Domain - Contract Requirement
 */
export declare const LegalContractRequirementCrystal: Crystal;
/**
 * EXAMPLE 3: Technical Domain - API Contract
 */
export declare const TechnicalAPIContractCrystal: Crystal;
/**
 * EXAMPLE 4: Universal Logic - Abstract Reasoning Puzzle
 *
 * Tests core logical consistency and chained inference (A -> B, B -> C)
 */
export declare const UniversalLogicCrystal: Crystal;
export declare const CrystalExamples: {
    medical: Crystal;
    legal: Crystal;
    technical: Crystal;
    universal: Crystal;
};
