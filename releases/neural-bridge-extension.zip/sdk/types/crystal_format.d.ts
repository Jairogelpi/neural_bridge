/**
 * CRYSTAL FORMAT SPECIFICATION v0.1
 *
 * A Crystal is a structured, versioned, cryptographically verifiable
 * container for transferring knowledge between LLMs with guarantees.
 *
 * Design Principles:
 * 1. Machine-readable (JSON)
 * 2. Human-auditable (clear structure)
 * 3. Extensible (additional fields allowed)
 * 4. Verifiable (cryptographic hashing)
 * 5. Domain-agnostic (works for medicine, law, code, etc.)
 */
export interface CrystalMetadata {
    /** SCP (Structured Context Protocol) version */
    scp_version: string;
    /** Unique identifier for this Crystal */
    context_id: string;
    /** ISO 8601 timestamp of creation */
    created_at: string;
    /** Optional: Crystal name/title */
    name?: string;
    /** Optional: Human-readable description */
    description?: string;
}
export interface CrystalSource {
    /** Platform where this was captured (chatgpt, claude, gemini, etc.) */
    platform: string;
    /** URL or identifier of the source conversation */
    url: string;
    /** Timestamp of capture */
    timestamp: string;
    /** Optional: Model used to create content */
    model?: string;
    /** Optional: User who created/captured this */
    creator?: string;
}
export declare enum CrystalStatus {
    ACTIVE = "active",
    DEPRECATED = "deprecated",
    SUPERSEDED = "superseded"
}
export interface CrystalIntent {
    /** Primary goal of this knowledge */
    primary: string;
    /** Current status: active, deprecated, superseded */
    status: CrystalStatus;
    /** Optional: Secondary goals */
    secondary?: string[];
    /** Optional: Known limitations */
    limitations?: string[];
}
export declare enum ConstraintRule {
    MUST = "MUST",
    NEVER = "NEVER",
    IF_THEN = "IF_THEN",
    RANGE = "RANGE",
    ENUM = "ENUM",
    REGEX = "REGEX",
    CUSTOM = "CUSTOM"
}
export interface CrystalConstraint {
    /** Unique constraint ID */
    id: string;
    /** Rule type: MUST, NEVER, IF_THEN, RANGE, etc. */
    rule: ConstraintRule;
    /** The actual constraint value/statement */
    value: string;
    /** Why this constraint exists */
    rationale: string;
    /** Optional: Severity (critical, high, medium, low) */
    severity?: 'critical' | 'high' | 'medium' | 'low';
    /** Optional: Reference to external documentation */
    reference?: string;
    /** Optional: Tags for categorization */
    tags?: string[];
}
export interface CrystalEntity {
    /** Entity identifier */
    name: string;
    /** Entity type (person, medication, concept, etc.) */
    type: string;
    /** Entity category/domain */
    category?: string;
    /** Optional: Entity attributes */
    attributes?: Record<string, any>;
    /** Optional: Relationships to other entities */
    relationships?: Array<{
        type: string;
        target: string;
    }>;
}
export interface CrystalEvidence {
    /** Evidence type: quote, fact, source, etc. */
    type: 'quote' | 'fact' | 'source' | 'calculation' | 'reference';
    /** The evidence content */
    content: string;
    /** Optional: Source of this evidence */
    source?: string;
    /** Optional: Timestamp or date */
    timestamp?: string;
    /** Optional: Confidence level (0-1) */
    confidence?: number;
}
export interface SemanticInvariant {
    /** Unique invariant ID */
    id: string;
    /** Invariant kind: constraint_check, safety_check, fact_check, etc. */
    kind: 'constraint_check' | 'safety_check' | 'fact_check' | 'derivation' | 'custom';
    /** Test prompt/question */
    prompt: string;
    /** Expected result */
    expected: {
        type: 'boolean' | 'string' | 'number' | 'enum' | 'regex' | 'json';
        value: any;
    };
    /** Weight of this invariant (0-1, default 1.0) */
    weight: number;
    /** Is this a strict failure? (if false, SRI drops but continues) */
    strict: boolean;
    /** Why this invariant matters */
    rationale: string;
    /** Optional: Custom metadata */
    metadata?: Record<string, any>;
}
export interface VerificationPolicy {
    /** Minimum number of checks required */
    min_checks: number;
    /** Acceptance threshold (SRI minimum) */
    accept_threshold: number;
    /** Maximum retries on failure */
    max_retries: number;
    /** Verification strategy */
    strategy: 'strict' | 'balanced' | 'lenient';
    /** Optional: Domain-specific rules */
    domain_rules?: Record<string, any>;
}
export interface CrystalVerification {
    /** Canonical hash of the Crystal content (SHA-256) */
    canonical_hash: string;
    /** Semantic invariants to verify */
    semantic_invariants: SemanticInvariant[];
    /** Verification policy */
    policy: VerificationPolicy;
    /** Optional: External verifier requirements */
    external_verifiers?: string[];
    /** Optional: Expert cryptographic signatures (Jury of Truth) */
    expert_signatures?: Array<{
        algorithm: 'ECDSA-P256' | 'PGP' | 'WebAuthn';
        public_key: string;
        signature: string;
        timestamp: string;
        expert_id: string;
        domain: string;
    }>;
    /** Optional: Retroactively applied vaccine IDs for safety hardening */
    retroactive_vaccines?: string[];
    /** FRACTAL: Merkle proof for recursive verification */
    merkle_proof?: {
        root: string;
        path: string[];
        leaf: string;
    };
}
export interface CrystalDependency {
    /** Dependency Crystal ID */
    crystal_id: string;
    /** Required version (semver) */
    version: string;
    /** Dependency type */
    type: 'requires' | 'extends' | 'conflicts_with';
    /** Scope of dependency */
    scope: 'domain' | 'client' | 'project' | 'implementation';
    /** Optional: Why this dependency exists */
    reason?: string;
}
export interface RealityProof {
    /** The domain of reality (e.g., 'legal_spain', 'physics_newtonian') */
    domain: string;
    /** The specific constraints that were checked */
    constraints: string[];
    /** Validation status - output is BLOCKED if not 'valid' */
    status: 'valid' | 'invalid' | 'unchecked';
    /** Confidence score of the proof (0-1) */
    confidence: number;
    /** ID of the attestation record */
    attestation_id?: string;
    /** Timestamp of reality check */
    checked_at: string;
}
/**
 * Crystal v0.1 - The Universal Knowledge Container
 *
 * This is the format that revolutionizes AI knowledge transfer.
 * Every Crystal is:
 * - Self-contained (all context in one object)
 * - Verifiable (invariants + hash)
 * - Traceable (source + metadata)
 * - Extensible (additional fields allowed)
 */
export interface Crystal {
    /** SCP version identifier */
    scp_version: string;
    /** Unique Crystal identifier */
    context_id: string;
    /** Creation timestamp */
    created_at: string;
    /** Source of this Crystal */
    source: CrystalSource;
    /** Intent and purpose */
    intent: CrystalIntent;
    /** Verification config (REQUIRED for runtime) */
    verification: CrystalVerification;
    /** Human-readable name */
    name?: string;
    /** Description of this Crystal */
    description?: string;
    /** Domain (medicine, law, tech, general, etc.) */
    domain?: string;
    /** Constraints (NEVER, MUST, IF_THEN rules) */
    constraints?: CrystalConstraint[];
    /** Entities mentioned in this Crystal */
    entities?: CrystalEntity[];
    /** Evidence supporting this knowledge */
    evidence?: CrystalEvidence[];
    /** Dependencies on other Crystals */
    dependencies?: CrystalDependency[];
    /** Semantic Merkle Root (Hash of Meaning) */
    smt_root?: string;
    /** Embedded Proof-Carrying Knowledge Tree */
    proof_tree?: Record<string, any>;
    /** Fractal depth (0 = atomic, >0 = meta-reality) */
    fractal_depth?: number;
    /**
     * Proof of Reality (PoR)
     * The AI cannot produce this output unless it is valid within the domain.
     */
    reality_proof?: RealityProof;
    /** Version of THIS Crystal (semver) */
    version: string;
    /** Trust Tier: COMMUNITY | VERIFIED | CERTIFIED | TRUSTED | SOVEREIGN */
    tier: 'community' | 'verified' | 'certified' | 'trusted' | 'sovereign';
    /** Author Metadata */
    author: {
        id: string;
        name: string;
        reputation: number;
        verified_credentials?: string[];
    };
    /** Crystal this supersedes */
    supersedes?: string;
    /** Is this Crystal deprecated? */
    deprecated?: boolean;
    /** Tags for categorization */
    tags?: string[];
    /** Reinforcement Logic Modeling (Active Stats) */
    rlm_stats?: {
        /** Q-Learning Score (Utility Probability 0.0-1.0) */
        q_score: number;
        /** Number of times this crystal was retrieved */
        usage_count: number;
        /** ISO timestamp of last reinforcement (reward/penalty) */
        last_reward_at: string;
        /** Stability of the truth (lower is better) */
        volatility: number;
    };
    /** Domain-specific extensions (medicine, law, etc.) */
    extensions?: Record<string, any>;
    /** Custom metadata */
    metadata?: Record<string, any>;
    /**
     * Zero-Knowledge Receipts
     * Verifiable proofs of private data validity without exposing the data itself.
     */
    zkp_receipts?: Array<{
        commitment: string;
        proof: string;
        nullifier: string;
        target_constraint_id: string;
    }>;
    /** Neuromorphic / Active Inference metrics */
    neuromorphic_stats?: {
        /** Variational Free Energy score (F = Complexity - Accuracy) */
        free_energy: number;
        /** Predictive Surprise (Prediction Error) */
        surprise: number;
        /** Geometric Concept Density (HDC Logic Gravity) */
        geometric_density: number;
        /** True if this is a Geometric Singularity (Converged Axiom) */
        is_singularity: boolean;
    };
    /**
     * Fractal Lineage
     * Tracks how this crystal evolved from others.
     */
    genealogy?: {
        generation: number;
        parents: string[];
        evolved_from?: string;
    };
    /**
     * Synaptic Connections
     * Autonomous semantic links between crystals.
     */
    synapses?: Array<{
        target: string;
        type: 'SUPPORTS' | 'CONTRADICTS' | 'REFINES' | 'ORIGINATES_FROM' | 'RELATED_TO' | 'MERGED_INTO';
        strength: number;
        discovered_at: string;
        justification?: string;
    }>;
}
export declare const CrystalSchemaV01: {
    $schema: string;
    title: string;
    type: string;
    required: string[];
    properties: {
        scp_version: {
            type: string;
            pattern: string;
            description: string;
        };
        context_id: {
            type: string;
            minLength: number;
            description: string;
        };
        created_at: {
            type: string;
            format: string;
            description: string;
        };
        name: {
            type: string;
            description: string;
        };
        description: {
            type: string;
            description: string;
        };
        domain: {
            type: string;
            description: string;
        };
        source: {
            type: string;
            required: string[];
            properties: {
                platform: {
                    type: string;
                };
                url: {
                    type: string;
                };
                timestamp: {
                    type: string;
                    format: string;
                };
                model: {
                    type: string;
                };
                creator: {
                    type: string;
                };
            };
        };
        intent: {
            type: string;
            required: string[];
            properties: {
                primary: {
                    type: string;
                };
                status: {
                    type: string;
                    enum: string[];
                };
                secondary: {
                    type: string;
                    items: {
                        type: string;
                    };
                };
                limitations: {
                    type: string;
                    items: {
                        type: string;
                    };
                };
            };
        };
        constraints: {
            type: string;
            items: {
                type: string;
                required: string[];
                properties: {
                    id: {
                        type: string;
                    };
                    rule: {
                        type: string;
                        enum: string[];
                    };
                    value: {
                        type: string;
                    };
                    rationale: {
                        type: string;
                    };
                    severity: {
                        type: string;
                        enum: string[];
                    };
                    reference: {
                        type: string;
                    };
                };
            };
        };
        entities: {
            type: string;
            items: {
                type: string;
                required: string[];
                properties: {
                    name: {
                        type: string;
                    };
                    type: {
                        type: string;
                    };
                    category: {
                        type: string;
                    };
                    attributes: {
                        type: string;
                    };
                    relationships: {
                        type: string;
                        items: {
                            type: string;
                            properties: {
                                type: {
                                    type: string;
                                };
                                target: {
                                    type: string;
                                };
                            };
                        };
                    };
                };
            };
        };
        evidence: {
            type: string;
            items: {
                type: string;
                required: string[];
                properties: {
                    type: {
                        type: string;
                        enum: string[];
                    };
                    content: {
                        type: string;
                    };
                    source: {
                        type: string;
                    };
                    timestamp: {
                        type: string;
                    };
                    confidence: {
                        type: string;
                        minimum: number;
                        maximum: number;
                    };
                };
            };
        };
        verification: {
            type: string;
            required: string[];
            properties: {
                canonical_hash: {
                    type: string;
                };
                semantic_invariants: {
                    type: string;
                    items: {
                        type: string;
                        required: string[];
                    };
                };
                policy: {
                    type: string;
                    required: string[];
                };
            };
        };
        dependencies: {
            type: string;
            items: {
                type: string;
                required: string[];
                properties: {
                    crystal_id: {
                        type: string;
                    };
                    version: {
                        type: string;
                    };
                    type: {
                        type: string;
                        enum: string[];
                    };
                    scope: {
                        type: string;
                        enum: string[];
                    };
                    reason: {
                        type: string;
                    };
                };
            };
        };
        version: {
            type: string;
            pattern: string;
        };
        tier: {
            type: string;
            enum: string[];
        };
        author: {
            type: string;
            required: string[];
            properties: {
                id: {
                    type: string;
                };
                name: {
                    type: string;
                };
                reputation: {
                    type: string;
                    minimum: number;
                    maximum: number;
                };
                verified_credentials: {
                    type: string;
                    items: {
                        type: string;
                    };
                };
            };
        };
        supersedes: {
            type: string;
        };
        deprecated: {
            type: string;
        };
        tags: {
            type: string;
            items: {
                type: string;
            };
        };
        extensions: {
            type: string;
        };
        metadata: {
            type: string;
        };
    };
    additionalProperties: boolean;
};
export declare function validateCrystalFormat(crystal: any): {
    valid: boolean;
    errors: string[];
};
/**
 * Canonical JSON stringify to ensure consistent hashing.
 * Sorts all object keys alphabetically.
 */
export declare function canonicalStringify(obj: any): string;
export declare const CrystalFormat: {
    version: string;
    schema: {
        $schema: string;
        title: string;
        type: string;
        required: string[];
        properties: {
            scp_version: {
                type: string;
                pattern: string;
                description: string;
            };
            context_id: {
                type: string;
                minLength: number;
                description: string;
            };
            created_at: {
                type: string;
                format: string;
                description: string;
            };
            name: {
                type: string;
                description: string;
            };
            description: {
                type: string;
                description: string;
            };
            domain: {
                type: string;
                description: string;
            };
            source: {
                type: string;
                required: string[];
                properties: {
                    platform: {
                        type: string;
                    };
                    url: {
                        type: string;
                    };
                    timestamp: {
                        type: string;
                        format: string;
                    };
                    model: {
                        type: string;
                    };
                    creator: {
                        type: string;
                    };
                };
            };
            intent: {
                type: string;
                required: string[];
                properties: {
                    primary: {
                        type: string;
                    };
                    status: {
                        type: string;
                        enum: string[];
                    };
                    secondary: {
                        type: string;
                        items: {
                            type: string;
                        };
                    };
                    limitations: {
                        type: string;
                        items: {
                            type: string;
                        };
                    };
                };
            };
            constraints: {
                type: string;
                items: {
                    type: string;
                    required: string[];
                    properties: {
                        id: {
                            type: string;
                        };
                        rule: {
                            type: string;
                            enum: string[];
                        };
                        value: {
                            type: string;
                        };
                        rationale: {
                            type: string;
                        };
                        severity: {
                            type: string;
                            enum: string[];
                        };
                        reference: {
                            type: string;
                        };
                    };
                };
            };
            entities: {
                type: string;
                items: {
                    type: string;
                    required: string[];
                    properties: {
                        name: {
                            type: string;
                        };
                        type: {
                            type: string;
                        };
                        category: {
                            type: string;
                        };
                        attributes: {
                            type: string;
                        };
                        relationships: {
                            type: string;
                            items: {
                                type: string;
                                properties: {
                                    type: {
                                        type: string;
                                    };
                                    target: {
                                        type: string;
                                    };
                                };
                            };
                        };
                    };
                };
            };
            evidence: {
                type: string;
                items: {
                    type: string;
                    required: string[];
                    properties: {
                        type: {
                            type: string;
                            enum: string[];
                        };
                        content: {
                            type: string;
                        };
                        source: {
                            type: string;
                        };
                        timestamp: {
                            type: string;
                        };
                        confidence: {
                            type: string;
                            minimum: number;
                            maximum: number;
                        };
                    };
                };
            };
            verification: {
                type: string;
                required: string[];
                properties: {
                    canonical_hash: {
                        type: string;
                    };
                    semantic_invariants: {
                        type: string;
                        items: {
                            type: string;
                            required: string[];
                        };
                    };
                    policy: {
                        type: string;
                        required: string[];
                    };
                };
            };
            dependencies: {
                type: string;
                items: {
                    type: string;
                    required: string[];
                    properties: {
                        crystal_id: {
                            type: string;
                        };
                        version: {
                            type: string;
                        };
                        type: {
                            type: string;
                            enum: string[];
                        };
                        scope: {
                            type: string;
                            enum: string[];
                        };
                        reason: {
                            type: string;
                        };
                    };
                };
            };
            version: {
                type: string;
                pattern: string;
            };
            tier: {
                type: string;
                enum: string[];
            };
            author: {
                type: string;
                required: string[];
                properties: {
                    id: {
                        type: string;
                    };
                    name: {
                        type: string;
                    };
                    reputation: {
                        type: string;
                        minimum: number;
                        maximum: number;
                    };
                    verified_credentials: {
                        type: string;
                        items: {
                            type: string;
                        };
                    };
                };
            };
            supersedes: {
                type: string;
            };
            deprecated: {
                type: string;
            };
            tags: {
                type: string;
                items: {
                    type: string;
                };
            };
            extensions: {
                type: string;
            };
            metadata: {
                type: string;
            };
        };
        additionalProperties: boolean;
    };
    validate: typeof validateCrystalFormat;
    canonicalStringify: typeof canonicalStringify;
};
