/**
 * UNIVERSAL SEMANTIC IMPOSSIBILITY DETECTION (uSID)
 * Constraint Computing for AI - v0.1
 */
export type ConstraintType = 'FORMAT' | 'CONTENT' | 'PROHIBITION' | 'CAPABILITY' | 'TIME' | 'EVIDENCE' | 'CERTAINTY' | 'IDENTITY';
export type ConstraintOp = '=' | '!=' | 'contains' | 'in' | 'not_in' | '<=' | '>=' | 'implies';
export interface UniversalConstraint {
    id: string;
    type: ConstraintType;
    key: string;
    op: ConstraintOp;
    value: any;
    source_snippet?: string;
}
export interface SystemCapabilities {
    web_browse: boolean;
    send_email: boolean;
    filesystem_access: boolean;
    real_time_access: boolean;
    execute_code: boolean;
    financial_actions: boolean;
    probabilistic_nature: boolean;
}
export interface ConflictRepair {
    change: string;
    effect: string;
}
export interface UnsatCoreItem {
    constraint_id: string;
    constraint_desc: string;
    conflict_reason: string;
}
export interface uSidResult {
    status: 'SAT' | 'UNSAT' | 'UNKNOWN';
    normalized_intent?: {
        action: string;
        constraints: UniversalConstraint[];
    };
    message?: string;
    unsat_core?: UnsatCoreItem[];
    minimal_conflict_set?: string[];
    repair_options?: ConflictRepair[];
}
export declare const DEFAULT_CAPABILITIES: SystemCapabilities;
