import 'dotenv/config';
export declare function runComparativeStudy(): Promise<{
    neural_bridge_wins: number;
    traditional_wins: number;
    results: {
        neural_bridge: {
            crystal_hash: string;
            crystal_id: string;
        };
        traditional: {};
    }[];
    metrics: {
        neural_bridge: {
            has_crypto_proof: boolean;
            has_audit_trail: boolean;
            avg_sri: number;
            avg_pac_epsilon: number;
        };
        traditional: {
            has_crypto_proof: boolean;
            has_audit_trail: boolean;
        };
    };
    proof_hash: string;
}>;
