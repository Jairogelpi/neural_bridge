/**
 * SEMANTIC MERKLE TREES (SMT)
 *
 * Revolutionary feature: Hash of MEANING, not bytes.
 *
 * Key capabilities:
 * 1. Two documents with same meaning = same semantic hash
 * 2. Detects paraphrases (semantically equivalent)
 * 3. Detects contradictions
 * 4. Detects plagiarism (semantic similarity)
 * 5. Auditable truth tree
 *
 * How it works:
 * - Extract semantic features (entities, numbers, relationships, claims)
 * - Normalize to canonical form (removes stylistic variations)
 * - Hash the canonical meaning, not the raw text
 * - Build Merkle tree from semantic nodes
 */
export interface SemanticFeature {
    type: 'entity' | 'number' | 'claim' | 'relationship' | 'temporal' | 'negation' | 'location' | 'composition';
    canonical: string;
    original: string;
    confidence: number;
    position: number;
}
export interface SemanticNode {
    id: string;
    semantic_hash: string;
    features: SemanticFeature[];
    children: string[];
    parent?: string;
    depth: number;
}
export interface SemanticMerkleTree {
    smt_version: '1.0';
    tree_id: string;
    created_at: string;
    root: {
        semantic_hash: string;
        feature_count: number;
        depth: number;
    };
    nodes: Map<string, SemanticNode>;
    document: {
        original_hash: string;
        semantic_hash: string;
        word_count: number;
        claim_count: number;
    };
    claims: Array<{
        id: string;
        canonical: string;
        original: string;
        semantic_hash: string;
        evidence: string[];
    }>;
}
export interface SemanticComparisonResult {
    semantic_similarity: number;
    paraphrase_detected: boolean;
    contradiction_detected: boolean;
    plagiarism_score: number;
    matching_claims: Array<{
        doc1_claim: string;
        doc2_claim: string;
        similarity: number;
        relationship: 'equivalent' | 'paraphrase' | 'contradiction' | 'related' | 'unrelated';
    }>;
    contradictions: Array<{
        claim1: string;
        claim2: string;
        reason: string;
    }>;
    comparison_proof: {
        doc1_semantic_hash: string;
        doc2_semantic_hash: string;
        comparison_hash: string;
        timestamp: string;
    };
}
export declare class SemanticExtractor {
    /**
     * Extract semantic features from text
     * These features represent MEANING, not surface form
     */
    static extract(text: string): SemanticFeature[];
    private static extractNumbers;
    private static normalizeUnit;
    private static extractEntities;
    private static extractClaims;
    private static extractRelationships;
    private static extractTemporals;
    private static extractNegations;
    private static normalizeText;
    /**
     * Extract location and spatial information
     */
    private static extractLocations;
    /**
     * Extract composition and part-whole relationships
     */
    private static extractCompositions;
    /**
     * Extract explicit definitions from text
     */
    private static extractDefinitions;
}
export declare class SemanticHasher {
    /**
     * Create a semantic hash from features
     * Same meaning = same hash (regardless of wording)
     */
    static hash(features: SemanticFeature[]): Promise<string>;
    /**
     * Calculate semantic similarity between two feature sets
     */
    static similarity(features1: SemanticFeature[], features2: SemanticFeature[]): number;
    /**
     * Check if two documents are paraphrases (same meaning, different words)
     */
    static isParaphrase(text1: string, text2: string, threshold?: number): Promise<boolean>;
    /**
     * Detect contradictions between two texts
     */
    static findContradictions(text1: string, text2: string): Array<{
        claim1: string;
        claim2: string;
        reason: string;
    }>;
}
export declare class SMTBuilder {
    private nodes;
    private claims;
    /**
     * Build a Semantic Merkle Tree from a document
     */
    build(text: string): Promise<SemanticMerkleTree>;
    private groupFeatures;
    private createNode;
    private buildTreeLevel;
    private extractClaims;
}
export declare class SMTRuntime {
    /**
     * Build a Semantic Merkle Tree from text
     */
    static build(text: string): Promise<SemanticMerkleTree>;
    /**
     * Compare two documents semantically
     */
    static compare(text1: string, text2: string): Promise<SemanticComparisonResult>;
    /**
     * Verify a claim against a truth tree
     */
    static verifyClaim(smt: SemanticMerkleTree, claim: string): Promise<{
        found: boolean;
        matching_claim?: SemanticMerkleTree['claims'][0] | undefined;
        semantic_match: boolean;
        confidence: number;
    }>;
    /**
     * Get audit trail for a semantic tree
     */
    static getAuditTrail(smt: SemanticMerkleTree): {
        tree_id: string;
        root_hash: string;
        claims: Array<{
            canonical: string;
            hash: string;
        }>;
        verification_path: string[];
    };
    private static calculateClaimSimilarity;
}
