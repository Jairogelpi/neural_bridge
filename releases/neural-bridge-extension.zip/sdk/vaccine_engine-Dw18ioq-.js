import { A as v, s as l, a as p } from "./index-kfgM1LPn.js";
class I {
  /**
   * Extracts the "Logical DNA" of a contradiction and creates a vaccine.
   */
  static async synthesizeFromContradiction(t, a) {
    console.log(`[VaccineEngine] 💉 Analyzing contradiction for context ${t.context_id}...`);
    const { SemanticHasher: i } = await import("./index-kfgM1LPn.js").then((s) => s.k), { Hypervector: c } = await import("./index-kfgM1LPn.js").then((s) => s.j), m = c.fromString(i.computeHolographicHash(a.claim_a)), h = c.fromString(i.computeHolographicHash(a.claim_b)), n = m.bind(h), r = await v.realSHA256(n.toString()), { data: o } = await l.from("vaccines").select("*").eq("error_signature_hash", r).single();
    if (o)
      return console.log("[VaccineEngine] ⚡ Vaccine already exists for this pattern. Strengthening..."), await l.rpc("increment_vaccine_potency", { vid: o.vaccine_id }), o;
    const d = `
        LOGICAL DNA EXTRACTION
        
        A contradiction was found in an AI-generated knowledge crystal:
        CLAIM A: "${a.claim_a}"
        CLAIM B: "${a.claim_b}"
        
        Task: Identify the underlying LOGICAL FALLACY (e.g., Causal Reversal, Temporal Inconsistency, Scope Creep).
        Then, write a UNIVERSAL RULE (Meta-Invariant) that prevents this specific logical error.
        
        Return JSON:
        {
            "fallacy": "string",
            "rule": "High-level human readable rule",
            "logical_constraint": "Precise mathematical/logical constraint",
            "pattern_to_block": "Semantic pattern that triggers this error"
        }
        `, f = await p.resilientCallLLM(d, "google/gemini-pro", "You are a Formal Logician.");
    let e;
    try {
      e = JSON.parse(f.content);
    } catch {
      return null;
    }
    const g = {
      error_signature_hash: r,
      fallacy_type: e.fallacy,
      meta_invariant: {
        rule: e.rule,
        logical_constraint: e.logical_constraint,
        prohibited_pattern: e.pattern_to_block
      },
      context_domain: t.domain || "general"
    }, { error: u } = await l.from("vaccines").insert({
      ...g,
      meta_invariant: g.meta_invariant
    });
    if (u)
      return console.error("[VaccineEngine] ❌ Failed to store vaccine:", u.message), null;
    console.log(`[VaccineEngine] ✅ New Vaccine synthesized: ${e.fallacy} ("${e.rule}")`);
    const { Sentinel: _ } = await import("./index-kfgM1LPn.js").then((s) => s.l);
    return await _.emit({
      type: "VACCINE_SYNTHESIS",
      severity: "info",
      message: `New Vaccine synthesized for ${e.fallacy}: "${e.rule}"`,
      details: { fallacy: e.fallacy, rule: e.rule, domain: t.domain }
    }), await _.triggerEntanglement(g.vaccine_id || r), g;
  }
  /**
   * 🔮 PRECOGNITIVE VACCINATION
   * Synthesizes a vaccine for a failure that hasn't happened yet (predicted by the Oracle).
   */
  static async synthesizePrecognitiveVaccine(t, a) {
    console.log(`[VaccineEngine] 🔮 Precognitive synthesis for predicted error: "${a}"`);
    const i = `PRECOGNITIVE_FAILURE: [${a}] in DOMAIN: [${t.domain}]`, c = await (await import("./index-kfgM1LPn.js").then((o) => o.i)).Attestation.realSHA256(i), m = `
        PRECOGNITIVE DNA EXTRACTION
        
        The Oracle predicted a future failure in an AI knowledge crystal:
        PREDICTED FAILURE: "${a}"
        DOMAIN: "${t.domain}"
        
        Task: Identify the underlying LOGICAL FALLACY that would cause this.
        Write a UNIVERSAL RULE (Meta-Invariant) to BLOCK this failure before it ever happens.
        
        Return JSON:
        {
            "fallacy": "string",
            "rule": "High-level human readable rule",
            "logical_constraint": "Precise mathematical/logical constraint",
            "pattern_to_block": "Semantic pattern that triggers this error"
        }
        `, h = await p.resilientCallLLM(m, "google/gemini-pro", "You are a Precognitive Logician.");
    let n;
    try {
      n = JSON.parse(h.content);
    } catch {
      return null;
    }
    const r = {
      error_signature_hash: c,
      fallacy_type: n.fallacy,
      meta_invariant: {
        rule: n.rule,
        logical_constraint: n.logical_constraint,
        prohibited_pattern: n.pattern_to_block
      },
      context_domain: t.domain || "general"
    };
    return await l.from("vaccines").insert({
      ...r,
      meta_invariant: r.meta_invariant
    }), console.log(`[VaccineEngine] 💉 PRE-IMMUNIZED: System is now protected against "${n.fallacy}" (Oracle Prediction).`), r;
  }
  /**
   * Returns relevant vaccines for a given source text to be used as pre-emptive guards.
   */
  static async getActiveGuards(t, a) {
    const { data: i, error: c } = await l.from("vaccines").select("*").eq("context_domain", a).order("severity", { ascending: !1 }).limit(5);
    return c || !i ? [] : i;
  }
}
export {
  I as VaccineEngine
};
//# sourceMappingURL=vaccine_engine-Dw18ioq-.js.map
