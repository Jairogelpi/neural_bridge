"use strict";Object.defineProperty(exports,Symbol.toStringTag,{value:"Module"});const u=require("./index-BTB1CzpV.cjs"),E=require("./falsification-OnLHwftf.cjs");class n{static async evolve(i,t){console.log(`[Hegel] 🧬 Starting Dialectical Evolution for: "${i.substring(0,40)}..."`);let e=i;const r=[],a=3;for(let s=1;s<=a;s++){console.log(`[Hegel] Round ${s}: Challenging Thesis...`);const o=await E.FalsificationEngine.challenge(e,t);if(o.survived){console.log(`[Hegel] ✅ Thesis survived Round ${s}. Evolution complete.`);const y=await n.calculateFreeEnergy(e,t);return{final_thesis:e,iterations:s,history:r,is_resilient:!0,final_free_energy:y,final_accuracy:1}}console.log(`[Hegel] ⚠️ Thesis destroyed by: "${o.attack_vector}". Synthesizing new truth...`);const g=`
            THE NEUROMORPHIC DIALECTIC (Active Inference Mode)
            
            Current Thesis (Thesis): "${e}"
            Prediction Error (Attack): "${o.attack_vector}"
            Context: "${t.substring(0,500)}..."
            
            OBJECTIVE: Propose a synthesis that minimizes Variational Free Energy.
            This means:
            1. ACCURACY: It must fully resolve the prediction error (the attack).
            2. COMPLEXITY: It must be as simple as possible (Minimum Description Length).
            
            Return ONLY the new synthesized Thesis string. No markdown.
            `,c=(await u.SCPService.resilientCallLLM(g,"anthropic/claude-3.5-sonnet","You are a Variational Free Energy Optimizer.")).content.trim(),h=await n.calculateFreeEnergy(e,t),f=await n.calculateFreeEnergy(c,t)-h;console.log(`[Hegel] 🧠 Free Energy Delta: ${f.toFixed(4)} (Objective: < 0)`),r.push({round:s,thesis:e,attack:o.attack_vector,synthesis:c}),console.log(`[Hegel] 🔄 Evolved Thesis: "${c.substring(0,50)}..."`),e=c}const l=await n.calculateFreeEnergy(e,t);return{final_thesis:e,iterations:a,history:r,is_resilient:!1,final_free_energy:l,final_accuracy:.5}}static async calculateFreeEnergy(i,t){const e=Math.log2(i.length+1)*.1,r=`
        SCORE THE ACCURACY of this thesis against the provided context.
        Thesis: "${i}"
        Context: "${t.substring(0,1e3)}..."
        
        Return a single number between 0 and 1, where 1 is "perfect explanation" 
        and 0 is "irrelevant or wrong".
        RETURN ONLY THE NUMBER.
        `,a=await u.SCPService.resilientCallLLM(r,"google/gemini-2.0-flash-exp:free","Semantic Accuracy Scorer"),l=parseFloat(a.content.trim())||.1;return e-l}}exports.DialecticalEngine=n;
//# sourceMappingURL=dialectical_engine-B_rCJN9R.cjs.map
