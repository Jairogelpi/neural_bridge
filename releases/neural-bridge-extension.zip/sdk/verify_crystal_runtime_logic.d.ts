export declare function runGrandRealityDemo(): Promise<{
    tech: import("./sdk").CrystalExecutionResult;
    medical: import("./sdk").CrystalExecutionResult;
    proof: {
        session_id: string;
        timestamp: string;
        crystals: {
            tech: {
                id: string;
                hash: string;
            };
            med: {
                id: string;
                hash: string;
            };
        };
        verifications: {
            tech: {
                passed: boolean;
                sri: number;
                issues: string[];
            };
            med: {
                passed: boolean;
                sri: number;
                issues: string[];
            };
        };
        metrics: {
            total_time_ms: number;
            llm_calls: number;
            total_tokens: number;
            total_cost: number;
        };
    };
    sessionHash: string;
}>;
