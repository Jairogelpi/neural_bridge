import type { ContextCrystal } from "./scp_types";
export interface VerificationResult {
    context_id: string;
    score: number;
    status: "ACCEPT" | "RETRY" | "FAIL";
    checks: Record<string, boolean>;
}
export interface LadderStep {
    id: string;
    prompt: string;
    type: "compact" | "redundant" | "sectioned";
}
/**
 * Verification Ladder (i1..i8 Handshake)
 * Generates the prompt used to inject the crystal into a target LLM.
 */
export declare function buildHandshakePrompt(crystal: ContextCrystal, strategy?: "compact" | "redundant"): string;
/**
 * Parses the LLM's response to verify the handshake.
 */
export declare function verifyHandshakeResponse(text: string, crystal: ContextCrystal): VerificationResult;
