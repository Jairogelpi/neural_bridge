export declare function sha256Hex(text: string): Promise<string>;
export declare function computeEvidenceFingerprints(content: string): Promise<{
    sha256: string;
    rolling64_dec: string;
}>;
