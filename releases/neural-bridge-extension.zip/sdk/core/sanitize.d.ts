export declare function wrapDataBlock(label: string, data: string): string;
