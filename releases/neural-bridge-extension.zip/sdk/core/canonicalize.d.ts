/**
 * Standardizes a string for deterministic hashing.
 */
export declare function canonicalize(text: string): string;
/**
 * Computes a deterministic hash of the crystal content.
 * Recursively canonicalizes keys and values for SCP sealing.
 */
export declare function computeCanonicalHash(crystal: unknown): Promise<string>;
