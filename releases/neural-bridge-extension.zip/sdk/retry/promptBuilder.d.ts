import type { LadderLevel, InvariantV2 } from "./types";
export declare function buildChallengePrompt(params: {
    level: LadderLevel;
    crystalJSON: string;
    invariants: InvariantV2[];
    canonicalHash: string;
}): string;
