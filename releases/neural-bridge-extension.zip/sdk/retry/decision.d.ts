import type { LadderLevel, RetryDecision } from "./types";
export interface DecisionInput {
    score: number;
    acceptThreshold: number;
    strictFailures: string[];
    level: LadderLevel;
    attemptIndex: number;
}
export interface DecisionResult {
    decision: RetryDecision;
    reason: string;
    nextLevel?: LadderLevel;
}
export declare function decide(input: DecisionInput): DecisionResult;
