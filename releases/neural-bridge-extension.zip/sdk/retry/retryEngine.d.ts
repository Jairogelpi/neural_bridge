import type { LadderAttempt, InvariantV2, RetryDecision } from "./types";
export interface VerifierFunction {
    (parsedResponse: any): {
        score: number;
        strictFailures: string[];
    };
}
export interface HostBridge {
    send: (prompt: string) => Promise<void>;
    readLastAssistantMessage: () => Promise<string>;
}
export interface RunVerifiedBridgeParams {
    crystal: any;
    invariants: InvariantV2[];
    canonicalHash: string;
    acceptThreshold: number;
    maxTotalAttempts?: number;
    verifier: VerifierFunction;
    host: HostBridge;
    onAttempt?: (attempt: LadderAttempt) => void;
}
export interface RunVerifiedBridgeResult {
    ok: boolean;
    score: number;
    decision: RetryDecision;
    attempts: LadderAttempt[];
    finalParsed?: any;
}
export declare function runVerifiedBridge(params: RunVerifiedBridgeParams): Promise<RunVerifiedBridgeResult>;
export declare function createBackendVerifier(invariants: InvariantV2[]): VerifierFunction;
