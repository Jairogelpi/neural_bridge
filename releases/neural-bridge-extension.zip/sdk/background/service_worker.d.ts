type BridgeState = {
    activeContextId?: string;
    lastHost?: string;
};
declare const STATE_KEY = "nb_state_v1";
declare function getState(): Promise<BridgeState>;
declare function setState(patch: Partial<BridgeState>): Promise<void>;
