/**
 * Logical operators for invariant composition
 */
export type LogicalOperator = "AND" | "OR" | "NOT" | "IMPLIES" | "IFF";
/**
 * Quantifiers for invariant scope
 */
export type Quantifier = "FORALL" | "EXISTS" | "UNIQUE";
/**
 * Base predicate that can be evaluated
 */
export interface Predicate {
    id: string;
    name: string;
    arity: number;
    domain: string;
    evaluate: (args: unknown[]) => boolean | Promise<boolean>;
}
/**
 * First-order logic formula
 */
export interface FOLFormula {
    type: "atomic" | "compound" | "quantified";
    predicate?: Predicate;
    args?: unknown[];
    operator?: LogicalOperator;
    operands?: FOLFormula[];
    quantifier?: Quantifier;
    variable?: string;
    scope?: FOLFormula;
}
/**
 * Invariant expressed in first-order logic
 */
export interface FOLInvariant {
    id: string;
    kind: "fact" | "constraint" | "boundary" | "state" | "objective" | "preference";
    formula: FOLFormula;
    naturalLanguage: string;
    weight: number;
    strict: boolean;
}
/**
 * Standard predicates for LLM verification
 */
export declare const StandardPredicates: Record<string, Predicate>;
/**
 * Build an atomic formula
 */
export declare function atomic(predicate: Predicate, ...args: unknown[]): FOLFormula;
/**
 * Build a conjunction (AND)
 */
export declare function and(...formulas: FOLFormula[]): FOLFormula;
/**
 * Build a disjunction (OR)
 */
export declare function or(...formulas: FOLFormula[]): FOLFormula;
/**
 * Build a negation (NOT)
 */
export declare function not(formula: FOLFormula): FOLFormula;
/**
 * Build an implication (P → Q)
 */
export declare function implies(antecedent: FOLFormula, consequent: FOLFormula): FOLFormula;
/**
 * Build a universal quantification (∀x. P(x))
 */
export declare function forall(variable: string, scope: FOLFormula): FOLFormula;
/**
 * Build an existential quantification (∃x. P(x))
 */
export declare function exists(variable: string, scope: FOLFormula): FOLFormula;
/**
 * Evaluate a FOL formula
 */
export declare function evaluateFormula(formula: FOLFormula, bindings?: Record<string, unknown>): Promise<boolean>;
/**
 * Convert FOL formula to human-readable string
 */
export declare function formulaToString(formula: FOLFormula): string;
/**
 * Example: Build invariant "User's name is Alice"
 */
export declare function exampleFactInvariant(): FOLInvariant;
/**
 * Example: Build constraint "All prices are in USD"
 */
export declare function exampleConstraintInvariant(): FOLInvariant;
