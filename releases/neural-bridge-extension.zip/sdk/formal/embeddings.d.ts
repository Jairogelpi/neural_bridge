export interface EmbeddingResult {
    embedding: number[];
    tokens: number;
    model: string;
}
/**
 * Get embedding vector for text using OpenRouter
 */
export declare function getEmbedding(text: string, apiKey: string): Promise<EmbeddingResult | null>;
/**
 * Calculate cosine similarity between two embedding vectors
 */
export declare function cosineSimilarity(a: number[], b: number[]): number;
/**
 * Calculate semantic distance (1 - cosine similarity)
 */
export declare function semanticDistanceFromEmbeddings(a: number[], b: number[]): number;
/**
 * Compare original conversation with reconstructed context
 * Returns semantic fidelity score (0-1, higher is better)
 */
export declare function measureSemanticFidelity(originalText: string, reconstructedText: string, apiKey: string): Promise<{
    fidelity: number;
    distance: number;
} | null>;
/**
 * Batch embed multiple texts for efficiency
 */
export declare function batchEmbed(texts: string[], apiKey: string): Promise<number[][]>;
/**
 * Calculate average pairwise similarity in a set of texts
 * Useful for measuring invariant coherence
 */
export declare function clusterCoherence(texts: string[], apiKey: string): Promise<number>;
