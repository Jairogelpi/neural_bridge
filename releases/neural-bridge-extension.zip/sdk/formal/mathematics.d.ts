import type { InvariantV2 } from "../retry/types";
/**
 * Calculate PAC bound for verification score
 *
 * Theorem 2: If we test k invariants with score ≥ θ, then with probability ≥ 1-δ:
 * P(success) ≥ θ - √(ln(1/δ) / 2k)
 *
 * @param observedScore - The observed invariant score (0-1)
 * @param numInvariants - Number of invariants tested (k)
 * @param confidence - Confidence level (1-δ), e.g., 0.95
 * @returns Lower bound on true success probability
 */
export declare function pacLowerBound(observedScore: number, numInvariants: number, confidence?: number): number;
/**
 * Calculate confidence interval for fidelity score
 *
 * @param score - Observed score (0-1)
 * @param k - Number of invariants
 * @param z - Z-score (1.96 for 95% CI)
 * @returns [lower, upper] bounds
 */
export declare function confidenceInterval(score: number, k: number, z?: number): [number, number];
/**
 * Calculate optimal threshold based on cost tradeoff
 *
 * Theorem 3: θ* = β / (α + β) where α = cost of false positive, β = cost of false negative
 *
 * @param costFalsePositive - Cost of accepting when should reject (α)
 * @param costFalseNegative - Cost of rejecting when should accept (β)
 * @returns Optimal threshold
 */
export declare function optimalThreshold(costFalsePositive: number, costFalseNegative: number): number;
/**
 * Calculate optimal number of ladder levels
 *
 * Theorem 5: L* = ⌈log(1/δ) / log(1/(1-p₀))⌉
 *
 * @param baseSuccessRate - Success rate at level 0 (p₀)
 * @param targetConfidence - Target probability of eventual success (1-δ)
 * @returns Optimal number of levels
 */
export declare function optimalLadderLevels(baseSuccessRate: number, targetConfidence?: number): number;
/**
 * Information content of Crystal (bits)
 * Approximation: tokens × log2(vocab_size)
 *
 * @param crystalTokens - Number of tokens in crystal
 * @param vocabSize - Vocabulary size (default GPT-4: ~100k)
 */
export declare function crystalEntropy(crystalTokens: number, vocabSize?: number): number;
/**
 * Compression ratio relative to original conversation
 *
 * @param originalTokens - Tokens in original conversation
 * @param crystalTokens - Tokens in crystal
 */
export declare function compressionRatio(originalTokens: number, crystalTokens: number): number;
/**
 * Calculate semantic distance using cosine similarity
 * (To be used with actual embedding vectors)
 *
 * @param vecA - Embedding vector A
 * @param vecB - Embedding vector B
 * @returns Semantic distance (0 = identical, 1 = orthogonal)
 */
export declare function semanticDistance(vecA: number[], vecB: number[]): number;
/**
 * Verify that invariant score predicts fidelity within bounds
 *
 * Theorem 4: d_semantic ≤ L * (1 - s) + ε
 *
 * @param score - Invariant score
 * @param lipschitzConstant - Estimated L (typically 1-2)
 * @param epsilon - Noise floor (typically 0.05)
 * @returns Maximum expected semantic distance
 */
export declare function maxSemanticDistance(score: number, lipschitzConstant?: number, epsilon?: number): number;
/**
 * Calculate invariant completeness score
 *
 * A complete invariant set should cover all aspects:
 * - Facts (existence of key information)
 * - Constraints (rules that must hold)
 * - Boundaries (things to avoid)
 * - State (current progress/context)
 */
export declare function invariantCompleteness(invariants: InvariantV2[]): {
    completeness: number;
    coverage: Record<string, number>;
    missing: string[];
};
/**
 * Calculate expected success rate for ladder level
 *
 * Model: p_l = p₀ + Δp * l (linear improvement)
 */
export declare function ladderLevelSuccessRate(level: number, baseRate?: number, improvementPerLevel?: number): number;
/**
 * Calculate expected cost for ladder level
 *
 * Model: c_l = c₀ * (1 + μ)^l (exponential cost)
 */
export declare function ladderLevelCost(level: number, baseCost?: number, // USD
costMultiplier?: number): number;
/**
 * Compute verification summary with formal guarantees
 */
export interface VerificationSummary {
    observedScore: number;
    numInvariants: number;
    pacLowerBound: number;
    confidenceInterval: [number, number];
    maxSemanticDistance: number;
    completeness: number;
    isProvablySound: boolean;
}
export declare function computeVerificationSummary(score: number, invariants: InvariantV2[], confidence?: number): VerificationSummary;
