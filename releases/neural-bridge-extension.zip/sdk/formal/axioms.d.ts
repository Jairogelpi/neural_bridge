/**
 * AXIOM 1: Semantic Content Existence
 * Every conversation has semantic content
 */
export interface SemanticContent {
    hash: string;
    entities: string[];
    relations: Array<{
        from: string;
        to: string;
        type: string;
    }>;
    intents: string[];
    constraints: string[];
}
export declare function axiom1_semanticContentExists(conversation: string): Promise<SemanticContent>;
/**
 * AXIOM 2: Task-Relevant Subset
 * Minimal sufficient subset exists for any task
 */
export interface TaskRelevantSubset {
    taskId: string;
    requiredEntities: string[];
    requiredRelations: Array<{
        from: string;
        to: string;
        type: string;
    }>;
    requiredIntents: string[];
    isMinimal: boolean;
}
export declare function axiom2_taskRelevantSubset(content: SemanticContent, task: string): TaskRelevantSubset;
/**
 * AXIOM 3: Crystal Existence
 * Finite representation preserving task-relevant info always exists
 */
export interface Crystal {
    version: "SCP-1.0";
    hash: string;
    content: TaskRelevantSubset;
    size: number;
    compressionRatio: number;
}
export declare function axiom3_crystalExists(content: SemanticContent, task: string): Promise<Crystal>;
/**
 * AXIOM 4: Invariant Testability
 * All invariants are decidable
 */
export interface TestableInvariant {
    id: string;
    predicate: string;
    isDecidable: true;
    test: (response: Record<string, unknown>) => boolean;
    timeout: number;
}
export declare function axiom4_invariantIsDecidable(invariant: {
    id: string;
    prompt: string;
    expected: unknown;
}): TestableInvariant;
/**
 * AXIOM 5: Model Independence
 * Transfer works between any capable models
 */
export interface ModelCapability {
    modelId: string;
    contextWindow: number;
    capabilities: string[];
}
export declare function axiom5_transferPossible(source: ModelCapability, target: ModelCapability, crystalSize: number): boolean;
/**
 * AXIOM 6: Verification Correlation
 * Passing tests correlates with fidelity
 */
export interface VerificationResult {
    score: number;
    passedCount: number;
    totalCount: number;
    confidence: number;
    fidelityLowerBound: number;
}
export declare function axiom6_verificationCorrelation(score: number, k: number, delta?: number): VerificationResult;
/**
 * THEOREM 2: Minimum Invariants Required
 * k* ≥ ln(1/δ) / (2ε²)
 */
export declare function theorem2_minimumInvariants(epsilon: number, // Desired precision
delta: number): number;
/**
 * THEOREM 3: Retry Ladder Success Rate
 * P(success) = 1 - (1 - p₀)^L
 */
export declare function theorem3_ladderSuccessRate(baseRate: number, // p₀
levels: number): number;
/**
 * THEOREM 4: Semantic Distance Bound
 */
export declare function theorem4_distanceBound(score: number, k: number, lipschitz?: number, delta?: number): number;
/**
 * IMPOSSIBILITY 1: No Universal Invariant
 * Check that we're using multiple invariants
 */
export declare function impossibility1_check(invariantCount: number): void;
/**
 * IMPOSSIBILITY 2: Zero-Shot Verification
 * Verification requires at least one test
 */
export declare function impossibility2_check(testsRun: number): void;
/**
 * IMPOSSIBILITY 3: Compression Limit
 * Crystal cannot be smaller than entropy lower bound
 */
export declare function impossibility3_check(crystalBits: number, entropyLowerBound: number): void;
/**
 * P1: Termination Invariant
 */
export declare const PROTOCOL_P1_MAX_TIME_MS = 30000;
export declare function protocolP1_terminates<T>(operation: () => Promise<T>, timeout?: number): Promise<T>;
/**
 * P2: Determinism Invariant
 */
export declare function protocolP2_deterministic(input: string, salt: string): Promise<string>;
/**
 * P3: Monotonicity Invariant
 */
export declare function protocolP3_monotonicity(successRates: number[]): boolean;
/**
 * P4: Soundness Invariant
 */
export declare function protocolP4_soundness(score: number, threshold: number, epsilon?: number): boolean;
/**
 * P5: Completeness Invariant
 */
export declare function protocolP5_completeness(trueFidelity: number, threshold: number, margin?: number): boolean;
/**
 * P6: Independence Invariant
 */
export declare function protocolP6_independence(sourceModel: string, targetModel: string): boolean;
