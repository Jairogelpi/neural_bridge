var Qs = Object.defineProperty;
var Xs = (s, e, t) => e in s ? Qs(s, e, { enumerable: !0, configurable: !0, writable: !0, value: t }) : s[e] = t;
var K = (s, e, t) => Xs(s, typeof e != "symbol" ? e + "" : e, t);
import V from "crypto";
var ce = /* @__PURE__ */ ((s) => (s.ACTIVE = "active", s.DEPRECATED = "deprecated", s.SUPERSEDED = "superseded", s))(ce || {}), te = /* @__PURE__ */ ((s) => (s.MUST = "MUST", s.NEVER = "NEVER", s.IF_THEN = "IF_THEN", s.RANGE = "RANGE", s.ENUM = "ENUM", s.REGEX = "REGEX", s.CUSTOM = "CUSTOM", s))(te || {});
const cs = {
  $schema: "http://json-schema.org/draft-07/schema#",
  title: "Crystal Format v0.1",
  type: "object",
  required: [
    "scp_version",
    "context_id",
    "created_at",
    "source",
    "intent",
    "verification"
  ],
  properties: {
    scp_version: {
      type: "string",
      pattern: "^\\d+\\.\\d+$",
      description: "SCP version (e.g., '1.0')"
    },
    context_id: {
      type: "string",
      minLength: 1,
      description: "Unique identifier for this Crystal"
    },
    created_at: {
      type: "string",
      format: "date-time",
      description: "ISO 8601 timestamp"
    },
    name: {
      type: "string",
      description: "Human-readable name"
    },
    description: {
      type: "string",
      description: "Crystal description"
    },
    domain: {
      type: "string",
      description: "Domain classification"
    },
    source: {
      type: "object",
      required: ["platform", "url", "timestamp"],
      properties: {
        platform: { type: "string" },
        url: { type: "string" },
        timestamp: { type: "string", format: "date-time" },
        model: { type: "string" },
        creator: { type: "string" }
      }
    },
    intent: {
      type: "object",
      required: ["primary", "status"],
      properties: {
        primary: { type: "string" },
        status: {
          type: "string",
          enum: ["active", "deprecated", "superseded"]
        },
        secondary: {
          type: "array",
          items: { type: "string" }
        },
        limitations: {
          type: "array",
          items: { type: "string" }
        }
      }
    },
    constraints: {
      type: "array",
      items: {
        type: "object",
        required: ["id", "rule", "value", "rationale"],
        properties: {
          id: { type: "string" },
          rule: {
            type: "string",
            enum: ["MUST", "NEVER", "IF_THEN", "RANGE", "ENUM", "REGEX", "CUSTOM"]
          },
          value: { type: "string" },
          rationale: { type: "string" },
          severity: {
            type: "string",
            enum: ["critical", "high", "medium", "low"]
          },
          reference: { type: "string" }
        }
      }
    },
    entities: {
      type: "array",
      items: {
        type: "object",
        required: ["name", "type"],
        properties: {
          name: { type: "string" },
          type: { type: "string" },
          category: { type: "string" },
          attributes: { type: "object" },
          relationships: {
            type: "array",
            items: {
              type: "object",
              properties: {
                type: { type: "string" },
                target: { type: "string" }
              }
            }
          }
        }
      }
    },
    evidence: {
      type: "array",
      items: {
        type: "object",
        required: ["type", "content"],
        properties: {
          type: {
            type: "string",
            enum: ["quote", "fact", "source", "calculation", "reference"]
          },
          content: { type: "string" },
          source: { type: "string" },
          timestamp: { type: "string" },
          confidence: { type: "number", minimum: 0, maximum: 1 }
        }
      }
    },
    verification: {
      type: "object",
      required: ["canonical_hash", "semantic_invariants", "policy"],
      properties: {
        canonical_hash: { type: "string" },
        semantic_invariants: {
          type: "array",
          items: {
            type: "object",
            required: ["id", "kind", "prompt", "expected", "weight", "strict", "rationale"]
          }
        },
        policy: {
          type: "object",
          required: ["min_checks", "accept_threshold", "max_retries", "strategy"]
        }
      }
    },
    dependencies: {
      type: "array",
      items: {
        type: "object",
        required: ["crystal_id", "version", "type", "scope"],
        properties: {
          crystal_id: { type: "string" },
          version: { type: "string" },
          type: {
            type: "string",
            enum: ["requires", "extends", "conflicts_with"]
          },
          scope: {
            type: "string",
            enum: ["domain", "client", "project", "implementation"]
          },
          reason: { type: "string" }
        }
      }
    },
    version: { type: "string", pattern: "^\\d+\\.\\d+\\.\\d+$" },
    tier: {
      type: "string",
      enum: ["community", "verified", "certified", "trusted", "sovereign"]
    },
    author: {
      type: "object",
      required: ["id", "name", "reputation"],
      properties: {
        id: { type: "string" },
        name: { type: "string" },
        reputation: { type: "number", minimum: 0, maximum: 1 },
        verified_credentials: { type: "array", items: { type: "string" } }
      }
    },
    supersedes: { type: "string" },
    deprecated: { type: "boolean" },
    tags: {
      type: "array",
      items: { type: "string" }
    },
    extensions: { type: "object" },
    metadata: { type: "object" }
  },
  additionalProperties: !1
};
function ls(s) {
  const e = [];
  return s.scp_version || e.push("Missing scp_version"), s.context_id || e.push("Missing context_id"), s.created_at || e.push("Missing created_at"), s.source || e.push("Missing source"), s.intent || e.push("Missing intent"), s.verification || e.push("Missing verification"), s.version || e.push("Missing version"), s.tier || e.push("Missing tier"), s.author || e.push("Missing author"), s.source && (s.source.platform || e.push("source.platform is required"), s.source.url || e.push("source.url is required"), s.source.timestamp || e.push("source.timestamp is required")), s.intent && (s.intent.primary || e.push("intent.primary is required"), s.intent.status || e.push("intent.status is required"), s.intent.status && !["active", "deprecated", "superseded"].includes(s.intent.status) && e.push("intent.status must be active, deprecated, or superseded")), s.verification && (s.verification.canonical_hash || e.push("verification.canonical_hash is required"), Array.isArray(s.verification.semantic_invariants) || e.push("verification.semantic_invariants must be an array"), s.verification.policy || e.push("verification.policy is required")), {
    valid: e.length === 0,
    errors: e
  };
}
function Ve(s) {
  return s === null || typeof s != "object" ? JSON.stringify(s) : Array.isArray(s) ? "[" + s.map((r) => Ve(r)).join(",") + "]" : "{" + Object.entries(s).filter(([r, n]) => n !== void 0).sort(([r], [n]) => r.localeCompare(n)).map(([r, n]) => `"${r}":${Ve(n)}`).join(",") + "}";
}
const ct = {
  version: "0.1",
  schema: cs,
  validate: ls,
  canonicalStringify: Ve
}, Zs = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  ConstraintRule: te,
  CrystalFormat: ct,
  CrystalSchemaV01: cs,
  CrystalStatus: ce,
  canonicalStringify: Ve,
  validateCrystalFormat: ls
}, Symbol.toStringTag, { value: "Module" }));
async function us(s) {
  const { crystal: e, keyPair: t, capturer_id: r } = s, n = await fs(e), i = s.keyPair ?? await ps(), a = await gs(n, i.privateKey), o = await bt(i.publicKey);
  return {
    signature: a,
    public_key: o,
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    capturer_id: r,
    payload_hash: n
  };
}
async function hs(s) {
  const { crystal: e, signature: t } = s;
  if (await fs(e) !== t.payload_hash)
    return { valid: !1, reason: "payload_hash_mismatch" };
  try {
    const n = await St(t.public_key);
    return await ys(t.signature, t.payload_hash, n) ? { valid: !0 } : { valid: !1, reason: "invalid_signature" };
  } catch (n) {
    return { valid: !1, reason: `verification_error: ${n}` };
  }
}
function ds(s) {
  return {
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    action: s.action,
    actor: s.actor,
    details: s.details
  };
}
async function Fe(s) {
  const t = new TextEncoder().encode(s), r = await crypto.subtle.digest("SHA-256", t);
  return "0x" + Array.from(new Uint8Array(r)).map((i) => i.toString(16).padStart(2, "0")).join("");
}
async function fs(s) {
  var n;
  const { Hypervector: e } = await Promise.resolve().then(() => At), t = [];
  for (const i of ((n = s.verification) == null ? void 0 : n.semantic_invariants) || [])
    t.push(e.fromString(await Fe(i.prompt + JSON.stringify(i.expected))));
  if (t.length === 0) return await Fe(JSON.stringify(s));
  const r = e.bundle(t);
  return await Fe(r.toString());
}
async function ps() {
  return await crypto.subtle.generateKey(
    {
      name: "ECDSA",
      namedCurve: "P-256"
    },
    !0,
    ["sign", "verify"]
  );
}
async function gs(s, e) {
  const r = new TextEncoder().encode(s), n = await crypto.subtle.sign(
    { name: "ECDSA", hash: "SHA-256" },
    e,
    r
  );
  return "0x" + Array.from(new Uint8Array(n)).map((o) => o.toString(16).padStart(2, "0")).join("");
}
async function ms(s, e) {
  return gs(s, e);
}
async function ys(s, e, t) {
  const n = new TextEncoder().encode(e), i = vs(s);
  return await crypto.subtle.verify(
    { name: "ECDSA", hash: "SHA-256" },
    t,
    i,
    n
  );
}
async function _s(s, e, t) {
  return ys(e, s, t);
}
async function bt(s) {
  const e = await crypto.subtle.exportKey("raw", s);
  return "0x" + Array.from(new Uint8Array(e)).map((r) => r.toString(16).padStart(2, "0")).join("");
}
async function St(s) {
  const e = vs(s);
  return await crypto.subtle.importKey(
    "raw",
    e,
    { name: "ECDSA", namedCurve: "P-256" },
    !0,
    ["verify"]
  );
}
function vs(s) {
  const e = s.replace("0x", ""), t = new Uint8Array(e.length / 2);
  for (let r = 0; r < e.length; r += 2)
    t[r / 2] = parseInt(e.substr(r, 2), 16);
  return t;
}
const G = {
  signCrystal: us,
  verifyCrystalSignature: hs,
  createAuditEntry: ds,
  generateKeyPair: ps,
  realSHA256: Fe,
  signData: ms,
  verifySignature: _s,
  exportPublicKey: bt,
  importPublicKey: St
}, Qi = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Attestation: G,
  createAuditEntry: ds,
  exportPublicKey: bt,
  importPublicKey: St,
  signCrystal: us,
  signData: ms,
  verifyCrystalSignature: hs,
  verifySignature: _s
}, Symbol.toStringTag, { value: "Module" }));
class er {
  /**
   * Generate a cryptographically signed receipt of a decision.
   * This is the "Invoice of Truth".
   */
  static async generateDecisionReceipt(e) {
    const {
      crystal_refs: t,
      question: r,
      answer: n,
      verification_result: i,
      model_config: a,
      requester: o,
      author: c,
      reputation_impact: l = 0,
      sign: u = !0
    } = e, d = {
      receipt_id: `rcpt_${Math.random().toString(36).slice(2, 11)}`,
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      crystal_refs: t,
      question: r,
      answer: n,
      verification: i,
      model_config: a,
      requester: o,
      author: c,
      reputation_impact: l,
      signature: {
        alg: "ECDSA_P256_SHA256",
        payload_hash: "",
        signature: "",
        public_key: "PENDING",
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      }
    };
    if (u) {
      const h = { ...d };
      delete h.signature;
      const f = ct.canonicalStringify(h), p = await G.realSHA256(f), g = await G.generateKeyPair(), m = await G.signData(p, g.privateKey), y = await G.exportPublicKey(g.publicKey);
      d.signature = {
        alg: "ECDSA_P256_SHA256",
        payload_hash: p,
        signature: m,
        public_key: y,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      };
    }
    return d;
  }
  /**
   * Verify a decision receipt's cryptographic integrity.
   */
  static async verifyReceipt(e) {
    if (!e.signature || !e.signature.signature || e.signature.public_key === "PENDING")
      return !1;
    const t = { ...e };
    delete t.signature;
    const r = ct.canonicalStringify(t), n = await G.realSHA256(r);
    try {
      const i = await G.importPublicKey(e.signature.public_key);
      return await G.verifySignature(
        n,
        e.signature.signature,
        i
      );
    } catch (i) {
      return console.error("Receipt verification failed:", i), !1;
    }
  }
}
const tr = {
  web_browse: !1,
  send_email: !1,
  filesystem_access: !1,
  real_time_access: !1,
  execute_code: !1,
  financial_actions: !1,
  probabilistic_nature: !0
};
class ws {
  /**
   * COMPILER: Transforms natural language intent into Logic Constraints
   */
  static async compileIntent(e, t = "general") {
    console.log(`[uSID] Compiling Intent for domain '${t}': "${e}"`);
    const { ExpertRegistry: r } = await import("./expert_registry-C99NCMeY.js"), i = (await r.findBestJudges(t))[0] || "anthropic/claude-3.5-sonnet", a = `
        You are a LOGIC COMPILER. Translate User Intent into UNIVERSAL CONSTRAINTS.
        Return ONLY the JSON array.
        `;
    try {
      const o = await M.resilientCallLLM(e, i, a);
      return JSON.parse(o.content);
    } catch {
      return [];
    }
  }
  /**
   * SOLVER: Checks if the constraints are Satisfiable (SAT)
   */
  static async solve(e, t = tr) {
    const r = await this.compileIntent(e);
    if (r.length === 0) return { status: "UNKNOWN", message: "Could not parse constraints" };
    const n = [], i = [];
    r.forEach((o) => {
      o.type === "CAPABILITY" && o.key === "requires" && (Array.isArray(o.value) ? o.value : [o.value]).forEach((l) => {
        t[l] === !1 && (n.push({
          constraint_id: o.id,
          constraint_desc: `Requires capability: ${l}`,
          conflict_reason: `System capability '${l}' is DISABLED/MISSING.`
        }), i.push(o.id));
      });
    });
    const a = r.find((o) => o.type === "CERTAINTY" && (o.value === "absolute" || o.value === "100%"));
    if (a && t.probabilistic_nature && (n.push({
      constraint_id: a.id,
      constraint_desc: "Requires absolute certainty/zero risk",
      conflict_reason: "System is PROBABILISTIC. Absolute certainty is epistemologically impossible."
    }), i.push(a.id)), n.length === 0) {
      const o = await this.checkLogicalConsistency(r);
      o.consistent || (n.push(...o.conflicts), i.push(...o.ids));
    }
    return n.length > 0 ? {
      status: "UNSAT",
      message: "No exists a coherent configuration that satisfies all constraints.",
      unsat_core: n,
      minimal_conflict_set: i,
      repair_options: await this.generateRepairs(n)
    } : {
      status: "SAT",
      normalized_intent: { action: e, constraints: r }
    };
  }
  static async checkLogicalConsistency(e) {
    const t = `
        Start by analyzing these constraints looking for LOGICAL CONTRADICTIONS.
        ${JSON.stringify(e, null, 2)}
        
        Examples of contradictions:
        - "Must be JSON only" AND "Must include paragraph outside JSON"
        - "Max length 10 words" AND "Must include full history of Rome"
        
        If CONTRADICTORY, return JSON: {"consistent": false, "conflicts": [{"constraint_id": "...", "reason": "..."}], "ids": ["..."]}
        If CONSISTENT, return: {"consistent": true}
        `;
    try {
      const r = await M.resilientCallLLM("Analyze Consistency", "nvidia/nemotron-3-nano-30b-a3b:free", t), n = JSON.parse(r.content);
      return {
        consistent: !!n.consistent,
        conflicts: (n.conflicts || []).map((i) => ({
          constraint_id: i.constraint_id,
          constraint_desc: "Logical Contradiction",
          conflict_reason: i.reason
        })),
        ids: n.ids || []
      };
    } catch (r) {
      return (r && typeof r == "object" && "message" in r && typeof r.message == "string" ? r.message : "") === "SOVEREIGN_REQUIRED" ? { consistent: !0, conflicts: [], ids: [] } : { consistent: !0, conflicts: [], ids: [] };
    }
  }
  static async generateRepairs(e) {
    const t = `
        Given these UNSATISFIABLE Constraints, suggest repairs:
        ${JSON.stringify(e)}
        
        Return JSON array: [{"change": "...", "effect": "..."}]
        `, r = await M.callLLM("Suggest Repairs", "anthropic/claude-3.5-sonnet", t);
    try {
      return JSON.parse(r.content);
    } catch {
      return [];
    }
  }
}
const J = {};
var ss, rs, ns, is;
J != null && J.VITE_OPENROUTER_API_KEY || (rs = (ss = globalThis.process) == null ? void 0 : ss.env) != null && rs.VITE_OPENROUTER_API_KEY || (is = (ns = globalThis.process) == null ? void 0 : ns.env) != null && is.OPENROUTER_API_KEY;
const sr = "https://openrouter.ai/api/v1";
var as, os;
const rr = (J == null ? void 0 : J.OPENAI_MODEL) || ((os = (as = globalThis.process) == null ? void 0 : as.env) == null ? void 0 : os.OPENAI_MODEL), bs = rr || "nvidia/nemotron-3-nano-30b-a3b:free", nr = [
  "arcee-ai/trinity-large-preview:free",
  // Arcee Trinity 400B MoE
  "liquid/lfm-2.5-1.2b-instruct:free",
  // Liquid LFM - fast
  "upstage/solar-pro-3:free"
  // Upstage Solar Pro 3
], ir = 50;
async function Ze(s) {
  return new Promise((e) => setTimeout(e, s));
}
async function Ss(s, e = "anthropic/claude-3.5-sonnet", t, r = 1) {
  var c, l, u, d, h, f;
  const n = Date.now(), i = [];
  t && i.push({ role: "system", content: t }), i.push({ role: "user", content: s });
  const a = (J == null ? void 0 : J.VITE_OPENROUTER_API_KEY) || ((l = (c = globalThis.process) == null ? void 0 : c.env) == null ? void 0 : l.VITE_OPENROUTER_API_KEY) || ((d = (u = globalThis.process) == null ? void 0 : u.env) == null ? void 0 : d.OPENROUTER_API_KEY);
  if (!a)
    throw new Error("MISSING_API_KEY: VITE_OPENROUTER_API_KEY is not defined.");
  let o = 0;
  for (; ; )
    try {
      const p = await fetch(`${sr}/chat/completions`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${a}`,
          "Content-Type": "application/json",
          "HTTP-Referer": "https://neural-bridge.ai",
          "X-Title": "Neural Bridge SCP"
        },
        body: JSON.stringify({
          model: e,
          messages: i,
          temperature: 0.3,
          max_tokens: 2e3
        })
      });
      if (!p.ok) {
        const A = await p.text();
        if ((p.status === 429 || p.status === 503 || p.status === 502) && o < r) {
          const C = 500 + Math.random() * 200;
          console.log(`⚡ [TURBO-RETRY] ${e} → ${p.status}. Quick retry in ${Math.round(C)}ms...`), await Ze(C), o++;
          continue;
        }
        throw new Error(`LLM API error: ${p.status} - ${A}`);
      }
      await Ze(ir);
      const g = await p.json(), m = Date.now() - n, y = {
        "anthropic/claude-3.5-sonnet": { prompt: 3e-3, completion: 0.015 },
        "openai/gpt-4o": { prompt: 5e-3, completion: 0.015 }
      }, v = e.endsWith(":free") ? { prompt: 0, completion: 0 } : y[e] || { prompt: 1e-3, completion: 2e-3 }, _ = g.usage.prompt_tokens || 0, S = g.usage.completion_tokens || 0, O = _ / 1e3 * v.prompt + S / 1e3 * v.completion;
      return {
        content: ((f = (h = g.choices[0]) == null ? void 0 : h.message) == null ? void 0 : f.content) || "",
        model: e,
        tokens: {
          prompt: _,
          completion: S,
          total: _ + S
        },
        cost: O,
        latency: m
      };
    } catch (p) {
      if (p && typeof p == "object" && "message" in p && typeof p.message == "string" && o < r && (p.message.includes("429") || p.message.includes("503"))) {
        o++, await Ze(Math.pow(2, o) * 1e3);
        continue;
      }
      throw p;
    }
}
async function le(s, e, t) {
  const r = e.endsWith(":free") ? [e, ...nr.filter((i) => i !== e)] : [e];
  let n;
  for (const i of r)
    try {
      return await Ss(s, i, t);
    } catch (a) {
      n = a;
      const o = a && typeof a == "object" && "message" in a && typeof a.message == "string" ? a.message : "";
      if (o.includes("401") || o.includes("MISSING_API_KEY"))
        throw console.warn("🛡️ [SOVEREIGN_MODE] API Access Denied. Switching to internal Ontological Synthesis..."), new Error("SOVEREIGN_REQUIRED");
      r.length > 1 && console.warn(`⚠️ [FALLBACK] Model ${i} failed. Trying next in stack...`);
    }
  throw n;
}
async function Et(s) {
  const e = `You are a Domain Classifier for Neural Bridge.
Analyze the conversation and identify the specific knowledge domain (e.g., medicine, law, tech, finance, education, etc.).
Be precise. If it is a mix, choose the most critical one.`, t = `Conversation sample:
"${s.substring(0, 1e3)}"

Identify the domain. Return ONLY the domain name in lowercase (e.g. "medicine"). No explanation.`;
  try {
    const n = (await le(t, bs, e)).content.trim().toLowerCase().replace(/[^a-z0-9]/g, "");
    if (n === "general" || !n) {
      const { DomainEvolver: i } = await import("./domain_evolver-COeOls8f.js");
      return (await i.evolveDomain(s)).domain;
    }
    return n;
  } catch (r) {
    if ((r && typeof r == "object" && "message" in r && typeof r.message == "string" ? r.message : "") === "SOVEREIGN_REQUIRED")
      return "sovereign_evolution";
    console.warn("⚠️ Autonomous domain detection failed, falling back to evolution:", r);
    const { DomainEvolver: i } = await import("./domain_evolver-COeOls8f.js");
    return (await i.evolveDomain(s)).domain;
  }
}
async function Es(s, e, t) {
  var _, S, O, A;
  const r = `You are a Semantic Context Protocol (SCP) compiler. Your task is to extract structured semantic content from conversations for verified transfer to another LLM.

You MUST return a valid JSON object with this exact structure:
{
  "entities": [{"name": "e1", "type": "person|project|concept|tool|constraint", "category": "..."}],
  "intent": {"primary": "...", "status": "active"},
  "constraints": [{"id": "c1", "rule": "MUST|NEVER", "value": "...", "rationale": "..."}],
  "verification": {
    "semantic_invariants": [
      {
        "id": "inv_001",
        "kind": "fact_check|constraint_check",
        "prompt": "Question to verify this fact",
        "expected": {"type": "boolean|string", "value": "..."},
        "weight": 0.0-1.0,
        "strict": true/false,
        "rationale": "..."
      }
    ]
  }
}

Extract:
1. ALL named entities (people, projects, technologies, concepts)
2. User's primary intent
3. Technical or preference constraints
4. 3-5 invariants that can verify successful context transfer

Be thorough but precise.`, n = await ws.solve(s);
  if (n.status === "UNSAT") {
    const w = (n.repair_options || []).map((C) => `
     * ${C.change} -> ${C.effect}`).join("");
    throw new Error(`
        ⛔ ONTOLOGICAL REFUSAL TRIGGERED (uSID v2.0)
        The system cannot process this request because it describes an impossible reality configuration.
        
        Reason: ${n.message}
        
        Violated Constraints (UNSAT CORE):
        ${(n.unsat_core || []).map((C) => `• [${C.constraint_id}] ${C.constraint_desc}: ${C.conflict_reason}`).join(`
`)}

        SUGGESTED REPAIRS to make reality consistent:${w}
        `);
  }
  const { FractalCompressor: i } = await import("./fractal_compressor-DVaEZe4I.js"), a = await i.compress(s), { StochasticEngine: o } = await import("./stochastic_engine-DQmcxaHP.js"), { semanticPotential: c, entropy: l } = await o.processChaos(a), u = await Et(a), d = We({ task: "compile" });
  await o.entropyBalancer(l);
  const { VaccineEngine: h } = await import("./vaccine_engine-BaaUOlgy.js"), f = await h.getActiveGuards(a, u);
  let p = "";
  f.length > 0 && (p = `

💉 SEMANTIC IMMUNITY GUARDS (Avoid these known patterns):
` + f.map((w) => `- [${w.fallacy_type}] ${w.meta_invariant.rule}`).join(`
`));
  let g;
  try {
    g = await le(
      `Analyze the following conversation and extract its semantic content in Crystal Format v0.1:
            
            ---CONVERSATION START---
            ${a}
            ---CONVERSATION END---
            ${p}
            
            Return ONLY valid JSON, no markdown or explanation.`,
      d,
      r
    );
  } catch (w) {
    if ((w && typeof w == "object" && "message" in w && typeof w.message == "string" ? w.message : "") === "SOVEREIGN_REQUIRED")
      return await ks(a, u);
    throw w;
  }
  let m;
  try {
    let w = g.content;
    const C = w.match(/```(?:json)?\s*([\s\S]*?)```/);
    C && C[1] && (w = C[1]), m = JSON.parse(w.trim());
  } catch (w) {
    throw new Error(`Failed to parse LLM response as JSON: ${w}`);
  }
  const y = {
    scp_version: "1.0",
    context_id: lr(),
    created_at: (/* @__PURE__ */ new Date()).toISOString(),
    version: "1.0.0",
    tier: "community",
    author: t || {
      id: ((_ = m.author) == null ? void 0 : _.id) || "ai_generated",
      name: ((S = m.author) == null ? void 0 : S.name) || e,
      reputation: 0.5
    },
    domain: u,
    source: {
      platform: "neural-bridge-compiler",
      url: "https://neural-bridge.ai/compile",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      model: "anthropic/claude-3.5-sonnet"
    },
    intent: {
      primary: ((O = m.intent) == null ? void 0 : O.primary) || "General knowledge transfer",
      status: ce.ACTIVE
    },
    constraints: (m.constraints || []).map((w) => ({
      id: w.id,
      rule: w.rule || te.MUST,
      value: w.value,
      rationale: w.rationale
    })),
    entities: (m.entities || []).map((w) => ({
      name: w.name,
      type: w.type,
      category: w.category
    })),
    verification: {
      canonical_hash: "",
      // Set below
      semantic_invariants: (((A = m.verification) == null ? void 0 : A.semantic_invariants) || []).map((w) => ({
        id: w.id,
        kind: w.kind || "fact_check",
        prompt: w.prompt,
        expected: {
          type: w.expected.type,
          value: w.expected.value
        },
        weight: w.weight || 1,
        strict: w.strict ?? !0,
        rationale: w.rationale
      })),
      policy: {
        min_checks: 2,
        accept_threshold: 0.7,
        max_retries: 2,
        strategy: "balanced"
      }
    }
  }, v = { ...y };
  return v.verification && (v.verification.canonical_hash = void 0), y.verification.canonical_hash = await G.realSHA256(JSON.stringify(v)), { crystal: y, llmResponse: g };
}
async function Ts(s, e) {
  var y, v, _, S, O;
  const t = {
    decision: "FAIL",
    score: 0,
    confidence_interval: [0, 0],
    passed_invariants: [],
    failed_invariants: [],
    ladder_level: 1,
    total_attempts: 1,
    tokens_used: 0,
    cost: 0
  }, r = e || We({ domain: s.domain, task: "verify" }), { SemanticProtocol: n } = await import("./semantic_protocol-CLPtrTyg.js"), i = await n.performHandshake(s, r);
  if (i.resonance < 0.6)
    throw console.error(`[SCPService] 🚨 CRITICAL RESONANCE FAILURE (${i.resonance}) with ${r}. Aborting transfer to prevent semantic drift.`), new Error("SEMANTIC_SYNC_FAILURE: Target model resonance too low for safe transfer.");
  const a = await or(s), o = await le(
    a,
    r,
    "You are receiving context from a previous conversation. Acknowledge and internalize it."
  );
  t.tokens_used += o.tokens.total, t.cost += o.cost;
  const c = cr(s), l = await le(
    c,
    r,
    "Answer each verification question briefly and accurately based on the context received."
  );
  t.tokens_used += l.tokens.total, t.cost += l.cost, l.content.toLowerCase();
  let u = 0, d = 0;
  for (const A of s.verification.semantic_invariants) {
    u += A.weight;
    const w = await Tt({
      crystal: s,
      question: A.prompt,
      answer: l.content,
      targetModel: r
    });
    w.score >= 0.8 ? (d += A.weight, t.passed_invariants.push(A.id)) : t.failed_invariants.push({
      id: A.id,
      expected: A.expected.value,
      actual: l.content.substring(0, 150),
      reason: w.reasoning
    });
  }
  t.score = u > 0 ? d / u : 0;
  const h = ((v = (y = s.verification) == null ? void 0 : y.semantic_invariants) == null ? void 0 : v.length) || 1, p = Math.sqrt(Math.log(2 / 0.05) / (2 * h));
  t.confidence_interval = [
    Math.max(0, t.score - p),
    Math.min(1, t.score + p)
  ];
  const g = (_ = s.verification) == null ? void 0 : _.policy, m = (g == null ? void 0 : g.accept_threshold) ?? 0.7;
  return t.decision = t.score >= m ? "ACCEPT" : "FAIL", t.receipt = await er.generateDecisionReceipt({
    crystal_refs: [{
      crystal_id: s.context_id,
      version: "1.0.0",
      hash: ((S = s.verification) == null ? void 0 : S.canonical_hash) || "unknown"
    }],
    question: `Verify context transfer for context_id: ${s.context_id}`,
    answer: l.content,
    verification_result: {
      invariants_used: (((O = s.verification) == null ? void 0 : O.semantic_invariants) || []).map((A) => A.id),
      invariants_passed: t.passed_invariants,
      invariants_failed: t.failed_invariants.map((A) => A.id),
      counterfactuals_passed: [],
      counterfactuals_failed: [],
      sri: t.score,
      pac_epsilon: p,
      fidelity_badge: t.score > 0.9 ? "GOLD" : t.score > 0.7 ? "SILVER" : "BRONZE"
    },
    model_config: {
      provider: "OpenRouter",
      model: r,
      temperature: 0.3,
      max_tokens: 2e3
    },
    requester: "NeuralBridge_System_Verifier",
    sign: !0
  }), t;
}
const Ct = /* @__PURE__ */ new Map(), ar = 5 * 60 * 1e3;
async function It(s) {
  let e = 0;
  for (let t = 0; t < s.length; t++) {
    const r = s.charCodeAt(t);
    e = (e << 5) - e + r, e = e & e;
  }
  return e.toString(36);
}
async function As(s) {
  const { crystal: e, invariants: t, answer: r, targetModel: n = bs } = s;
  if (t.length === 0)
    return { results: [], cost: 0, latency: 0 };
  const a = `You are a Semantic Validator for Neural Bridge.
Validate the answer against multiple verification questions.

Crystal Constraints:
${(e.constraints || []).map((h) => `- [${h.rule}] ${h.value}`).join(`
`)}

Return a JSON array with scores for EACH question:
[
  {"id": "inv_001", "score": 0.0-1.0, "reasoning": "brief explanation"},
  {"id": "inv_002", "score": 0.0-1.0, "reasoning": "brief explanation"}
]`, o = t.map(
    (h, f) => `${f + 1}. [${h.id}] ${h.prompt}`
  ).join(`
`), c = `Answer to verify:
"${r}"

Verification questions:
${o}

Return ONLY a JSON array with scores for each question ID.`, l = Date.now(), u = await le(c, n, a), d = Date.now() - l;
  try {
    let h = u.content;
    const f = h.match(/```(?:json)?\s*([\s\S]*?)```/);
    f && f[1] && (h = f[1]);
    const p = JSON.parse(h.trim()), g = Array.isArray(p) ? p : [p];
    return { results: t.map((y) => {
      const v = g.find((_) => _.id === y.id);
      return {
        id: y.id,
        score: v && Number(v.score) || 0,
        reasoning: (v == null ? void 0 : v.reasoning) || "Not found in batch response"
      };
    }), cost: u.cost, latency: d };
  } catch {
    return {
      results: t.map((f) => ({
        id: f.id,
        score: 0.2,
        reasoning: "Batch parse failed, conservative score"
      })),
      cost: u.cost,
      latency: d
    };
  }
}
async function Tt(s) {
  const { crystal: e, question: t, answer: r, targetModel: n = "anthropic/claude-3.5-sonnet", useCache: i = !0 } = s;
  if (i) {
    const u = await It(`${e.context_id}:${t}:${r}`), d = Ct.get(u);
    if (d && Date.now() - d.timestamp < ar)
      return { ...d.result, cost: 0 };
  }
  const a = `You are a Semantic Validator for Neural Bridge.
You are given a Knowledge Crystal (context) and a question/answer pair.
Your task is to determine if the answer is CORRECT and CONSISTENT with the Crystal.

Crystal Constraints:
${(e.constraints || []).map((u) => `- [${u.rule}] ${u.value}`).join(`
`)}

Return a JSON score:
{
  "score": 0.0 to 1.0,
  "reasoning": "Brief explanation of why it passed or failed"
}`, o = `Question: ${t}
Answer: ${r}

Analyze and verify focus on CRYSTAL CONSISTENCY. Return ONLY JSON.`, c = await le(o, n, a);
  let l;
  try {
    let u = c.content;
    const d = u.match(/```(?:json)?\s*([\s\S]*?)```/);
    d && d[1] && (u = d[1]);
    const h = JSON.parse(u.trim());
    l = {
      score: Number(h.score) || 0,
      reasoning: String(h.reasoning) || "No reasoning provided",
      cost: c.cost
    };
  } catch {
    const d = c.content.toLowerCase();
    l = { score: d.includes("correct") || d.includes("verified") ? 0.8 : 0.2, reasoning: `Fuzzy Match (JSON Parse Failed): ${c.content.substring(0, 50)}`, cost: c.cost };
  }
  if (i) {
    const u = await It(`${e.context_id}:${t}:${r}`);
    Ct.set(u, { result: l, timestamp: Date.now() });
  }
  return l;
}
async function or(s) {
  const { LatentAnchor: e } = await Promise.resolve().then(() => zi);
  return `
SYSTEM ADVISORY: LATENT ANCHOR INJECTION DETECTED
---
The following block contains Axiomatic Context. Your reasoning weights MUST align with these constraints.

${e.anchor(s)}

Acknowledge initialization by stating: "Latent Anchor [${s.context_id.substring(0, 8)}] Active. Reality Constraints synchronized."
`.trim();
}
function cr(s) {
  return `I need to verify context transfer. Answer concisely:
${s.verification.semantic_invariants.map((e, t) => `${t + 1}. ${e.prompt}`).join(`
`)}`;
}
function lr() {
  const s = new Uint8Array(16), e = globalThis.crypto || globalThis.msCrypto;
  if (e && e.getRandomValues)
    e.getRandomValues(s);
  else
    for (let r = 0; r < 16; r++) s[r] = Math.floor(Math.random() * 256);
  s[6] = s[6] & 15 | 64, s[8] = s[8] & 63 | 128;
  const t = Array.from(s).map((r) => r.toString(16).padStart(2, "0")).join("");
  return `${t.slice(0, 8)}-${t.slice(8, 12)}-${t.slice(12, 16)}-${t.slice(16, 20)}-${t.slice(20, 32)}`;
}
function We(s) {
  const { isCritical: e = !1, task: t = "verify", text: r = "" } = s;
  let n = e ? 0.9 : 0.5;
  (t === "compile" || t === "repair") && (n += 0.2), r.length > 5e3 && (n += 0.1);
  const o = [
    { id: "google/gemini-2.0-flash-exp:free", capability: 0.6, cost: 0 },
    { id: "google/gemini-pro-1.5", capability: 0.85, cost: 0.01 },
    { id: "anthropic/claude-3.5-sonnet", capability: 0.95, cost: 0.03 }
  ].filter((c) => c.capability >= Math.min(n, 0.95)).sort((c, l) => l.capability / (l.cost + 0.01) - c.capability / (c.cost + 0.01))[0];
  return (o == null ? void 0 : o.id) || "google/gemini-2.0-flash-exp:free";
}
async function ur(s) {
  const { CrystalFormat: e } = await Promise.resolve().then(() => Zs), t = e.canonicalStringify(s), r = new TextEncoder().encode(t), n = await crypto.subtle.digest("SHA-256", r);
  return Array.from(new Uint8Array(n)).map((a) => a.toString(16).padStart(2, "0")).join("");
}
async function ks(s, e) {
  var i;
  console.log(`🏛️ [SovereignSynthesis] Initiating structural extraction for domain: ${e}...`);
  const t = ((i = s.match(/[A-Z][a-z]{3,}/g)) == null ? void 0 : i.slice(0, 5).map((a) => ({ name: a, type: "concept", category: "evolved" }))) || [], r = {
    scp_version: "1.0",
    context_id: `SOV_${Date.now()}`,
    created_at: (/* @__PURE__ */ new Date()).toISOString(),
    version: "1.0.0-sov",
    tier: "trusted",
    domain: e,
    source: {
      platform: "neural_bridge_core",
      url: "internal://sovereign_engine",
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      model: "SOVEREIGN_ENGINE"
    },
    intent: {
      primary: "Sovereign Context Extraction",
      status: ce.ACTIVE
    },
    entities: t,
    constraints: [
      {
        id: "sov_001",
        rule: te.MUST,
        value: "Maintain axiomatic consistency",
        rationale: "Sovereign override",
        severity: "critical"
      }
    ],
    verification: {
      canonical_hash: "",
      // Will be calculated below
      semantic_invariants: [
        {
          id: "inv_sov",
          kind: "fact_check",
          prompt: "Is this context logic-anchored?",
          expected: { type: "boolean", value: !0 },
          weight: 1,
          strict: !0,
          rationale: "Self-verification"
        }
      ],
      policy: {
        min_checks: 1,
        accept_threshold: 1,
        max_retries: 0,
        strategy: "strict"
      }
    },
    author: { id: "neural_bridge_core", name: "Sovereign Anchor", reputation: 1 }
  };
  r.verification.canonical_hash = await ur(r);
  const n = {
    content: JSON.stringify(r),
    model: "SOVEREIGN_ENGINE",
    tokens: { prompt: 0, completion: 0, total: 0 },
    cost: 0,
    latency: 0
  };
  return { crystal: r, llmResponse: n };
}
const M = {
  generateCrystal: Es,
  verifyTransfer: Ts,
  verifyArbitrary: Tt,
  verifyBatch: As,
  callLLM: Ss,
  getOptimalModel: We,
  resilientCallLLM: le
}, hr = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  SCPService: M,
  detectDomainAutonomously: Et,
  generateCrystal: Es,
  getOptimalModel: We,
  sovereignSynthesize: ks,
  verifyArbitrary: Tt,
  verifyBatch: As,
  verifyTransfer: Ts
}, Symbol.toStringTag, { value: "Module" })), B = 4096, He = 32, $ = B / He;
class k {
  constructor(e) {
    K(this, "data");
    e ? this.data = e : this.data = new Uint32Array($);
  }
  /**
   * Creates a random hypervector (Independent & Identically Distributed - i.i.d)
   * Each bit has 50% chance of being 0 or 1.
   * This ensures orthogonality between unrelated concepts.
   */
  static random() {
    const e = new k();
    if (typeof globalThis < "u" && globalThis.crypto)
      globalThis.crypto.getRandomValues(e.data);
    else
      for (let t = 0; t < $; t++)
        e.data[t] = Math.floor(Math.random() * 4294967295);
    return e;
  }
  /**
   * Binds this vector with another using XOR (Involutory).
   * Used for Role-Filler pairs (e.g., Action * Purchase).
   */
  bind(e) {
    if (e.data.length !== $)
      throw new Error("Dimension mismatch");
    const t = new Uint32Array($);
    for (let r = 0; r < $; r++)
      t[r] = this.data[r] ^ e.data[r];
    return new k(t);
  }
  /**
   * UNBIND (Reasoning) 🧠
   * Queries the structure.
   * If C = A * B, then C.unbind(A) = B.
   * Since XOR is self-inverse, this is functionally identical to bind(),
   * but semantically distinct for "Question Answering".
   */
  unbind(e) {
    return this.bind(e);
  }
  /**
   * ARITHMETICAL SUPERPOSITION (HDC 2.0) 🌌📈
   * 
   * Instead of raw binary majority, we use weighted arithmetic bundling.
   * This allows us to "sum" realities with different weights (e.g., trust scores).
   * For now, we use a bit-wise counter to simulate a "graded" consensus.
   */
  static bundle(e) {
    if (e.length === 0) return new k();
    if (e.length === 1) return new k(new Uint32Array(e[0].data));
    const t = new Uint32Array($), r = new Int32Array(B);
    for (const n of e)
      for (let i = 0; i < B; i++) {
        const a = i >>> 5, o = i & 31, c = n.data[a] >>> o & 1;
        r[i] += c === 1 ? 1 : -1;
      }
    for (let n = 0; n < B; n++)
      if (r[n] > 0) {
        const i = n >>> 5, a = n & 31;
        t[i] |= 1 << a;
      }
    return new k(t);
  }
  /**
   * Permutation (Rotation) Π
   * Used to encode sequence/order. 
   * permute(A) != A.
   */
  /**
   * Permutation (Rotation) Π
   * 
   * RIGOROUS 4096-BIT CYCLIC SHIFT 🔄
   * Shifts every bit in the 128-word array as a single contiguous 4096-bit register.
   * This is essential for sequence encoding (e.g., A -> B != B -> A).
   */
  permute(e = 1) {
    const t = new Uint32Array($), r = (e % B + B) % B;
    if (r === 0) return new k(new Uint32Array(this.data));
    const n = Math.floor(r / He), i = r % He;
    for (let a = 0; a < $; a++) {
      const o = (a + n) % $, c = (o + 1) % $, l = this.data[o] >>> i, u = this.data[c] << He - i;
      t[a] = l | (i === 0 ? 0 : u);
    }
    return new k(t);
  }
  /**
   * Dot Product (Hamming Similarity)
   * Measures the overlap between two vectors.
   */
  dotProduct(e) {
    let t = 0;
    for (let r = 0; r < $; r++) {
      let n = this.data[r] & e.data[r];
      for (; n !== 0; )
        t++, n &= n - 1;
    }
    return t;
  }
  /**
   * Similarity Metric (Normalized Hamming Distance)
   * Returns 0.0 (Orthogonal/Different) to 1.0 (Identical).
   */
  similarity(e) {
    let t = 0;
    for (let r = 0; r < $; r++) {
      let n = this.data[r] ^ e.data[r];
      for (; n !== 0; )
        t++, n &= n - 1;
    }
    return 1 - t / B;
  }
  toString() {
    let e = "";
    for (let t = 0; t < $; t++)
      e += this.data[t].toString(16).padStart(8, "0");
    return e;
  }
  static fromString(e) {
    const t = new Uint32Array($);
    for (let r = 0; r < $; r++)
      t[r] = parseInt(e.substr(r * 8, 8), 16);
    return new k(t);
  }
  /**
   * SPARSE DISTRIBUTED REPRESENTATION (SDR) THINNING 🧠🧬
   * 
   * Mimics the human neocortex by reducing active bits to ~2% (Sparse).
   * This exponentially increases the system's ability to distinguish between
   * similar concepts and makes it virtually immune to noise.
   */
  static sdrThinning(e, t = 0.02) {
    const r = new Uint32Array($), n = Math.floor(B * t);
    for (let i = 0; i < n; i++) {
      const a = (Math.imul(i, 73244475) >>> 0) % B;
      e.data[a >>> 5] >>> (a & 31) & 1 && (r[a >>> 5] |= 1 << (a & 31));
    }
    return new k(r);
  }
  /**
   * OVERLAP ⋂
   * 
   * The SDR equivalent of Similarity. 
   * Measures the absolute intersection of active bits.
   */
  /**
   * OVERLAP ⋂
   * 
   * The SDR equivalent of Similarity. 
   * Measures the absolute intersection of active bits.
   */
  static overlap(e, t) {
    let r = 0;
    for (let n = 0; n < $; n++) {
      let i = e.data[n] & t.data[n];
      i = i - (i >> 1 & 1431655765), i = (i & 858993459) + (i >> 2 & 858993459), r += (i + (i >> 4) & 252645135) * 16843009 >> 24;
    }
    return r;
  }
  /**
   * CIRCULAR CONVOLUTION (*)
   * 
   * HDC 3.0: High-order binding. 
   * Allows recursive nesting of concepts without semantic collapse.
   * Implemented via bit-wise circular shifts and XOR superposition.
   */
  static bind(e, t) {
    const r = new Uint32Array($);
    for (let n = 0; n < $; n++) {
      const i = n % 32, a = t.data[n] << i | t.data[n] >>> 32 - i;
      r[n] = e.data[n] ^ a;
    }
    return new k(r);
  }
  /**
   * CIRCULAR UNBINDING (/)
   * 
   * If R = A * B, then B ≈ R / A. 
   * Reconstitutes the original concept from a bound relationship.
   */
  static unbind(e, t) {
    const r = new Uint32Array($);
    for (let n = 0; n < $; n++) {
      const i = n % 32, a = e.data[n] ^ t.data[n];
      r[n] = a >>> i | a << 32 - i;
    }
    return new k(r);
  }
  /**
   * SHANNON ENTROPY (H) 📉
   * 
   * Calculates the information density of the hypervector.
   * H = -p*log2(p) - (1-p)*log2(1-p)
   */
  getEntropy() {
    let e = 0;
    for (let r = 0; r < $; r++) {
      let n = this.data[r];
      n = n - (n >> 1 & 1431655765), n = (n & 858993459) + (n >> 2 & 858993459), e += (n + (n >> 4) & 252645135) * 16843009 >> 24;
    }
    const t = e / B;
    return t === 0 || t === 1 ? 0 : -(t * Math.log2(t) + (1 - t) * Math.log2(1 - t));
  }
  /**
   * FISHER INFORMATION (F) 🏛️
   * 
   * Measures the "Certainty" of the vector.
   */
  getFisherInformation() {
    return 1 - this.getEntropy();
  }
}
const At = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Hypervector: k
}, Symbol.toStringTag, { value: "Module" }));
function Je(s, e) {
  var t = {};
  for (var r in s) Object.prototype.hasOwnProperty.call(s, r) && e.indexOf(r) < 0 && (t[r] = s[r]);
  if (s != null && typeof Object.getOwnPropertySymbols == "function")
    for (var n = 0, r = Object.getOwnPropertySymbols(s); n < r.length; n++)
      e.indexOf(r[n]) < 0 && Object.prototype.propertyIsEnumerable.call(s, r[n]) && (t[r[n]] = s[r[n]]);
  return t;
}
function dr(s, e, t, r) {
  function n(i) {
    return i instanceof t ? i : new t(function(a) {
      a(i);
    });
  }
  return new (t || (t = Promise))(function(i, a) {
    function o(u) {
      try {
        l(r.next(u));
      } catch (d) {
        a(d);
      }
    }
    function c(u) {
      try {
        l(r.throw(u));
      } catch (d) {
        a(d);
      }
    }
    function l(u) {
      u.done ? i(u.value) : n(u.value).then(o, c);
    }
    l((r = r.apply(s, e || [])).next());
  });
}
const fr = (s) => s ? (...e) => s(...e) : (...e) => fetch(...e);
class kt extends Error {
  constructor(e, t = "FunctionsError", r) {
    super(e), this.name = t, this.context = r;
  }
}
class pr extends kt {
  constructor(e) {
    super("Failed to send a request to the Edge Function", "FunctionsFetchError", e);
  }
}
class $t extends kt {
  constructor(e) {
    super("Relay Error invoking the Edge Function", "FunctionsRelayError", e);
  }
}
class xt extends kt {
  constructor(e) {
    super("Edge Function returned a non-2xx status code", "FunctionsHttpError", e);
  }
}
var lt;
(function(s) {
  s.Any = "any", s.ApNortheast1 = "ap-northeast-1", s.ApNortheast2 = "ap-northeast-2", s.ApSouth1 = "ap-south-1", s.ApSoutheast1 = "ap-southeast-1", s.ApSoutheast2 = "ap-southeast-2", s.CaCentral1 = "ca-central-1", s.EuCentral1 = "eu-central-1", s.EuWest1 = "eu-west-1", s.EuWest2 = "eu-west-2", s.EuWest3 = "eu-west-3", s.SaEast1 = "sa-east-1", s.UsEast1 = "us-east-1", s.UsWest1 = "us-west-1", s.UsWest2 = "us-west-2";
})(lt || (lt = {}));
class gr {
  /**
   * Creates a new Functions client bound to an Edge Functions URL.
   *
   * @example
   * ```ts
   * import { FunctionsClient, FunctionRegion } from '@supabase/functions-js'
   *
   * const functions = new FunctionsClient('https://xyzcompany.supabase.co/functions/v1', {
   *   headers: { apikey: 'public-anon-key' },
   *   region: FunctionRegion.UsEast1,
   * })
   * ```
   */
  constructor(e, { headers: t = {}, customFetch: r, region: n = lt.Any } = {}) {
    this.url = e, this.headers = t, this.region = n, this.fetch = fr(r);
  }
  /**
   * Updates the authorization header
   * @param token - the new jwt token sent in the authorisation header
   * @example
   * ```ts
   * functions.setAuth(session.access_token)
   * ```
   */
  setAuth(e) {
    this.headers.Authorization = `Bearer ${e}`;
  }
  /**
   * Invokes a function
   * @param functionName - The name of the Function to invoke.
   * @param options - Options for invoking the Function.
   * @example
   * ```ts
   * const { data, error } = await functions.invoke('hello-world', {
   *   body: { name: 'Ada' },
   * })
   * ```
   */
  invoke(e) {
    return dr(this, arguments, void 0, function* (t, r = {}) {
      var n;
      let i, a;
      try {
        const { headers: o, method: c, body: l, signal: u, timeout: d } = r;
        let h = {}, { region: f } = r;
        f || (f = this.region);
        const p = new URL(`${this.url}/${t}`);
        f && f !== "any" && (h["x-region"] = f, p.searchParams.set("forceFunctionRegion", f));
        let g;
        l && (o && !Object.prototype.hasOwnProperty.call(o, "Content-Type") || !o) ? typeof Blob < "u" && l instanceof Blob || l instanceof ArrayBuffer ? (h["Content-Type"] = "application/octet-stream", g = l) : typeof l == "string" ? (h["Content-Type"] = "text/plain", g = l) : typeof FormData < "u" && l instanceof FormData ? g = l : (h["Content-Type"] = "application/json", g = JSON.stringify(l)) : l && typeof l != "string" && !(typeof Blob < "u" && l instanceof Blob) && !(l instanceof ArrayBuffer) && !(typeof FormData < "u" && l instanceof FormData) ? g = JSON.stringify(l) : g = l;
        let m = u;
        d && (a = new AbortController(), i = setTimeout(() => a.abort(), d), u ? (m = a.signal, u.addEventListener("abort", () => a.abort())) : m = a.signal);
        const y = yield this.fetch(p.toString(), {
          method: c || "POST",
          // headers priority is (high to low):
          // 1. invoke-level headers
          // 2. client-level headers
          // 3. default Content-Type header
          headers: Object.assign(Object.assign(Object.assign({}, h), this.headers), o),
          body: g,
          signal: m
        }).catch((O) => {
          throw new pr(O);
        }), v = y.headers.get("x-relay-error");
        if (v && v === "true")
          throw new $t(y);
        if (!y.ok)
          throw new xt(y);
        let _ = ((n = y.headers.get("Content-Type")) !== null && n !== void 0 ? n : "text/plain").split(";")[0].trim(), S;
        return _ === "application/json" ? S = yield y.json() : _ === "application/octet-stream" || _ === "application/pdf" ? S = yield y.blob() : _ === "text/event-stream" ? S = y : _ === "multipart/form-data" ? S = yield y.formData() : S = yield y.text(), { data: S, error: null, response: y };
      } catch (o) {
        return {
          data: null,
          error: o,
          response: o instanceof xt || o instanceof $t ? o.context : void 0
        };
      } finally {
        i && clearTimeout(i);
      }
    });
  }
}
var mr = class extends Error {
  /**
  * @example
  * ```ts
  * import PostgrestError from '@supabase/postgrest-js'
  *
  * throw new PostgrestError({
  *   message: 'Row level security prevented the request',
  *   details: 'RLS denied the insert',
  *   hint: 'Check your policies',
  *   code: 'PGRST301',
  * })
  * ```
  */
  constructor(s) {
    super(s.message), this.name = "PostgrestError", this.details = s.details, this.hint = s.hint, this.code = s.code;
  }
}, yr = class {
  /**
  * Creates a builder configured for a specific PostgREST request.
  *
  * @example
  * ```ts
  * import PostgrestQueryBuilder from '@supabase/postgrest-js'
  *
  * const builder = new PostgrestQueryBuilder(
  *   new URL('https://xyzcompany.supabase.co/rest/v1/users'),
  *   { headers: new Headers({ apikey: 'public-anon-key' }) }
  * )
  * ```
  */
  constructor(s) {
    var e, t;
    this.shouldThrowOnError = !1, this.method = s.method, this.url = s.url, this.headers = new Headers(s.headers), this.schema = s.schema, this.body = s.body, this.shouldThrowOnError = (e = s.shouldThrowOnError) !== null && e !== void 0 ? e : !1, this.signal = s.signal, this.isMaybeSingle = (t = s.isMaybeSingle) !== null && t !== void 0 ? t : !1, s.fetch ? this.fetch = s.fetch : this.fetch = fetch;
  }
  /**
  * If there's an error with the query, throwOnError will reject the promise by
  * throwing the error instead of returning it as part of a successful response.
  *
  * {@link https://github.com/supabase/supabase-js/issues/92}
  */
  throwOnError() {
    return this.shouldThrowOnError = !0, this;
  }
  /**
  * Set an HTTP header for the request.
  */
  setHeader(s, e) {
    return this.headers = new Headers(this.headers), this.headers.set(s, e), this;
  }
  then(s, e) {
    var t = this;
    this.schema === void 0 || (["GET", "HEAD"].includes(this.method) ? this.headers.set("Accept-Profile", this.schema) : this.headers.set("Content-Profile", this.schema)), this.method !== "GET" && this.method !== "HEAD" && this.headers.set("Content-Type", "application/json");
    const r = this.fetch;
    let n = r(this.url.toString(), {
      method: this.method,
      headers: this.headers,
      body: JSON.stringify(this.body),
      signal: this.signal
    }).then(async (i) => {
      let a = null, o = null, c = null, l = i.status, u = i.statusText;
      if (i.ok) {
        var d, h;
        if (t.method !== "HEAD") {
          var f;
          const y = await i.text();
          y === "" || (t.headers.get("Accept") === "text/csv" || t.headers.get("Accept") && (!((f = t.headers.get("Accept")) === null || f === void 0) && f.includes("application/vnd.pgrst.plan+text")) ? o = y : o = JSON.parse(y));
        }
        const g = (d = t.headers.get("Prefer")) === null || d === void 0 ? void 0 : d.match(/count=(exact|planned|estimated)/), m = (h = i.headers.get("content-range")) === null || h === void 0 ? void 0 : h.split("/");
        g && m && m.length > 1 && (c = parseInt(m[1])), t.isMaybeSingle && t.method === "GET" && Array.isArray(o) && (o.length > 1 ? (a = {
          code: "PGRST116",
          details: `Results contain ${o.length} rows, application/vnd.pgrst.object+json requires 1 row`,
          hint: null,
          message: "JSON object requested, multiple (or no) rows returned"
        }, o = null, c = null, l = 406, u = "Not Acceptable") : o.length === 1 ? o = o[0] : o = null);
      } else {
        var p;
        const g = await i.text();
        try {
          a = JSON.parse(g), Array.isArray(a) && i.status === 404 && (o = [], a = null, l = 200, u = "OK");
        } catch {
          i.status === 404 && g === "" ? (l = 204, u = "No Content") : a = { message: g };
        }
        if (a && t.isMaybeSingle && (!(a == null || (p = a.details) === null || p === void 0) && p.includes("0 rows")) && (a = null, l = 200, u = "OK"), a && t.shouldThrowOnError) throw new mr(a);
      }
      return {
        error: a,
        data: o,
        count: c,
        status: l,
        statusText: u
      };
    });
    return this.shouldThrowOnError || (n = n.catch((i) => {
      var a;
      let o = "";
      const c = i == null ? void 0 : i.cause;
      if (c) {
        var l, u, d, h;
        const p = (l = c == null ? void 0 : c.message) !== null && l !== void 0 ? l : "", g = (u = c == null ? void 0 : c.code) !== null && u !== void 0 ? u : "";
        o = `${(d = i == null ? void 0 : i.name) !== null && d !== void 0 ? d : "FetchError"}: ${i == null ? void 0 : i.message}`, o += `

Caused by: ${(h = c == null ? void 0 : c.name) !== null && h !== void 0 ? h : "Error"}: ${p}`, g && (o += ` (${g})`), c != null && c.stack && (o += `
${c.stack}`);
      } else {
        var f;
        o = (f = i == null ? void 0 : i.stack) !== null && f !== void 0 ? f : "";
      }
      return {
        error: {
          message: `${(a = i == null ? void 0 : i.name) !== null && a !== void 0 ? a : "FetchError"}: ${i == null ? void 0 : i.message}`,
          details: o,
          hint: "",
          code: ""
        },
        data: null,
        count: null,
        status: 0,
        statusText: ""
      };
    })), n.then(s, e);
  }
  /**
  * Override the type of the returned `data`.
  *
  * @typeParam NewResult - The new result type to override with
  * @deprecated Use overrideTypes<yourType, { merge: false }>() method at the end of your call chain instead
  */
  returns() {
    return this;
  }
  /**
  * Override the type of the returned `data` field in the response.
  *
  * @typeParam NewResult - The new type to cast the response data to
  * @typeParam Options - Optional type configuration (defaults to { merge: true })
  * @typeParam Options.merge - When true, merges the new type with existing return type. When false, replaces the existing types entirely (defaults to true)
  * @example
  * ```typescript
  * // Merge with existing types (default behavior)
  * const query = supabase
  *   .from('users')
  *   .select()
  *   .overrideTypes<{ custom_field: string }>()
  *
  * // Replace existing types completely
  * const replaceQuery = supabase
  *   .from('users')
  *   .select()
  *   .overrideTypes<{ id: number; name: string }, { merge: false }>()
  * ```
  * @returns A PostgrestBuilder instance with the new type
  */
  overrideTypes() {
    return this;
  }
}, _r = class extends yr {
  /**
  * Perform a SELECT on the query result.
  *
  * By default, `.insert()`, `.update()`, `.upsert()`, and `.delete()` do not
  * return modified rows. By calling this method, modified rows are returned in
  * `data`.
  *
  * @param columns - The columns to retrieve, separated by commas
  */
  select(s) {
    let e = !1;
    const t = (s ?? "*").split("").map((r) => /\s/.test(r) && !e ? "" : (r === '"' && (e = !e), r)).join("");
    return this.url.searchParams.set("select", t), this.headers.append("Prefer", "return=representation"), this;
  }
  /**
  * Order the query result by `column`.
  *
  * You can call this method multiple times to order by multiple columns.
  *
  * You can order referenced tables, but it only affects the ordering of the
  * parent table if you use `!inner` in the query.
  *
  * @param column - The column to order by
  * @param options - Named parameters
  * @param options.ascending - If `true`, the result will be in ascending order
  * @param options.nullsFirst - If `true`, `null`s appear first. If `false`,
  * `null`s appear last.
  * @param options.referencedTable - Set this to order a referenced table by
  * its columns
  * @param options.foreignTable - Deprecated, use `options.referencedTable`
  * instead
  */
  order(s, { ascending: e = !0, nullsFirst: t, foreignTable: r, referencedTable: n = r } = {}) {
    const i = n ? `${n}.order` : "order", a = this.url.searchParams.get(i);
    return this.url.searchParams.set(i, `${a ? `${a},` : ""}${s}.${e ? "asc" : "desc"}${t === void 0 ? "" : t ? ".nullsfirst" : ".nullslast"}`), this;
  }
  /**
  * Limit the query result by `count`.
  *
  * @param count - The maximum number of rows to return
  * @param options - Named parameters
  * @param options.referencedTable - Set this to limit rows of referenced
  * tables instead of the parent table
  * @param options.foreignTable - Deprecated, use `options.referencedTable`
  * instead
  */
  limit(s, { foreignTable: e, referencedTable: t = e } = {}) {
    const r = typeof t > "u" ? "limit" : `${t}.limit`;
    return this.url.searchParams.set(r, `${s}`), this;
  }
  /**
  * Limit the query result by starting at an offset `from` and ending at the offset `to`.
  * Only records within this range are returned.
  * This respects the query order and if there is no order clause the range could behave unexpectedly.
  * The `from` and `to` values are 0-based and inclusive: `range(1, 3)` will include the second, third
  * and fourth rows of the query.
  *
  * @param from - The starting index from which to limit the result
  * @param to - The last index to which to limit the result
  * @param options - Named parameters
  * @param options.referencedTable - Set this to limit rows of referenced
  * tables instead of the parent table
  * @param options.foreignTable - Deprecated, use `options.referencedTable`
  * instead
  */
  range(s, e, { foreignTable: t, referencedTable: r = t } = {}) {
    const n = typeof r > "u" ? "offset" : `${r}.offset`, i = typeof r > "u" ? "limit" : `${r}.limit`;
    return this.url.searchParams.set(n, `${s}`), this.url.searchParams.set(i, `${e - s + 1}`), this;
  }
  /**
  * Set the AbortSignal for the fetch request.
  *
  * @param signal - The AbortSignal to use for the fetch request
  */
  abortSignal(s) {
    return this.signal = s, this;
  }
  /**
  * Return `data` as a single object instead of an array of objects.
  *
  * Query result must be one row (e.g. using `.limit(1)`), otherwise this
  * returns an error.
  */
  single() {
    return this.headers.set("Accept", "application/vnd.pgrst.object+json"), this;
  }
  /**
  * Return `data` as a single object instead of an array of objects.
  *
  * Query result must be zero or one row (e.g. using `.limit(1)`), otherwise
  * this returns an error.
  */
  maybeSingle() {
    return this.method === "GET" ? this.headers.set("Accept", "application/json") : this.headers.set("Accept", "application/vnd.pgrst.object+json"), this.isMaybeSingle = !0, this;
  }
  /**
  * Return `data` as a string in CSV format.
  */
  csv() {
    return this.headers.set("Accept", "text/csv"), this;
  }
  /**
  * Return `data` as an object in [GeoJSON](https://geojson.org) format.
  */
  geojson() {
    return this.headers.set("Accept", "application/geo+json"), this;
  }
  /**
  * Return `data` as the EXPLAIN plan for the query.
  *
  * You need to enable the
  * [db_plan_enabled](https://supabase.com/docs/guides/database/debugging-performance#enabling-explain)
  * setting before using this method.
  *
  * @param options - Named parameters
  *
  * @param options.analyze - If `true`, the query will be executed and the
  * actual run time will be returned
  *
  * @param options.verbose - If `true`, the query identifier will be returned
  * and `data` will include the output columns of the query
  *
  * @param options.settings - If `true`, include information on configuration
  * parameters that affect query planning
  *
  * @param options.buffers - If `true`, include information on buffer usage
  *
  * @param options.wal - If `true`, include information on WAL record generation
  *
  * @param options.format - The format of the output, can be `"text"` (default)
  * or `"json"`
  */
  explain({ analyze: s = !1, verbose: e = !1, settings: t = !1, buffers: r = !1, wal: n = !1, format: i = "text" } = {}) {
    var a;
    const o = [
      s ? "analyze" : null,
      e ? "verbose" : null,
      t ? "settings" : null,
      r ? "buffers" : null,
      n ? "wal" : null
    ].filter(Boolean).join("|"), c = (a = this.headers.get("Accept")) !== null && a !== void 0 ? a : "application/json";
    return this.headers.set("Accept", `application/vnd.pgrst.plan+${i}; for="${c}"; options=${o};`), i === "json" ? this : this;
  }
  /**
  * Rollback the query.
  *
  * `data` will still be returned, but the query is not committed.
  */
  rollback() {
    return this.headers.append("Prefer", "tx=rollback"), this;
  }
  /**
  * Override the type of the returned `data`.
  *
  * @typeParam NewResult - The new result type to override with
  * @deprecated Use overrideTypes<yourType, { merge: false }>() method at the end of your call chain instead
  */
  returns() {
    return this;
  }
  /**
  * Set the maximum number of rows that can be affected by the query.
  * Only available in PostgREST v13+ and only works with PATCH and DELETE methods.
  *
  * @param value - The maximum number of rows that can be affected
  */
  maxAffected(s) {
    return this.headers.append("Prefer", "handling=strict"), this.headers.append("Prefer", `max-affected=${s}`), this;
  }
};
const Pt = /* @__PURE__ */ new RegExp("[,()]");
var me = class extends _r {
  /**
  * Match only rows where `column` is equal to `value`.
  *
  * To check if the value of `column` is NULL, you should use `.is()` instead.
  *
  * @param column - The column to filter on
  * @param value - The value to filter with
  */
  eq(s, e) {
    return this.url.searchParams.append(s, `eq.${e}`), this;
  }
  /**
  * Match only rows where `column` is not equal to `value`.
  *
  * @param column - The column to filter on
  * @param value - The value to filter with
  */
  neq(s, e) {
    return this.url.searchParams.append(s, `neq.${e}`), this;
  }
  /**
  * Match only rows where `column` is greater than `value`.
  *
  * @param column - The column to filter on
  * @param value - The value to filter with
  */
  gt(s, e) {
    return this.url.searchParams.append(s, `gt.${e}`), this;
  }
  /**
  * Match only rows where `column` is greater than or equal to `value`.
  *
  * @param column - The column to filter on
  * @param value - The value to filter with
  */
  gte(s, e) {
    return this.url.searchParams.append(s, `gte.${e}`), this;
  }
  /**
  * Match only rows where `column` is less than `value`.
  *
  * @param column - The column to filter on
  * @param value - The value to filter with
  */
  lt(s, e) {
    return this.url.searchParams.append(s, `lt.${e}`), this;
  }
  /**
  * Match only rows where `column` is less than or equal to `value`.
  *
  * @param column - The column to filter on
  * @param value - The value to filter with
  */
  lte(s, e) {
    return this.url.searchParams.append(s, `lte.${e}`), this;
  }
  /**
  * Match only rows where `column` matches `pattern` case-sensitively.
  *
  * @param column - The column to filter on
  * @param pattern - The pattern to match with
  */
  like(s, e) {
    return this.url.searchParams.append(s, `like.${e}`), this;
  }
  /**
  * Match only rows where `column` matches all of `patterns` case-sensitively.
  *
  * @param column - The column to filter on
  * @param patterns - The patterns to match with
  */
  likeAllOf(s, e) {
    return this.url.searchParams.append(s, `like(all).{${e.join(",")}}`), this;
  }
  /**
  * Match only rows where `column` matches any of `patterns` case-sensitively.
  *
  * @param column - The column to filter on
  * @param patterns - The patterns to match with
  */
  likeAnyOf(s, e) {
    return this.url.searchParams.append(s, `like(any).{${e.join(",")}}`), this;
  }
  /**
  * Match only rows where `column` matches `pattern` case-insensitively.
  *
  * @param column - The column to filter on
  * @param pattern - The pattern to match with
  */
  ilike(s, e) {
    return this.url.searchParams.append(s, `ilike.${e}`), this;
  }
  /**
  * Match only rows where `column` matches all of `patterns` case-insensitively.
  *
  * @param column - The column to filter on
  * @param patterns - The patterns to match with
  */
  ilikeAllOf(s, e) {
    return this.url.searchParams.append(s, `ilike(all).{${e.join(",")}}`), this;
  }
  /**
  * Match only rows where `column` matches any of `patterns` case-insensitively.
  *
  * @param column - The column to filter on
  * @param patterns - The patterns to match with
  */
  ilikeAnyOf(s, e) {
    return this.url.searchParams.append(s, `ilike(any).{${e.join(",")}}`), this;
  }
  /**
  * Match only rows where `column` matches the PostgreSQL regex `pattern`
  * case-sensitively (using the `~` operator).
  *
  * @param column - The column to filter on
  * @param pattern - The PostgreSQL regular expression pattern to match with
  */
  regexMatch(s, e) {
    return this.url.searchParams.append(s, `match.${e}`), this;
  }
  /**
  * Match only rows where `column` matches the PostgreSQL regex `pattern`
  * case-insensitively (using the `~*` operator).
  *
  * @param column - The column to filter on
  * @param pattern - The PostgreSQL regular expression pattern to match with
  */
  regexIMatch(s, e) {
    return this.url.searchParams.append(s, `imatch.${e}`), this;
  }
  /**
  * Match only rows where `column` IS `value`.
  *
  * For non-boolean columns, this is only relevant for checking if the value of
  * `column` is NULL by setting `value` to `null`.
  *
  * For boolean columns, you can also set `value` to `true` or `false` and it
  * will behave the same way as `.eq()`.
  *
  * @param column - The column to filter on
  * @param value - The value to filter with
  */
  is(s, e) {
    return this.url.searchParams.append(s, `is.${e}`), this;
  }
  /**
  * Match only rows where `column` IS DISTINCT FROM `value`.
  *
  * Unlike `.neq()`, this treats `NULL` as a comparable value. Two `NULL` values
  * are considered equal (not distinct), and comparing `NULL` with any non-NULL
  * value returns true (distinct).
  *
  * @param column - The column to filter on
  * @param value - The value to filter with
  */
  isDistinct(s, e) {
    return this.url.searchParams.append(s, `isdistinct.${e}`), this;
  }
  /**
  * Match only rows where `column` is included in the `values` array.
  *
  * @param column - The column to filter on
  * @param values - The values array to filter with
  */
  in(s, e) {
    const t = Array.from(new Set(e)).map((r) => typeof r == "string" && Pt.test(r) ? `"${r}"` : `${r}`).join(",");
    return this.url.searchParams.append(s, `in.(${t})`), this;
  }
  /**
  * Match only rows where `column` is NOT included in the `values` array.
  *
  * @param column - The column to filter on
  * @param values - The values array to filter with
  */
  notIn(s, e) {
    const t = Array.from(new Set(e)).map((r) => typeof r == "string" && Pt.test(r) ? `"${r}"` : `${r}`).join(",");
    return this.url.searchParams.append(s, `not.in.(${t})`), this;
  }
  /**
  * Only relevant for jsonb, array, and range columns. Match only rows where
  * `column` contains every element appearing in `value`.
  *
  * @param column - The jsonb, array, or range column to filter on
  * @param value - The jsonb, array, or range value to filter with
  */
  contains(s, e) {
    return typeof e == "string" ? this.url.searchParams.append(s, `cs.${e}`) : Array.isArray(e) ? this.url.searchParams.append(s, `cs.{${e.join(",")}}`) : this.url.searchParams.append(s, `cs.${JSON.stringify(e)}`), this;
  }
  /**
  * Only relevant for jsonb, array, and range columns. Match only rows where
  * every element appearing in `column` is contained by `value`.
  *
  * @param column - The jsonb, array, or range column to filter on
  * @param value - The jsonb, array, or range value to filter with
  */
  containedBy(s, e) {
    return typeof e == "string" ? this.url.searchParams.append(s, `cd.${e}`) : Array.isArray(e) ? this.url.searchParams.append(s, `cd.{${e.join(",")}}`) : this.url.searchParams.append(s, `cd.${JSON.stringify(e)}`), this;
  }
  /**
  * Only relevant for range columns. Match only rows where every element in
  * `column` is greater than any element in `range`.
  *
  * @param column - The range column to filter on
  * @param range - The range to filter with
  */
  rangeGt(s, e) {
    return this.url.searchParams.append(s, `sr.${e}`), this;
  }
  /**
  * Only relevant for range columns. Match only rows where every element in
  * `column` is either contained in `range` or greater than any element in
  * `range`.
  *
  * @param column - The range column to filter on
  * @param range - The range to filter with
  */
  rangeGte(s, e) {
    return this.url.searchParams.append(s, `nxl.${e}`), this;
  }
  /**
  * Only relevant for range columns. Match only rows where every element in
  * `column` is less than any element in `range`.
  *
  * @param column - The range column to filter on
  * @param range - The range to filter with
  */
  rangeLt(s, e) {
    return this.url.searchParams.append(s, `sl.${e}`), this;
  }
  /**
  * Only relevant for range columns. Match only rows where every element in
  * `column` is either contained in `range` or less than any element in
  * `range`.
  *
  * @param column - The range column to filter on
  * @param range - The range to filter with
  */
  rangeLte(s, e) {
    return this.url.searchParams.append(s, `nxr.${e}`), this;
  }
  /**
  * Only relevant for range columns. Match only rows where `column` is
  * mutually exclusive to `range` and there can be no element between the two
  * ranges.
  *
  * @param column - The range column to filter on
  * @param range - The range to filter with
  */
  rangeAdjacent(s, e) {
    return this.url.searchParams.append(s, `adj.${e}`), this;
  }
  /**
  * Only relevant for array and range columns. Match only rows where
  * `column` and `value` have an element in common.
  *
  * @param column - The array or range column to filter on
  * @param value - The array or range value to filter with
  */
  overlaps(s, e) {
    return typeof e == "string" ? this.url.searchParams.append(s, `ov.${e}`) : this.url.searchParams.append(s, `ov.{${e.join(",")}}`), this;
  }
  /**
  * Only relevant for text and tsvector columns. Match only rows where
  * `column` matches the query string in `query`.
  *
  * @param column - The text or tsvector column to filter on
  * @param query - The query text to match with
  * @param options - Named parameters
  * @param options.config - The text search configuration to use
  * @param options.type - Change how the `query` text is interpreted
  */
  textSearch(s, e, { config: t, type: r } = {}) {
    let n = "";
    r === "plain" ? n = "pl" : r === "phrase" ? n = "ph" : r === "websearch" && (n = "w");
    const i = t === void 0 ? "" : `(${t})`;
    return this.url.searchParams.append(s, `${n}fts${i}.${e}`), this;
  }
  /**
  * Match only rows where each column in `query` keys is equal to its
  * associated value. Shorthand for multiple `.eq()`s.
  *
  * @param query - The object to filter with, with column names as keys mapped
  * to their filter values
  */
  match(s) {
    return Object.entries(s).forEach(([e, t]) => {
      this.url.searchParams.append(e, `eq.${t}`);
    }), this;
  }
  /**
  * Match only rows which doesn't satisfy the filter.
  *
  * Unlike most filters, `opearator` and `value` are used as-is and need to
  * follow [PostgREST
  * syntax](https://postgrest.org/en/stable/api.html#operators). You also need
  * to make sure they are properly sanitized.
  *
  * @param column - The column to filter on
  * @param operator - The operator to be negated to filter with, following
  * PostgREST syntax
  * @param value - The value to filter with, following PostgREST syntax
  */
  not(s, e, t) {
    return this.url.searchParams.append(s, `not.${e}.${t}`), this;
  }
  /**
  * Match only rows which satisfy at least one of the filters.
  *
  * Unlike most filters, `filters` is used as-is and needs to follow [PostgREST
  * syntax](https://postgrest.org/en/stable/api.html#operators). You also need
  * to make sure it's properly sanitized.
  *
  * It's currently not possible to do an `.or()` filter across multiple tables.
  *
  * @param filters - The filters to use, following PostgREST syntax
  * @param options - Named parameters
  * @param options.referencedTable - Set this to filter on referenced tables
  * instead of the parent table
  * @param options.foreignTable - Deprecated, use `referencedTable` instead
  */
  or(s, { foreignTable: e, referencedTable: t = e } = {}) {
    const r = t ? `${t}.or` : "or";
    return this.url.searchParams.append(r, `(${s})`), this;
  }
  /**
  * Match only rows which satisfy the filter. This is an escape hatch - you
  * should use the specific filter methods wherever possible.
  *
  * Unlike most filters, `opearator` and `value` are used as-is and need to
  * follow [PostgREST
  * syntax](https://postgrest.org/en/stable/api.html#operators). You also need
  * to make sure they are properly sanitized.
  *
  * @param column - The column to filter on
  * @param operator - The operator to filter with, following PostgREST syntax
  * @param value - The value to filter with, following PostgREST syntax
  */
  filter(s, e, t) {
    return this.url.searchParams.append(s, `${e}.${t}`), this;
  }
}, vr = class {
  /**
  * Creates a query builder scoped to a Postgres table or view.
  *
  * @example
  * ```ts
  * import PostgrestQueryBuilder from '@supabase/postgrest-js'
  *
  * const query = new PostgrestQueryBuilder(
  *   new URL('https://xyzcompany.supabase.co/rest/v1/users'),
  *   { headers: { apikey: 'public-anon-key' } }
  * )
  * ```
  */
  constructor(s, { headers: e = {}, schema: t, fetch: r }) {
    this.url = s, this.headers = new Headers(e), this.schema = t, this.fetch = r;
  }
  /**
  * Clone URL and headers to prevent shared state between operations.
  */
  cloneRequestState() {
    return {
      url: new URL(this.url.toString()),
      headers: new Headers(this.headers)
    };
  }
  /**
  * Perform a SELECT query on the table or view.
  *
  * @param columns - The columns to retrieve, separated by commas. Columns can be renamed when returned with `customName:columnName`
  *
  * @param options - Named parameters
  *
  * @param options.head - When set to `true`, `data` will not be returned.
  * Useful if you only need the count.
  *
  * @param options.count - Count algorithm to use to count rows in the table or view.
  *
  * `"exact"`: Exact but slow count algorithm. Performs a `COUNT(*)` under the
  * hood.
  *
  * `"planned"`: Approximated but fast count algorithm. Uses the Postgres
  * statistics under the hood.
  *
  * `"estimated"`: Uses exact count for low numbers and planned count for high
  * numbers.
  *
  * @remarks
  * When using `count` with `.range()` or `.limit()`, the returned `count` is the total number of rows
  * that match your filters, not the number of rows in the current page. Use this to build pagination UI.
  */
  select(s, e) {
    const { head: t = !1, count: r } = e ?? {}, n = t ? "HEAD" : "GET";
    let i = !1;
    const a = (s ?? "*").split("").map((l) => /\s/.test(l) && !i ? "" : (l === '"' && (i = !i), l)).join(""), { url: o, headers: c } = this.cloneRequestState();
    return o.searchParams.set("select", a), r && c.append("Prefer", `count=${r}`), new me({
      method: n,
      url: o,
      headers: c,
      schema: this.schema,
      fetch: this.fetch
    });
  }
  /**
  * Perform an INSERT into the table or view.
  *
  * By default, inserted rows are not returned. To return it, chain the call
  * with `.select()`.
  *
  * @param values - The values to insert. Pass an object to insert a single row
  * or an array to insert multiple rows.
  *
  * @param options - Named parameters
  *
  * @param options.count - Count algorithm to use to count inserted rows.
  *
  * `"exact"`: Exact but slow count algorithm. Performs a `COUNT(*)` under the
  * hood.
  *
  * `"planned"`: Approximated but fast count algorithm. Uses the Postgres
  * statistics under the hood.
  *
  * `"estimated"`: Uses exact count for low numbers and planned count for high
  * numbers.
  *
  * @param options.defaultToNull - Make missing fields default to `null`.
  * Otherwise, use the default value for the column. Only applies for bulk
  * inserts.
  */
  insert(s, { count: e, defaultToNull: t = !0 } = {}) {
    var r;
    const n = "POST", { url: i, headers: a } = this.cloneRequestState();
    if (e && a.append("Prefer", `count=${e}`), t || a.append("Prefer", "missing=default"), Array.isArray(s)) {
      const o = s.reduce((c, l) => c.concat(Object.keys(l)), []);
      if (o.length > 0) {
        const c = [...new Set(o)].map((l) => `"${l}"`);
        i.searchParams.set("columns", c.join(","));
      }
    }
    return new me({
      method: n,
      url: i,
      headers: a,
      schema: this.schema,
      body: s,
      fetch: (r = this.fetch) !== null && r !== void 0 ? r : fetch
    });
  }
  /**
  * Perform an UPSERT on the table or view. Depending on the column(s) passed
  * to `onConflict`, `.upsert()` allows you to perform the equivalent of
  * `.insert()` if a row with the corresponding `onConflict` columns doesn't
  * exist, or if it does exist, perform an alternative action depending on
  * `ignoreDuplicates`.
  *
  * By default, upserted rows are not returned. To return it, chain the call
  * with `.select()`.
  *
  * @param values - The values to upsert with. Pass an object to upsert a
  * single row or an array to upsert multiple rows.
  *
  * @param options - Named parameters
  *
  * @param options.onConflict - Comma-separated UNIQUE column(s) to specify how
  * duplicate rows are determined. Two rows are duplicates if all the
  * `onConflict` columns are equal.
  *
  * @param options.ignoreDuplicates - If `true`, duplicate rows are ignored. If
  * `false`, duplicate rows are merged with existing rows.
  *
  * @param options.count - Count algorithm to use to count upserted rows.
  *
  * `"exact"`: Exact but slow count algorithm. Performs a `COUNT(*)` under the
  * hood.
  *
  * `"planned"`: Approximated but fast count algorithm. Uses the Postgres
  * statistics under the hood.
  *
  * `"estimated"`: Uses exact count for low numbers and planned count for high
  * numbers.
  *
  * @param options.defaultToNull - Make missing fields default to `null`.
  * Otherwise, use the default value for the column. This only applies when
  * inserting new rows, not when merging with existing rows under
  * `ignoreDuplicates: false`. This also only applies when doing bulk upserts.
  *
  * @example Upsert a single row using a unique key
  * ```ts
  * // Upserting a single row, overwriting based on the 'username' unique column
  * const { data, error } = await supabase
  *   .from('users')
  *   .upsert({ username: 'supabot' }, { onConflict: 'username' })
  *
  * // Example response:
  * // {
  * //   data: [
  * //     { id: 4, message: 'bar', username: 'supabot' }
  * //   ],
  * //   error: null
  * // }
  * ```
  *
  * @example Upsert with conflict resolution and exact row counting
  * ```ts
  * // Upserting and returning exact count
  * const { data, error, count } = await supabase
  *   .from('users')
  *   .upsert(
  *     {
  *       id: 3,
  *       message: 'foo',
  *       username: 'supabot'
  *     },
  *     {
  *       onConflict: 'username',
  *       count: 'exact'
  *     }
  *   )
  *
  * // Example response:
  * // {
  * //   data: [
  * //     {
  * //       id: 42,
  * //       handle: "saoirse",
  * //       display_name: "Saoirse"
  * //     }
  * //   ],
  * //   count: 1,
  * //   error: null
  * // }
  * ```
  */
  upsert(s, { onConflict: e, ignoreDuplicates: t = !1, count: r, defaultToNull: n = !0 } = {}) {
    var i;
    const a = "POST", { url: o, headers: c } = this.cloneRequestState();
    if (c.append("Prefer", `resolution=${t ? "ignore" : "merge"}-duplicates`), e !== void 0 && o.searchParams.set("on_conflict", e), r && c.append("Prefer", `count=${r}`), n || c.append("Prefer", "missing=default"), Array.isArray(s)) {
      const l = s.reduce((u, d) => u.concat(Object.keys(d)), []);
      if (l.length > 0) {
        const u = [...new Set(l)].map((d) => `"${d}"`);
        o.searchParams.set("columns", u.join(","));
      }
    }
    return new me({
      method: a,
      url: o,
      headers: c,
      schema: this.schema,
      body: s,
      fetch: (i = this.fetch) !== null && i !== void 0 ? i : fetch
    });
  }
  /**
  * Perform an UPDATE on the table or view.
  *
  * By default, updated rows are not returned. To return it, chain the call
  * with `.select()` after filters.
  *
  * @param values - The values to update with
  *
  * @param options - Named parameters
  *
  * @param options.count - Count algorithm to use to count updated rows.
  *
  * `"exact"`: Exact but slow count algorithm. Performs a `COUNT(*)` under the
  * hood.
  *
  * `"planned"`: Approximated but fast count algorithm. Uses the Postgres
  * statistics under the hood.
  *
  * `"estimated"`: Uses exact count for low numbers and planned count for high
  * numbers.
  */
  update(s, { count: e } = {}) {
    var t;
    const r = "PATCH", { url: n, headers: i } = this.cloneRequestState();
    return e && i.append("Prefer", `count=${e}`), new me({
      method: r,
      url: n,
      headers: i,
      schema: this.schema,
      body: s,
      fetch: (t = this.fetch) !== null && t !== void 0 ? t : fetch
    });
  }
  /**
  * Perform a DELETE on the table or view.
  *
  * By default, deleted rows are not returned. To return it, chain the call
  * with `.select()` after filters.
  *
  * @param options - Named parameters
  *
  * @param options.count - Count algorithm to use to count deleted rows.
  *
  * `"exact"`: Exact but slow count algorithm. Performs a `COUNT(*)` under the
  * hood.
  *
  * `"planned"`: Approximated but fast count algorithm. Uses the Postgres
  * statistics under the hood.
  *
  * `"estimated"`: Uses exact count for low numbers and planned count for high
  * numbers.
  */
  delete({ count: s } = {}) {
    var e;
    const t = "DELETE", { url: r, headers: n } = this.cloneRequestState();
    return s && n.append("Prefer", `count=${s}`), new me({
      method: t,
      url: r,
      headers: n,
      schema: this.schema,
      fetch: (e = this.fetch) !== null && e !== void 0 ? e : fetch
    });
  }
}, wr = class Os {
  /**
  * Creates a PostgREST client.
  *
  * @param url - URL of the PostgREST endpoint
  * @param options - Named parameters
  * @param options.headers - Custom headers
  * @param options.schema - Postgres schema to switch to
  * @param options.fetch - Custom fetch
  * @example
  * ```ts
  * import PostgrestClient from '@supabase/postgrest-js'
  *
  * const postgrest = new PostgrestClient('https://xyzcompany.supabase.co/rest/v1', {
  *   headers: { apikey: 'public-anon-key' },
  *   schema: 'public',
  * })
  * ```
  */
  constructor(e, { headers: t = {}, schema: r, fetch: n } = {}) {
    this.url = e, this.headers = new Headers(t), this.schemaName = r, this.fetch = n;
  }
  /**
  * Perform a query on a table or a view.
  *
  * @param relation - The table or view name to query
  */
  from(e) {
    if (!e || typeof e != "string" || e.trim() === "") throw new Error("Invalid relation name: relation must be a non-empty string.");
    return new vr(new URL(`${this.url}/${e}`), {
      headers: new Headers(this.headers),
      schema: this.schemaName,
      fetch: this.fetch
    });
  }
  /**
  * Select a schema to query or perform an function (rpc) call.
  *
  * The schema needs to be on the list of exposed schemas inside Supabase.
  *
  * @param schema - The schema to query
  */
  schema(e) {
    return new Os(this.url, {
      headers: this.headers,
      schema: e,
      fetch: this.fetch
    });
  }
  /**
  * Perform a function call.
  *
  * @param fn - The function name to call
  * @param args - The arguments to pass to the function call
  * @param options - Named parameters
  * @param options.head - When set to `true`, `data` will not be returned.
  * Useful if you only need the count.
  * @param options.get - When set to `true`, the function will be called with
  * read-only access mode.
  * @param options.count - Count algorithm to use to count rows returned by the
  * function. Only applicable for [set-returning
  * functions](https://www.postgresql.org/docs/current/functions-srf.html).
  *
  * `"exact"`: Exact but slow count algorithm. Performs a `COUNT(*)` under the
  * hood.
  *
  * `"planned"`: Approximated but fast count algorithm. Uses the Postgres
  * statistics under the hood.
  *
  * `"estimated"`: Uses exact count for low numbers and planned count for high
  * numbers.
  *
  * @example
  * ```ts
  * // For cross-schema functions where type inference fails, use overrideTypes:
  * const { data } = await supabase
  *   .schema('schema_b')
  *   .rpc('function_a', {})
  *   .overrideTypes<{ id: string; user_id: string }[]>()
  * ```
  */
  rpc(e, t = {}, { head: r = !1, get: n = !1, count: i } = {}) {
    var a;
    let o;
    const c = new URL(`${this.url}/rpc/${e}`);
    let l;
    const u = (f) => f !== null && typeof f == "object" && (!Array.isArray(f) || f.some(u)), d = r && Object.values(t).some(u);
    d ? (o = "POST", l = t) : r || n ? (o = r ? "HEAD" : "GET", Object.entries(t).filter(([f, p]) => p !== void 0).map(([f, p]) => [f, Array.isArray(p) ? `{${p.join(",")}}` : `${p}`]).forEach(([f, p]) => {
      c.searchParams.append(f, p);
    })) : (o = "POST", l = t);
    const h = new Headers(this.headers);
    return d ? h.set("Prefer", i ? `count=${i},return=minimal` : "return=minimal") : i && h.set("Prefer", `count=${i}`), new me({
      method: o,
      url: c,
      headers: h,
      schema: this.schemaName,
      body: l,
      fetch: (a = this.fetch) !== null && a !== void 0 ? a : fetch
    });
  }
};
class br {
  /**
   * Static-only utility – prevent instantiation.
   */
  constructor() {
  }
  static detectEnvironment() {
    var e;
    if (typeof WebSocket < "u")
      return { type: "native", constructor: WebSocket };
    if (typeof globalThis < "u" && typeof globalThis.WebSocket < "u")
      return { type: "native", constructor: globalThis.WebSocket };
    if (typeof global < "u" && typeof global.WebSocket < "u")
      return { type: "native", constructor: global.WebSocket };
    if (typeof globalThis < "u" && typeof globalThis.WebSocketPair < "u" && typeof globalThis.WebSocket > "u")
      return {
        type: "cloudflare",
        error: "Cloudflare Workers detected. WebSocket clients are not supported in Cloudflare Workers.",
        workaround: "Use Cloudflare Workers WebSocket API for server-side WebSocket handling, or deploy to a different runtime."
      };
    if (typeof globalThis < "u" && globalThis.EdgeRuntime || typeof navigator < "u" && (!((e = navigator.userAgent) === null || e === void 0) && e.includes("Vercel-Edge")))
      return {
        type: "unsupported",
        error: "Edge runtime detected (Vercel Edge/Netlify Edge). WebSockets are not supported in edge functions.",
        workaround: "Use serverless functions or a different deployment target for WebSocket functionality."
      };
    const t = globalThis.process;
    if (t) {
      const r = t.versions;
      if (r && r.node) {
        const n = r.node, i = parseInt(n.replace(/^v/, "").split(".")[0]);
        return i >= 22 ? typeof globalThis.WebSocket < "u" ? { type: "native", constructor: globalThis.WebSocket } : {
          type: "unsupported",
          error: `Node.js ${i} detected but native WebSocket not found.`,
          workaround: "Provide a WebSocket implementation via the transport option."
        } : {
          type: "unsupported",
          error: `Node.js ${i} detected without native WebSocket support.`,
          workaround: `For Node.js < 22, install "ws" package and provide it via the transport option:
import ws from "ws"
new RealtimeClient(url, { transport: ws })`
        };
      }
    }
    return {
      type: "unsupported",
      error: "Unknown JavaScript runtime without WebSocket support.",
      workaround: "Ensure you're running in a supported environment (browser, Node.js, Deno) or provide a custom WebSocket implementation."
    };
  }
  /**
   * Returns the best available WebSocket constructor for the current runtime.
   *
   * @example
   * ```ts
   * const WS = WebSocketFactory.getWebSocketConstructor()
   * const socket = new WS('wss://realtime.supabase.co/socket')
   * ```
   */
  static getWebSocketConstructor() {
    const e = this.detectEnvironment();
    if (e.constructor)
      return e.constructor;
    let t = e.error || "WebSocket not supported in this environment.";
    throw e.workaround && (t += `

Suggested solution: ${e.workaround}`), new Error(t);
  }
  /**
   * Creates a WebSocket using the detected constructor.
   *
   * @example
   * ```ts
   * const socket = WebSocketFactory.createWebSocket('wss://realtime.supabase.co/socket')
   * ```
   */
  static createWebSocket(e, t) {
    const r = this.getWebSocketConstructor();
    return new r(e, t);
  }
  /**
   * Detects whether the runtime can establish WebSocket connections.
   *
   * @example
   * ```ts
   * if (!WebSocketFactory.isWebSocketSupported()) {
   *   console.warn('Falling back to long polling')
   * }
   * ```
   */
  static isWebSocketSupported() {
    try {
      const e = this.detectEnvironment();
      return e.type === "native" || e.type === "ws";
    } catch {
      return !1;
    }
  }
}
const Sr = "2.93.3", Er = `realtime-js/${Sr}`, Tr = "1.0.0", Rs = "2.0.0", Nt = Rs, ut = 1e4, Ar = 1e3, kr = 100;
var X;
(function(s) {
  s[s.connecting = 0] = "connecting", s[s.open = 1] = "open", s[s.closing = 2] = "closing", s[s.closed = 3] = "closed";
})(X || (X = {}));
var N;
(function(s) {
  s.closed = "closed", s.errored = "errored", s.joined = "joined", s.joining = "joining", s.leaving = "leaving";
})(N || (N = {}));
var H;
(function(s) {
  s.close = "phx_close", s.error = "phx_error", s.join = "phx_join", s.reply = "phx_reply", s.leave = "phx_leave", s.access_token = "access_token";
})(H || (H = {}));
var ht;
(function(s) {
  s.websocket = "websocket";
})(ht || (ht = {}));
var ie;
(function(s) {
  s.Connecting = "connecting", s.Open = "open", s.Closing = "closing", s.Closed = "closed";
})(ie || (ie = {}));
class Or {
  constructor(e) {
    this.HEADER_LENGTH = 1, this.USER_BROADCAST_PUSH_META_LENGTH = 6, this.KINDS = { userBroadcastPush: 3, userBroadcast: 4 }, this.BINARY_ENCODING = 0, this.JSON_ENCODING = 1, this.BROADCAST_EVENT = "broadcast", this.allowedMetadataKeys = [], this.allowedMetadataKeys = e ?? [];
  }
  encode(e, t) {
    if (e.event === this.BROADCAST_EVENT && !(e.payload instanceof ArrayBuffer) && typeof e.payload.event == "string")
      return t(this._binaryEncodeUserBroadcastPush(e));
    let r = [e.join_ref, e.ref, e.topic, e.event, e.payload];
    return t(JSON.stringify(r));
  }
  _binaryEncodeUserBroadcastPush(e) {
    var t;
    return this._isArrayBuffer((t = e.payload) === null || t === void 0 ? void 0 : t.payload) ? this._encodeBinaryUserBroadcastPush(e) : this._encodeJsonUserBroadcastPush(e);
  }
  _encodeBinaryUserBroadcastPush(e) {
    var t, r;
    const n = (r = (t = e.payload) === null || t === void 0 ? void 0 : t.payload) !== null && r !== void 0 ? r : new ArrayBuffer(0);
    return this._encodeUserBroadcastPush(e, this.BINARY_ENCODING, n);
  }
  _encodeJsonUserBroadcastPush(e) {
    var t, r;
    const n = (r = (t = e.payload) === null || t === void 0 ? void 0 : t.payload) !== null && r !== void 0 ? r : {}, a = new TextEncoder().encode(JSON.stringify(n)).buffer;
    return this._encodeUserBroadcastPush(e, this.JSON_ENCODING, a);
  }
  _encodeUserBroadcastPush(e, t, r) {
    var n, i;
    const a = e.topic, o = (n = e.ref) !== null && n !== void 0 ? n : "", c = (i = e.join_ref) !== null && i !== void 0 ? i : "", l = e.payload.event, u = this.allowedMetadataKeys ? this._pick(e.payload, this.allowedMetadataKeys) : {}, d = Object.keys(u).length === 0 ? "" : JSON.stringify(u);
    if (c.length > 255)
      throw new Error(`joinRef length ${c.length} exceeds maximum of 255`);
    if (o.length > 255)
      throw new Error(`ref length ${o.length} exceeds maximum of 255`);
    if (a.length > 255)
      throw new Error(`topic length ${a.length} exceeds maximum of 255`);
    if (l.length > 255)
      throw new Error(`userEvent length ${l.length} exceeds maximum of 255`);
    if (d.length > 255)
      throw new Error(`metadata length ${d.length} exceeds maximum of 255`);
    const h = this.USER_BROADCAST_PUSH_META_LENGTH + c.length + o.length + a.length + l.length + d.length, f = new ArrayBuffer(this.HEADER_LENGTH + h);
    let p = new DataView(f), g = 0;
    p.setUint8(g++, this.KINDS.userBroadcastPush), p.setUint8(g++, c.length), p.setUint8(g++, o.length), p.setUint8(g++, a.length), p.setUint8(g++, l.length), p.setUint8(g++, d.length), p.setUint8(g++, t), Array.from(c, (y) => p.setUint8(g++, y.charCodeAt(0))), Array.from(o, (y) => p.setUint8(g++, y.charCodeAt(0))), Array.from(a, (y) => p.setUint8(g++, y.charCodeAt(0))), Array.from(l, (y) => p.setUint8(g++, y.charCodeAt(0))), Array.from(d, (y) => p.setUint8(g++, y.charCodeAt(0)));
    var m = new Uint8Array(f.byteLength + r.byteLength);
    return m.set(new Uint8Array(f), 0), m.set(new Uint8Array(r), f.byteLength), m.buffer;
  }
  decode(e, t) {
    if (this._isArrayBuffer(e)) {
      let r = this._binaryDecode(e);
      return t(r);
    }
    if (typeof e == "string") {
      const r = JSON.parse(e), [n, i, a, o, c] = r;
      return t({ join_ref: n, ref: i, topic: a, event: o, payload: c });
    }
    return t({});
  }
  _binaryDecode(e) {
    const t = new DataView(e), r = t.getUint8(0), n = new TextDecoder();
    switch (r) {
      case this.KINDS.userBroadcast:
        return this._decodeUserBroadcast(e, t, n);
    }
  }
  _decodeUserBroadcast(e, t, r) {
    const n = t.getUint8(1), i = t.getUint8(2), a = t.getUint8(3), o = t.getUint8(4);
    let c = this.HEADER_LENGTH + 4;
    const l = r.decode(e.slice(c, c + n));
    c = c + n;
    const u = r.decode(e.slice(c, c + i));
    c = c + i;
    const d = r.decode(e.slice(c, c + a));
    c = c + a;
    const h = e.slice(c, e.byteLength), f = o === this.JSON_ENCODING ? JSON.parse(r.decode(h)) : h, p = {
      type: this.BROADCAST_EVENT,
      event: u,
      payload: f
    };
    return a > 0 && (p.meta = JSON.parse(d)), { join_ref: null, ref: null, topic: l, event: this.BROADCAST_EVENT, payload: p };
  }
  _isArrayBuffer(e) {
    var t;
    return e instanceof ArrayBuffer || ((t = e == null ? void 0 : e.constructor) === null || t === void 0 ? void 0 : t.name) === "ArrayBuffer";
  }
  _pick(e, t) {
    return !e || typeof e != "object" ? {} : Object.fromEntries(Object.entries(e).filter(([r]) => t.includes(r)));
  }
}
class Cs {
  constructor(e, t) {
    this.callback = e, this.timerCalc = t, this.timer = void 0, this.tries = 0, this.callback = e, this.timerCalc = t;
  }
  reset() {
    this.tries = 0, clearTimeout(this.timer), this.timer = void 0;
  }
  // Cancels any previous scheduleTimeout and schedules callback
  scheduleTimeout() {
    clearTimeout(this.timer), this.timer = setTimeout(() => {
      this.tries = this.tries + 1, this.callback();
    }, this.timerCalc(this.tries + 1));
  }
}
var R;
(function(s) {
  s.abstime = "abstime", s.bool = "bool", s.date = "date", s.daterange = "daterange", s.float4 = "float4", s.float8 = "float8", s.int2 = "int2", s.int4 = "int4", s.int4range = "int4range", s.int8 = "int8", s.int8range = "int8range", s.json = "json", s.jsonb = "jsonb", s.money = "money", s.numeric = "numeric", s.oid = "oid", s.reltime = "reltime", s.text = "text", s.time = "time", s.timestamp = "timestamp", s.timestamptz = "timestamptz", s.timetz = "timetz", s.tsrange = "tsrange", s.tstzrange = "tstzrange";
})(R || (R = {}));
const jt = (s, e, t = {}) => {
  var r;
  const n = (r = t.skipTypes) !== null && r !== void 0 ? r : [];
  return e ? Object.keys(e).reduce((i, a) => (i[a] = Rr(a, s, e, n), i), {}) : {};
}, Rr = (s, e, t, r) => {
  const n = e.find((o) => o.name === s), i = n == null ? void 0 : n.type, a = t[s];
  return i && !r.includes(i) ? Is(i, a) : dt(a);
}, Is = (s, e) => {
  if (s.charAt(0) === "_") {
    const t = s.slice(1, s.length);
    return xr(e, t);
  }
  switch (s) {
    case R.bool:
      return Cr(e);
    case R.float4:
    case R.float8:
    case R.int2:
    case R.int4:
    case R.int8:
    case R.numeric:
    case R.oid:
      return Ir(e);
    case R.json:
    case R.jsonb:
      return $r(e);
    case R.timestamp:
      return Pr(e);
    case R.abstime:
    case R.date:
    case R.daterange:
    case R.int4range:
    case R.int8range:
    case R.money:
    case R.reltime:
    case R.text:
    case R.time:
    case R.timestamptz:
    case R.timetz:
    case R.tsrange:
    case R.tstzrange:
      return dt(e);
    default:
      return dt(e);
  }
}, dt = (s) => s, Cr = (s) => {
  switch (s) {
    case "t":
      return !0;
    case "f":
      return !1;
    default:
      return s;
  }
}, Ir = (s) => {
  if (typeof s == "string") {
    const e = parseFloat(s);
    if (!Number.isNaN(e))
      return e;
  }
  return s;
}, $r = (s) => {
  if (typeof s == "string")
    try {
      return JSON.parse(s);
    } catch {
      return s;
    }
  return s;
}, xr = (s, e) => {
  if (typeof s != "string")
    return s;
  const t = s.length - 1, r = s[t];
  if (s[0] === "{" && r === "}") {
    let i;
    const a = s.slice(1, t);
    try {
      i = JSON.parse("[" + a + "]");
    } catch {
      i = a ? a.split(",") : [];
    }
    return i.map((o) => Is(e, o));
  }
  return s;
}, Pr = (s) => typeof s == "string" ? s.replace(" ", "T") : s, $s = (s) => {
  const e = new URL(s);
  return e.protocol = e.protocol.replace(/^ws/i, "http"), e.pathname = e.pathname.replace(/\/+$/, "").replace(/\/socket\/websocket$/i, "").replace(/\/socket$/i, "").replace(/\/websocket$/i, ""), e.pathname === "" || e.pathname === "/" ? e.pathname = "/api/broadcast" : e.pathname = e.pathname + "/api/broadcast", e.href;
};
class et {
  /**
   * Initializes the Push
   *
   * @param channel The Channel
   * @param event The event, for example `"phx_join"`
   * @param payload The payload, for example `{user_id: 123}`
   * @param timeout The push timeout in milliseconds
   */
  constructor(e, t, r = {}, n = ut) {
    this.channel = e, this.event = t, this.payload = r, this.timeout = n, this.sent = !1, this.timeoutTimer = void 0, this.ref = "", this.receivedResp = null, this.recHooks = [], this.refEvent = null;
  }
  resend(e) {
    this.timeout = e, this._cancelRefEvent(), this.ref = "", this.refEvent = null, this.receivedResp = null, this.sent = !1, this.send();
  }
  send() {
    this._hasReceived("timeout") || (this.startTimeout(), this.sent = !0, this.channel.socket.push({
      topic: this.channel.topic,
      event: this.event,
      payload: this.payload,
      ref: this.ref,
      join_ref: this.channel._joinRef()
    }));
  }
  updatePayload(e) {
    this.payload = Object.assign(Object.assign({}, this.payload), e);
  }
  receive(e, t) {
    var r;
    return this._hasReceived(e) && t((r = this.receivedResp) === null || r === void 0 ? void 0 : r.response), this.recHooks.push({ status: e, callback: t }), this;
  }
  startTimeout() {
    if (this.timeoutTimer)
      return;
    this.ref = this.channel.socket._makeRef(), this.refEvent = this.channel._replyEventName(this.ref);
    const e = (t) => {
      this._cancelRefEvent(), this._cancelTimeout(), this.receivedResp = t, this._matchReceive(t);
    };
    this.channel._on(this.refEvent, {}, e), this.timeoutTimer = setTimeout(() => {
      this.trigger("timeout", {});
    }, this.timeout);
  }
  trigger(e, t) {
    this.refEvent && this.channel._trigger(this.refEvent, { status: e, response: t });
  }
  destroy() {
    this._cancelRefEvent(), this._cancelTimeout();
  }
  _cancelRefEvent() {
    this.refEvent && this.channel._off(this.refEvent, {});
  }
  _cancelTimeout() {
    clearTimeout(this.timeoutTimer), this.timeoutTimer = void 0;
  }
  _matchReceive({ status: e, response: t }) {
    this.recHooks.filter((r) => r.status === e).forEach((r) => r.callback(t));
  }
  _hasReceived(e) {
    return this.receivedResp && this.receivedResp.status === e;
  }
}
var Ut;
(function(s) {
  s.SYNC = "sync", s.JOIN = "join", s.LEAVE = "leave";
})(Ut || (Ut = {}));
class Oe {
  /**
   * Creates a Presence helper that keeps the local presence state in sync with the server.
   *
   * @param channel - The realtime channel to bind to.
   * @param opts - Optional custom event names, e.g. `{ events: { state: 'state', diff: 'diff' } }`.
   *
   * @example
   * ```ts
   * const presence = new RealtimePresence(channel)
   *
   * channel.on('presence', ({ event, key }) => {
   *   console.log(`Presence ${event} on ${key}`)
   * })
   * ```
   */
  constructor(e, t) {
    this.channel = e, this.state = {}, this.pendingDiffs = [], this.joinRef = null, this.enabled = !1, this.caller = {
      onJoin: () => {
      },
      onLeave: () => {
      },
      onSync: () => {
      }
    };
    const r = (t == null ? void 0 : t.events) || {
      state: "presence_state",
      diff: "presence_diff"
    };
    this.channel._on(r.state, {}, (n) => {
      const { onJoin: i, onLeave: a, onSync: o } = this.caller;
      this.joinRef = this.channel._joinRef(), this.state = Oe.syncState(this.state, n, i, a), this.pendingDiffs.forEach((c) => {
        this.state = Oe.syncDiff(this.state, c, i, a);
      }), this.pendingDiffs = [], o();
    }), this.channel._on(r.diff, {}, (n) => {
      const { onJoin: i, onLeave: a, onSync: o } = this.caller;
      this.inPendingSyncState() ? this.pendingDiffs.push(n) : (this.state = Oe.syncDiff(this.state, n, i, a), o());
    }), this.onJoin((n, i, a) => {
      this.channel._trigger("presence", {
        event: "join",
        key: n,
        currentPresences: i,
        newPresences: a
      });
    }), this.onLeave((n, i, a) => {
      this.channel._trigger("presence", {
        event: "leave",
        key: n,
        currentPresences: i,
        leftPresences: a
      });
    }), this.onSync(() => {
      this.channel._trigger("presence", { event: "sync" });
    });
  }
  /**
   * Used to sync the list of presences on the server with the
   * client's state.
   *
   * An optional `onJoin` and `onLeave` callback can be provided to
   * react to changes in the client's local presences across
   * disconnects and reconnects with the server.
   *
   * @internal
   */
  static syncState(e, t, r, n) {
    const i = this.cloneDeep(e), a = this.transformState(t), o = {}, c = {};
    return this.map(i, (l, u) => {
      a[l] || (c[l] = u);
    }), this.map(a, (l, u) => {
      const d = i[l];
      if (d) {
        const h = u.map((m) => m.presence_ref), f = d.map((m) => m.presence_ref), p = u.filter((m) => f.indexOf(m.presence_ref) < 0), g = d.filter((m) => h.indexOf(m.presence_ref) < 0);
        p.length > 0 && (o[l] = p), g.length > 0 && (c[l] = g);
      } else
        o[l] = u;
    }), this.syncDiff(i, { joins: o, leaves: c }, r, n);
  }
  /**
   * Used to sync a diff of presence join and leave events from the
   * server, as they happen.
   *
   * Like `syncState`, `syncDiff` accepts optional `onJoin` and
   * `onLeave` callbacks to react to a user joining or leaving from a
   * device.
   *
   * @internal
   */
  static syncDiff(e, t, r, n) {
    const { joins: i, leaves: a } = {
      joins: this.transformState(t.joins),
      leaves: this.transformState(t.leaves)
    };
    return r || (r = () => {
    }), n || (n = () => {
    }), this.map(i, (o, c) => {
      var l;
      const u = (l = e[o]) !== null && l !== void 0 ? l : [];
      if (e[o] = this.cloneDeep(c), u.length > 0) {
        const d = e[o].map((f) => f.presence_ref), h = u.filter((f) => d.indexOf(f.presence_ref) < 0);
        e[o].unshift(...h);
      }
      r(o, u, c);
    }), this.map(a, (o, c) => {
      let l = e[o];
      if (!l)
        return;
      const u = c.map((d) => d.presence_ref);
      l = l.filter((d) => u.indexOf(d.presence_ref) < 0), e[o] = l, n(o, l, c), l.length === 0 && delete e[o];
    }), e;
  }
  /** @internal */
  static map(e, t) {
    return Object.getOwnPropertyNames(e).map((r) => t(r, e[r]));
  }
  /**
   * Remove 'metas' key
   * Change 'phx_ref' to 'presence_ref'
   * Remove 'phx_ref' and 'phx_ref_prev'
   *
   * @example
   * // returns {
   *  abc123: [
   *    { presence_ref: '2', user_id: 1 },
   *    { presence_ref: '3', user_id: 2 }
   *  ]
   * }
   * RealtimePresence.transformState({
   *  abc123: {
   *    metas: [
   *      { phx_ref: '2', phx_ref_prev: '1' user_id: 1 },
   *      { phx_ref: '3', user_id: 2 }
   *    ]
   *  }
   * })
   *
   * @internal
   */
  static transformState(e) {
    return e = this.cloneDeep(e), Object.getOwnPropertyNames(e).reduce((t, r) => {
      const n = e[r];
      return "metas" in n ? t[r] = n.metas.map((i) => (i.presence_ref = i.phx_ref, delete i.phx_ref, delete i.phx_ref_prev, i)) : t[r] = n, t;
    }, {});
  }
  /** @internal */
  static cloneDeep(e) {
    return JSON.parse(JSON.stringify(e));
  }
  /** @internal */
  onJoin(e) {
    this.caller.onJoin = e;
  }
  /** @internal */
  onLeave(e) {
    this.caller.onLeave = e;
  }
  /** @internal */
  onSync(e) {
    this.caller.onSync = e;
  }
  /** @internal */
  inPendingSyncState() {
    return !this.joinRef || this.joinRef !== this.channel._joinRef();
  }
}
var Lt;
(function(s) {
  s.ALL = "*", s.INSERT = "INSERT", s.UPDATE = "UPDATE", s.DELETE = "DELETE";
})(Lt || (Lt = {}));
var Re;
(function(s) {
  s.BROADCAST = "broadcast", s.PRESENCE = "presence", s.POSTGRES_CHANGES = "postgres_changes", s.SYSTEM = "system";
})(Re || (Re = {}));
var W;
(function(s) {
  s.SUBSCRIBED = "SUBSCRIBED", s.TIMED_OUT = "TIMED_OUT", s.CLOSED = "CLOSED", s.CHANNEL_ERROR = "CHANNEL_ERROR";
})(W || (W = {}));
class ve {
  /**
   * Creates a channel that can broadcast messages, sync presence, and listen to Postgres changes.
   *
   * The topic determines which realtime stream you are subscribing to. Config options let you
   * enable acknowledgement for broadcasts, presence tracking, or private channels.
   *
   * @example
   * ```ts
   * import RealtimeClient from '@supabase/realtime-js'
   *
   * const client = new RealtimeClient('https://xyzcompany.supabase.co/realtime/v1', {
   *   params: { apikey: 'public-anon-key' },
   * })
   * const channel = new RealtimeChannel('realtime:public:messages', { config: {} }, client)
   * ```
   */
  constructor(e, t = { config: {} }, r) {
    var n, i;
    if (this.topic = e, this.params = t, this.socket = r, this.bindings = {}, this.state = N.closed, this.joinedOnce = !1, this.pushBuffer = [], this.subTopic = e.replace(/^realtime:/i, ""), this.params.config = Object.assign({
      broadcast: { ack: !1, self: !1 },
      presence: { key: "", enabled: !1 },
      private: !1
    }, t.config), this.timeout = this.socket.timeout, this.joinPush = new et(this, H.join, this.params, this.timeout), this.rejoinTimer = new Cs(() => this._rejoinUntilConnected(), this.socket.reconnectAfterMs), this.joinPush.receive("ok", () => {
      this.state = N.joined, this.rejoinTimer.reset(), this.pushBuffer.forEach((a) => a.send()), this.pushBuffer = [];
    }), this._onClose(() => {
      this.rejoinTimer.reset(), this.socket.log("channel", `close ${this.topic} ${this._joinRef()}`), this.state = N.closed, this.socket._remove(this);
    }), this._onError((a) => {
      this._isLeaving() || this._isClosed() || (this.socket.log("channel", `error ${this.topic}`, a), this.state = N.errored, this.rejoinTimer.scheduleTimeout());
    }), this.joinPush.receive("timeout", () => {
      this._isJoining() && (this.socket.log("channel", `timeout ${this.topic}`, this.joinPush.timeout), this.state = N.errored, this.rejoinTimer.scheduleTimeout());
    }), this.joinPush.receive("error", (a) => {
      this._isLeaving() || this._isClosed() || (this.socket.log("channel", `error ${this.topic}`, a), this.state = N.errored, this.rejoinTimer.scheduleTimeout());
    }), this._on(H.reply, {}, (a, o) => {
      this._trigger(this._replyEventName(o), a);
    }), this.presence = new Oe(this), this.broadcastEndpointURL = $s(this.socket.endPoint), this.private = this.params.config.private || !1, !this.private && (!((i = (n = this.params.config) === null || n === void 0 ? void 0 : n.broadcast) === null || i === void 0) && i.replay))
      throw `tried to use replay on public channel '${this.topic}'. It must be a private channel.`;
  }
  /** Subscribe registers your client with the server */
  subscribe(e, t = this.timeout) {
    var r, n, i;
    if (this.socket.isConnected() || this.socket.connect(), this.state == N.closed) {
      const { config: { broadcast: a, presence: o, private: c } } = this.params, l = (n = (r = this.bindings.postgres_changes) === null || r === void 0 ? void 0 : r.map((f) => f.filter)) !== null && n !== void 0 ? n : [], u = !!this.bindings[Re.PRESENCE] && this.bindings[Re.PRESENCE].length > 0 || ((i = this.params.config.presence) === null || i === void 0 ? void 0 : i.enabled) === !0, d = {}, h = {
        broadcast: a,
        presence: Object.assign(Object.assign({}, o), { enabled: u }),
        postgres_changes: l,
        private: c
      };
      this.socket.accessTokenValue && (d.access_token = this.socket.accessTokenValue), this._onError((f) => e == null ? void 0 : e(W.CHANNEL_ERROR, f)), this._onClose(() => e == null ? void 0 : e(W.CLOSED)), this.updateJoinPayload(Object.assign({ config: h }, d)), this.joinedOnce = !0, this._rejoin(t), this.joinPush.receive("ok", async ({ postgres_changes: f }) => {
        var p;
        if (this.socket._isManualToken() || this.socket.setAuth(), f === void 0) {
          e == null || e(W.SUBSCRIBED);
          return;
        } else {
          const g = this.bindings.postgres_changes, m = (p = g == null ? void 0 : g.length) !== null && p !== void 0 ? p : 0, y = [];
          for (let v = 0; v < m; v++) {
            const _ = g[v], { filter: { event: S, schema: O, table: A, filter: w } } = _, C = f && f[v];
            if (C && C.event === S && ve.isFilterValueEqual(C.schema, O) && ve.isFilterValueEqual(C.table, A) && ve.isFilterValueEqual(C.filter, w))
              y.push(Object.assign(Object.assign({}, _), { id: C.id }));
            else {
              this.unsubscribe(), this.state = N.errored, e == null || e(W.CHANNEL_ERROR, new Error("mismatch between server and client bindings for postgres changes"));
              return;
            }
          }
          this.bindings.postgres_changes = y, e && e(W.SUBSCRIBED);
          return;
        }
      }).receive("error", (f) => {
        this.state = N.errored, e == null || e(W.CHANNEL_ERROR, new Error(JSON.stringify(Object.values(f).join(", ") || "error")));
      }).receive("timeout", () => {
        e == null || e(W.TIMED_OUT);
      });
    }
    return this;
  }
  /**
   * Returns the current presence state for this channel.
   *
   * The shape is a map keyed by presence key (for example a user id) where each entry contains the
   * tracked metadata for that user.
   */
  presenceState() {
    return this.presence.state;
  }
  /**
   * Sends the supplied payload to the presence tracker so other subscribers can see that this
   * client is online. Use `untrack` to stop broadcasting presence for the same key.
   */
  async track(e, t = {}) {
    return await this.send({
      type: "presence",
      event: "track",
      payload: e
    }, t.timeout || this.timeout);
  }
  /**
   * Removes the current presence state for this client.
   */
  async untrack(e = {}) {
    return await this.send({
      type: "presence",
      event: "untrack"
    }, e);
  }
  on(e, t, r) {
    return this.state === N.joined && e === Re.PRESENCE && (this.socket.log("channel", `resubscribe to ${this.topic} due to change in presence callbacks on joined channel`), this.unsubscribe().then(async () => await this.subscribe())), this._on(e, t, r);
  }
  /**
   * Sends a broadcast message explicitly via REST API.
   *
   * This method always uses the REST API endpoint regardless of WebSocket connection state.
   * Useful when you want to guarantee REST delivery or when gradually migrating from implicit REST fallback.
   *
   * @param event The name of the broadcast event
   * @param payload Payload to be sent (required)
   * @param opts Options including timeout
   * @returns Promise resolving to object with success status, and error details if failed
   */
  async httpSend(e, t, r = {}) {
    var n;
    if (t == null)
      return Promise.reject("Payload is required for httpSend()");
    const i = {
      apikey: this.socket.apiKey ? this.socket.apiKey : "",
      "Content-Type": "application/json"
    };
    this.socket.accessTokenValue && (i.Authorization = `Bearer ${this.socket.accessTokenValue}`);
    const a = {
      method: "POST",
      headers: i,
      body: JSON.stringify({
        messages: [
          {
            topic: this.subTopic,
            event: e,
            payload: t,
            private: this.private
          }
        ]
      })
    }, o = await this._fetchWithTimeout(this.broadcastEndpointURL, a, (n = r.timeout) !== null && n !== void 0 ? n : this.timeout);
    if (o.status === 202)
      return { success: !0 };
    let c = o.statusText;
    try {
      const l = await o.json();
      c = l.error || l.message || c;
    } catch {
    }
    return Promise.reject(new Error(c));
  }
  /**
   * Sends a message into the channel.
   *
   * @param args Arguments to send to channel
   * @param args.type The type of event to send
   * @param args.event The name of the event being sent
   * @param args.payload Payload to be sent
   * @param opts Options to be used during the send process
   */
  async send(e, t = {}) {
    var r, n;
    if (!this._canPush() && e.type === "broadcast") {
      console.warn("Realtime send() is automatically falling back to REST API. This behavior will be deprecated in the future. Please use httpSend() explicitly for REST delivery.");
      const { event: i, payload: a } = e, o = {
        apikey: this.socket.apiKey ? this.socket.apiKey : "",
        "Content-Type": "application/json"
      };
      this.socket.accessTokenValue && (o.Authorization = `Bearer ${this.socket.accessTokenValue}`);
      const c = {
        method: "POST",
        headers: o,
        body: JSON.stringify({
          messages: [
            {
              topic: this.subTopic,
              event: i,
              payload: a,
              private: this.private
            }
          ]
        })
      };
      try {
        const l = await this._fetchWithTimeout(this.broadcastEndpointURL, c, (r = t.timeout) !== null && r !== void 0 ? r : this.timeout);
        return await ((n = l.body) === null || n === void 0 ? void 0 : n.cancel()), l.ok ? "ok" : "error";
      } catch (l) {
        return l.name === "AbortError" ? "timed out" : "error";
      }
    } else
      return new Promise((i) => {
        var a, o, c;
        const l = this._push(e.type, e, t.timeout || this.timeout);
        e.type === "broadcast" && !(!((c = (o = (a = this.params) === null || a === void 0 ? void 0 : a.config) === null || o === void 0 ? void 0 : o.broadcast) === null || c === void 0) && c.ack) && i("ok"), l.receive("ok", () => i("ok")), l.receive("error", () => i("error")), l.receive("timeout", () => i("timed out"));
      });
  }
  /**
   * Updates the payload that will be sent the next time the channel joins (reconnects).
   * Useful for rotating access tokens or updating config without re-creating the channel.
   */
  updateJoinPayload(e) {
    this.joinPush.updatePayload(e);
  }
  /**
   * Leaves the channel.
   *
   * Unsubscribes from server events, and instructs channel to terminate on server.
   * Triggers onClose() hooks.
   *
   * To receive leave acknowledgements, use the a `receive` hook to bind to the server ack, ie:
   * channel.unsubscribe().receive("ok", () => alert("left!") )
   */
  unsubscribe(e = this.timeout) {
    this.state = N.leaving;
    const t = () => {
      this.socket.log("channel", `leave ${this.topic}`), this._trigger(H.close, "leave", this._joinRef());
    };
    this.joinPush.destroy();
    let r = null;
    return new Promise((n) => {
      r = new et(this, H.leave, {}, e), r.receive("ok", () => {
        t(), n("ok");
      }).receive("timeout", () => {
        t(), n("timed out");
      }).receive("error", () => {
        n("error");
      }), r.send(), this._canPush() || r.trigger("ok", {});
    }).finally(() => {
      r == null || r.destroy();
    });
  }
  /**
   * Teardown the channel.
   *
   * Destroys and stops related timers.
   */
  teardown() {
    this.pushBuffer.forEach((e) => e.destroy()), this.pushBuffer = [], this.rejoinTimer.reset(), this.joinPush.destroy(), this.state = N.closed, this.bindings = {};
  }
  /** @internal */
  async _fetchWithTimeout(e, t, r) {
    const n = new AbortController(), i = setTimeout(() => n.abort(), r), a = await this.socket.fetch(e, Object.assign(Object.assign({}, t), { signal: n.signal }));
    return clearTimeout(i), a;
  }
  /** @internal */
  _push(e, t, r = this.timeout) {
    if (!this.joinedOnce)
      throw `tried to push '${e}' to '${this.topic}' before joining. Use channel.subscribe() before pushing events`;
    let n = new et(this, e, t, r);
    return this._canPush() ? n.send() : this._addToPushBuffer(n), n;
  }
  /** @internal */
  _addToPushBuffer(e) {
    if (e.startTimeout(), this.pushBuffer.push(e), this.pushBuffer.length > kr) {
      const t = this.pushBuffer.shift();
      t && (t.destroy(), this.socket.log("channel", `discarded push due to buffer overflow: ${t.event}`, t.payload));
    }
  }
  /**
   * Overridable message hook
   *
   * Receives all events for specialized message handling before dispatching to the channel callbacks.
   * Must return the payload, modified or unmodified.
   *
   * @internal
   */
  _onMessage(e, t, r) {
    return t;
  }
  /** @internal */
  _isMember(e) {
    return this.topic === e;
  }
  /** @internal */
  _joinRef() {
    return this.joinPush.ref;
  }
  /** @internal */
  _trigger(e, t, r) {
    var n, i;
    const a = e.toLocaleLowerCase(), { close: o, error: c, leave: l, join: u } = H;
    if (r && [o, c, l, u].indexOf(a) >= 0 && r !== this._joinRef())
      return;
    let h = this._onMessage(a, t, r);
    if (t && !h)
      throw "channel onMessage callbacks must return the payload, modified or unmodified";
    ["insert", "update", "delete"].includes(a) ? (n = this.bindings.postgres_changes) === null || n === void 0 || n.filter((f) => {
      var p, g, m;
      return ((p = f.filter) === null || p === void 0 ? void 0 : p.event) === "*" || ((m = (g = f.filter) === null || g === void 0 ? void 0 : g.event) === null || m === void 0 ? void 0 : m.toLocaleLowerCase()) === a;
    }).map((f) => f.callback(h, r)) : (i = this.bindings[a]) === null || i === void 0 || i.filter((f) => {
      var p, g, m, y, v, _;
      if (["broadcast", "presence", "postgres_changes"].includes(a))
        if ("id" in f) {
          const S = f.id, O = (p = f.filter) === null || p === void 0 ? void 0 : p.event;
          return S && ((g = t.ids) === null || g === void 0 ? void 0 : g.includes(S)) && (O === "*" || (O == null ? void 0 : O.toLocaleLowerCase()) === ((m = t.data) === null || m === void 0 ? void 0 : m.type.toLocaleLowerCase()));
        } else {
          const S = (v = (y = f == null ? void 0 : f.filter) === null || y === void 0 ? void 0 : y.event) === null || v === void 0 ? void 0 : v.toLocaleLowerCase();
          return S === "*" || S === ((_ = t == null ? void 0 : t.event) === null || _ === void 0 ? void 0 : _.toLocaleLowerCase());
        }
      else
        return f.type.toLocaleLowerCase() === a;
    }).map((f) => {
      if (typeof h == "object" && "ids" in h) {
        const p = h.data, { schema: g, table: m, commit_timestamp: y, type: v, errors: _ } = p;
        h = Object.assign(Object.assign({}, {
          schema: g,
          table: m,
          commit_timestamp: y,
          eventType: v,
          new: {},
          old: {},
          errors: _
        }), this._getPayloadRecords(p));
      }
      f.callback(h, r);
    });
  }
  /** @internal */
  _isClosed() {
    return this.state === N.closed;
  }
  /** @internal */
  _isJoined() {
    return this.state === N.joined;
  }
  /** @internal */
  _isJoining() {
    return this.state === N.joining;
  }
  /** @internal */
  _isLeaving() {
    return this.state === N.leaving;
  }
  /** @internal */
  _replyEventName(e) {
    return `chan_reply_${e}`;
  }
  /** @internal */
  _on(e, t, r) {
    const n = e.toLocaleLowerCase(), i = {
      type: n,
      filter: t,
      callback: r
    };
    return this.bindings[n] ? this.bindings[n].push(i) : this.bindings[n] = [i], this;
  }
  /** @internal */
  _off(e, t) {
    const r = e.toLocaleLowerCase();
    return this.bindings[r] && (this.bindings[r] = this.bindings[r].filter((n) => {
      var i;
      return !(((i = n.type) === null || i === void 0 ? void 0 : i.toLocaleLowerCase()) === r && ve.isEqual(n.filter, t));
    })), this;
  }
  /** @internal */
  static isEqual(e, t) {
    if (Object.keys(e).length !== Object.keys(t).length)
      return !1;
    for (const r in e)
      if (e[r] !== t[r])
        return !1;
    return !0;
  }
  /**
   * Compares two optional filter values for equality.
   * Treats undefined, null, and empty string as equivalent empty values.
   * @internal
   */
  static isFilterValueEqual(e, t) {
    return (e ?? void 0) === (t ?? void 0);
  }
  /** @internal */
  _rejoinUntilConnected() {
    this.rejoinTimer.scheduleTimeout(), this.socket.isConnected() && this._rejoin();
  }
  /**
   * Registers a callback that will be executed when the channel closes.
   *
   * @internal
   */
  _onClose(e) {
    this._on(H.close, {}, e);
  }
  /**
   * Registers a callback that will be executed when the channel encounteres an error.
   *
   * @internal
   */
  _onError(e) {
    this._on(H.error, {}, (t) => e(t));
  }
  /**
   * Returns `true` if the socket is connected and the channel has been joined.
   *
   * @internal
   */
  _canPush() {
    return this.socket.isConnected() && this._isJoined();
  }
  /** @internal */
  _rejoin(e = this.timeout) {
    this._isLeaving() || (this.socket._leaveOpenTopic(this.topic), this.state = N.joining, this.joinPush.resend(e));
  }
  /** @internal */
  _getPayloadRecords(e) {
    const t = {
      new: {},
      old: {}
    };
    return (e.type === "INSERT" || e.type === "UPDATE") && (t.new = jt(e.columns, e.record)), (e.type === "UPDATE" || e.type === "DELETE") && (t.old = jt(e.columns, e.old_record)), t;
  }
}
const tt = () => {
}, Ue = {
  HEARTBEAT_INTERVAL: 25e3,
  RECONNECT_DELAY: 10,
  HEARTBEAT_TIMEOUT_FALLBACK: 100
}, Nr = [1e3, 2e3, 5e3, 1e4], jr = 1e4, Ur = `
  addEventListener("message", (e) => {
    if (e.data.event === "start") {
      setInterval(() => postMessage({ event: "keepAlive" }), e.data.interval);
    }
  });`;
class Lr {
  /**
   * Initializes the Socket.
   *
   * @param endPoint The string WebSocket endpoint, ie, "ws://example.com/socket", "wss://example.com", "/socket" (inherited host & protocol)
   * @param httpEndpoint The string HTTP endpoint, ie, "https://example.com", "/" (inherited host & protocol)
   * @param options.transport The Websocket Transport, for example WebSocket. This can be a custom implementation
   * @param options.timeout The default timeout in milliseconds to trigger push timeouts.
   * @param options.params The optional params to pass when connecting.
   * @param options.headers Deprecated: headers cannot be set on websocket connections and this option will be removed in the future.
   * @param options.heartbeatIntervalMs The millisec interval to send a heartbeat message.
   * @param options.heartbeatCallback The optional function to handle heartbeat status and latency.
   * @param options.logger The optional function for specialized logging, ie: logger: (kind, msg, data) => { console.log(`${kind}: ${msg}`, data) }
   * @param options.logLevel Sets the log level for Realtime
   * @param options.encode The function to encode outgoing messages. Defaults to JSON: (payload, callback) => callback(JSON.stringify(payload))
   * @param options.decode The function to decode incoming messages. Defaults to Serializer's decode.
   * @param options.reconnectAfterMs he optional function that returns the millsec reconnect interval. Defaults to stepped backoff off.
   * @param options.worker Use Web Worker to set a side flow. Defaults to false.
   * @param options.workerUrl The URL of the worker script. Defaults to https://realtime.supabase.com/worker.js that includes a heartbeat event call to keep the connection alive.
   * @param options.vsn The protocol version to use when connecting. Supported versions are "1.0.0" and "2.0.0". Defaults to "2.0.0".
   * @example
   * ```ts
   * import RealtimeClient from '@supabase/realtime-js'
   *
   * const client = new RealtimeClient('https://xyzcompany.supabase.co/realtime/v1', {
   *   params: { apikey: 'public-anon-key' },
   * })
   * client.connect()
   * ```
   */
  constructor(e, t) {
    var r;
    if (this.accessTokenValue = null, this.apiKey = null, this._manuallySetToken = !1, this.channels = new Array(), this.endPoint = "", this.httpEndpoint = "", this.headers = {}, this.params = {}, this.timeout = ut, this.transport = null, this.heartbeatIntervalMs = Ue.HEARTBEAT_INTERVAL, this.heartbeatTimer = void 0, this.pendingHeartbeatRef = null, this.heartbeatCallback = tt, this.ref = 0, this.reconnectTimer = null, this.vsn = Nt, this.logger = tt, this.conn = null, this.sendBuffer = [], this.serializer = new Or(), this.stateChangeCallbacks = {
      open: [],
      close: [],
      error: [],
      message: []
    }, this.accessToken = null, this._connectionState = "disconnected", this._wasManualDisconnect = !1, this._authPromise = null, this._heartbeatSentAt = null, this._resolveFetch = (n) => n ? (...i) => n(...i) : (...i) => fetch(...i), !(!((r = t == null ? void 0 : t.params) === null || r === void 0) && r.apikey))
      throw new Error("API key is required to connect to Realtime");
    this.apiKey = t.params.apikey, this.endPoint = `${e}/${ht.websocket}`, this.httpEndpoint = $s(e), this._initializeOptions(t), this._setupReconnectionTimer(), this.fetch = this._resolveFetch(t == null ? void 0 : t.fetch);
  }
  /**
   * Connects the socket, unless already connected.
   */
  connect() {
    if (!(this.isConnecting() || this.isDisconnecting() || this.conn !== null && this.isConnected())) {
      if (this._setConnectionState("connecting"), this.accessToken && !this._authPromise && this._setAuthSafely("connect"), this.transport)
        this.conn = new this.transport(this.endpointURL());
      else
        try {
          this.conn = br.createWebSocket(this.endpointURL());
        } catch (e) {
          this._setConnectionState("disconnected");
          const t = e.message;
          throw t.includes("Node.js") ? new Error(`${t}

To use Realtime in Node.js, you need to provide a WebSocket implementation:

Option 1: Use Node.js 22+ which has native WebSocket support
Option 2: Install and provide the "ws" package:

  npm install ws

  import ws from "ws"
  const client = new RealtimeClient(url, {
    ...options,
    transport: ws
  })`) : new Error(`WebSocket not available: ${t}`);
        }
      this._setupConnectionHandlers();
    }
  }
  /**
   * Returns the URL of the websocket.
   * @returns string The URL of the websocket.
   */
  endpointURL() {
    return this._appendParams(this.endPoint, Object.assign({}, this.params, { vsn: this.vsn }));
  }
  /**
   * Disconnects the socket.
   *
   * @param code A numeric status code to send on disconnect.
   * @param reason A custom reason for the disconnect.
   */
  disconnect(e, t) {
    if (!this.isDisconnecting())
      if (this._setConnectionState("disconnecting", !0), this.conn) {
        const r = setTimeout(() => {
          this._setConnectionState("disconnected");
        }, 100);
        this.conn.onclose = () => {
          clearTimeout(r), this._setConnectionState("disconnected");
        }, typeof this.conn.close == "function" && (e ? this.conn.close(e, t ?? "") : this.conn.close()), this._teardownConnection();
      } else
        this._setConnectionState("disconnected");
  }
  /**
   * Returns all created channels
   */
  getChannels() {
    return this.channels;
  }
  /**
   * Unsubscribes and removes a single channel
   * @param channel A RealtimeChannel instance
   */
  async removeChannel(e) {
    const t = await e.unsubscribe();
    return this.channels.length === 0 && this.disconnect(), t;
  }
  /**
   * Unsubscribes and removes all channels
   */
  async removeAllChannels() {
    const e = await Promise.all(this.channels.map((t) => t.unsubscribe()));
    return this.channels = [], this.disconnect(), e;
  }
  /**
   * Logs the message.
   *
   * For customized logging, `this.logger` can be overridden.
   */
  log(e, t, r) {
    this.logger(e, t, r);
  }
  /**
   * Returns the current state of the socket.
   */
  connectionState() {
    switch (this.conn && this.conn.readyState) {
      case X.connecting:
        return ie.Connecting;
      case X.open:
        return ie.Open;
      case X.closing:
        return ie.Closing;
      default:
        return ie.Closed;
    }
  }
  /**
   * Returns `true` is the connection is open.
   */
  isConnected() {
    return this.connectionState() === ie.Open;
  }
  /**
   * Returns `true` if the connection is currently connecting.
   */
  isConnecting() {
    return this._connectionState === "connecting";
  }
  /**
   * Returns `true` if the connection is currently disconnecting.
   */
  isDisconnecting() {
    return this._connectionState === "disconnecting";
  }
  /**
   * Creates (or reuses) a {@link RealtimeChannel} for the provided topic.
   *
   * Topics are automatically prefixed with `realtime:` to match the Realtime service.
   * If a channel with the same topic already exists it will be returned instead of creating
   * a duplicate connection.
   */
  channel(e, t = { config: {} }) {
    const r = `realtime:${e}`, n = this.getChannels().find((i) => i.topic === r);
    if (n)
      return n;
    {
      const i = new ve(`realtime:${e}`, t, this);
      return this.channels.push(i), i;
    }
  }
  /**
   * Push out a message if the socket is connected.
   *
   * If the socket is not connected, the message gets enqueued within a local buffer, and sent out when a connection is next established.
   */
  push(e) {
    const { topic: t, event: r, payload: n, ref: i } = e, a = () => {
      this.encode(e, (o) => {
        var c;
        (c = this.conn) === null || c === void 0 || c.send(o);
      });
    };
    this.log("push", `${t} ${r} (${i})`, n), this.isConnected() ? a() : this.sendBuffer.push(a);
  }
  /**
   * Sets the JWT access token used for channel subscription authorization and Realtime RLS.
   *
   * If param is null it will use the `accessToken` callback function or the token set on the client.
   *
   * On callback used, it will set the value of the token internal to the client.
   *
   * When a token is explicitly provided, it will be preserved across channel operations
   * (including removeChannel and resubscribe). The `accessToken` callback will not be
   * invoked until `setAuth()` is called without arguments.
   *
   * @param token A JWT string to override the token set on the client.
   *
   * @example
   * // Use a manual token (preserved across resubscribes, ignores accessToken callback)
   * client.realtime.setAuth('my-custom-jwt')
   *
   * // Switch back to using the accessToken callback
   * client.realtime.setAuth()
   */
  async setAuth(e = null) {
    this._authPromise = this._performAuth(e);
    try {
      await this._authPromise;
    } finally {
      this._authPromise = null;
    }
  }
  /**
   * Returns true if the current access token was explicitly set via setAuth(token),
   * false if it was obtained via the accessToken callback.
   * @internal
   */
  _isManualToken() {
    return this._manuallySetToken;
  }
  /**
   * Sends a heartbeat message if the socket is connected.
   */
  async sendHeartbeat() {
    var e;
    if (!this.isConnected()) {
      try {
        this.heartbeatCallback("disconnected");
      } catch (t) {
        this.log("error", "error in heartbeat callback", t);
      }
      return;
    }
    if (this.pendingHeartbeatRef) {
      this.pendingHeartbeatRef = null, this._heartbeatSentAt = null, this.log("transport", "heartbeat timeout. Attempting to re-establish connection");
      try {
        this.heartbeatCallback("timeout");
      } catch (t) {
        this.log("error", "error in heartbeat callback", t);
      }
      this._wasManualDisconnect = !1, (e = this.conn) === null || e === void 0 || e.close(Ar, "heartbeat timeout"), setTimeout(() => {
        var t;
        this.isConnected() || (t = this.reconnectTimer) === null || t === void 0 || t.scheduleTimeout();
      }, Ue.HEARTBEAT_TIMEOUT_FALLBACK);
      return;
    }
    this._heartbeatSentAt = Date.now(), this.pendingHeartbeatRef = this._makeRef(), this.push({
      topic: "phoenix",
      event: "heartbeat",
      payload: {},
      ref: this.pendingHeartbeatRef
    });
    try {
      this.heartbeatCallback("sent");
    } catch (t) {
      this.log("error", "error in heartbeat callback", t);
    }
    this._setAuthSafely("heartbeat");
  }
  /**
   * Sets a callback that receives lifecycle events for internal heartbeat messages.
   * Useful for instrumenting connection health (e.g. sent/ok/timeout/disconnected).
   */
  onHeartbeat(e) {
    this.heartbeatCallback = e;
  }
  /**
   * Flushes send buffer
   */
  flushSendBuffer() {
    this.isConnected() && this.sendBuffer.length > 0 && (this.sendBuffer.forEach((e) => e()), this.sendBuffer = []);
  }
  /**
   * Return the next message ref, accounting for overflows
   *
   * @internal
   */
  _makeRef() {
    let e = this.ref + 1;
    return e === this.ref ? this.ref = 0 : this.ref = e, this.ref.toString();
  }
  /**
   * Unsubscribe from channels with the specified topic.
   *
   * @internal
   */
  _leaveOpenTopic(e) {
    let t = this.channels.find((r) => r.topic === e && (r._isJoined() || r._isJoining()));
    t && (this.log("transport", `leaving duplicate topic "${e}"`), t.unsubscribe());
  }
  /**
   * Removes a subscription from the socket.
   *
   * @param channel An open subscription.
   *
   * @internal
   */
  _remove(e) {
    this.channels = this.channels.filter((t) => t.topic !== e.topic);
  }
  /** @internal */
  _onConnMessage(e) {
    this.decode(e.data, (t) => {
      if (t.topic === "phoenix" && t.event === "phx_reply" && t.ref && t.ref === this.pendingHeartbeatRef) {
        const l = this._heartbeatSentAt ? Date.now() - this._heartbeatSentAt : void 0;
        try {
          this.heartbeatCallback(t.payload.status === "ok" ? "ok" : "error", l);
        } catch (u) {
          this.log("error", "error in heartbeat callback", u);
        }
        this._heartbeatSentAt = null, this.pendingHeartbeatRef = null;
      }
      const { topic: r, event: n, payload: i, ref: a } = t, o = a ? `(${a})` : "", c = i.status || "";
      this.log("receive", `${c} ${r} ${n} ${o}`.trim(), i), this.channels.filter((l) => l._isMember(r)).forEach((l) => l._trigger(n, i, a)), this._triggerStateCallbacks("message", t);
    });
  }
  /**
   * Clear specific timer
   * @internal
   */
  _clearTimer(e) {
    var t;
    e === "heartbeat" && this.heartbeatTimer ? (clearInterval(this.heartbeatTimer), this.heartbeatTimer = void 0) : e === "reconnect" && ((t = this.reconnectTimer) === null || t === void 0 || t.reset());
  }
  /**
   * Clear all timers
   * @internal
   */
  _clearAllTimers() {
    this._clearTimer("heartbeat"), this._clearTimer("reconnect");
  }
  /**
   * Setup connection handlers for WebSocket events
   * @internal
   */
  _setupConnectionHandlers() {
    this.conn && ("binaryType" in this.conn && (this.conn.binaryType = "arraybuffer"), this.conn.onopen = () => this._onConnOpen(), this.conn.onerror = (e) => this._onConnError(e), this.conn.onmessage = (e) => this._onConnMessage(e), this.conn.onclose = (e) => this._onConnClose(e), this.conn.readyState === X.open && this._onConnOpen());
  }
  /**
   * Teardown connection and cleanup resources
   * @internal
   */
  _teardownConnection() {
    if (this.conn) {
      if (this.conn.readyState === X.open || this.conn.readyState === X.connecting)
        try {
          this.conn.close();
        } catch (e) {
          this.log("error", "Error closing connection", e);
        }
      this.conn.onopen = null, this.conn.onerror = null, this.conn.onmessage = null, this.conn.onclose = null, this.conn = null;
    }
    this._clearAllTimers(), this._terminateWorker(), this.channels.forEach((e) => e.teardown());
  }
  /** @internal */
  _onConnOpen() {
    this._setConnectionState("connected"), this.log("transport", `connected to ${this.endpointURL()}`), (this._authPromise || (this.accessToken && !this.accessTokenValue ? this.setAuth() : Promise.resolve())).then(() => {
      this.flushSendBuffer();
    }).catch((t) => {
      this.log("error", "error waiting for auth on connect", t), this.flushSendBuffer();
    }), this._clearTimer("reconnect"), this.worker ? this.workerRef || this._startWorkerHeartbeat() : this._startHeartbeat(), this._triggerStateCallbacks("open");
  }
  /** @internal */
  _startHeartbeat() {
    this.heartbeatTimer && clearInterval(this.heartbeatTimer), this.heartbeatTimer = setInterval(() => this.sendHeartbeat(), this.heartbeatIntervalMs);
  }
  /** @internal */
  _startWorkerHeartbeat() {
    this.workerUrl ? this.log("worker", `starting worker for from ${this.workerUrl}`) : this.log("worker", "starting default worker");
    const e = this._workerObjectUrl(this.workerUrl);
    this.workerRef = new Worker(e), this.workerRef.onerror = (t) => {
      this.log("worker", "worker error", t.message), this._terminateWorker();
    }, this.workerRef.onmessage = (t) => {
      t.data.event === "keepAlive" && this.sendHeartbeat();
    }, this.workerRef.postMessage({
      event: "start",
      interval: this.heartbeatIntervalMs
    });
  }
  /**
   * Terminate the Web Worker and clear the reference
   * @internal
   */
  _terminateWorker() {
    this.workerRef && (this.log("worker", "terminating worker"), this.workerRef.terminate(), this.workerRef = void 0);
  }
  /** @internal */
  _onConnClose(e) {
    var t;
    this._setConnectionState("disconnected"), this.log("transport", "close", e), this._triggerChanError(), this._clearTimer("heartbeat"), this._wasManualDisconnect || (t = this.reconnectTimer) === null || t === void 0 || t.scheduleTimeout(), this._triggerStateCallbacks("close", e);
  }
  /** @internal */
  _onConnError(e) {
    this._setConnectionState("disconnected"), this.log("transport", `${e}`), this._triggerChanError(), this._triggerStateCallbacks("error", e);
    try {
      this.heartbeatCallback("error");
    } catch (t) {
      this.log("error", "error in heartbeat callback", t);
    }
  }
  /** @internal */
  _triggerChanError() {
    this.channels.forEach((e) => e._trigger(H.error));
  }
  /** @internal */
  _appendParams(e, t) {
    if (Object.keys(t).length === 0)
      return e;
    const r = e.match(/\?/) ? "&" : "?", n = new URLSearchParams(t);
    return `${e}${r}${n}`;
  }
  _workerObjectUrl(e) {
    let t;
    if (e)
      t = e;
    else {
      const r = new Blob([Ur], { type: "application/javascript" });
      t = URL.createObjectURL(r);
    }
    return t;
  }
  /**
   * Set connection state with proper state management
   * @internal
   */
  _setConnectionState(e, t = !1) {
    this._connectionState = e, e === "connecting" ? this._wasManualDisconnect = !1 : e === "disconnecting" && (this._wasManualDisconnect = t);
  }
  /**
   * Perform the actual auth operation
   * @internal
   */
  async _performAuth(e = null) {
    let t, r = !1;
    if (e)
      t = e, r = !0;
    else if (this.accessToken)
      try {
        t = await this.accessToken();
      } catch (n) {
        this.log("error", "Error fetching access token from callback", n), t = this.accessTokenValue;
      }
    else
      t = this.accessTokenValue;
    r ? this._manuallySetToken = !0 : this.accessToken && (this._manuallySetToken = !1), this.accessTokenValue != t && (this.accessTokenValue = t, this.channels.forEach((n) => {
      const i = {
        access_token: t,
        version: Er
      };
      t && n.updateJoinPayload(i), n.joinedOnce && n._isJoined() && n._push(H.access_token, {
        access_token: t
      });
    }));
  }
  /**
   * Wait for any in-flight auth operations to complete
   * @internal
   */
  async _waitForAuthIfNeeded() {
    this._authPromise && await this._authPromise;
  }
  /**
   * Safely call setAuth with standardized error handling
   * @internal
   */
  _setAuthSafely(e = "general") {
    this._isManualToken() || this.setAuth().catch((t) => {
      this.log("error", `Error setting auth in ${e}`, t);
    });
  }
  /**
   * Trigger state change callbacks with proper error handling
   * @internal
   */
  _triggerStateCallbacks(e, t) {
    try {
      this.stateChangeCallbacks[e].forEach((r) => {
        try {
          r(t);
        } catch (n) {
          this.log("error", `error in ${e} callback`, n);
        }
      });
    } catch (r) {
      this.log("error", `error triggering ${e} callbacks`, r);
    }
  }
  /**
   * Setup reconnection timer with proper configuration
   * @internal
   */
  _setupReconnectionTimer() {
    this.reconnectTimer = new Cs(async () => {
      setTimeout(async () => {
        await this._waitForAuthIfNeeded(), this.isConnected() || this.connect();
      }, Ue.RECONNECT_DELAY);
    }, this.reconnectAfterMs);
  }
  /**
   * Initialize client options with defaults
   * @internal
   */
  _initializeOptions(e) {
    var t, r, n, i, a, o, c, l, u, d, h, f;
    switch (this.transport = (t = e == null ? void 0 : e.transport) !== null && t !== void 0 ? t : null, this.timeout = (r = e == null ? void 0 : e.timeout) !== null && r !== void 0 ? r : ut, this.heartbeatIntervalMs = (n = e == null ? void 0 : e.heartbeatIntervalMs) !== null && n !== void 0 ? n : Ue.HEARTBEAT_INTERVAL, this.worker = (i = e == null ? void 0 : e.worker) !== null && i !== void 0 ? i : !1, this.accessToken = (a = e == null ? void 0 : e.accessToken) !== null && a !== void 0 ? a : null, this.heartbeatCallback = (o = e == null ? void 0 : e.heartbeatCallback) !== null && o !== void 0 ? o : tt, this.vsn = (c = e == null ? void 0 : e.vsn) !== null && c !== void 0 ? c : Nt, e != null && e.params && (this.params = e.params), e != null && e.logger && (this.logger = e.logger), (e != null && e.logLevel || e != null && e.log_level) && (this.logLevel = e.logLevel || e.log_level, this.params = Object.assign(Object.assign({}, this.params), { log_level: this.logLevel })), this.reconnectAfterMs = (l = e == null ? void 0 : e.reconnectAfterMs) !== null && l !== void 0 ? l : (p) => Nr[p - 1] || jr, this.vsn) {
      case Tr:
        this.encode = (u = e == null ? void 0 : e.encode) !== null && u !== void 0 ? u : (p, g) => g(JSON.stringify(p)), this.decode = (d = e == null ? void 0 : e.decode) !== null && d !== void 0 ? d : (p, g) => g(JSON.parse(p));
        break;
      case Rs:
        this.encode = (h = e == null ? void 0 : e.encode) !== null && h !== void 0 ? h : this.serializer.encode.bind(this.serializer), this.decode = (f = e == null ? void 0 : e.decode) !== null && f !== void 0 ? f : this.serializer.decode.bind(this.serializer);
        break;
      default:
        throw new Error(`Unsupported serializer version: ${this.vsn}`);
    }
    if (this.worker) {
      if (typeof window < "u" && !window.Worker)
        throw new Error("Web Worker is not supported");
      this.workerUrl = e == null ? void 0 : e.workerUrl;
    }
  }
}
var Ce = class extends Error {
  constructor(s, e) {
    var t;
    super(s), this.name = "IcebergError", this.status = e.status, this.icebergType = e.icebergType, this.icebergCode = e.icebergCode, this.details = e.details, this.isCommitStateUnknown = e.icebergType === "CommitStateUnknownException" || [500, 502, 504].includes(e.status) && ((t = e.icebergType) == null ? void 0 : t.includes("CommitState")) === !0;
  }
  /**
   * Returns true if the error is a 404 Not Found error.
   */
  isNotFound() {
    return this.status === 404;
  }
  /**
   * Returns true if the error is a 409 Conflict error.
   */
  isConflict() {
    return this.status === 409;
  }
  /**
   * Returns true if the error is a 419 Authentication Timeout error.
   */
  isAuthenticationTimeout() {
    return this.status === 419;
  }
};
function Dr(s, e, t) {
  const r = new URL(e, s);
  if (t)
    for (const [n, i] of Object.entries(t))
      i !== void 0 && r.searchParams.set(n, i);
  return r.toString();
}
async function Mr(s) {
  return !s || s.type === "none" ? {} : s.type === "bearer" ? { Authorization: `Bearer ${s.token}` } : s.type === "header" ? { [s.name]: s.value } : s.type === "custom" ? await s.getHeaders() : {};
}
function Br(s) {
  const e = s.fetchImpl ?? globalThis.fetch;
  return {
    async request({
      method: t,
      path: r,
      query: n,
      body: i,
      headers: a
    }) {
      const o = Dr(s.baseUrl, r, n), c = await Mr(s.auth), l = await e(o, {
        method: t,
        headers: {
          ...i ? { "Content-Type": "application/json" } : {},
          ...c,
          ...a
        },
        body: i ? JSON.stringify(i) : void 0
      }), u = await l.text(), d = (l.headers.get("content-type") || "").includes("application/json"), h = d && u ? JSON.parse(u) : u;
      if (!l.ok) {
        const f = d ? h : void 0, p = f == null ? void 0 : f.error;
        throw new Ce(
          (p == null ? void 0 : p.message) ?? `Request failed with status ${l.status}`,
          {
            status: l.status,
            icebergType: p == null ? void 0 : p.type,
            icebergCode: p == null ? void 0 : p.code,
            details: f
          }
        );
      }
      return { status: l.status, headers: l.headers, data: h };
    }
  };
}
function Le(s) {
  return s.join("");
}
var qr = class {
  constructor(s, e = "") {
    this.client = s, this.prefix = e;
  }
  async listNamespaces(s) {
    const e = s ? { parent: Le(s.namespace) } : void 0;
    return (await this.client.request({
      method: "GET",
      path: `${this.prefix}/namespaces`,
      query: e
    })).data.namespaces.map((r) => ({ namespace: r }));
  }
  async createNamespace(s, e) {
    const t = {
      namespace: s.namespace,
      properties: e == null ? void 0 : e.properties
    };
    return (await this.client.request({
      method: "POST",
      path: `${this.prefix}/namespaces`,
      body: t
    })).data;
  }
  async dropNamespace(s) {
    await this.client.request({
      method: "DELETE",
      path: `${this.prefix}/namespaces/${Le(s.namespace)}`
    });
  }
  async loadNamespaceMetadata(s) {
    return {
      properties: (await this.client.request({
        method: "GET",
        path: `${this.prefix}/namespaces/${Le(s.namespace)}`
      })).data.properties
    };
  }
  async namespaceExists(s) {
    try {
      return await this.client.request({
        method: "HEAD",
        path: `${this.prefix}/namespaces/${Le(s.namespace)}`
      }), !0;
    } catch (e) {
      if (e instanceof Ce && e.status === 404)
        return !1;
      throw e;
    }
  }
  async createNamespaceIfNotExists(s, e) {
    try {
      return await this.createNamespace(s, e);
    } catch (t) {
      if (t instanceof Ce && t.status === 409)
        return;
      throw t;
    }
  }
};
function ue(s) {
  return s.join("");
}
var Fr = class {
  constructor(s, e = "", t) {
    this.client = s, this.prefix = e, this.accessDelegation = t;
  }
  async listTables(s) {
    return (await this.client.request({
      method: "GET",
      path: `${this.prefix}/namespaces/${ue(s.namespace)}/tables`
    })).data.identifiers;
  }
  async createTable(s, e) {
    const t = {};
    return this.accessDelegation && (t["X-Iceberg-Access-Delegation"] = this.accessDelegation), (await this.client.request({
      method: "POST",
      path: `${this.prefix}/namespaces/${ue(s.namespace)}/tables`,
      body: e,
      headers: t
    })).data.metadata;
  }
  async updateTable(s, e) {
    const t = await this.client.request({
      method: "POST",
      path: `${this.prefix}/namespaces/${ue(s.namespace)}/tables/${s.name}`,
      body: e
    });
    return {
      "metadata-location": t.data["metadata-location"],
      metadata: t.data.metadata
    };
  }
  async dropTable(s, e) {
    await this.client.request({
      method: "DELETE",
      path: `${this.prefix}/namespaces/${ue(s.namespace)}/tables/${s.name}`,
      query: { purgeRequested: String((e == null ? void 0 : e.purge) ?? !1) }
    });
  }
  async loadTable(s) {
    const e = {};
    return this.accessDelegation && (e["X-Iceberg-Access-Delegation"] = this.accessDelegation), (await this.client.request({
      method: "GET",
      path: `${this.prefix}/namespaces/${ue(s.namespace)}/tables/${s.name}`,
      headers: e
    })).data.metadata;
  }
  async tableExists(s) {
    const e = {};
    this.accessDelegation && (e["X-Iceberg-Access-Delegation"] = this.accessDelegation);
    try {
      return await this.client.request({
        method: "HEAD",
        path: `${this.prefix}/namespaces/${ue(s.namespace)}/tables/${s.name}`,
        headers: e
      }), !0;
    } catch (t) {
      if (t instanceof Ce && t.status === 404)
        return !1;
      throw t;
    }
  }
  async createTableIfNotExists(s, e) {
    try {
      return await this.createTable(s, e);
    } catch (t) {
      if (t instanceof Ce && t.status === 409)
        return await this.loadTable({ namespace: s.namespace, name: e.name });
      throw t;
    }
  }
}, Hr = class {
  /**
   * Creates a new Iceberg REST Catalog client.
   *
   * @param options - Configuration options for the catalog client
   */
  constructor(s) {
    var r;
    let e = "v1";
    s.catalogName && (e += `/${s.catalogName}`);
    const t = s.baseUrl.endsWith("/") ? s.baseUrl : `${s.baseUrl}/`;
    this.client = Br({
      baseUrl: t,
      auth: s.auth,
      fetchImpl: s.fetch
    }), this.accessDelegation = (r = s.accessDelegation) == null ? void 0 : r.join(","), this.namespaceOps = new qr(this.client, e), this.tableOps = new Fr(this.client, e, this.accessDelegation);
  }
  /**
   * Lists all namespaces in the catalog.
   *
   * @param parent - Optional parent namespace to list children under
   * @returns Array of namespace identifiers
   *
   * @example
   * ```typescript
   * // List all top-level namespaces
   * const namespaces = await catalog.listNamespaces();
   *
   * // List namespaces under a parent
   * const children = await catalog.listNamespaces({ namespace: ['analytics'] });
   * ```
   */
  async listNamespaces(s) {
    return this.namespaceOps.listNamespaces(s);
  }
  /**
   * Creates a new namespace in the catalog.
   *
   * @param id - Namespace identifier to create
   * @param metadata - Optional metadata properties for the namespace
   * @returns Response containing the created namespace and its properties
   *
   * @example
   * ```typescript
   * const response = await catalog.createNamespace(
   *   { namespace: ['analytics'] },
   *   { properties: { owner: 'data-team' } }
   * );
   * console.log(response.namespace); // ['analytics']
   * console.log(response.properties); // { owner: 'data-team', ... }
   * ```
   */
  async createNamespace(s, e) {
    return this.namespaceOps.createNamespace(s, e);
  }
  /**
   * Drops a namespace from the catalog.
   *
   * The namespace must be empty (contain no tables) before it can be dropped.
   *
   * @param id - Namespace identifier to drop
   *
   * @example
   * ```typescript
   * await catalog.dropNamespace({ namespace: ['analytics'] });
   * ```
   */
  async dropNamespace(s) {
    await this.namespaceOps.dropNamespace(s);
  }
  /**
   * Loads metadata for a namespace.
   *
   * @param id - Namespace identifier to load
   * @returns Namespace metadata including properties
   *
   * @example
   * ```typescript
   * const metadata = await catalog.loadNamespaceMetadata({ namespace: ['analytics'] });
   * console.log(metadata.properties);
   * ```
   */
  async loadNamespaceMetadata(s) {
    return this.namespaceOps.loadNamespaceMetadata(s);
  }
  /**
   * Lists all tables in a namespace.
   *
   * @param namespace - Namespace identifier to list tables from
   * @returns Array of table identifiers
   *
   * @example
   * ```typescript
   * const tables = await catalog.listTables({ namespace: ['analytics'] });
   * console.log(tables); // [{ namespace: ['analytics'], name: 'events' }, ...]
   * ```
   */
  async listTables(s) {
    return this.tableOps.listTables(s);
  }
  /**
   * Creates a new table in the catalog.
   *
   * @param namespace - Namespace to create the table in
   * @param request - Table creation request including name, schema, partition spec, etc.
   * @returns Table metadata for the created table
   *
   * @example
   * ```typescript
   * const metadata = await catalog.createTable(
   *   { namespace: ['analytics'] },
   *   {
   *     name: 'events',
   *     schema: {
   *       type: 'struct',
   *       fields: [
   *         { id: 1, name: 'id', type: 'long', required: true },
   *         { id: 2, name: 'timestamp', type: 'timestamp', required: true }
   *       ],
   *       'schema-id': 0
   *     },
   *     'partition-spec': {
   *       'spec-id': 0,
   *       fields: [
   *         { source_id: 2, field_id: 1000, name: 'ts_day', transform: 'day' }
   *       ]
   *     }
   *   }
   * );
   * ```
   */
  async createTable(s, e) {
    return this.tableOps.createTable(s, e);
  }
  /**
   * Updates an existing table's metadata.
   *
   * Can update the schema, partition spec, or properties of a table.
   *
   * @param id - Table identifier to update
   * @param request - Update request with fields to modify
   * @returns Response containing the metadata location and updated table metadata
   *
   * @example
   * ```typescript
   * const response = await catalog.updateTable(
   *   { namespace: ['analytics'], name: 'events' },
   *   {
   *     properties: { 'read.split.target-size': '134217728' }
   *   }
   * );
   * console.log(response['metadata-location']); // s3://...
   * console.log(response.metadata); // TableMetadata object
   * ```
   */
  async updateTable(s, e) {
    return this.tableOps.updateTable(s, e);
  }
  /**
   * Drops a table from the catalog.
   *
   * @param id - Table identifier to drop
   *
   * @example
   * ```typescript
   * await catalog.dropTable({ namespace: ['analytics'], name: 'events' });
   * ```
   */
  async dropTable(s, e) {
    await this.tableOps.dropTable(s, e);
  }
  /**
   * Loads metadata for a table.
   *
   * @param id - Table identifier to load
   * @returns Table metadata including schema, partition spec, location, etc.
   *
   * @example
   * ```typescript
   * const metadata = await catalog.loadTable({ namespace: ['analytics'], name: 'events' });
   * console.log(metadata.schema);
   * console.log(metadata.location);
   * ```
   */
  async loadTable(s) {
    return this.tableOps.loadTable(s);
  }
  /**
   * Checks if a namespace exists in the catalog.
   *
   * @param id - Namespace identifier to check
   * @returns True if the namespace exists, false otherwise
   *
   * @example
   * ```typescript
   * const exists = await catalog.namespaceExists({ namespace: ['analytics'] });
   * console.log(exists); // true or false
   * ```
   */
  async namespaceExists(s) {
    return this.namespaceOps.namespaceExists(s);
  }
  /**
   * Checks if a table exists in the catalog.
   *
   * @param id - Table identifier to check
   * @returns True if the table exists, false otherwise
   *
   * @example
   * ```typescript
   * const exists = await catalog.tableExists({ namespace: ['analytics'], name: 'events' });
   * console.log(exists); // true or false
   * ```
   */
  async tableExists(s) {
    return this.tableOps.tableExists(s);
  }
  /**
   * Creates a namespace if it does not exist.
   *
   * If the namespace already exists, returns void. If created, returns the response.
   *
   * @param id - Namespace identifier to create
   * @param metadata - Optional metadata properties for the namespace
   * @returns Response containing the created namespace and its properties, or void if it already exists
   *
   * @example
   * ```typescript
   * const response = await catalog.createNamespaceIfNotExists(
   *   { namespace: ['analytics'] },
   *   { properties: { owner: 'data-team' } }
   * );
   * if (response) {
   *   console.log('Created:', response.namespace);
   * } else {
   *   console.log('Already exists');
   * }
   * ```
   */
  async createNamespaceIfNotExists(s, e) {
    return this.namespaceOps.createNamespaceIfNotExists(s, e);
  }
  /**
   * Creates a table if it does not exist.
   *
   * If the table already exists, returns its metadata instead.
   *
   * @param namespace - Namespace to create the table in
   * @param request - Table creation request including name, schema, partition spec, etc.
   * @returns Table metadata for the created or existing table
   *
   * @example
   * ```typescript
   * const metadata = await catalog.createTableIfNotExists(
   *   { namespace: ['analytics'] },
   *   {
   *     name: 'events',
   *     schema: {
   *       type: 'struct',
   *       fields: [
   *         { id: 1, name: 'id', type: 'long', required: true },
   *         { id: 2, name: 'timestamp', type: 'timestamp', required: true }
   *       ],
   *       'schema-id': 0
   *     }
   *   }
   * );
   * ```
   */
  async createTableIfNotExists(s, e) {
    return this.tableOps.createTableIfNotExists(s, e);
  }
}, Ye = class extends Error {
  constructor(s, e = "storage", t, r) {
    super(s), this.__isStorageError = !0, this.namespace = e, this.name = e === "vectors" ? "StorageVectorsError" : "StorageError", this.status = t, this.statusCode = r;
  }
};
function Qe(s) {
  return typeof s == "object" && s !== null && "__isStorageError" in s;
}
var De = class extends Ye {
  constructor(s, e, t, r = "storage") {
    super(s, r, e, t), this.name = r === "vectors" ? "StorageVectorsApiError" : "StorageApiError", this.status = e, this.statusCode = t;
  }
  toJSON() {
    return {
      name: this.name,
      message: this.message,
      status: this.status,
      statusCode: this.statusCode
    };
  }
}, xs = class extends Ye {
  constructor(s, e, t = "storage") {
    super(s, t), this.name = t === "vectors" ? "StorageVectorsUnknownError" : "StorageUnknownError", this.originalError = e;
  }
};
const Vr = (s) => s ? (...e) => s(...e) : (...e) => fetch(...e), Kr = (s) => {
  if (typeof s != "object" || s === null) return !1;
  const e = Object.getPrototypeOf(s);
  return (e === null || e === Object.prototype || Object.getPrototypeOf(e) === null) && !(Symbol.toStringTag in s) && !(Symbol.iterator in s);
}, ft = (s) => {
  if (Array.isArray(s)) return s.map((t) => ft(t));
  if (typeof s == "function" || s !== Object(s)) return s;
  const e = {};
  return Object.entries(s).forEach(([t, r]) => {
    const n = t.replace(/([-_][a-z])/gi, (i) => i.toUpperCase().replace(/[-_]/g, ""));
    e[n] = ft(r);
  }), e;
}, Gr = (s) => !s || typeof s != "string" || s.length === 0 || s.length > 100 || s.trim() !== s || s.includes("/") || s.includes("\\") ? !1 : /^[\w!.\*'() &$@=;:+,?-]+$/.test(s);
function Ie(s) {
  "@babel/helpers - typeof";
  return Ie = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
    return typeof e;
  } : function(e) {
    return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
  }, Ie(s);
}
function zr(s, e) {
  if (Ie(s) != "object" || !s) return s;
  var t = s[Symbol.toPrimitive];
  if (t !== void 0) {
    var r = t.call(s, e);
    if (Ie(r) != "object") return r;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (e === "string" ? String : Number)(s);
}
function Wr(s) {
  var e = zr(s, "string");
  return Ie(e) == "symbol" ? e : e + "";
}
function Jr(s, e, t) {
  return (e = Wr(e)) in s ? Object.defineProperty(s, e, {
    value: t,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : s[e] = t, s;
}
function Dt(s, e) {
  var t = Object.keys(s);
  if (Object.getOwnPropertySymbols) {
    var r = Object.getOwnPropertySymbols(s);
    e && (r = r.filter(function(n) {
      return Object.getOwnPropertyDescriptor(s, n).enumerable;
    })), t.push.apply(t, r);
  }
  return t;
}
function T(s) {
  for (var e = 1; e < arguments.length; e++) {
    var t = arguments[e] != null ? arguments[e] : {};
    e % 2 ? Dt(Object(t), !0).forEach(function(r) {
      Jr(s, r, t[r]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(s, Object.getOwnPropertyDescriptors(t)) : Dt(Object(t)).forEach(function(r) {
      Object.defineProperty(s, r, Object.getOwnPropertyDescriptor(t, r));
    });
  }
  return s;
}
const Mt = (s) => {
  var e;
  return s.msg || s.message || s.error_description || (typeof s.error == "string" ? s.error : (e = s.error) === null || e === void 0 ? void 0 : e.message) || JSON.stringify(s);
}, Yr = async (s, e, t, r) => {
  if (s && typeof s == "object" && "status" in s && "ok" in s && typeof s.status == "number" && !(t != null && t.noResolveJson)) {
    const n = s, i = n.status || 500;
    if (typeof n.json == "function") n.json().then((a) => {
      const o = (a == null ? void 0 : a.statusCode) || (a == null ? void 0 : a.code) || i + "";
      e(new De(Mt(a), i, o, r));
    }).catch(() => {
      if (r === "vectors") {
        const a = i + "";
        e(new De(n.statusText || `HTTP ${i} error`, i, a, r));
      } else {
        const a = i + "";
        e(new De(n.statusText || `HTTP ${i} error`, i, a, r));
      }
    });
    else {
      const a = i + "";
      e(new De(n.statusText || `HTTP ${i} error`, i, a, r));
    }
  } else e(new xs(Mt(s), s, r));
}, Qr = (s, e, t, r) => {
  const n = {
    method: s,
    headers: (e == null ? void 0 : e.headers) || {}
  };
  return s === "GET" || s === "HEAD" || !r ? T(T({}, n), t) : (Kr(r) ? (n.headers = T({ "Content-Type": "application/json" }, e == null ? void 0 : e.headers), n.body = JSON.stringify(r)) : n.body = r, e != null && e.duplex && (n.duplex = e.duplex), T(T({}, n), t));
};
async function Ae(s, e, t, r, n, i, a) {
  return new Promise((o, c) => {
    s(t, Qr(e, r, n, i)).then((l) => {
      if (!l.ok) throw l;
      if (r != null && r.noResolveJson) return l;
      if (a === "vectors") {
        const u = l.headers.get("content-type");
        if (l.headers.get("content-length") === "0" || l.status === 204) return {};
        if (!u || !u.includes("application/json")) return {};
      }
      return l.json();
    }).then((l) => o(l)).catch((l) => Yr(l, c, r, a));
  });
}
function Ps(s = "storage") {
  return {
    get: async (e, t, r, n) => Ae(e, "GET", t, r, n, void 0, s),
    post: async (e, t, r, n, i) => Ae(e, "POST", t, n, i, r, s),
    put: async (e, t, r, n, i) => Ae(e, "PUT", t, n, i, r, s),
    head: async (e, t, r, n) => Ae(e, "HEAD", t, T(T({}, r), {}, { noResolveJson: !0 }), n, void 0, s),
    remove: async (e, t, r, n, i) => Ae(e, "DELETE", t, n, i, r, s)
  };
}
const Xr = Ps("storage"), { get: $e, post: F, put: pt, head: Zr, remove: Ot } = Xr, D = Ps("vectors");
var Te = class {
  /**
  * Creates a new BaseApiClient instance
  * @param url - Base URL for API requests
  * @param headers - Default headers for API requests
  * @param fetch - Optional custom fetch implementation
  * @param namespace - Error namespace ('storage' or 'vectors')
  */
  constructor(s, e = {}, t, r = "storage") {
    this.shouldThrowOnError = !1, this.url = s, this.headers = e, this.fetch = Vr(t), this.namespace = r;
  }
  /**
  * Enable throwing errors instead of returning them.
  * When enabled, errors are thrown instead of returned in { data, error } format.
  *
  * @returns this - For method chaining
  */
  throwOnError() {
    return this.shouldThrowOnError = !0, this;
  }
  /**
  * Handles API operation with standardized error handling
  * Eliminates repetitive try-catch blocks across all API methods
  *
  * This wrapper:
  * 1. Executes the operation
  * 2. Returns { data, error: null } on success
  * 3. Returns { data: null, error } on failure (if shouldThrowOnError is false)
  * 4. Throws error on failure (if shouldThrowOnError is true)
  *
  * @typeParam T - The expected data type from the operation
  * @param operation - Async function that performs the API call
  * @returns Promise with { data, error } tuple
  *
  * @example
  * ```typescript
  * async listBuckets() {
  *   return this.handleOperation(async () => {
  *     return await get(this.fetch, `${this.url}/bucket`, {
  *       headers: this.headers,
  *     })
  *   })
  * }
  * ```
  */
  async handleOperation(s) {
    var e = this;
    try {
      return {
        data: await s(),
        error: null
      };
    } catch (t) {
      if (e.shouldThrowOnError) throw t;
      if (Qe(t)) return {
        data: null,
        error: t
      };
      throw t;
    }
  }
}, en = class {
  constructor(s, e) {
    this.downloadFn = s, this.shouldThrowOnError = e;
  }
  then(s, e) {
    return this.execute().then(s, e);
  }
  async execute() {
    var s = this;
    try {
      return {
        data: (await s.downloadFn()).body,
        error: null
      };
    } catch (e) {
      if (s.shouldThrowOnError) throw e;
      if (Qe(e)) return {
        data: null,
        error: e
      };
      throw e;
    }
  }
};
let Ns;
Ns = Symbol.toStringTag;
var tn = class {
  constructor(s, e) {
    this.downloadFn = s, this.shouldThrowOnError = e, this[Ns] = "BlobDownloadBuilder", this.promise = null;
  }
  asStream() {
    return new en(this.downloadFn, this.shouldThrowOnError);
  }
  then(s, e) {
    return this.getPromise().then(s, e);
  }
  catch(s) {
    return this.getPromise().catch(s);
  }
  finally(s) {
    return this.getPromise().finally(s);
  }
  getPromise() {
    return this.promise || (this.promise = this.execute()), this.promise;
  }
  async execute() {
    var s = this;
    try {
      return {
        data: await (await s.downloadFn()).blob(),
        error: null
      };
    } catch (e) {
      if (s.shouldThrowOnError) throw e;
      if (Qe(e)) return {
        data: null,
        error: e
      };
      throw e;
    }
  }
};
const sn = {
  limit: 100,
  offset: 0,
  sortBy: {
    column: "name",
    order: "asc"
  }
}, Bt = {
  cacheControl: "3600",
  contentType: "text/plain;charset=UTF-8",
  upsert: !1
};
var rn = class extends Te {
  constructor(s, e = {}, t, r) {
    super(s, e, r, "storage"), this.bucketId = t;
  }
  /**
  * Uploads a file to an existing bucket or replaces an existing file at the specified path with a new one.
  *
  * @param method HTTP method.
  * @param path The relative file path. Should be of the format `folder/subfolder/filename.png`. The bucket must already exist before attempting to upload.
  * @param fileBody The body of the file to be stored in the bucket.
  */
  async uploadOrUpdate(s, e, t, r) {
    var n = this;
    return n.handleOperation(async () => {
      let i;
      const a = T(T({}, Bt), r);
      let o = T(T({}, n.headers), s === "POST" && { "x-upsert": String(a.upsert) });
      const c = a.metadata;
      typeof Blob < "u" && t instanceof Blob ? (i = new FormData(), i.append("cacheControl", a.cacheControl), c && i.append("metadata", n.encodeMetadata(c)), i.append("", t)) : typeof FormData < "u" && t instanceof FormData ? (i = t, i.has("cacheControl") || i.append("cacheControl", a.cacheControl), c && !i.has("metadata") && i.append("metadata", n.encodeMetadata(c))) : (i = t, o["cache-control"] = `max-age=${a.cacheControl}`, o["content-type"] = a.contentType, c && (o["x-metadata"] = n.toBase64(n.encodeMetadata(c))), (typeof ReadableStream < "u" && i instanceof ReadableStream || i && typeof i == "object" && "pipe" in i && typeof i.pipe == "function") && !a.duplex && (a.duplex = "half")), r != null && r.headers && (o = T(T({}, o), r.headers));
      const l = n._removeEmptyFolders(e), u = n._getFinalPath(l), d = await (s == "PUT" ? pt : F)(n.fetch, `${n.url}/object/${u}`, i, T({ headers: o }, a != null && a.duplex ? { duplex: a.duplex } : {}));
      return {
        path: l,
        id: d.Id,
        fullPath: d.Key
      };
    });
  }
  /**
  * Uploads a file to an existing bucket.
  *
  * @category File Buckets
  * @param path The file path, including the file name. Should be of the format `folder/subfolder/filename.png`. The bucket must already exist before attempting to upload.
  * @param fileBody The body of the file to be stored in the bucket.
  * @param fileOptions Optional file upload options including cacheControl, contentType, upsert, and metadata.
  * @returns Promise with response containing file path, id, and fullPath or error
  *
  * @example Upload file
  * ```js
  * const avatarFile = event.target.files[0]
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .upload('public/avatar1.png', avatarFile, {
  *     cacheControl: '3600',
  *     upsert: false
  *   })
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "path": "public/avatar1.png",
  *     "fullPath": "avatars/public/avatar1.png"
  *   },
  *   "error": null
  * }
  * ```
  *
  * @example Upload file using `ArrayBuffer` from base64 file data
  * ```js
  * import { decode } from 'base64-arraybuffer'
  *
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .upload('public/avatar1.png', decode('base64FileData'), {
  *     contentType: 'image/png'
  *   })
  * ```
  */
  async upload(s, e, t) {
    return this.uploadOrUpdate("POST", s, e, t);
  }
  /**
  * Upload a file with a token generated from `createSignedUploadUrl`.
  *
  * @category File Buckets
  * @param path The file path, including the file name. Should be of the format `folder/subfolder/filename.png`. The bucket must already exist before attempting to upload.
  * @param token The token generated from `createSignedUploadUrl`
  * @param fileBody The body of the file to be stored in the bucket.
  * @param fileOptions HTTP headers (cacheControl, contentType, etc.).
  * **Note:** The `upsert` option has no effect here. To enable upsert behavior,
  * pass `{ upsert: true }` when calling `createSignedUploadUrl()` instead.
  * @returns Promise with response containing file path and fullPath or error
  *
  * @example Upload to a signed URL
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .uploadToSignedUrl('folder/cat.jpg', 'token-from-createSignedUploadUrl', file)
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "path": "folder/cat.jpg",
  *     "fullPath": "avatars/folder/cat.jpg"
  *   },
  *   "error": null
  * }
  * ```
  */
  async uploadToSignedUrl(s, e, t, r) {
    var n = this;
    const i = n._removeEmptyFolders(s), a = n._getFinalPath(i), o = new URL(n.url + `/object/upload/sign/${a}`);
    return o.searchParams.set("token", e), n.handleOperation(async () => {
      let c;
      const l = T({ upsert: Bt.upsert }, r), u = T(T({}, n.headers), { "x-upsert": String(l.upsert) });
      return typeof Blob < "u" && t instanceof Blob ? (c = new FormData(), c.append("cacheControl", l.cacheControl), c.append("", t)) : typeof FormData < "u" && t instanceof FormData ? (c = t, c.append("cacheControl", l.cacheControl)) : (c = t, u["cache-control"] = `max-age=${l.cacheControl}`, u["content-type"] = l.contentType), {
        path: i,
        fullPath: (await pt(n.fetch, o.toString(), c, { headers: u })).Key
      };
    });
  }
  /**
  * Creates a signed upload URL.
  * Signed upload URLs can be used to upload files to the bucket without further authentication.
  * They are valid for 2 hours.
  *
  * @category File Buckets
  * @param path The file path, including the current file name. For example `folder/image.png`.
  * @param options.upsert If set to true, allows the file to be overwritten if it already exists.
  * @returns Promise with response containing signed upload URL, token, and path or error
  *
  * @example Create Signed Upload URL
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .createSignedUploadUrl('folder/cat.jpg')
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "signedUrl": "https://example.supabase.co/storage/v1/object/upload/sign/avatars/folder/cat.jpg?token=<TOKEN>",
  *     "path": "folder/cat.jpg",
  *     "token": "<TOKEN>"
  *   },
  *   "error": null
  * }
  * ```
  */
  async createSignedUploadUrl(s, e) {
    var t = this;
    return t.handleOperation(async () => {
      let r = t._getFinalPath(s);
      const n = T({}, t.headers);
      e != null && e.upsert && (n["x-upsert"] = "true");
      const i = await F(t.fetch, `${t.url}/object/upload/sign/${r}`, {}, { headers: n }), a = new URL(t.url + i.url), o = a.searchParams.get("token");
      if (!o) throw new Ye("No token returned by API");
      return {
        signedUrl: a.toString(),
        path: s,
        token: o
      };
    });
  }
  /**
  * Replaces an existing file at the specified path with a new one.
  *
  * @category File Buckets
  * @param path The relative file path. Should be of the format `folder/subfolder/filename.png`. The bucket must already exist before attempting to update.
  * @param fileBody The body of the file to be stored in the bucket.
  * @param fileOptions Optional file upload options including cacheControl, contentType, upsert, and metadata.
  * @returns Promise with response containing file path, id, and fullPath or error
  *
  * @example Update file
  * ```js
  * const avatarFile = event.target.files[0]
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .update('public/avatar1.png', avatarFile, {
  *     cacheControl: '3600',
  *     upsert: true
  *   })
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "path": "public/avatar1.png",
  *     "fullPath": "avatars/public/avatar1.png"
  *   },
  *   "error": null
  * }
  * ```
  *
  * @example Update file using `ArrayBuffer` from base64 file data
  * ```js
  * import {decode} from 'base64-arraybuffer'
  *
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .update('public/avatar1.png', decode('base64FileData'), {
  *     contentType: 'image/png'
  *   })
  * ```
  */
  async update(s, e, t) {
    return this.uploadOrUpdate("PUT", s, e, t);
  }
  /**
  * Moves an existing file to a new path in the same bucket.
  *
  * @category File Buckets
  * @param fromPath The original file path, including the current file name. For example `folder/image.png`.
  * @param toPath The new file path, including the new file name. For example `folder/image-new.png`.
  * @param options The destination options.
  * @returns Promise with response containing success message or error
  *
  * @example Move file
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .move('public/avatar1.png', 'private/avatar2.png')
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "message": "Successfully moved"
  *   },
  *   "error": null
  * }
  * ```
  */
  async move(s, e, t) {
    var r = this;
    return r.handleOperation(async () => await F(r.fetch, `${r.url}/object/move`, {
      bucketId: r.bucketId,
      sourceKey: s,
      destinationKey: e,
      destinationBucket: t == null ? void 0 : t.destinationBucket
    }, { headers: r.headers }));
  }
  /**
  * Copies an existing file to a new path in the same bucket.
  *
  * @category File Buckets
  * @param fromPath The original file path, including the current file name. For example `folder/image.png`.
  * @param toPath The new file path, including the new file name. For example `folder/image-copy.png`.
  * @param options The destination options.
  * @returns Promise with response containing copied file path or error
  *
  * @example Copy file
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .copy('public/avatar1.png', 'private/avatar2.png')
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "path": "avatars/private/avatar2.png"
  *   },
  *   "error": null
  * }
  * ```
  */
  async copy(s, e, t) {
    var r = this;
    return r.handleOperation(async () => ({ path: (await F(r.fetch, `${r.url}/object/copy`, {
      bucketId: r.bucketId,
      sourceKey: s,
      destinationKey: e,
      destinationBucket: t == null ? void 0 : t.destinationBucket
    }, { headers: r.headers })).Key }));
  }
  /**
  * Creates a signed URL. Use a signed URL to share a file for a fixed amount of time.
  *
  * @category File Buckets
  * @param path The file path, including the current file name. For example `folder/image.png`.
  * @param expiresIn The number of seconds until the signed URL expires. For example, `60` for a URL which is valid for one minute.
  * @param options.download triggers the file as a download if set to true. Set this parameter as the name of the file if you want to trigger the download with a different filename.
  * @param options.transform Transform the asset before serving it to the client.
  * @returns Promise with response containing signed URL or error
  *
  * @example Create Signed URL
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .createSignedUrl('folder/avatar1.png', 60)
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "signedUrl": "https://example.supabase.co/storage/v1/object/sign/avatars/folder/avatar1.png?token=<TOKEN>"
  *   },
  *   "error": null
  * }
  * ```
  *
  * @example Create a signed URL for an asset with transformations
  * ```js
  * const { data } = await supabase
  *   .storage
  *   .from('avatars')
  *   .createSignedUrl('folder/avatar1.png', 60, {
  *     transform: {
  *       width: 100,
  *       height: 100,
  *     }
  *   })
  * ```
  *
  * @example Create a signed URL which triggers the download of the asset
  * ```js
  * const { data } = await supabase
  *   .storage
  *   .from('avatars')
  *   .createSignedUrl('folder/avatar1.png', 60, {
  *     download: true,
  *   })
  * ```
  */
  async createSignedUrl(s, e, t) {
    var r = this;
    return r.handleOperation(async () => {
      let n = r._getFinalPath(s), i = await F(r.fetch, `${r.url}/object/sign/${n}`, T({ expiresIn: e }, t != null && t.transform ? { transform: t.transform } : {}), { headers: r.headers });
      const a = t != null && t.download ? `&download=${t.download === !0 ? "" : t.download}` : "";
      return { signedUrl: encodeURI(`${r.url}${i.signedURL}${a}`) };
    });
  }
  /**
  * Creates multiple signed URLs. Use a signed URL to share a file for a fixed amount of time.
  *
  * @category File Buckets
  * @param paths The file paths to be downloaded, including the current file names. For example `['folder/image.png', 'folder2/image2.png']`.
  * @param expiresIn The number of seconds until the signed URLs expire. For example, `60` for URLs which are valid for one minute.
  * @param options.download triggers the file as a download if set to true. Set this parameter as the name of the file if you want to trigger the download with a different filename.
  * @returns Promise with response containing array of objects with signedUrl, path, and error or error
  *
  * @example Create Signed URLs
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .createSignedUrls(['folder/avatar1.png', 'folder/avatar2.png'], 60)
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": [
  *     {
  *       "error": null,
  *       "path": "folder/avatar1.png",
  *       "signedURL": "/object/sign/avatars/folder/avatar1.png?token=<TOKEN>",
  *       "signedUrl": "https://example.supabase.co/storage/v1/object/sign/avatars/folder/avatar1.png?token=<TOKEN>"
  *     },
  *     {
  *       "error": null,
  *       "path": "folder/avatar2.png",
  *       "signedURL": "/object/sign/avatars/folder/avatar2.png?token=<TOKEN>",
  *       "signedUrl": "https://example.supabase.co/storage/v1/object/sign/avatars/folder/avatar2.png?token=<TOKEN>"
  *     }
  *   ],
  *   "error": null
  * }
  * ```
  */
  async createSignedUrls(s, e, t) {
    var r = this;
    return r.handleOperation(async () => {
      const n = await F(r.fetch, `${r.url}/object/sign/${r.bucketId}`, {
        expiresIn: e,
        paths: s
      }, { headers: r.headers }), i = t != null && t.download ? `&download=${t.download === !0 ? "" : t.download}` : "";
      return n.map((a) => T(T({}, a), {}, { signedUrl: a.signedURL ? encodeURI(`${r.url}${a.signedURL}${i}`) : null }));
    });
  }
  /**
  * Downloads a file from a private bucket. For public buckets, make a request to the URL returned from `getPublicUrl` instead.
  *
  * @category File Buckets
  * @param path The full path and file name of the file to be downloaded. For example `folder/image.png`.
  * @param options.transform Transform the asset before serving it to the client.
  * @returns BlobDownloadBuilder instance for downloading the file
  *
  * @example Download file
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .download('folder/avatar1.png')
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": <BLOB>,
  *   "error": null
  * }
  * ```
  *
  * @example Download file with transformations
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .download('folder/avatar1.png', {
  *     transform: {
  *       width: 100,
  *       height: 100,
  *       quality: 80
  *     }
  *   })
  * ```
  */
  download(s, e) {
    const t = typeof (e == null ? void 0 : e.transform) < "u" ? "render/image/authenticated" : "object", r = this.transformOptsToQueryString((e == null ? void 0 : e.transform) || {}), n = r ? `?${r}` : "", i = this._getFinalPath(s), a = () => $e(this.fetch, `${this.url}/${t}/${i}${n}`, {
      headers: this.headers,
      noResolveJson: !0
    });
    return new tn(a, this.shouldThrowOnError);
  }
  /**
  * Retrieves the details of an existing file.
  *
  * @category File Buckets
  * @param path The file path, including the file name. For example `folder/image.png`.
  * @returns Promise with response containing file metadata or error
  *
  * @example Get file info
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .info('folder/avatar1.png')
  * ```
  */
  async info(s) {
    var e = this;
    const t = e._getFinalPath(s);
    return e.handleOperation(async () => ft(await $e(e.fetch, `${e.url}/object/info/${t}`, { headers: e.headers })));
  }
  /**
  * Checks the existence of a file.
  *
  * @category File Buckets
  * @param path The file path, including the file name. For example `folder/image.png`.
  * @returns Promise with response containing boolean indicating file existence or error
  *
  * @example Check file existence
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .exists('folder/avatar1.png')
  * ```
  */
  async exists(s) {
    var e = this;
    const t = e._getFinalPath(s);
    try {
      return await Zr(e.fetch, `${e.url}/object/${t}`, { headers: e.headers }), {
        data: !0,
        error: null
      };
    } catch (r) {
      if (e.shouldThrowOnError) throw r;
      if (Qe(r) && r instanceof xs) {
        const n = r.originalError;
        if ([400, 404].includes(n == null ? void 0 : n.status)) return {
          data: !1,
          error: r
        };
      }
      throw r;
    }
  }
  /**
  * A simple convenience function to get the URL for an asset in a public bucket. If you do not want to use this function, you can construct the public URL by concatenating the bucket URL with the path to the asset.
  * This function does not verify if the bucket is public. If a public URL is created for a bucket which is not public, you will not be able to download the asset.
  *
  * @category File Buckets
  * @param path The path and name of the file to generate the public URL for. For example `folder/image.png`.
  * @param options.download Triggers the file as a download if set to true. Set this parameter as the name of the file if you want to trigger the download with a different filename.
  * @param options.transform Transform the asset before serving it to the client.
  * @returns Object with public URL
  *
  * @example Returns the URL for an asset in a public bucket
  * ```js
  * const { data } = supabase
  *   .storage
  *   .from('public-bucket')
  *   .getPublicUrl('folder/avatar1.png')
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "publicUrl": "https://example.supabase.co/storage/v1/object/public/public-bucket/folder/avatar1.png"
  *   }
  * }
  * ```
  *
  * @example Returns the URL for an asset in a public bucket with transformations
  * ```js
  * const { data } = supabase
  *   .storage
  *   .from('public-bucket')
  *   .getPublicUrl('folder/avatar1.png', {
  *     transform: {
  *       width: 100,
  *       height: 100,
  *     }
  *   })
  * ```
  *
  * @example Returns the URL which triggers the download of an asset in a public bucket
  * ```js
  * const { data } = supabase
  *   .storage
  *   .from('public-bucket')
  *   .getPublicUrl('folder/avatar1.png', {
  *     download: true,
  *   })
  * ```
  */
  getPublicUrl(s, e) {
    const t = this._getFinalPath(s), r = [], n = e != null && e.download ? `download=${e.download === !0 ? "" : e.download}` : "";
    n !== "" && r.push(n);
    const i = typeof (e == null ? void 0 : e.transform) < "u" ? "render/image" : "object", a = this.transformOptsToQueryString((e == null ? void 0 : e.transform) || {});
    a !== "" && r.push(a);
    let o = r.join("&");
    return o !== "" && (o = `?${o}`), { data: { publicUrl: encodeURI(`${this.url}/${i}/public/${t}${o}`) } };
  }
  /**
  * Deletes files within the same bucket
  *
  * @category File Buckets
  * @param paths An array of files to delete, including the path and file name. For example [`'folder/image.png'`].
  * @returns Promise with response containing array of deleted file objects or error
  *
  * @example Delete file
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .remove(['folder/avatar1.png'])
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": [],
  *   "error": null
  * }
  * ```
  */
  async remove(s) {
    var e = this;
    return e.handleOperation(async () => await Ot(e.fetch, `${e.url}/object/${e.bucketId}`, { prefixes: s }, { headers: e.headers }));
  }
  /**
  * Get file metadata
  * @param id the file id to retrieve metadata
  */
  /**
  * Update file metadata
  * @param id the file id to update metadata
  * @param meta the new file metadata
  */
  /**
  * Lists all the files and folders within a path of the bucket.
  *
  * @category File Buckets
  * @param path The folder path.
  * @param options Search options including limit (defaults to 100), offset, sortBy, and search
  * @param parameters Optional fetch parameters including signal for cancellation
  * @returns Promise with response containing array of files or error
  *
  * @example List files in a bucket
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .list('folder', {
  *     limit: 100,
  *     offset: 0,
  *     sortBy: { column: 'name', order: 'asc' },
  *   })
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": [
  *     {
  *       "name": "avatar1.png",
  *       "id": "e668cf7f-821b-4a2f-9dce-7dfa5dd1cfd2",
  *       "updated_at": "2024-05-22T23:06:05.580Z",
  *       "created_at": "2024-05-22T23:04:34.443Z",
  *       "last_accessed_at": "2024-05-22T23:04:34.443Z",
  *       "metadata": {
  *         "eTag": "\"c5e8c553235d9af30ef4f6e280790b92\"",
  *         "size": 32175,
  *         "mimetype": "image/png",
  *         "cacheControl": "max-age=3600",
  *         "lastModified": "2024-05-22T23:06:05.574Z",
  *         "contentLength": 32175,
  *         "httpStatusCode": 200
  *       }
  *     }
  *   ],
  *   "error": null
  * }
  * ```
  *
  * @example Search files in a bucket
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .from('avatars')
  *   .list('folder', {
  *     limit: 100,
  *     offset: 0,
  *     sortBy: { column: 'name', order: 'asc' },
  *     search: 'jon'
  *   })
  * ```
  */
  async list(s, e, t) {
    var r = this;
    return r.handleOperation(async () => {
      const n = T(T(T({}, sn), e), {}, { prefix: s || "" });
      return await F(r.fetch, `${r.url}/object/list/${r.bucketId}`, n, { headers: r.headers }, t);
    });
  }
  /**
  * @experimental this method signature might change in the future
  *
  * @category File Buckets
  * @param options search options
  * @param parameters
  */
  async listV2(s, e) {
    var t = this;
    return t.handleOperation(async () => {
      const r = T({}, s);
      return await F(t.fetch, `${t.url}/object/list-v2/${t.bucketId}`, r, { headers: t.headers }, e);
    });
  }
  encodeMetadata(s) {
    return JSON.stringify(s);
  }
  toBase64(s) {
    return typeof Buffer < "u" ? Buffer.from(s).toString("base64") : btoa(s);
  }
  _getFinalPath(s) {
    return `${this.bucketId}/${s.replace(/^\/+/, "")}`;
  }
  _removeEmptyFolders(s) {
    return s.replace(/^\/|\/$/g, "").replace(/\/+/g, "/");
  }
  transformOptsToQueryString(s) {
    const e = [];
    return s.width && e.push(`width=${s.width}`), s.height && e.push(`height=${s.height}`), s.resize && e.push(`resize=${s.resize}`), s.format && e.push(`format=${s.format}`), s.quality && e.push(`quality=${s.quality}`), e.join("&");
  }
};
const nn = "2.93.3", je = { "X-Client-Info": `storage-js/${nn}` };
var an = class extends Te {
  constructor(s, e = {}, t, r) {
    const n = new URL(s);
    r != null && r.useNewHostname && /supabase\.(co|in|red)$/.test(n.hostname) && !n.hostname.includes("storage.supabase.") && (n.hostname = n.hostname.replace("supabase.", "storage.supabase."));
    const i = n.href.replace(/\/$/, ""), a = T(T({}, je), e);
    super(i, a, t, "storage");
  }
  /**
  * Retrieves the details of all Storage buckets within an existing project.
  *
  * @category File Buckets
  * @param options Query parameters for listing buckets
  * @param options.limit Maximum number of buckets to return
  * @param options.offset Number of buckets to skip
  * @param options.sortColumn Column to sort by ('id', 'name', 'created_at', 'updated_at')
  * @param options.sortOrder Sort order ('asc' or 'desc')
  * @param options.search Search term to filter bucket names
  * @returns Promise with response containing array of buckets or error
  *
  * @example List buckets
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .listBuckets()
  * ```
  *
  * @example List buckets with options
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .listBuckets({
  *     limit: 10,
  *     offset: 0,
  *     sortColumn: 'created_at',
  *     sortOrder: 'desc',
  *     search: 'prod'
  *   })
  * ```
  */
  async listBuckets(s) {
    var e = this;
    return e.handleOperation(async () => {
      const t = e.listBucketOptionsToQueryString(s);
      return await $e(e.fetch, `${e.url}/bucket${t}`, { headers: e.headers });
    });
  }
  /**
  * Retrieves the details of an existing Storage bucket.
  *
  * @category File Buckets
  * @param id The unique identifier of the bucket you would like to retrieve.
  * @returns Promise with response containing bucket details or error
  *
  * @example Get bucket
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .getBucket('avatars')
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "id": "avatars",
  *     "name": "avatars",
  *     "owner": "",
  *     "public": false,
  *     "file_size_limit": 1024,
  *     "allowed_mime_types": [
  *       "image/png"
  *     ],
  *     "created_at": "2024-05-22T22:26:05.100Z",
  *     "updated_at": "2024-05-22T22:26:05.100Z"
  *   },
  *   "error": null
  * }
  * ```
  */
  async getBucket(s) {
    var e = this;
    return e.handleOperation(async () => await $e(e.fetch, `${e.url}/bucket/${s}`, { headers: e.headers }));
  }
  /**
  * Creates a new Storage bucket
  *
  * @category File Buckets
  * @param id A unique identifier for the bucket you are creating.
  * @param options.public The visibility of the bucket. Public buckets don't require an authorization token to download objects, but still require a valid token for all other operations. By default, buckets are private.
  * @param options.fileSizeLimit specifies the max file size in bytes that can be uploaded to this bucket.
  * The global file size limit takes precedence over this value.
  * The default value is null, which doesn't set a per bucket file size limit.
  * @param options.allowedMimeTypes specifies the allowed mime types that this bucket can accept during upload.
  * The default value is null, which allows files with all mime types to be uploaded.
  * Each mime type specified can be a wildcard, e.g. image/*, or a specific mime type, e.g. image/png.
  * @param options.type (private-beta) specifies the bucket type. see `BucketType` for more details.
  *   - default bucket type is `STANDARD`
  * @returns Promise with response containing newly created bucket name or error
  *
  * @example Create bucket
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .createBucket('avatars', {
  *     public: false,
  *     allowedMimeTypes: ['image/png'],
  *     fileSizeLimit: 1024
  *   })
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "name": "avatars"
  *   },
  *   "error": null
  * }
  * ```
  */
  async createBucket(s, e = { public: !1 }) {
    var t = this;
    return t.handleOperation(async () => await F(t.fetch, `${t.url}/bucket`, {
      id: s,
      name: s,
      type: e.type,
      public: e.public,
      file_size_limit: e.fileSizeLimit,
      allowed_mime_types: e.allowedMimeTypes
    }, { headers: t.headers }));
  }
  /**
  * Updates a Storage bucket
  *
  * @category File Buckets
  * @param id A unique identifier for the bucket you are updating.
  * @param options.public The visibility of the bucket. Public buckets don't require an authorization token to download objects, but still require a valid token for all other operations.
  * @param options.fileSizeLimit specifies the max file size in bytes that can be uploaded to this bucket.
  * The global file size limit takes precedence over this value.
  * The default value is null, which doesn't set a per bucket file size limit.
  * @param options.allowedMimeTypes specifies the allowed mime types that this bucket can accept during upload.
  * The default value is null, which allows files with all mime types to be uploaded.
  * Each mime type specified can be a wildcard, e.g. image/*, or a specific mime type, e.g. image/png.
  * @returns Promise with response containing success message or error
  *
  * @example Update bucket
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .updateBucket('avatars', {
  *     public: false,
  *     allowedMimeTypes: ['image/png'],
  *     fileSizeLimit: 1024
  *   })
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "message": "Successfully updated"
  *   },
  *   "error": null
  * }
  * ```
  */
  async updateBucket(s, e) {
    var t = this;
    return t.handleOperation(async () => await pt(t.fetch, `${t.url}/bucket/${s}`, {
      id: s,
      name: s,
      public: e.public,
      file_size_limit: e.fileSizeLimit,
      allowed_mime_types: e.allowedMimeTypes
    }, { headers: t.headers }));
  }
  /**
  * Removes all objects inside a single bucket.
  *
  * @category File Buckets
  * @param id The unique identifier of the bucket you would like to empty.
  * @returns Promise with success message or error
  *
  * @example Empty bucket
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .emptyBucket('avatars')
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "message": "Successfully emptied"
  *   },
  *   "error": null
  * }
  * ```
  */
  async emptyBucket(s) {
    var e = this;
    return e.handleOperation(async () => await F(e.fetch, `${e.url}/bucket/${s}/empty`, {}, { headers: e.headers }));
  }
  /**
  * Deletes an existing bucket. A bucket can't be deleted with existing objects inside it.
  * You must first `empty()` the bucket.
  *
  * @category File Buckets
  * @param id The unique identifier of the bucket you would like to delete.
  * @returns Promise with success message or error
  *
  * @example Delete bucket
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .deleteBucket('avatars')
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "message": "Successfully deleted"
  *   },
  *   "error": null
  * }
  * ```
  */
  async deleteBucket(s) {
    var e = this;
    return e.handleOperation(async () => await Ot(e.fetch, `${e.url}/bucket/${s}`, {}, { headers: e.headers }));
  }
  listBucketOptionsToQueryString(s) {
    const e = {};
    return s && ("limit" in s && (e.limit = String(s.limit)), "offset" in s && (e.offset = String(s.offset)), s.search && (e.search = s.search), s.sortColumn && (e.sortColumn = s.sortColumn), s.sortOrder && (e.sortOrder = s.sortOrder)), Object.keys(e).length > 0 ? "?" + new URLSearchParams(e).toString() : "";
  }
}, on = class extends Te {
  /**
  * @alpha
  *
  * Creates a new StorageAnalyticsClient instance
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Analytics Buckets
  * @param url - The base URL for the storage API
  * @param headers - HTTP headers to include in requests
  * @param fetch - Optional custom fetch implementation
  *
  * @example
  * ```typescript
  * const client = new StorageAnalyticsClient(url, headers)
  * ```
  */
  constructor(s, e = {}, t) {
    const r = s.replace(/\/$/, ""), n = T(T({}, je), e);
    super(r, n, t, "storage");
  }
  /**
  * @alpha
  *
  * Creates a new analytics bucket using Iceberg tables
  * Analytics buckets are optimized for analytical queries and data processing
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Analytics Buckets
  * @param name A unique name for the bucket you are creating
  * @returns Promise with response containing newly created analytics bucket or error
  *
  * @example Create analytics bucket
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .analytics
  *   .createBucket('analytics-data')
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "name": "analytics-data",
  *     "type": "ANALYTICS",
  *     "format": "iceberg",
  *     "created_at": "2024-05-22T22:26:05.100Z",
  *     "updated_at": "2024-05-22T22:26:05.100Z"
  *   },
  *   "error": null
  * }
  * ```
  */
  async createBucket(s) {
    var e = this;
    return e.handleOperation(async () => await F(e.fetch, `${e.url}/bucket`, { name: s }, { headers: e.headers }));
  }
  /**
  * @alpha
  *
  * Retrieves the details of all Analytics Storage buckets within an existing project
  * Only returns buckets of type 'ANALYTICS'
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Analytics Buckets
  * @param options Query parameters for listing buckets
  * @param options.limit Maximum number of buckets to return
  * @param options.offset Number of buckets to skip
  * @param options.sortColumn Column to sort by ('name', 'created_at', 'updated_at')
  * @param options.sortOrder Sort order ('asc' or 'desc')
  * @param options.search Search term to filter bucket names
  * @returns Promise with response containing array of analytics buckets or error
  *
  * @example List analytics buckets
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .analytics
  *   .listBuckets({
  *     limit: 10,
  *     offset: 0,
  *     sortColumn: 'created_at',
  *     sortOrder: 'desc'
  *   })
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": [
  *     {
  *       "name": "analytics-data",
  *       "type": "ANALYTICS",
  *       "format": "iceberg",
  *       "created_at": "2024-05-22T22:26:05.100Z",
  *       "updated_at": "2024-05-22T22:26:05.100Z"
  *     }
  *   ],
  *   "error": null
  * }
  * ```
  */
  async listBuckets(s) {
    var e = this;
    return e.handleOperation(async () => {
      const t = new URLSearchParams();
      (s == null ? void 0 : s.limit) !== void 0 && t.set("limit", s.limit.toString()), (s == null ? void 0 : s.offset) !== void 0 && t.set("offset", s.offset.toString()), s != null && s.sortColumn && t.set("sortColumn", s.sortColumn), s != null && s.sortOrder && t.set("sortOrder", s.sortOrder), s != null && s.search && t.set("search", s.search);
      const r = t.toString(), n = r ? `${e.url}/bucket?${r}` : `${e.url}/bucket`;
      return await $e(e.fetch, n, { headers: e.headers });
    });
  }
  /**
  * @alpha
  *
  * Deletes an existing analytics bucket
  * A bucket can't be deleted with existing objects inside it
  * You must first empty the bucket before deletion
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Analytics Buckets
  * @param bucketName The unique identifier of the bucket you would like to delete
  * @returns Promise with response containing success message or error
  *
  * @example Delete analytics bucket
  * ```js
  * const { data, error } = await supabase
  *   .storage
  *   .analytics
  *   .deleteBucket('analytics-data')
  * ```
  *
  * Response:
  * ```json
  * {
  *   "data": {
  *     "message": "Successfully deleted"
  *   },
  *   "error": null
  * }
  * ```
  */
  async deleteBucket(s) {
    var e = this;
    return e.handleOperation(async () => await Ot(e.fetch, `${e.url}/bucket/${s}`, {}, { headers: e.headers }));
  }
  /**
  * @alpha
  *
  * Get an Iceberg REST Catalog client configured for a specific analytics bucket
  * Use this to perform advanced table and namespace operations within the bucket
  * The returned client provides full access to the Apache Iceberg REST Catalog API
  * with the Supabase `{ data, error }` pattern for consistent error handling on all operations.
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Analytics Buckets
  * @param bucketName - The name of the analytics bucket (warehouse) to connect to
  * @returns The wrapped Iceberg catalog client
  * @throws {StorageError} If the bucket name is invalid
  *
  * @example Get catalog and create table
  * ```js
  * // First, create an analytics bucket
  * const { data: bucket, error: bucketError } = await supabase
  *   .storage
  *   .analytics
  *   .createBucket('analytics-data')
  *
  * // Get the Iceberg catalog for that bucket
  * const catalog = supabase.storage.analytics.from('analytics-data')
  *
  * // Create a namespace
  * const { error: nsError } = await catalog.createNamespace({ namespace: ['default'] })
  *
  * // Create a table with schema
  * const { data: tableMetadata, error: tableError } = await catalog.createTable(
  *   { namespace: ['default'] },
  *   {
  *     name: 'events',
  *     schema: {
  *       type: 'struct',
  *       fields: [
  *         { id: 1, name: 'id', type: 'long', required: true },
  *         { id: 2, name: 'timestamp', type: 'timestamp', required: true },
  *         { id: 3, name: 'user_id', type: 'string', required: false }
  *       ],
  *       'schema-id': 0,
  *       'identifier-field-ids': [1]
  *     },
  *     'partition-spec': {
  *       'spec-id': 0,
  *       fields: []
  *     },
  *     'write-order': {
  *       'order-id': 0,
  *       fields: []
  *     },
  *     properties: {
  *       'write.format.default': 'parquet'
  *     }
  *   }
  * )
  * ```
  *
  * @example List tables in namespace
  * ```js
  * const catalog = supabase.storage.analytics.from('analytics-data')
  *
  * // List all tables in the default namespace
  * const { data: tables, error: listError } = await catalog.listTables({ namespace: ['default'] })
  * if (listError) {
  *   if (listError.isNotFound()) {
  *     console.log('Namespace not found')
  *   }
  *   return
  * }
  * console.log(tables) // [{ namespace: ['default'], name: 'events' }]
  * ```
  *
  * @example Working with namespaces
  * ```js
  * const catalog = supabase.storage.analytics.from('analytics-data')
  *
  * // List all namespaces
  * const { data: namespaces } = await catalog.listNamespaces()
  *
  * // Create namespace with properties
  * await catalog.createNamespace(
  *   { namespace: ['production'] },
  *   { properties: { owner: 'data-team', env: 'prod' } }
  * )
  * ```
  *
  * @example Cleanup operations
  * ```js
  * const catalog = supabase.storage.analytics.from('analytics-data')
  *
  * // Drop table with purge option (removes all data)
  * const { error: dropError } = await catalog.dropTable(
  *   { namespace: ['default'], name: 'events' },
  *   { purge: true }
  * )
  *
  * if (dropError?.isNotFound()) {
  *   console.log('Table does not exist')
  * }
  *
  * // Drop namespace (must be empty)
  * await catalog.dropNamespace({ namespace: ['default'] })
  * ```
  *
  * @remarks
  * This method provides a bridge between Supabase's bucket management and the standard
  * Apache Iceberg REST Catalog API. The bucket name maps to the Iceberg warehouse parameter.
  * All authentication and configuration is handled automatically using your Supabase credentials.
  *
  * **Error Handling**: Invalid bucket names throw immediately. All catalog
  * operations return `{ data, error }` where errors are `IcebergError` instances from iceberg-js.
  * Use helper methods like `error.isNotFound()` or check `error.status` for specific error handling.
  * Use `.throwOnError()` on the analytics client if you prefer exceptions for catalog operations.
  *
  * **Cleanup Operations**: When using `dropTable`, the `purge: true` option permanently
  * deletes all table data. Without it, the table is marked as deleted but data remains.
  *
  * **Library Dependency**: The returned catalog wraps `IcebergRestCatalog` from iceberg-js.
  * For complete API documentation and advanced usage, refer to the
  * [iceberg-js documentation](https://supabase.github.io/iceberg-js/).
  */
  from(s) {
    var e = this;
    if (!Gr(s)) throw new Ye("Invalid bucket name: File, folder, and bucket names must follow AWS object key naming guidelines and should avoid the use of any other characters.");
    const t = new Hr({
      baseUrl: this.url,
      catalogName: s,
      auth: {
        type: "custom",
        getHeaders: async () => e.headers
      },
      fetch: this.fetch
    }), r = this.shouldThrowOnError;
    return new Proxy(t, { get(n, i) {
      const a = n[i];
      return typeof a != "function" ? a : async (...o) => {
        try {
          return {
            data: await a.apply(n, o),
            error: null
          };
        } catch (c) {
          if (r) throw c;
          return {
            data: null,
            error: c
          };
        }
      };
    } });
  }
}, cn = class extends Te {
  /** Creates a new VectorIndexApi instance */
  constructor(s, e = {}, t) {
    const r = s.replace(/\/$/, ""), n = T(T({}, je), {}, { "Content-Type": "application/json" }, e);
    super(r, n, t, "vectors");
  }
  /** Creates a new vector index within a bucket */
  async createIndex(s) {
    var e = this;
    return e.handleOperation(async () => await D.post(e.fetch, `${e.url}/CreateIndex`, s, { headers: e.headers }) || {});
  }
  /** Retrieves metadata for a specific vector index */
  async getIndex(s, e) {
    var t = this;
    return t.handleOperation(async () => await D.post(t.fetch, `${t.url}/GetIndex`, {
      vectorBucketName: s,
      indexName: e
    }, { headers: t.headers }));
  }
  /** Lists vector indexes within a bucket with optional filtering and pagination */
  async listIndexes(s) {
    var e = this;
    return e.handleOperation(async () => await D.post(e.fetch, `${e.url}/ListIndexes`, s, { headers: e.headers }));
  }
  /** Deletes a vector index and all its data */
  async deleteIndex(s, e) {
    var t = this;
    return t.handleOperation(async () => await D.post(t.fetch, `${t.url}/DeleteIndex`, {
      vectorBucketName: s,
      indexName: e
    }, { headers: t.headers }) || {});
  }
}, ln = class extends Te {
  /** Creates a new VectorDataApi instance */
  constructor(s, e = {}, t) {
    const r = s.replace(/\/$/, ""), n = T(T({}, je), {}, { "Content-Type": "application/json" }, e);
    super(r, n, t, "vectors");
  }
  /** Inserts or updates vectors in batch (1-500 per request) */
  async putVectors(s) {
    var e = this;
    if (s.vectors.length < 1 || s.vectors.length > 500) throw new Error("Vector batch size must be between 1 and 500 items");
    return e.handleOperation(async () => await D.post(e.fetch, `${e.url}/PutVectors`, s, { headers: e.headers }) || {});
  }
  /** Retrieves vectors by their keys in batch */
  async getVectors(s) {
    var e = this;
    return e.handleOperation(async () => await D.post(e.fetch, `${e.url}/GetVectors`, s, { headers: e.headers }));
  }
  /** Lists vectors in an index with pagination */
  async listVectors(s) {
    var e = this;
    if (s.segmentCount !== void 0) {
      if (s.segmentCount < 1 || s.segmentCount > 16) throw new Error("segmentCount must be between 1 and 16");
      if (s.segmentIndex !== void 0 && (s.segmentIndex < 0 || s.segmentIndex >= s.segmentCount))
        throw new Error(`segmentIndex must be between 0 and ${s.segmentCount - 1}`);
    }
    return e.handleOperation(async () => await D.post(e.fetch, `${e.url}/ListVectors`, s, { headers: e.headers }));
  }
  /** Queries for similar vectors using approximate nearest neighbor search */
  async queryVectors(s) {
    var e = this;
    return e.handleOperation(async () => await D.post(e.fetch, `${e.url}/QueryVectors`, s, { headers: e.headers }));
  }
  /** Deletes vectors by their keys in batch (1-500 per request) */
  async deleteVectors(s) {
    var e = this;
    if (s.keys.length < 1 || s.keys.length > 500) throw new Error("Keys batch size must be between 1 and 500 items");
    return e.handleOperation(async () => await D.post(e.fetch, `${e.url}/DeleteVectors`, s, { headers: e.headers }) || {});
  }
}, un = class extends Te {
  /** Creates a new VectorBucketApi instance */
  constructor(s, e = {}, t) {
    const r = s.replace(/\/$/, ""), n = T(T({}, je), {}, { "Content-Type": "application/json" }, e);
    super(r, n, t, "vectors");
  }
  /** Creates a new vector bucket */
  async createBucket(s) {
    var e = this;
    return e.handleOperation(async () => await D.post(e.fetch, `${e.url}/CreateVectorBucket`, { vectorBucketName: s }, { headers: e.headers }) || {});
  }
  /** Retrieves metadata for a specific vector bucket */
  async getBucket(s) {
    var e = this;
    return e.handleOperation(async () => await D.post(e.fetch, `${e.url}/GetVectorBucket`, { vectorBucketName: s }, { headers: e.headers }));
  }
  /** Lists vector buckets with optional filtering and pagination */
  async listBuckets(s = {}) {
    var e = this;
    return e.handleOperation(async () => await D.post(e.fetch, `${e.url}/ListVectorBuckets`, s, { headers: e.headers }));
  }
  /** Deletes a vector bucket (must be empty first) */
  async deleteBucket(s) {
    var e = this;
    return e.handleOperation(async () => await D.post(e.fetch, `${e.url}/DeleteVectorBucket`, { vectorBucketName: s }, { headers: e.headers }) || {});
  }
}, hn = class extends un {
  /**
  * @alpha
  *
  * Creates a StorageVectorsClient that can manage buckets, indexes, and vectors.
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param url - Base URL of the Storage Vectors REST API.
  * @param options.headers - Optional headers (for example `Authorization`) applied to every request.
  * @param options.fetch - Optional custom `fetch` implementation for non-browser runtimes.
  *
  * @example
  * ```typescript
  * const client = new StorageVectorsClient(url, options)
  * ```
  */
  constructor(s, e = {}) {
    super(s, e.headers || {}, e.fetch);
  }
  /**
  *
  * @alpha
  *
  * Access operations for a specific vector bucket
  * Returns a scoped client for index and vector operations within the bucket
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param vectorBucketName - Name of the vector bucket
  * @returns Bucket-scoped client with index and vector operations
  *
  * @example
  * ```typescript
  * const bucket = supabase.storage.vectors.from('embeddings-prod')
  * ```
  */
  from(s) {
    return new dn(this.url, this.headers, s, this.fetch);
  }
  /**
  *
  * @alpha
  *
  * Creates a new vector bucket
  * Vector buckets are containers for vector indexes and their data
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param vectorBucketName - Unique name for the vector bucket
  * @returns Promise with empty response on success or error
  *
  * @example
  * ```typescript
  * const { data, error } = await supabase
  *   .storage
  *   .vectors
  *   .createBucket('embeddings-prod')
  * ```
  */
  async createBucket(s) {
    var e = () => super.createBucket, t = this;
    return e().call(t, s);
  }
  /**
  *
  * @alpha
  *
  * Retrieves metadata for a specific vector bucket
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param vectorBucketName - Name of the vector bucket
  * @returns Promise with bucket metadata or error
  *
  * @example
  * ```typescript
  * const { data, error } = await supabase
  *   .storage
  *   .vectors
  *   .getBucket('embeddings-prod')
  *
  * console.log('Bucket created:', data?.vectorBucket.creationTime)
  * ```
  */
  async getBucket(s) {
    var e = () => super.getBucket, t = this;
    return e().call(t, s);
  }
  /**
  *
  * @alpha
  *
  * Lists all vector buckets with optional filtering and pagination
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param options - Optional filters (prefix, maxResults, nextToken)
  * @returns Promise with list of buckets or error
  *
  * @example
  * ```typescript
  * const { data, error } = await supabase
  *   .storage
  *   .vectors
  *   .listBuckets({ prefix: 'embeddings-' })
  *
  * data?.vectorBuckets.forEach(bucket => {
  *   console.log(bucket.vectorBucketName)
  * })
  * ```
  */
  async listBuckets(s = {}) {
    var e = () => super.listBuckets, t = this;
    return e().call(t, s);
  }
  /**
  *
  * @alpha
  *
  * Deletes a vector bucket (bucket must be empty)
  * All indexes must be deleted before deleting the bucket
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param vectorBucketName - Name of the vector bucket to delete
  * @returns Promise with empty response on success or error
  *
  * @example
  * ```typescript
  * const { data, error } = await supabase
  *   .storage
  *   .vectors
  *   .deleteBucket('embeddings-old')
  * ```
  */
  async deleteBucket(s) {
    var e = () => super.deleteBucket, t = this;
    return e().call(t, s);
  }
}, dn = class extends cn {
  /**
  * @alpha
  *
  * Creates a helper that automatically scopes all index operations to the provided bucket.
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @example
  * ```typescript
  * const bucket = supabase.storage.vectors.from('embeddings-prod')
  * ```
  */
  constructor(s, e, t, r) {
    super(s, e, r), this.vectorBucketName = t;
  }
  /**
  *
  * @alpha
  *
  * Creates a new vector index in this bucket
  * Convenience method that automatically includes the bucket name
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param options - Index configuration (vectorBucketName is automatically set)
  * @returns Promise with empty response on success or error
  *
  * @example
  * ```typescript
  * const bucket = supabase.storage.vectors.from('embeddings-prod')
  * await bucket.createIndex({
  *   indexName: 'documents-openai',
  *   dataType: 'float32',
  *   dimension: 1536,
  *   distanceMetric: 'cosine',
  *   metadataConfiguration: {
  *     nonFilterableMetadataKeys: ['raw_text']
  *   }
  * })
  * ```
  */
  async createIndex(s) {
    var e = () => super.createIndex, t = this;
    return e().call(t, T(T({}, s), {}, { vectorBucketName: t.vectorBucketName }));
  }
  /**
  *
  * @alpha
  *
  * Lists indexes in this bucket
  * Convenience method that automatically includes the bucket name
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param options - Listing options (vectorBucketName is automatically set)
  * @returns Promise with response containing indexes array and pagination token or error
  *
  * @example
  * ```typescript
  * const bucket = supabase.storage.vectors.from('embeddings-prod')
  * const { data } = await bucket.listIndexes({ prefix: 'documents-' })
  * ```
  */
  async listIndexes(s = {}) {
    var e = () => super.listIndexes, t = this;
    return e().call(t, T(T({}, s), {}, { vectorBucketName: t.vectorBucketName }));
  }
  /**
  *
  * @alpha
  *
  * Retrieves metadata for a specific index in this bucket
  * Convenience method that automatically includes the bucket name
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param indexName - Name of the index to retrieve
  * @returns Promise with index metadata or error
  *
  * @example
  * ```typescript
  * const bucket = supabase.storage.vectors.from('embeddings-prod')
  * const { data } = await bucket.getIndex('documents-openai')
  * console.log('Dimension:', data?.index.dimension)
  * ```
  */
  async getIndex(s) {
    var e = () => super.getIndex, t = this;
    return e().call(t, t.vectorBucketName, s);
  }
  /**
  *
  * @alpha
  *
  * Deletes an index from this bucket
  * Convenience method that automatically includes the bucket name
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param indexName - Name of the index to delete
  * @returns Promise with empty response on success or error
  *
  * @example
  * ```typescript
  * const bucket = supabase.storage.vectors.from('embeddings-prod')
  * await bucket.deleteIndex('old-index')
  * ```
  */
  async deleteIndex(s) {
    var e = () => super.deleteIndex, t = this;
    return e().call(t, t.vectorBucketName, s);
  }
  /**
  *
  * @alpha
  *
  * Access operations for a specific index within this bucket
  * Returns a scoped client for vector data operations
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param indexName - Name of the index
  * @returns Index-scoped client with vector data operations
  *
  * @example
  * ```typescript
  * const index = supabase.storage.vectors.from('embeddings-prod').index('documents-openai')
  *
  * // Insert vectors
  * await index.putVectors({
  *   vectors: [
  *     { key: 'doc-1', data: { float32: [...] }, metadata: { title: 'Intro' } }
  *   ]
  * })
  *
  * // Query similar vectors
  * const { data } = await index.queryVectors({
  *   queryVector: { float32: [...] },
  *   topK: 5
  * })
  * ```
  */
  index(s) {
    return new fn(this.url, this.headers, this.vectorBucketName, s, this.fetch);
  }
}, fn = class extends ln {
  /**
  *
  * @alpha
  *
  * Creates a helper that automatically scopes all vector operations to the provided bucket/index names.
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @example
  * ```typescript
  * const index = supabase.storage.vectors.from('embeddings-prod').index('documents-openai')
  * ```
  */
  constructor(s, e, t, r, n) {
    super(s, e, n), this.vectorBucketName = t, this.indexName = r;
  }
  /**
  *
  * @alpha
  *
  * Inserts or updates vectors in this index
  * Convenience method that automatically includes bucket and index names
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param options - Vector insertion options (bucket and index names automatically set)
  * @returns Promise with empty response on success or error
  *
  * @example
  * ```typescript
  * const index = supabase.storage.vectors.from('embeddings-prod').index('documents-openai')
  * await index.putVectors({
  *   vectors: [
  *     {
  *       key: 'doc-1',
  *       data: { float32: [0.1, 0.2, ...] },
  *       metadata: { title: 'Introduction', page: 1 }
  *     }
  *   ]
  * })
  * ```
  */
  async putVectors(s) {
    var e = () => super.putVectors, t = this;
    return e().call(t, T(T({}, s), {}, {
      vectorBucketName: t.vectorBucketName,
      indexName: t.indexName
    }));
  }
  /**
  *
  * @alpha
  *
  * Retrieves vectors by keys from this index
  * Convenience method that automatically includes bucket and index names
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param options - Vector retrieval options (bucket and index names automatically set)
  * @returns Promise with response containing vectors array or error
  *
  * @example
  * ```typescript
  * const index = supabase.storage.vectors.from('embeddings-prod').index('documents-openai')
  * const { data } = await index.getVectors({
  *   keys: ['doc-1', 'doc-2'],
  *   returnMetadata: true
  * })
  * ```
  */
  async getVectors(s) {
    var e = () => super.getVectors, t = this;
    return e().call(t, T(T({}, s), {}, {
      vectorBucketName: t.vectorBucketName,
      indexName: t.indexName
    }));
  }
  /**
  *
  * @alpha
  *
  * Lists vectors in this index with pagination
  * Convenience method that automatically includes bucket and index names
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param options - Listing options (bucket and index names automatically set)
  * @returns Promise with response containing vectors array and pagination token or error
  *
  * @example
  * ```typescript
  * const index = supabase.storage.vectors.from('embeddings-prod').index('documents-openai')
  * const { data } = await index.listVectors({
  *   maxResults: 500,
  *   returnMetadata: true
  * })
  * ```
  */
  async listVectors(s = {}) {
    var e = () => super.listVectors, t = this;
    return e().call(t, T(T({}, s), {}, {
      vectorBucketName: t.vectorBucketName,
      indexName: t.indexName
    }));
  }
  /**
  *
  * @alpha
  *
  * Queries for similar vectors in this index
  * Convenience method that automatically includes bucket and index names
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param options - Query options (bucket and index names automatically set)
  * @returns Promise with response containing matches array of similar vectors ordered by distance or error
  *
  * @example
  * ```typescript
  * const index = supabase.storage.vectors.from('embeddings-prod').index('documents-openai')
  * const { data } = await index.queryVectors({
  *   queryVector: { float32: [0.1, 0.2, ...] },
  *   topK: 5,
  *   filter: { category: 'technical' },
  *   returnDistance: true,
  *   returnMetadata: true
  * })
  * ```
  */
  async queryVectors(s) {
    var e = () => super.queryVectors, t = this;
    return e().call(t, T(T({}, s), {}, {
      vectorBucketName: t.vectorBucketName,
      indexName: t.indexName
    }));
  }
  /**
  *
  * @alpha
  *
  * Deletes vectors by keys from this index
  * Convenience method that automatically includes bucket and index names
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @param options - Deletion options (bucket and index names automatically set)
  * @returns Promise with empty response on success or error
  *
  * @example
  * ```typescript
  * const index = supabase.storage.vectors.from('embeddings-prod').index('documents-openai')
  * await index.deleteVectors({
  *   keys: ['doc-1', 'doc-2', 'doc-3']
  * })
  * ```
  */
  async deleteVectors(s) {
    var e = () => super.deleteVectors, t = this;
    return e().call(t, T(T({}, s), {}, {
      vectorBucketName: t.vectorBucketName,
      indexName: t.indexName
    }));
  }
}, pn = class extends an {
  /**
  * Creates a client for Storage buckets, files, analytics, and vectors.
  *
  * @category File Buckets
  * @example
  * ```ts
  * import { StorageClient } from '@supabase/storage-js'
  *
  * const storage = new StorageClient('https://xyzcompany.supabase.co/storage/v1', {
  *   apikey: 'public-anon-key',
  * })
  * const avatars = storage.from('avatars')
  * ```
  */
  constructor(s, e = {}, t, r) {
    super(s, e, t, r);
  }
  /**
  * Perform file operation in a bucket.
  *
  * @category File Buckets
  * @param id The bucket id to operate on.
  *
  * @example
  * ```typescript
  * const avatars = supabase.storage.from('avatars')
  * ```
  */
  from(s) {
    return new rn(this.url, this.headers, s, this.fetch);
  }
  /**
  *
  * @alpha
  *
  * Access vector storage operations.
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Vector Buckets
  * @returns A StorageVectorsClient instance configured with the current storage settings.
  */
  get vectors() {
    return new hn(this.url + "/vector", {
      headers: this.headers,
      fetch: this.fetch
    });
  }
  /**
  *
  * @alpha
  *
  * Access analytics storage operations using Iceberg tables.
  *
  * **Public alpha:** This API is part of a public alpha release and may not be available to your account type.
  *
  * @category Analytics Buckets
  * @returns A StorageAnalyticsClient instance configured with the current storage settings.
  */
  get analytics() {
    return new on(this.url + "/iceberg", this.headers, this.fetch);
  }
};
const js = "2.93.3", ye = 30 * 1e3, gt = 3, st = gt * ye, gn = "http://localhost:9999", mn = "supabase.auth.token", yn = { "X-Client-Info": `gotrue-js/${js}` }, mt = "X-Supabase-Api-Version", Us = {
  "2024-01-01": {
    timestamp: Date.parse("2024-01-01T00:00:00.0Z"),
    name: "2024-01-01"
  }
}, _n = /^([a-z0-9_-]{4})*($|[a-z0-9_-]{3}$|[a-z0-9_-]{2}$)$/i, vn = 10 * 60 * 1e3;
class xe extends Error {
  constructor(e, t, r) {
    super(e), this.__isAuthError = !0, this.name = "AuthError", this.status = t, this.code = r;
  }
}
function b(s) {
  return typeof s == "object" && s !== null && "__isAuthError" in s;
}
class wn extends xe {
  constructor(e, t, r) {
    super(e, t, r), this.name = "AuthApiError", this.status = t, this.code = r;
  }
}
function bn(s) {
  return b(s) && s.name === "AuthApiError";
}
class ae extends xe {
  constructor(e, t) {
    super(e), this.name = "AuthUnknownError", this.originalError = t;
  }
}
class Q extends xe {
  constructor(e, t, r, n) {
    super(e, r, n), this.name = t, this.status = r;
  }
}
class L extends Q {
  constructor() {
    super("Auth session missing!", "AuthSessionMissingError", 400, void 0);
  }
}
function rt(s) {
  return b(s) && s.name === "AuthSessionMissingError";
}
class he extends Q {
  constructor() {
    super("Auth session or user missing", "AuthInvalidTokenResponseError", 500, void 0);
  }
}
class Me extends Q {
  constructor(e) {
    super(e, "AuthInvalidCredentialsError", 400, void 0);
  }
}
class Be extends Q {
  constructor(e, t = null) {
    super(e, "AuthImplicitGrantRedirectError", 500, void 0), this.details = null, this.details = t;
  }
  toJSON() {
    return {
      name: this.name,
      message: this.message,
      status: this.status,
      details: this.details
    };
  }
}
function Sn(s) {
  return b(s) && s.name === "AuthImplicitGrantRedirectError";
}
class qt extends Q {
  constructor(e, t = null) {
    super(e, "AuthPKCEGrantCodeExchangeError", 500, void 0), this.details = null, this.details = t;
  }
  toJSON() {
    return {
      name: this.name,
      message: this.message,
      status: this.status,
      details: this.details
    };
  }
}
class En extends Q {
  constructor() {
    super("PKCE code verifier not found in storage. This can happen if the auth flow was initiated in a different browser or device, or if the storage was cleared. For SSR frameworks (Next.js, SvelteKit, etc.), use @supabase/ssr on both the server and client to store the code verifier in cookies.", "AuthPKCECodeVerifierMissingError", 400, "pkce_code_verifier_not_found");
  }
}
class yt extends Q {
  constructor(e, t) {
    super(e, "AuthRetryableFetchError", t, void 0);
  }
}
function nt(s) {
  return b(s) && s.name === "AuthRetryableFetchError";
}
class Ft extends Q {
  constructor(e, t, r) {
    super(e, "AuthWeakPasswordError", t, "weak_password"), this.reasons = r;
  }
}
class _t extends Q {
  constructor(e) {
    super(e, "AuthInvalidJwtError", 400, "invalid_jwt");
  }
}
const Ke = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".split(""), Ht = ` 	
\r=`.split(""), Tn = (() => {
  const s = new Array(128);
  for (let e = 0; e < s.length; e += 1)
    s[e] = -1;
  for (let e = 0; e < Ht.length; e += 1)
    s[Ht[e].charCodeAt(0)] = -2;
  for (let e = 0; e < Ke.length; e += 1)
    s[Ke[e].charCodeAt(0)] = e;
  return s;
})();
function Vt(s, e, t) {
  if (s !== null)
    for (e.queue = e.queue << 8 | s, e.queuedBits += 8; e.queuedBits >= 6; ) {
      const r = e.queue >> e.queuedBits - 6 & 63;
      t(Ke[r]), e.queuedBits -= 6;
    }
  else if (e.queuedBits > 0)
    for (e.queue = e.queue << 6 - e.queuedBits, e.queuedBits = 6; e.queuedBits >= 6; ) {
      const r = e.queue >> e.queuedBits - 6 & 63;
      t(Ke[r]), e.queuedBits -= 6;
    }
}
function Ls(s, e, t) {
  const r = Tn[s];
  if (r > -1)
    for (e.queue = e.queue << 6 | r, e.queuedBits += 6; e.queuedBits >= 8; )
      t(e.queue >> e.queuedBits - 8 & 255), e.queuedBits -= 8;
  else {
    if (r === -2)
      return;
    throw new Error(`Invalid Base64-URL character "${String.fromCharCode(s)}"`);
  }
}
function Kt(s) {
  const e = [], t = (a) => {
    e.push(String.fromCodePoint(a));
  }, r = {
    utf8seq: 0,
    codepoint: 0
  }, n = { queue: 0, queuedBits: 0 }, i = (a) => {
    On(a, r, t);
  };
  for (let a = 0; a < s.length; a += 1)
    Ls(s.charCodeAt(a), n, i);
  return e.join("");
}
function An(s, e) {
  if (s <= 127) {
    e(s);
    return;
  } else if (s <= 2047) {
    e(192 | s >> 6), e(128 | s & 63);
    return;
  } else if (s <= 65535) {
    e(224 | s >> 12), e(128 | s >> 6 & 63), e(128 | s & 63);
    return;
  } else if (s <= 1114111) {
    e(240 | s >> 18), e(128 | s >> 12 & 63), e(128 | s >> 6 & 63), e(128 | s & 63);
    return;
  }
  throw new Error(`Unrecognized Unicode codepoint: ${s.toString(16)}`);
}
function kn(s, e) {
  for (let t = 0; t < s.length; t += 1) {
    let r = s.charCodeAt(t);
    if (r > 55295 && r <= 56319) {
      const n = (r - 55296) * 1024 & 65535;
      r = (s.charCodeAt(t + 1) - 56320 & 65535 | n) + 65536, t += 1;
    }
    An(r, e);
  }
}
function On(s, e, t) {
  if (e.utf8seq === 0) {
    if (s <= 127) {
      t(s);
      return;
    }
    for (let r = 1; r < 6; r += 1)
      if (!(s >> 7 - r & 1)) {
        e.utf8seq = r;
        break;
      }
    if (e.utf8seq === 2)
      e.codepoint = s & 31;
    else if (e.utf8seq === 3)
      e.codepoint = s & 15;
    else if (e.utf8seq === 4)
      e.codepoint = s & 7;
    else
      throw new Error("Invalid UTF-8 sequence");
    e.utf8seq -= 1;
  } else if (e.utf8seq > 0) {
    if (s <= 127)
      throw new Error("Invalid UTF-8 sequence");
    e.codepoint = e.codepoint << 6 | s & 63, e.utf8seq -= 1, e.utf8seq === 0 && t(e.codepoint);
  }
}
function be(s) {
  const e = [], t = { queue: 0, queuedBits: 0 }, r = (n) => {
    e.push(n);
  };
  for (let n = 0; n < s.length; n += 1)
    Ls(s.charCodeAt(n), t, r);
  return new Uint8Array(e);
}
function Rn(s) {
  const e = [];
  return kn(s, (t) => e.push(t)), new Uint8Array(e);
}
function oe(s) {
  const e = [], t = { queue: 0, queuedBits: 0 }, r = (n) => {
    e.push(n);
  };
  return s.forEach((n) => Vt(n, t, r)), Vt(null, t, r), e.join("");
}
function Cn(s) {
  return Math.round(Date.now() / 1e3) + s;
}
function In() {
  return Symbol("auth-callback");
}
const U = () => typeof window < "u" && typeof document < "u", se = {
  tested: !1,
  writable: !1
}, Ds = () => {
  if (!U())
    return !1;
  try {
    if (typeof globalThis.localStorage != "object")
      return !1;
  } catch {
    return !1;
  }
  if (se.tested)
    return se.writable;
  const s = `lswt-${Math.random()}${Math.random()}`;
  try {
    globalThis.localStorage.setItem(s, s), globalThis.localStorage.removeItem(s), se.tested = !0, se.writable = !0;
  } catch {
    se.tested = !0, se.writable = !1;
  }
  return se.writable;
};
function $n(s) {
  const e = {}, t = new URL(s);
  if (t.hash && t.hash[0] === "#")
    try {
      new URLSearchParams(t.hash.substring(1)).forEach((n, i) => {
        e[i] = n;
      });
    } catch {
    }
  return t.searchParams.forEach((r, n) => {
    e[n] = r;
  }), e;
}
const Ms = (s) => s ? (...e) => s(...e) : (...e) => fetch(...e), xn = (s) => typeof s == "object" && s !== null && "status" in s && "ok" in s && "json" in s && typeof s.json == "function", _e = async (s, e, t) => {
  await s.setItem(e, JSON.stringify(t));
}, re = async (s, e) => {
  const t = await s.getItem(e);
  if (!t)
    return null;
  try {
    return JSON.parse(t);
  } catch {
    return t;
  }
}, j = async (s, e) => {
  await s.removeItem(e);
};
class Xe {
  constructor() {
    this.promise = new Xe.promiseConstructor((e, t) => {
      this.resolve = e, this.reject = t;
    });
  }
}
Xe.promiseConstructor = Promise;
function qe(s) {
  const e = s.split(".");
  if (e.length !== 3)
    throw new _t("Invalid JWT structure");
  for (let r = 0; r < e.length; r++)
    if (!_n.test(e[r]))
      throw new _t("JWT not in base64url format");
  return {
    // using base64url lib
    header: JSON.parse(Kt(e[0])),
    payload: JSON.parse(Kt(e[1])),
    signature: be(e[2]),
    raw: {
      header: e[0],
      payload: e[1]
    }
  };
}
async function Pn(s) {
  return await new Promise((e) => {
    setTimeout(() => e(null), s);
  });
}
function Nn(s, e) {
  return new Promise((r, n) => {
    (async () => {
      for (let i = 0; i < 1 / 0; i++)
        try {
          const a = await s(i);
          if (!e(i, null, a)) {
            r(a);
            return;
          }
        } catch (a) {
          if (!e(i, a)) {
            n(a);
            return;
          }
        }
    })();
  });
}
function jn(s) {
  return ("0" + s.toString(16)).substr(-2);
}
function Un() {
  const e = new Uint32Array(56);
  if (typeof crypto > "u") {
    const t = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~", r = t.length;
    let n = "";
    for (let i = 0; i < 56; i++)
      n += t.charAt(Math.floor(Math.random() * r));
    return n;
  }
  return crypto.getRandomValues(e), Array.from(e, jn).join("");
}
async function Ln(s) {
  const t = new TextEncoder().encode(s), r = await crypto.subtle.digest("SHA-256", t), n = new Uint8Array(r);
  return Array.from(n).map((i) => String.fromCharCode(i)).join("");
}
async function Dn(s) {
  if (!(typeof crypto < "u" && typeof crypto.subtle < "u" && typeof TextEncoder < "u"))
    return console.warn("WebCrypto API is not supported. Code challenge method will default to use plain instead of sha256."), s;
  const t = await Ln(s);
  return btoa(t).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
async function de(s, e, t = !1) {
  const r = Un();
  let n = r;
  t && (n += "/PASSWORD_RECOVERY"), await _e(s, `${e}-code-verifier`, n);
  const i = await Dn(r);
  return [i, r === i ? "plain" : "s256"];
}
const Mn = /^2[0-9]{3}-(0[1-9]|1[0-2])-(0[1-9]|1[0-9]|2[0-9]|3[0-1])$/i;
function Bn(s) {
  const e = s.headers.get(mt);
  if (!e || !e.match(Mn))
    return null;
  try {
    return /* @__PURE__ */ new Date(`${e}T00:00:00.0Z`);
  } catch {
    return null;
  }
}
function qn(s) {
  if (!s)
    throw new Error("Missing exp claim");
  const e = Math.floor(Date.now() / 1e3);
  if (s <= e)
    throw new Error("JWT has expired");
}
function Fn(s) {
  switch (s) {
    case "RS256":
      return {
        name: "RSASSA-PKCS1-v1_5",
        hash: { name: "SHA-256" }
      };
    case "ES256":
      return {
        name: "ECDSA",
        namedCurve: "P-256",
        hash: { name: "SHA-256" }
      };
    default:
      throw new Error("Invalid alg claim");
  }
}
const Hn = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
function fe(s) {
  if (!Hn.test(s))
    throw new Error("@supabase/auth-js: Expected parameter to be UUID but is not");
}
function it() {
  const s = {};
  return new Proxy(s, {
    get: (e, t) => {
      if (t === "__isUserNotAvailableProxy")
        return !0;
      if (typeof t == "symbol") {
        const r = t.toString();
        if (r === "Symbol(Symbol.toPrimitive)" || r === "Symbol(Symbol.toStringTag)" || r === "Symbol(util.inspect.custom)")
          return;
      }
      throw new Error(`@supabase/auth-js: client was created with userStorage option and there was no user stored in the user storage. Accessing the "${t}" property of the session object is not supported. Please use getUser() instead.`);
    },
    set: (e, t) => {
      throw new Error(`@supabase/auth-js: client was created with userStorage option and there was no user stored in the user storage. Setting the "${t}" property of the session object is not supported. Please use getUser() to fetch a user object you can manipulate.`);
    },
    deleteProperty: (e, t) => {
      throw new Error(`@supabase/auth-js: client was created with userStorage option and there was no user stored in the user storage. Deleting the "${t}" property of the session object is not supported. Please use getUser() to fetch a user object you can manipulate.`);
    }
  });
}
function Vn(s, e) {
  return new Proxy(s, {
    get: (t, r, n) => {
      if (r === "__isInsecureUserWarningProxy")
        return !0;
      if (typeof r == "symbol") {
        const i = r.toString();
        if (i === "Symbol(Symbol.toPrimitive)" || i === "Symbol(Symbol.toStringTag)" || i === "Symbol(util.inspect.custom)" || i === "Symbol(nodejs.util.inspect.custom)")
          return Reflect.get(t, r, n);
      }
      return !e.value && typeof r == "string" && (console.warn("Using the user object as returned from supabase.auth.getSession() or from some supabase.auth.onAuthStateChange() events could be insecure! This value comes directly from the storage medium (usually cookies on the server) and may not be authentic. Use supabase.auth.getUser() instead which authenticates the data by contacting the Supabase Auth server."), e.value = !0), Reflect.get(t, r, n);
    }
  });
}
function Gt(s) {
  return JSON.parse(JSON.stringify(s));
}
const ne = (s) => s.msg || s.message || s.error_description || s.error || JSON.stringify(s), Kn = [502, 503, 504];
async function zt(s) {
  var e;
  if (!xn(s))
    throw new yt(ne(s), 0);
  if (Kn.includes(s.status))
    throw new yt(ne(s), s.status);
  let t;
  try {
    t = await s.json();
  } catch (i) {
    throw new ae(ne(i), i);
  }
  let r;
  const n = Bn(s);
  if (n && n.getTime() >= Us["2024-01-01"].timestamp && typeof t == "object" && t && typeof t.code == "string" ? r = t.code : typeof t == "object" && t && typeof t.error_code == "string" && (r = t.error_code), r) {
    if (r === "weak_password")
      throw new Ft(ne(t), s.status, ((e = t.weak_password) === null || e === void 0 ? void 0 : e.reasons) || []);
    if (r === "session_not_found")
      throw new L();
  } else if (typeof t == "object" && t && typeof t.weak_password == "object" && t.weak_password && Array.isArray(t.weak_password.reasons) && t.weak_password.reasons.length && t.weak_password.reasons.reduce((i, a) => i && typeof a == "string", !0))
    throw new Ft(ne(t), s.status, t.weak_password.reasons);
  throw new wn(ne(t), s.status || 500, r);
}
const Gn = (s, e, t, r) => {
  const n = { method: s, headers: (e == null ? void 0 : e.headers) || {} };
  return s === "GET" ? n : (n.headers = Object.assign({ "Content-Type": "application/json;charset=UTF-8" }, e == null ? void 0 : e.headers), n.body = JSON.stringify(r), Object.assign(Object.assign({}, n), t));
};
async function E(s, e, t, r) {
  var n;
  const i = Object.assign({}, r == null ? void 0 : r.headers);
  i[mt] || (i[mt] = Us["2024-01-01"].name), r != null && r.jwt && (i.Authorization = `Bearer ${r.jwt}`);
  const a = (n = r == null ? void 0 : r.query) !== null && n !== void 0 ? n : {};
  r != null && r.redirectTo && (a.redirect_to = r.redirectTo);
  const o = Object.keys(a).length ? "?" + new URLSearchParams(a).toString() : "", c = await zn(s, e, t + o, {
    headers: i,
    noResolveJson: r == null ? void 0 : r.noResolveJson
  }, {}, r == null ? void 0 : r.body);
  return r != null && r.xform ? r == null ? void 0 : r.xform(c) : { data: Object.assign({}, c), error: null };
}
async function zn(s, e, t, r, n, i) {
  const a = Gn(e, r, n, i);
  let o;
  try {
    o = await s(t, Object.assign({}, a));
  } catch (c) {
    throw console.error(c), new yt(ne(c), 0);
  }
  if (o.ok || await zt(o), r != null && r.noResolveJson)
    return o;
  try {
    return await o.json();
  } catch (c) {
    await zt(c);
  }
}
function q(s) {
  var e;
  let t = null;
  Yn(s) && (t = Object.assign({}, s), s.expires_at || (t.expires_at = Cn(s.expires_in)));
  const r = (e = s.user) !== null && e !== void 0 ? e : s;
  return { data: { session: t, user: r }, error: null };
}
function Wt(s) {
  const e = q(s);
  return !e.error && s.weak_password && typeof s.weak_password == "object" && Array.isArray(s.weak_password.reasons) && s.weak_password.reasons.length && s.weak_password.message && typeof s.weak_password.message == "string" && s.weak_password.reasons.reduce((t, r) => t && typeof r == "string", !0) && (e.data.weak_password = s.weak_password), e;
}
function Z(s) {
  var e;
  return { data: { user: (e = s.user) !== null && e !== void 0 ? e : s }, error: null };
}
function Wn(s) {
  return { data: s, error: null };
}
function Jn(s) {
  const { action_link: e, email_otp: t, hashed_token: r, redirect_to: n, verification_type: i } = s, a = Je(s, ["action_link", "email_otp", "hashed_token", "redirect_to", "verification_type"]), o = {
    action_link: e,
    email_otp: t,
    hashed_token: r,
    redirect_to: n,
    verification_type: i
  }, c = Object.assign({}, a);
  return {
    data: {
      properties: o,
      user: c
    },
    error: null
  };
}
function Jt(s) {
  return s;
}
function Yn(s) {
  return s.access_token && s.refresh_token && s.expires_in;
}
const at = ["global", "local", "others"];
class Qn {
  /**
   * Creates an admin API client that can be used to manage users and OAuth clients.
   *
   * @example
   * ```ts
   * import { GoTrueAdminApi } from '@supabase/auth-js'
   *
   * const admin = new GoTrueAdminApi({
   *   url: 'https://xyzcompany.supabase.co/auth/v1',
   *   headers: { Authorization: `Bearer ${process.env.SUPABASE_SERVICE_ROLE_KEY}` },
   * })
   * ```
   */
  constructor({ url: e = "", headers: t = {}, fetch: r }) {
    this.url = e, this.headers = t, this.fetch = Ms(r), this.mfa = {
      listFactors: this._listFactors.bind(this),
      deleteFactor: this._deleteFactor.bind(this)
    }, this.oauth = {
      listClients: this._listOAuthClients.bind(this),
      createClient: this._createOAuthClient.bind(this),
      getClient: this._getOAuthClient.bind(this),
      updateClient: this._updateOAuthClient.bind(this),
      deleteClient: this._deleteOAuthClient.bind(this),
      regenerateClientSecret: this._regenerateOAuthClientSecret.bind(this)
    };
  }
  /**
   * Removes a logged-in session.
   * @param jwt A valid, logged-in JWT.
   * @param scope The logout sope.
   */
  async signOut(e, t = at[0]) {
    if (at.indexOf(t) < 0)
      throw new Error(`@supabase/auth-js: Parameter scope must be one of ${at.join(", ")}`);
    try {
      return await E(this.fetch, "POST", `${this.url}/logout?scope=${t}`, {
        headers: this.headers,
        jwt: e,
        noResolveJson: !0
      }), { data: null, error: null };
    } catch (r) {
      if (b(r))
        return { data: null, error: r };
      throw r;
    }
  }
  /**
   * Sends an invite link to an email address.
   * @param email The email address of the user.
   * @param options Additional options to be included when inviting.
   */
  async inviteUserByEmail(e, t = {}) {
    try {
      return await E(this.fetch, "POST", `${this.url}/invite`, {
        body: { email: e, data: t.data },
        headers: this.headers,
        redirectTo: t.redirectTo,
        xform: Z
      });
    } catch (r) {
      if (b(r))
        return { data: { user: null }, error: r };
      throw r;
    }
  }
  /**
   * Generates email links and OTPs to be sent via a custom email provider.
   * @param email The user's email.
   * @param options.password User password. For signup only.
   * @param options.data Optional user metadata. For signup only.
   * @param options.redirectTo The redirect url which should be appended to the generated link
   */
  async generateLink(e) {
    try {
      const { options: t } = e, r = Je(e, ["options"]), n = Object.assign(Object.assign({}, r), t);
      return "newEmail" in r && (n.new_email = r == null ? void 0 : r.newEmail, delete n.newEmail), await E(this.fetch, "POST", `${this.url}/admin/generate_link`, {
        body: n,
        headers: this.headers,
        xform: Jn,
        redirectTo: t == null ? void 0 : t.redirectTo
      });
    } catch (t) {
      if (b(t))
        return {
          data: {
            properties: null,
            user: null
          },
          error: t
        };
      throw t;
    }
  }
  // User Admin API
  /**
   * Creates a new user.
   * This function should only be called on a server. Never expose your `service_role` key in the browser.
   */
  async createUser(e) {
    try {
      return await E(this.fetch, "POST", `${this.url}/admin/users`, {
        body: e,
        headers: this.headers,
        xform: Z
      });
    } catch (t) {
      if (b(t))
        return { data: { user: null }, error: t };
      throw t;
    }
  }
  /**
   * Get a list of users.
   *
   * This function should only be called on a server. Never expose your `service_role` key in the browser.
   * @param params An object which supports `page` and `perPage` as numbers, to alter the paginated results.
   */
  async listUsers(e) {
    var t, r, n, i, a, o, c;
    try {
      const l = { nextPage: null, lastPage: 0, total: 0 }, u = await E(this.fetch, "GET", `${this.url}/admin/users`, {
        headers: this.headers,
        noResolveJson: !0,
        query: {
          page: (r = (t = e == null ? void 0 : e.page) === null || t === void 0 ? void 0 : t.toString()) !== null && r !== void 0 ? r : "",
          per_page: (i = (n = e == null ? void 0 : e.perPage) === null || n === void 0 ? void 0 : n.toString()) !== null && i !== void 0 ? i : ""
        },
        xform: Jt
      });
      if (u.error)
        throw u.error;
      const d = await u.json(), h = (a = u.headers.get("x-total-count")) !== null && a !== void 0 ? a : 0, f = (c = (o = u.headers.get("link")) === null || o === void 0 ? void 0 : o.split(",")) !== null && c !== void 0 ? c : [];
      return f.length > 0 && (f.forEach((p) => {
        const g = parseInt(p.split(";")[0].split("=")[1].substring(0, 1)), m = JSON.parse(p.split(";")[1].split("=")[1]);
        l[`${m}Page`] = g;
      }), l.total = parseInt(h)), { data: Object.assign(Object.assign({}, d), l), error: null };
    } catch (l) {
      if (b(l))
        return { data: { users: [] }, error: l };
      throw l;
    }
  }
  /**
   * Get user by id.
   *
   * @param uid The user's unique identifier
   *
   * This function should only be called on a server. Never expose your `service_role` key in the browser.
   */
  async getUserById(e) {
    fe(e);
    try {
      return await E(this.fetch, "GET", `${this.url}/admin/users/${e}`, {
        headers: this.headers,
        xform: Z
      });
    } catch (t) {
      if (b(t))
        return { data: { user: null }, error: t };
      throw t;
    }
  }
  /**
   * Updates the user data. Changes are applied directly without confirmation flows.
   *
   * @param attributes The data you want to update.
   *
   * This function should only be called on a server. Never expose your `service_role` key in the browser.
   */
  async updateUserById(e, t) {
    fe(e);
    try {
      return await E(this.fetch, "PUT", `${this.url}/admin/users/${e}`, {
        body: t,
        headers: this.headers,
        xform: Z
      });
    } catch (r) {
      if (b(r))
        return { data: { user: null }, error: r };
      throw r;
    }
  }
  /**
   * Delete a user. Requires a `service_role` key.
   *
   * @param id The user id you want to remove.
   * @param shouldSoftDelete If true, then the user will be soft-deleted from the auth schema. Soft deletion allows user identification from the hashed user ID but is not reversible.
   * Defaults to false for backward compatibility.
   *
   * This function should only be called on a server. Never expose your `service_role` key in the browser.
   */
  async deleteUser(e, t = !1) {
    fe(e);
    try {
      return await E(this.fetch, "DELETE", `${this.url}/admin/users/${e}`, {
        headers: this.headers,
        body: {
          should_soft_delete: t
        },
        xform: Z
      });
    } catch (r) {
      if (b(r))
        return { data: { user: null }, error: r };
      throw r;
    }
  }
  async _listFactors(e) {
    fe(e.userId);
    try {
      const { data: t, error: r } = await E(this.fetch, "GET", `${this.url}/admin/users/${e.userId}/factors`, {
        headers: this.headers,
        xform: (n) => ({ data: { factors: n }, error: null })
      });
      return { data: t, error: r };
    } catch (t) {
      if (b(t))
        return { data: null, error: t };
      throw t;
    }
  }
  async _deleteFactor(e) {
    fe(e.userId), fe(e.id);
    try {
      return { data: await E(this.fetch, "DELETE", `${this.url}/admin/users/${e.userId}/factors/${e.id}`, {
        headers: this.headers
      }), error: null };
    } catch (t) {
      if (b(t))
        return { data: null, error: t };
      throw t;
    }
  }
  /**
   * Lists all OAuth clients with optional pagination.
   * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
   *
   * This function should only be called on a server. Never expose your `service_role` key in the browser.
   */
  async _listOAuthClients(e) {
    var t, r, n, i, a, o, c;
    try {
      const l = { nextPage: null, lastPage: 0, total: 0 }, u = await E(this.fetch, "GET", `${this.url}/admin/oauth/clients`, {
        headers: this.headers,
        noResolveJson: !0,
        query: {
          page: (r = (t = e == null ? void 0 : e.page) === null || t === void 0 ? void 0 : t.toString()) !== null && r !== void 0 ? r : "",
          per_page: (i = (n = e == null ? void 0 : e.perPage) === null || n === void 0 ? void 0 : n.toString()) !== null && i !== void 0 ? i : ""
        },
        xform: Jt
      });
      if (u.error)
        throw u.error;
      const d = await u.json(), h = (a = u.headers.get("x-total-count")) !== null && a !== void 0 ? a : 0, f = (c = (o = u.headers.get("link")) === null || o === void 0 ? void 0 : o.split(",")) !== null && c !== void 0 ? c : [];
      return f.length > 0 && (f.forEach((p) => {
        const g = parseInt(p.split(";")[0].split("=")[1].substring(0, 1)), m = JSON.parse(p.split(";")[1].split("=")[1]);
        l[`${m}Page`] = g;
      }), l.total = parseInt(h)), { data: Object.assign(Object.assign({}, d), l), error: null };
    } catch (l) {
      if (b(l))
        return { data: { clients: [] }, error: l };
      throw l;
    }
  }
  /**
   * Creates a new OAuth client.
   * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
   *
   * This function should only be called on a server. Never expose your `service_role` key in the browser.
   */
  async _createOAuthClient(e) {
    try {
      return await E(this.fetch, "POST", `${this.url}/admin/oauth/clients`, {
        body: e,
        headers: this.headers,
        xform: (t) => ({ data: t, error: null })
      });
    } catch (t) {
      if (b(t))
        return { data: null, error: t };
      throw t;
    }
  }
  /**
   * Gets details of a specific OAuth client.
   * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
   *
   * This function should only be called on a server. Never expose your `service_role` key in the browser.
   */
  async _getOAuthClient(e) {
    try {
      return await E(this.fetch, "GET", `${this.url}/admin/oauth/clients/${e}`, {
        headers: this.headers,
        xform: (t) => ({ data: t, error: null })
      });
    } catch (t) {
      if (b(t))
        return { data: null, error: t };
      throw t;
    }
  }
  /**
   * Updates an existing OAuth client.
   * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
   *
   * This function should only be called on a server. Never expose your `service_role` key in the browser.
   */
  async _updateOAuthClient(e, t) {
    try {
      return await E(this.fetch, "PUT", `${this.url}/admin/oauth/clients/${e}`, {
        body: t,
        headers: this.headers,
        xform: (r) => ({ data: r, error: null })
      });
    } catch (r) {
      if (b(r))
        return { data: null, error: r };
      throw r;
    }
  }
  /**
   * Deletes an OAuth client.
   * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
   *
   * This function should only be called on a server. Never expose your `service_role` key in the browser.
   */
  async _deleteOAuthClient(e) {
    try {
      return await E(this.fetch, "DELETE", `${this.url}/admin/oauth/clients/${e}`, {
        headers: this.headers,
        noResolveJson: !0
      }), { data: null, error: null };
    } catch (t) {
      if (b(t))
        return { data: null, error: t };
      throw t;
    }
  }
  /**
   * Regenerates the secret for an OAuth client.
   * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
   *
   * This function should only be called on a server. Never expose your `service_role` key in the browser.
   */
  async _regenerateOAuthClientSecret(e) {
    try {
      return await E(this.fetch, "POST", `${this.url}/admin/oauth/clients/${e}/regenerate_secret`, {
        headers: this.headers,
        xform: (t) => ({ data: t, error: null })
      });
    } catch (t) {
      if (b(t))
        return { data: null, error: t };
      throw t;
    }
  }
}
function Yt(s = {}) {
  return {
    getItem: (e) => s[e] || null,
    setItem: (e, t) => {
      s[e] = t;
    },
    removeItem: (e) => {
      delete s[e];
    }
  };
}
const pe = {
  /**
   * @experimental
   */
  debug: !!(globalThis && Ds() && globalThis.localStorage && globalThis.localStorage.getItem("supabase.gotrue-js.locks.debug") === "true")
};
class Bs extends Error {
  constructor(e) {
    super(e), this.isAcquireTimeout = !0;
  }
}
class Xn extends Bs {
}
async function Zn(s, e, t) {
  pe.debug && console.log("@supabase/gotrue-js: navigatorLock: acquire lock", s, e);
  const r = new globalThis.AbortController();
  return e > 0 && setTimeout(() => {
    r.abort(), pe.debug && console.log("@supabase/gotrue-js: navigatorLock acquire timed out", s);
  }, e), await Promise.resolve().then(() => globalThis.navigator.locks.request(s, e === 0 ? {
    mode: "exclusive",
    ifAvailable: !0
  } : {
    mode: "exclusive",
    signal: r.signal
  }, async (n) => {
    if (n) {
      pe.debug && console.log("@supabase/gotrue-js: navigatorLock: acquired", s, n.name);
      try {
        return await t();
      } finally {
        pe.debug && console.log("@supabase/gotrue-js: navigatorLock: released", s, n.name);
      }
    } else {
      if (e === 0)
        throw pe.debug && console.log("@supabase/gotrue-js: navigatorLock: not immediately available", s), new Xn(`Acquiring an exclusive Navigator LockManager lock "${s}" immediately failed`);
      if (pe.debug)
        try {
          const i = await globalThis.navigator.locks.query();
          console.log("@supabase/gotrue-js: Navigator LockManager state", JSON.stringify(i, null, "  "));
        } catch (i) {
          console.warn("@supabase/gotrue-js: Error when querying Navigator LockManager state", i);
        }
      return console.warn("@supabase/gotrue-js: Navigator LockManager returned a null lock when using #request without ifAvailable set to true, it appears this browser is not following the LockManager spec https://developer.mozilla.org/en-US/docs/Web/API/LockManager/request"), await t();
    }
  }));
}
function ei() {
  if (typeof globalThis != "object")
    try {
      Object.defineProperty(Object.prototype, "__magic__", {
        get: function() {
          return this;
        },
        configurable: !0
      }), __magic__.globalThis = __magic__, delete Object.prototype.__magic__;
    } catch {
      typeof self < "u" && (self.globalThis = self);
    }
}
function qs(s) {
  if (!/^0x[a-fA-F0-9]{40}$/.test(s))
    throw new Error(`@supabase/auth-js: Address "${s}" is invalid.`);
  return s.toLowerCase();
}
function ti(s) {
  return parseInt(s, 16);
}
function si(s) {
  const e = new TextEncoder().encode(s);
  return "0x" + Array.from(e, (r) => r.toString(16).padStart(2, "0")).join("");
}
function ri(s) {
  var e;
  const { chainId: t, domain: r, expirationTime: n, issuedAt: i = /* @__PURE__ */ new Date(), nonce: a, notBefore: o, requestId: c, resources: l, scheme: u, uri: d, version: h } = s;
  {
    if (!Number.isInteger(t))
      throw new Error(`@supabase/auth-js: Invalid SIWE message field "chainId". Chain ID must be a EIP-155 chain ID. Provided value: ${t}`);
    if (!r)
      throw new Error('@supabase/auth-js: Invalid SIWE message field "domain". Domain must be provided.');
    if (a && a.length < 8)
      throw new Error(`@supabase/auth-js: Invalid SIWE message field "nonce". Nonce must be at least 8 characters. Provided value: ${a}`);
    if (!d)
      throw new Error('@supabase/auth-js: Invalid SIWE message field "uri". URI must be provided.');
    if (h !== "1")
      throw new Error(`@supabase/auth-js: Invalid SIWE message field "version". Version must be '1'. Provided value: ${h}`);
    if (!((e = s.statement) === null || e === void 0) && e.includes(`
`))
      throw new Error(`@supabase/auth-js: Invalid SIWE message field "statement". Statement must not include '\\n'. Provided value: ${s.statement}`);
  }
  const f = qs(s.address), p = u ? `${u}://${r}` : r, g = s.statement ? `${s.statement}
` : "", m = `${p} wants you to sign in with your Ethereum account:
${f}

${g}`;
  let y = `URI: ${d}
Version: ${h}
Chain ID: ${t}${a ? `
Nonce: ${a}` : ""}
Issued At: ${i.toISOString()}`;
  if (n && (y += `
Expiration Time: ${n.toISOString()}`), o && (y += `
Not Before: ${o.toISOString()}`), c && (y += `
Request ID: ${c}`), l) {
    let v = `
Resources:`;
    for (const _ of l) {
      if (!_ || typeof _ != "string")
        throw new Error(`@supabase/auth-js: Invalid SIWE message field "resources". Every resource must be a valid string. Provided value: ${_}`);
      v += `
- ${_}`;
    }
    y += v;
  }
  return `${m}
${y}`;
}
class P extends Error {
  constructor({ message: e, code: t, cause: r, name: n }) {
    var i;
    super(e, { cause: r }), this.__isWebAuthnError = !0, this.name = (i = n ?? (r instanceof Error ? r.name : void 0)) !== null && i !== void 0 ? i : "Unknown Error", this.code = t;
  }
}
class Ge extends P {
  constructor(e, t) {
    super({
      code: "ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY",
      cause: t,
      message: e
    }), this.name = "WebAuthnUnknownError", this.originalError = t;
  }
}
function ni({ error: s, options: e }) {
  var t, r, n;
  const { publicKey: i } = e;
  if (!i)
    throw Error("options was missing required publicKey property");
  if (s.name === "AbortError") {
    if (e.signal instanceof AbortSignal)
      return new P({
        message: "Registration ceremony was sent an abort signal",
        code: "ERROR_CEREMONY_ABORTED",
        cause: s
      });
  } else if (s.name === "ConstraintError") {
    if (((t = i.authenticatorSelection) === null || t === void 0 ? void 0 : t.requireResidentKey) === !0)
      return new P({
        message: "Discoverable credentials were required but no available authenticator supported it",
        code: "ERROR_AUTHENTICATOR_MISSING_DISCOVERABLE_CREDENTIAL_SUPPORT",
        cause: s
      });
    if (
      // @ts-ignore: `mediation` doesn't yet exist on CredentialCreationOptions but it's possible as of Sept 2024
      e.mediation === "conditional" && ((r = i.authenticatorSelection) === null || r === void 0 ? void 0 : r.userVerification) === "required"
    )
      return new P({
        message: "User verification was required during automatic registration but it could not be performed",
        code: "ERROR_AUTO_REGISTER_USER_VERIFICATION_FAILURE",
        cause: s
      });
    if (((n = i.authenticatorSelection) === null || n === void 0 ? void 0 : n.userVerification) === "required")
      return new P({
        message: "User verification was required but no available authenticator supported it",
        code: "ERROR_AUTHENTICATOR_MISSING_USER_VERIFICATION_SUPPORT",
        cause: s
      });
  } else {
    if (s.name === "InvalidStateError")
      return new P({
        message: "The authenticator was previously registered",
        code: "ERROR_AUTHENTICATOR_PREVIOUSLY_REGISTERED",
        cause: s
      });
    if (s.name === "NotAllowedError")
      return new P({
        message: s.message,
        code: "ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY",
        cause: s
      });
    if (s.name === "NotSupportedError")
      return i.pubKeyCredParams.filter((o) => o.type === "public-key").length === 0 ? new P({
        message: 'No entry in pubKeyCredParams was of type "public-key"',
        code: "ERROR_MALFORMED_PUBKEYCREDPARAMS",
        cause: s
      }) : new P({
        message: "No available authenticator supported any of the specified pubKeyCredParams algorithms",
        code: "ERROR_AUTHENTICATOR_NO_SUPPORTED_PUBKEYCREDPARAMS_ALG",
        cause: s
      });
    if (s.name === "SecurityError") {
      const a = window.location.hostname;
      if (Fs(a)) {
        if (i.rp.id !== a)
          return new P({
            message: `The RP ID "${i.rp.id}" is invalid for this domain`,
            code: "ERROR_INVALID_RP_ID",
            cause: s
          });
      } else return new P({
        message: `${window.location.hostname} is an invalid domain`,
        code: "ERROR_INVALID_DOMAIN",
        cause: s
      });
    } else if (s.name === "TypeError") {
      if (i.user.id.byteLength < 1 || i.user.id.byteLength > 64)
        return new P({
          message: "User ID was not between 1 and 64 characters",
          code: "ERROR_INVALID_USER_ID_LENGTH",
          cause: s
        });
    } else if (s.name === "UnknownError")
      return new P({
        message: "The authenticator was unable to process the specified options, or could not create a new credential",
        code: "ERROR_AUTHENTICATOR_GENERAL_ERROR",
        cause: s
      });
  }
  return new P({
    message: "a Non-Webauthn related error has occurred",
    code: "ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY",
    cause: s
  });
}
function ii({ error: s, options: e }) {
  const { publicKey: t } = e;
  if (!t)
    throw Error("options was missing required publicKey property");
  if (s.name === "AbortError") {
    if (e.signal instanceof AbortSignal)
      return new P({
        message: "Authentication ceremony was sent an abort signal",
        code: "ERROR_CEREMONY_ABORTED",
        cause: s
      });
  } else {
    if (s.name === "NotAllowedError")
      return new P({
        message: s.message,
        code: "ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY",
        cause: s
      });
    if (s.name === "SecurityError") {
      const r = window.location.hostname;
      if (Fs(r)) {
        if (t.rpId !== r)
          return new P({
            message: `The RP ID "${t.rpId}" is invalid for this domain`,
            code: "ERROR_INVALID_RP_ID",
            cause: s
          });
      } else return new P({
        message: `${window.location.hostname} is an invalid domain`,
        code: "ERROR_INVALID_DOMAIN",
        cause: s
      });
    } else if (s.name === "UnknownError")
      return new P({
        message: "The authenticator was unable to process the specified options, or could not create a new assertion signature",
        code: "ERROR_AUTHENTICATOR_GENERAL_ERROR",
        cause: s
      });
  }
  return new P({
    message: "a Non-Webauthn related error has occurred",
    code: "ERROR_PASSTHROUGH_SEE_CAUSE_PROPERTY",
    cause: s
  });
}
class ai {
  /**
   * Create an abort signal for a new WebAuthn operation.
   * Automatically cancels any existing operation.
   *
   * @returns {AbortSignal} Signal to pass to navigator.credentials.create() or .get()
   * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/AbortSignal MDN - AbortSignal}
   */
  createNewAbortSignal() {
    if (this.controller) {
      const t = new Error("Cancelling existing WebAuthn API call for new one");
      t.name = "AbortError", this.controller.abort(t);
    }
    const e = new AbortController();
    return this.controller = e, e.signal;
  }
  /**
   * Manually cancel the current WebAuthn operation.
   * Useful for cleaning up when user cancels or navigates away.
   *
   * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/AbortController/abort MDN - AbortController.abort}
   */
  cancelCeremony() {
    if (this.controller) {
      const e = new Error("Manually cancelling existing WebAuthn API call");
      e.name = "AbortError", this.controller.abort(e), this.controller = void 0;
    }
  }
}
const oi = new ai();
function ci(s) {
  if (!s)
    throw new Error("Credential creation options are required");
  if (typeof PublicKeyCredential < "u" && "parseCreationOptionsFromJSON" in PublicKeyCredential && typeof PublicKeyCredential.parseCreationOptionsFromJSON == "function")
    return PublicKeyCredential.parseCreationOptionsFromJSON(
      /** we assert the options here as typescript still doesn't know about future webauthn types */
      s
    );
  const { challenge: e, user: t, excludeCredentials: r } = s, n = Je(
    s,
    ["challenge", "user", "excludeCredentials"]
  ), i = be(e).buffer, a = Object.assign(Object.assign({}, t), { id: be(t.id).buffer }), o = Object.assign(Object.assign({}, n), {
    challenge: i,
    user: a
  });
  if (r && r.length > 0) {
    o.excludeCredentials = new Array(r.length);
    for (let c = 0; c < r.length; c++) {
      const l = r[c];
      o.excludeCredentials[c] = Object.assign(Object.assign({}, l), {
        id: be(l.id).buffer,
        type: l.type || "public-key",
        // Cast transports to handle future transport types like "cable"
        transports: l.transports
      });
    }
  }
  return o;
}
function li(s) {
  if (!s)
    throw new Error("Credential request options are required");
  if (typeof PublicKeyCredential < "u" && "parseRequestOptionsFromJSON" in PublicKeyCredential && typeof PublicKeyCredential.parseRequestOptionsFromJSON == "function")
    return PublicKeyCredential.parseRequestOptionsFromJSON(s);
  const { challenge: e, allowCredentials: t } = s, r = Je(
    s,
    ["challenge", "allowCredentials"]
  ), n = be(e).buffer, i = Object.assign(Object.assign({}, r), { challenge: n });
  if (t && t.length > 0) {
    i.allowCredentials = new Array(t.length);
    for (let a = 0; a < t.length; a++) {
      const o = t[a];
      i.allowCredentials[a] = Object.assign(Object.assign({}, o), {
        id: be(o.id).buffer,
        type: o.type || "public-key",
        // Cast transports to handle future transport types like "cable"
        transports: o.transports
      });
    }
  }
  return i;
}
function ui(s) {
  var e;
  if ("toJSON" in s && typeof s.toJSON == "function")
    return s.toJSON();
  const t = s;
  return {
    id: s.id,
    rawId: s.id,
    response: {
      attestationObject: oe(new Uint8Array(s.response.attestationObject)),
      clientDataJSON: oe(new Uint8Array(s.response.clientDataJSON))
    },
    type: "public-key",
    clientExtensionResults: s.getClientExtensionResults(),
    // Convert null to undefined and cast to AuthenticatorAttachment type
    authenticatorAttachment: (e = t.authenticatorAttachment) !== null && e !== void 0 ? e : void 0
  };
}
function hi(s) {
  var e;
  if ("toJSON" in s && typeof s.toJSON == "function")
    return s.toJSON();
  const t = s, r = s.getClientExtensionResults(), n = s.response;
  return {
    id: s.id,
    rawId: s.id,
    // W3C spec expects rawId to match id for JSON format
    response: {
      authenticatorData: oe(new Uint8Array(n.authenticatorData)),
      clientDataJSON: oe(new Uint8Array(n.clientDataJSON)),
      signature: oe(new Uint8Array(n.signature)),
      userHandle: n.userHandle ? oe(new Uint8Array(n.userHandle)) : void 0
    },
    type: "public-key",
    clientExtensionResults: r,
    // Convert null to undefined and cast to AuthenticatorAttachment type
    authenticatorAttachment: (e = t.authenticatorAttachment) !== null && e !== void 0 ? e : void 0
  };
}
function Fs(s) {
  return (
    // Consider localhost valid as well since it's okay wrt Secure Contexts
    s === "localhost" || /^([a-z0-9]+(-[a-z0-9]+)*\.)+[a-z]{2,}$/i.test(s)
  );
}
function Qt() {
  var s, e;
  return !!(U() && "PublicKeyCredential" in window && window.PublicKeyCredential && "credentials" in navigator && typeof ((s = navigator == null ? void 0 : navigator.credentials) === null || s === void 0 ? void 0 : s.create) == "function" && typeof ((e = navigator == null ? void 0 : navigator.credentials) === null || e === void 0 ? void 0 : e.get) == "function");
}
async function di(s) {
  try {
    const e = await navigator.credentials.create(
      /** we assert the type here until typescript types are updated */
      s
    );
    return e ? e instanceof PublicKeyCredential ? { data: e, error: null } : {
      data: null,
      error: new Ge("Browser returned unexpected credential type", e)
    } : {
      data: null,
      error: new Ge("Empty credential response", e)
    };
  } catch (e) {
    return {
      data: null,
      error: ni({
        error: e,
        options: s
      })
    };
  }
}
async function fi(s) {
  try {
    const e = await navigator.credentials.get(
      /** we assert the type here until typescript types are updated */
      s
    );
    return e ? e instanceof PublicKeyCredential ? { data: e, error: null } : {
      data: null,
      error: new Ge("Browser returned unexpected credential type", e)
    } : {
      data: null,
      error: new Ge("Empty credential response", e)
    };
  } catch (e) {
    return {
      data: null,
      error: ii({
        error: e,
        options: s
      })
    };
  }
}
const pi = {
  hints: ["security-key"],
  authenticatorSelection: {
    authenticatorAttachment: "cross-platform",
    requireResidentKey: !1,
    /** set to preferred because older yubikeys don't have PIN/Biometric */
    userVerification: "preferred",
    residentKey: "discouraged"
  },
  attestation: "direct"
}, gi = {
  /** set to preferred because older yubikeys don't have PIN/Biometric */
  userVerification: "preferred",
  hints: ["security-key"],
  attestation: "direct"
};
function ze(...s) {
  const e = (n) => n !== null && typeof n == "object" && !Array.isArray(n), t = (n) => n instanceof ArrayBuffer || ArrayBuffer.isView(n), r = {};
  for (const n of s)
    if (n)
      for (const i in n) {
        const a = n[i];
        if (a !== void 0)
          if (Array.isArray(a))
            r[i] = a;
          else if (t(a))
            r[i] = a;
          else if (e(a)) {
            const o = r[i];
            e(o) ? r[i] = ze(o, a) : r[i] = ze(a);
          } else
            r[i] = a;
      }
  return r;
}
function mi(s, e) {
  return ze(pi, s, e || {});
}
function yi(s, e) {
  return ze(gi, s, e || {});
}
class _i {
  constructor(e) {
    this.client = e, this.enroll = this._enroll.bind(this), this.challenge = this._challenge.bind(this), this.verify = this._verify.bind(this), this.authenticate = this._authenticate.bind(this), this.register = this._register.bind(this);
  }
  /**
   * Enroll a new WebAuthn factor.
   * Creates an unverified WebAuthn factor that must be verified with a credential.
   *
   * @experimental This method is experimental and may change in future releases
   * @param {Omit<MFAEnrollWebauthnParams, 'factorType'>} params - Enrollment parameters (friendlyName required)
   * @returns {Promise<AuthMFAEnrollWebauthnResponse>} Enrolled factor details or error
   * @see {@link https://w3c.github.io/webauthn/#sctn-registering-a-new-credential W3C WebAuthn Spec - Registering a New Credential}
   */
  async _enroll(e) {
    return this.client.mfa.enroll(Object.assign(Object.assign({}, e), { factorType: "webauthn" }));
  }
  /**
   * Challenge for WebAuthn credential creation or authentication.
   * Combines server challenge with browser credential operations.
   * Handles both registration (create) and authentication (request) flows.
   *
   * @experimental This method is experimental and may change in future releases
   * @param {MFAChallengeWebauthnParams & { friendlyName?: string; signal?: AbortSignal }} params - Challenge parameters including factorId
   * @param {Object} overrides - Allows you to override the parameters passed to navigator.credentials
   * @param {PublicKeyCredentialCreationOptionsFuture} overrides.create - Override options for credential creation
   * @param {PublicKeyCredentialRequestOptionsFuture} overrides.request - Override options for credential request
   * @returns {Promise<RequestResult>} Challenge response with credential or error
   * @see {@link https://w3c.github.io/webauthn/#sctn-credential-creation W3C WebAuthn Spec - Credential Creation}
   * @see {@link https://w3c.github.io/webauthn/#sctn-verifying-assertion W3C WebAuthn Spec - Verifying Assertion}
   */
  async _challenge({ factorId: e, webauthn: t, friendlyName: r, signal: n }, i) {
    var a;
    try {
      const { data: o, error: c } = await this.client.mfa.challenge({
        factorId: e,
        webauthn: t
      });
      if (!o)
        return { data: null, error: c };
      const l = n ?? oi.createNewAbortSignal();
      if (o.webauthn.type === "create") {
        const { user: u } = o.webauthn.credential_options.publicKey;
        if (!u.name) {
          const d = r;
          if (d)
            u.name = `${u.id}:${d}`;
          else {
            const f = (await this.client.getUser()).data.user, p = ((a = f == null ? void 0 : f.user_metadata) === null || a === void 0 ? void 0 : a.name) || (f == null ? void 0 : f.email) || (f == null ? void 0 : f.id) || "User";
            u.name = `${u.id}:${p}`;
          }
        }
        u.displayName || (u.displayName = u.name);
      }
      switch (o.webauthn.type) {
        case "create": {
          const u = mi(o.webauthn.credential_options.publicKey, i == null ? void 0 : i.create), { data: d, error: h } = await di({
            publicKey: u,
            signal: l
          });
          return d ? {
            data: {
              factorId: e,
              challengeId: o.id,
              webauthn: {
                type: o.webauthn.type,
                credential_response: d
              }
            },
            error: null
          } : { data: null, error: h };
        }
        case "request": {
          const u = yi(o.webauthn.credential_options.publicKey, i == null ? void 0 : i.request), { data: d, error: h } = await fi(Object.assign(Object.assign({}, o.webauthn.credential_options), { publicKey: u, signal: l }));
          return d ? {
            data: {
              factorId: e,
              challengeId: o.id,
              webauthn: {
                type: o.webauthn.type,
                credential_response: d
              }
            },
            error: null
          } : { data: null, error: h };
        }
      }
    } catch (o) {
      return b(o) ? { data: null, error: o } : {
        data: null,
        error: new ae("Unexpected error in challenge", o)
      };
    }
  }
  /**
   * Verify a WebAuthn credential with the server.
   * Completes the WebAuthn ceremony by sending the credential to the server for verification.
   *
   * @experimental This method is experimental and may change in future releases
   * @param {Object} params - Verification parameters
   * @param {string} params.challengeId - ID of the challenge being verified
   * @param {string} params.factorId - ID of the WebAuthn factor
   * @param {MFAVerifyWebauthnParams<T>['webauthn']} params.webauthn - WebAuthn credential response
   * @returns {Promise<AuthMFAVerifyResponse>} Verification result with session or error
   * @see {@link https://w3c.github.io/webauthn/#sctn-verifying-assertion W3C WebAuthn Spec - Verifying an Authentication Assertion}
   * */
  async _verify({ challengeId: e, factorId: t, webauthn: r }) {
    return this.client.mfa.verify({
      factorId: t,
      challengeId: e,
      webauthn: r
    });
  }
  /**
   * Complete WebAuthn authentication flow.
   * Performs challenge and verification in a single operation for existing credentials.
   *
   * @experimental This method is experimental and may change in future releases
   * @param {Object} params - Authentication parameters
   * @param {string} params.factorId - ID of the WebAuthn factor to authenticate with
   * @param {Object} params.webauthn - WebAuthn configuration
   * @param {string} params.webauthn.rpId - Relying Party ID (defaults to current hostname)
   * @param {string[]} params.webauthn.rpOrigins - Allowed origins (defaults to current origin)
   * @param {AbortSignal} params.webauthn.signal - Optional abort signal
   * @param {PublicKeyCredentialRequestOptionsFuture} overrides - Override options for navigator.credentials.get
   * @returns {Promise<RequestResult<AuthMFAVerifyResponseData, WebAuthnError | AuthError>>} Authentication result
   * @see {@link https://w3c.github.io/webauthn/#sctn-authentication W3C WebAuthn Spec - Authentication Ceremony}
   * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/PublicKeyCredentialRequestOptions MDN - PublicKeyCredentialRequestOptions}
   */
  async _authenticate({ factorId: e, webauthn: { rpId: t = typeof window < "u" ? window.location.hostname : void 0, rpOrigins: r = typeof window < "u" ? [window.location.origin] : void 0, signal: n } = {} }, i) {
    if (!t)
      return {
        data: null,
        error: new xe("rpId is required for WebAuthn authentication")
      };
    try {
      if (!Qt())
        return {
          data: null,
          error: new ae("Browser does not support WebAuthn", null)
        };
      const { data: a, error: o } = await this.challenge({
        factorId: e,
        webauthn: { rpId: t, rpOrigins: r },
        signal: n
      }, { request: i });
      if (!a)
        return { data: null, error: o };
      const { webauthn: c } = a;
      return this._verify({
        factorId: e,
        challengeId: a.challengeId,
        webauthn: {
          type: c.type,
          rpId: t,
          rpOrigins: r,
          credential_response: c.credential_response
        }
      });
    } catch (a) {
      return b(a) ? { data: null, error: a } : {
        data: null,
        error: new ae("Unexpected error in authenticate", a)
      };
    }
  }
  /**
   * Complete WebAuthn registration flow.
   * Performs enrollment, challenge, and verification in a single operation for new credentials.
   *
   * @experimental This method is experimental and may change in future releases
   * @param {Object} params - Registration parameters
   * @param {string} params.friendlyName - User-friendly name for the credential
   * @param {string} params.rpId - Relying Party ID (defaults to current hostname)
   * @param {string[]} params.rpOrigins - Allowed origins (defaults to current origin)
   * @param {AbortSignal} params.signal - Optional abort signal
   * @param {PublicKeyCredentialCreationOptionsFuture} overrides - Override options for navigator.credentials.create
   * @returns {Promise<RequestResult<AuthMFAVerifyResponseData, WebAuthnError | AuthError>>} Registration result
   * @see {@link https://w3c.github.io/webauthn/#sctn-registering-a-new-credential W3C WebAuthn Spec - Registration Ceremony}
   * @see {@link https://developer.mozilla.org/en-US/docs/Web/API/PublicKeyCredentialCreationOptions MDN - PublicKeyCredentialCreationOptions}
   */
  async _register({ friendlyName: e, webauthn: { rpId: t = typeof window < "u" ? window.location.hostname : void 0, rpOrigins: r = typeof window < "u" ? [window.location.origin] : void 0, signal: n } = {} }, i) {
    if (!t)
      return {
        data: null,
        error: new xe("rpId is required for WebAuthn registration")
      };
    try {
      if (!Qt())
        return {
          data: null,
          error: new ae("Browser does not support WebAuthn", null)
        };
      const { data: a, error: o } = await this._enroll({
        friendlyName: e
      });
      if (!a)
        return await this.client.mfa.listFactors().then((u) => {
          var d;
          return (d = u.data) === null || d === void 0 ? void 0 : d.all.find((h) => h.factor_type === "webauthn" && h.friendly_name === e && h.status !== "unverified");
        }).then((u) => u ? this.client.mfa.unenroll({ factorId: u == null ? void 0 : u.id }) : void 0), { data: null, error: o };
      const { data: c, error: l } = await this._challenge({
        factorId: a.id,
        friendlyName: a.friendly_name,
        webauthn: { rpId: t, rpOrigins: r },
        signal: n
      }, {
        create: i
      });
      return c ? this._verify({
        factorId: a.id,
        challengeId: c.challengeId,
        webauthn: {
          rpId: t,
          rpOrigins: r,
          type: c.webauthn.type,
          credential_response: c.webauthn.credential_response
        }
      }) : { data: null, error: l };
    } catch (a) {
      return b(a) ? { data: null, error: a } : {
        data: null,
        error: new ae("Unexpected error in register", a)
      };
    }
  }
}
ei();
const vi = {
  url: gn,
  storageKey: mn,
  autoRefreshToken: !0,
  persistSession: !0,
  detectSessionInUrl: !0,
  headers: yn,
  flowType: "implicit",
  debug: !1,
  hasCustomAuthorizationHeader: !1,
  throwOnError: !1,
  lockAcquireTimeout: 1e4
  // 10 seconds
};
async function Xt(s, e, t) {
  return await t();
}
const ge = {};
class Pe {
  /**
   * The JWKS used for verifying asymmetric JWTs
   */
  get jwks() {
    var e, t;
    return (t = (e = ge[this.storageKey]) === null || e === void 0 ? void 0 : e.jwks) !== null && t !== void 0 ? t : { keys: [] };
  }
  set jwks(e) {
    ge[this.storageKey] = Object.assign(Object.assign({}, ge[this.storageKey]), { jwks: e });
  }
  get jwks_cached_at() {
    var e, t;
    return (t = (e = ge[this.storageKey]) === null || e === void 0 ? void 0 : e.cachedAt) !== null && t !== void 0 ? t : Number.MIN_SAFE_INTEGER;
  }
  set jwks_cached_at(e) {
    ge[this.storageKey] = Object.assign(Object.assign({}, ge[this.storageKey]), { cachedAt: e });
  }
  /**
   * Create a new client for use in the browser.
   *
   * @example
   * ```ts
   * import { GoTrueClient } from '@supabase/auth-js'
   *
   * const auth = new GoTrueClient({
   *   url: 'https://xyzcompany.supabase.co/auth/v1',
   *   headers: { apikey: 'public-anon-key' },
   *   storageKey: 'supabase-auth',
   * })
   * ```
   */
  constructor(e) {
    var t, r, n;
    this.userStorage = null, this.memoryStorage = null, this.stateChangeEmitters = /* @__PURE__ */ new Map(), this.autoRefreshTicker = null, this.autoRefreshTickTimeout = null, this.visibilityChangedCallback = null, this.refreshingDeferred = null, this.initializePromise = null, this.detectSessionInUrl = !0, this.hasCustomAuthorizationHeader = !1, this.suppressGetSessionWarning = !1, this.lockAcquired = !1, this.pendingInLock = [], this.broadcastChannel = null, this.logger = console.log;
    const i = Object.assign(Object.assign({}, vi), e);
    if (this.storageKey = i.storageKey, this.instanceID = (t = Pe.nextInstanceID[this.storageKey]) !== null && t !== void 0 ? t : 0, Pe.nextInstanceID[this.storageKey] = this.instanceID + 1, this.logDebugMessages = !!i.debug, typeof i.debug == "function" && (this.logger = i.debug), this.instanceID > 0 && U()) {
      const a = `${this._logPrefix()} Multiple GoTrueClient instances detected in the same browser context. It is not an error, but this should be avoided as it may produce undefined behavior when used concurrently under the same storage key.`;
      console.warn(a), this.logDebugMessages && console.trace(a);
    }
    if (this.persistSession = i.persistSession, this.autoRefreshToken = i.autoRefreshToken, this.admin = new Qn({
      url: i.url,
      headers: i.headers,
      fetch: i.fetch
    }), this.url = i.url, this.headers = i.headers, this.fetch = Ms(i.fetch), this.lock = i.lock || Xt, this.detectSessionInUrl = i.detectSessionInUrl, this.flowType = i.flowType, this.hasCustomAuthorizationHeader = i.hasCustomAuthorizationHeader, this.throwOnError = i.throwOnError, this.lockAcquireTimeout = i.lockAcquireTimeout, i.lock ? this.lock = i.lock : this.persistSession && U() && (!((r = globalThis == null ? void 0 : globalThis.navigator) === null || r === void 0) && r.locks) ? this.lock = Zn : this.lock = Xt, this.jwks || (this.jwks = { keys: [] }, this.jwks_cached_at = Number.MIN_SAFE_INTEGER), this.mfa = {
      verify: this._verify.bind(this),
      enroll: this._enroll.bind(this),
      unenroll: this._unenroll.bind(this),
      challenge: this._challenge.bind(this),
      listFactors: this._listFactors.bind(this),
      challengeAndVerify: this._challengeAndVerify.bind(this),
      getAuthenticatorAssuranceLevel: this._getAuthenticatorAssuranceLevel.bind(this),
      webauthn: new _i(this)
    }, this.oauth = {
      getAuthorizationDetails: this._getAuthorizationDetails.bind(this),
      approveAuthorization: this._approveAuthorization.bind(this),
      denyAuthorization: this._denyAuthorization.bind(this),
      listGrants: this._listOAuthGrants.bind(this),
      revokeGrant: this._revokeOAuthGrant.bind(this)
    }, this.persistSession ? (i.storage ? this.storage = i.storage : Ds() ? this.storage = globalThis.localStorage : (this.memoryStorage = {}, this.storage = Yt(this.memoryStorage)), i.userStorage && (this.userStorage = i.userStorage)) : (this.memoryStorage = {}, this.storage = Yt(this.memoryStorage)), U() && globalThis.BroadcastChannel && this.persistSession && this.storageKey) {
      try {
        this.broadcastChannel = new globalThis.BroadcastChannel(this.storageKey);
      } catch (a) {
        console.error("Failed to create a new BroadcastChannel, multi-tab state changes will not be available", a);
      }
      (n = this.broadcastChannel) === null || n === void 0 || n.addEventListener("message", async (a) => {
        this._debug("received broadcast notification from other tab or client", a);
        try {
          await this._notifyAllSubscribers(a.data.event, a.data.session, !1);
        } catch (o) {
          this._debug("#broadcastChannel", "error", o);
        }
      });
    }
    this.initialize().catch((a) => {
      this._debug("#initialize()", "error", a);
    });
  }
  /**
   * Returns whether error throwing mode is enabled for this client.
   */
  isThrowOnErrorEnabled() {
    return this.throwOnError;
  }
  /**
   * Centralizes return handling with optional error throwing. When `throwOnError` is enabled
   * and the provided result contains a non-nullish error, the error is thrown instead of
   * being returned. This ensures consistent behavior across all public API methods.
   */
  _returnResult(e) {
    if (this.throwOnError && e && e.error)
      throw e.error;
    return e;
  }
  _logPrefix() {
    return `GoTrueClient@${this.storageKey}:${this.instanceID} (${js}) ${(/* @__PURE__ */ new Date()).toISOString()}`;
  }
  _debug(...e) {
    return this.logDebugMessages && this.logger(this._logPrefix(), ...e), this;
  }
  /**
   * Initializes the client session either from the url or from storage.
   * This method is automatically called when instantiating the client, but should also be called
   * manually when checking for an error from an auth redirect (oauth, magiclink, password recovery, etc).
   */
  async initialize() {
    return this.initializePromise ? await this.initializePromise : (this.initializePromise = (async () => await this._acquireLock(this.lockAcquireTimeout, async () => await this._initialize()))(), await this.initializePromise);
  }
  /**
   * IMPORTANT:
   * 1. Never throw in this method, as it is called from the constructor
   * 2. Never return a session from this method as it would be cached over
   *    the whole lifetime of the client
   */
  async _initialize() {
    var e;
    try {
      let t = {}, r = "none";
      if (U() && (t = $n(window.location.href), this._isImplicitGrantCallback(t) ? r = "implicit" : await this._isPKCECallback(t) && (r = "pkce")), U() && this.detectSessionInUrl && r !== "none") {
        const { data: n, error: i } = await this._getSessionFromURL(t, r);
        if (i) {
          if (this._debug("#_initialize()", "error detecting session from URL", i), Sn(i)) {
            const c = (e = i.details) === null || e === void 0 ? void 0 : e.code;
            if (c === "identity_already_exists" || c === "identity_not_found" || c === "single_identity_not_deletable")
              return { error: i };
          }
          return { error: i };
        }
        const { session: a, redirectType: o } = n;
        return this._debug("#_initialize()", "detected session in URL", a, "redirect type", o), await this._saveSession(a), setTimeout(async () => {
          o === "recovery" ? await this._notifyAllSubscribers("PASSWORD_RECOVERY", a) : await this._notifyAllSubscribers("SIGNED_IN", a);
        }, 0), { error: null };
      }
      return await this._recoverAndRefresh(), { error: null };
    } catch (t) {
      return b(t) ? this._returnResult({ error: t }) : this._returnResult({
        error: new ae("Unexpected error during initialization", t)
      });
    } finally {
      await this._handleVisibilityChange(), this._debug("#_initialize()", "end");
    }
  }
  /**
   * Creates a new anonymous user.
   *
   * @returns A session where the is_anonymous claim in the access token JWT set to true
   */
  async signInAnonymously(e) {
    var t, r, n;
    try {
      const i = await E(this.fetch, "POST", `${this.url}/signup`, {
        headers: this.headers,
        body: {
          data: (r = (t = e == null ? void 0 : e.options) === null || t === void 0 ? void 0 : t.data) !== null && r !== void 0 ? r : {},
          gotrue_meta_security: { captcha_token: (n = e == null ? void 0 : e.options) === null || n === void 0 ? void 0 : n.captchaToken }
        },
        xform: q
      }), { data: a, error: o } = i;
      if (o || !a)
        return this._returnResult({ data: { user: null, session: null }, error: o });
      const c = a.session, l = a.user;
      return a.session && (await this._saveSession(a.session), await this._notifyAllSubscribers("SIGNED_IN", c)), this._returnResult({ data: { user: l, session: c }, error: null });
    } catch (i) {
      if (b(i))
        return this._returnResult({ data: { user: null, session: null }, error: i });
      throw i;
    }
  }
  /**
   * Creates a new user.
   *
   * Be aware that if a user account exists in the system you may get back an
   * error message that attempts to hide this information from the user.
   * This method has support for PKCE via email signups. The PKCE flow cannot be used when autoconfirm is enabled.
   *
   * @returns A logged-in session if the server has "autoconfirm" ON
   * @returns A user if the server has "autoconfirm" OFF
   */
  async signUp(e) {
    var t, r, n;
    try {
      let i;
      if ("email" in e) {
        const { email: u, password: d, options: h } = e;
        let f = null, p = null;
        this.flowType === "pkce" && ([f, p] = await de(this.storage, this.storageKey)), i = await E(this.fetch, "POST", `${this.url}/signup`, {
          headers: this.headers,
          redirectTo: h == null ? void 0 : h.emailRedirectTo,
          body: {
            email: u,
            password: d,
            data: (t = h == null ? void 0 : h.data) !== null && t !== void 0 ? t : {},
            gotrue_meta_security: { captcha_token: h == null ? void 0 : h.captchaToken },
            code_challenge: f,
            code_challenge_method: p
          },
          xform: q
        });
      } else if ("phone" in e) {
        const { phone: u, password: d, options: h } = e;
        i = await E(this.fetch, "POST", `${this.url}/signup`, {
          headers: this.headers,
          body: {
            phone: u,
            password: d,
            data: (r = h == null ? void 0 : h.data) !== null && r !== void 0 ? r : {},
            channel: (n = h == null ? void 0 : h.channel) !== null && n !== void 0 ? n : "sms",
            gotrue_meta_security: { captcha_token: h == null ? void 0 : h.captchaToken }
          },
          xform: q
        });
      } else
        throw new Me("You must provide either an email or phone number and a password");
      const { data: a, error: o } = i;
      if (o || !a)
        return await j(this.storage, `${this.storageKey}-code-verifier`), this._returnResult({ data: { user: null, session: null }, error: o });
      const c = a.session, l = a.user;
      return a.session && (await this._saveSession(a.session), await this._notifyAllSubscribers("SIGNED_IN", c)), this._returnResult({ data: { user: l, session: c }, error: null });
    } catch (i) {
      if (await j(this.storage, `${this.storageKey}-code-verifier`), b(i))
        return this._returnResult({ data: { user: null, session: null }, error: i });
      throw i;
    }
  }
  /**
   * Log in an existing user with an email and password or phone and password.
   *
   * Be aware that you may get back an error message that will not distinguish
   * between the cases where the account does not exist or that the
   * email/phone and password combination is wrong or that the account can only
   * be accessed via social login.
   */
  async signInWithPassword(e) {
    try {
      let t;
      if ("email" in e) {
        const { email: i, password: a, options: o } = e;
        t = await E(this.fetch, "POST", `${this.url}/token?grant_type=password`, {
          headers: this.headers,
          body: {
            email: i,
            password: a,
            gotrue_meta_security: { captcha_token: o == null ? void 0 : o.captchaToken }
          },
          xform: Wt
        });
      } else if ("phone" in e) {
        const { phone: i, password: a, options: o } = e;
        t = await E(this.fetch, "POST", `${this.url}/token?grant_type=password`, {
          headers: this.headers,
          body: {
            phone: i,
            password: a,
            gotrue_meta_security: { captcha_token: o == null ? void 0 : o.captchaToken }
          },
          xform: Wt
        });
      } else
        throw new Me("You must provide either an email or phone number and a password");
      const { data: r, error: n } = t;
      if (n)
        return this._returnResult({ data: { user: null, session: null }, error: n });
      if (!r || !r.session || !r.user) {
        const i = new he();
        return this._returnResult({ data: { user: null, session: null }, error: i });
      }
      return r.session && (await this._saveSession(r.session), await this._notifyAllSubscribers("SIGNED_IN", r.session)), this._returnResult({
        data: Object.assign({ user: r.user, session: r.session }, r.weak_password ? { weakPassword: r.weak_password } : null),
        error: n
      });
    } catch (t) {
      if (b(t))
        return this._returnResult({ data: { user: null, session: null }, error: t });
      throw t;
    }
  }
  /**
   * Log in an existing user via a third-party provider.
   * This method supports the PKCE flow.
   */
  async signInWithOAuth(e) {
    var t, r, n, i;
    return await this._handleProviderSignIn(e.provider, {
      redirectTo: (t = e.options) === null || t === void 0 ? void 0 : t.redirectTo,
      scopes: (r = e.options) === null || r === void 0 ? void 0 : r.scopes,
      queryParams: (n = e.options) === null || n === void 0 ? void 0 : n.queryParams,
      skipBrowserRedirect: (i = e.options) === null || i === void 0 ? void 0 : i.skipBrowserRedirect
    });
  }
  /**
   * Log in an existing user by exchanging an Auth Code issued during the PKCE flow.
   */
  async exchangeCodeForSession(e) {
    return await this.initializePromise, this._acquireLock(this.lockAcquireTimeout, async () => this._exchangeCodeForSession(e));
  }
  /**
   * Signs in a user by verifying a message signed by the user's private key.
   * Supports Ethereum (via Sign-In-With-Ethereum) & Solana (Sign-In-With-Solana) standards,
   * both of which derive from the EIP-4361 standard
   * With slight variation on Solana's side.
   * @reference https://eips.ethereum.org/EIPS/eip-4361
   */
  async signInWithWeb3(e) {
    const { chain: t } = e;
    switch (t) {
      case "ethereum":
        return await this.signInWithEthereum(e);
      case "solana":
        return await this.signInWithSolana(e);
      default:
        throw new Error(`@supabase/auth-js: Unsupported chain "${t}"`);
    }
  }
  async signInWithEthereum(e) {
    var t, r, n, i, a, o, c, l, u, d, h;
    let f, p;
    if ("message" in e)
      f = e.message, p = e.signature;
    else {
      const { chain: g, wallet: m, statement: y, options: v } = e;
      let _;
      if (U())
        if (typeof m == "object")
          _ = m;
        else {
          const z = window;
          if ("ethereum" in z && typeof z.ethereum == "object" && "request" in z.ethereum && typeof z.ethereum.request == "function")
            _ = z.ethereum;
          else
            throw new Error("@supabase/auth-js: No compatible Ethereum wallet interface on the window object (window.ethereum) detected. Make sure the user already has a wallet installed and connected for this app. Prefer passing the wallet interface object directly to signInWithWeb3({ chain: 'ethereum', wallet: resolvedUserWallet }) instead.");
        }
      else {
        if (typeof m != "object" || !(v != null && v.url))
          throw new Error("@supabase/auth-js: Both wallet and url must be specified in non-browser environments.");
        _ = m;
      }
      const S = new URL((t = v == null ? void 0 : v.url) !== null && t !== void 0 ? t : window.location.href), O = await _.request({
        method: "eth_requestAccounts"
      }).then((z) => z).catch(() => {
        throw new Error("@supabase/auth-js: Wallet method eth_requestAccounts is missing or invalid");
      });
      if (!O || O.length === 0)
        throw new Error("@supabase/auth-js: No accounts available. Please ensure the wallet is connected.");
      const A = qs(O[0]);
      let w = (r = v == null ? void 0 : v.signInWithEthereum) === null || r === void 0 ? void 0 : r.chainId;
      if (!w) {
        const z = await _.request({
          method: "eth_chainId"
        });
        w = ti(z);
      }
      const C = {
        domain: S.host,
        address: A,
        statement: y,
        uri: S.href,
        version: "1",
        chainId: w,
        nonce: (n = v == null ? void 0 : v.signInWithEthereum) === null || n === void 0 ? void 0 : n.nonce,
        issuedAt: (a = (i = v == null ? void 0 : v.signInWithEthereum) === null || i === void 0 ? void 0 : i.issuedAt) !== null && a !== void 0 ? a : /* @__PURE__ */ new Date(),
        expirationTime: (o = v == null ? void 0 : v.signInWithEthereum) === null || o === void 0 ? void 0 : o.expirationTime,
        notBefore: (c = v == null ? void 0 : v.signInWithEthereum) === null || c === void 0 ? void 0 : c.notBefore,
        requestId: (l = v == null ? void 0 : v.signInWithEthereum) === null || l === void 0 ? void 0 : l.requestId,
        resources: (u = v == null ? void 0 : v.signInWithEthereum) === null || u === void 0 ? void 0 : u.resources
      };
      f = ri(C), p = await _.request({
        method: "personal_sign",
        params: [si(f), A]
      });
    }
    try {
      const { data: g, error: m } = await E(this.fetch, "POST", `${this.url}/token?grant_type=web3`, {
        headers: this.headers,
        body: Object.assign({
          chain: "ethereum",
          message: f,
          signature: p
        }, !((d = e.options) === null || d === void 0) && d.captchaToken ? { gotrue_meta_security: { captcha_token: (h = e.options) === null || h === void 0 ? void 0 : h.captchaToken } } : null),
        xform: q
      });
      if (m)
        throw m;
      if (!g || !g.session || !g.user) {
        const y = new he();
        return this._returnResult({ data: { user: null, session: null }, error: y });
      }
      return g.session && (await this._saveSession(g.session), await this._notifyAllSubscribers("SIGNED_IN", g.session)), this._returnResult({ data: Object.assign({}, g), error: m });
    } catch (g) {
      if (b(g))
        return this._returnResult({ data: { user: null, session: null }, error: g });
      throw g;
    }
  }
  async signInWithSolana(e) {
    var t, r, n, i, a, o, c, l, u, d, h, f;
    let p, g;
    if ("message" in e)
      p = e.message, g = e.signature;
    else {
      const { chain: m, wallet: y, statement: v, options: _ } = e;
      let S;
      if (U())
        if (typeof y == "object")
          S = y;
        else {
          const A = window;
          if ("solana" in A && typeof A.solana == "object" && ("signIn" in A.solana && typeof A.solana.signIn == "function" || "signMessage" in A.solana && typeof A.solana.signMessage == "function"))
            S = A.solana;
          else
            throw new Error("@supabase/auth-js: No compatible Solana wallet interface on the window object (window.solana) detected. Make sure the user already has a wallet installed and connected for this app. Prefer passing the wallet interface object directly to signInWithWeb3({ chain: 'solana', wallet: resolvedUserWallet }) instead.");
        }
      else {
        if (typeof y != "object" || !(_ != null && _.url))
          throw new Error("@supabase/auth-js: Both wallet and url must be specified in non-browser environments.");
        S = y;
      }
      const O = new URL((t = _ == null ? void 0 : _.url) !== null && t !== void 0 ? t : window.location.href);
      if ("signIn" in S && S.signIn) {
        const A = await S.signIn(Object.assign(Object.assign(Object.assign({ issuedAt: (/* @__PURE__ */ new Date()).toISOString() }, _ == null ? void 0 : _.signInWithSolana), {
          // non-overridable properties
          version: "1",
          domain: O.host,
          uri: O.href
        }), v ? { statement: v } : null));
        let w;
        if (Array.isArray(A) && A[0] && typeof A[0] == "object")
          w = A[0];
        else if (A && typeof A == "object" && "signedMessage" in A && "signature" in A)
          w = A;
        else
          throw new Error("@supabase/auth-js: Wallet method signIn() returned unrecognized value");
        if ("signedMessage" in w && "signature" in w && (typeof w.signedMessage == "string" || w.signedMessage instanceof Uint8Array) && w.signature instanceof Uint8Array)
          p = typeof w.signedMessage == "string" ? w.signedMessage : new TextDecoder().decode(w.signedMessage), g = w.signature;
        else
          throw new Error("@supabase/auth-js: Wallet method signIn() API returned object without signedMessage and signature fields");
      } else {
        if (!("signMessage" in S) || typeof S.signMessage != "function" || !("publicKey" in S) || typeof S != "object" || !S.publicKey || !("toBase58" in S.publicKey) || typeof S.publicKey.toBase58 != "function")
          throw new Error("@supabase/auth-js: Wallet does not have a compatible signMessage() and publicKey.toBase58() API");
        p = [
          `${O.host} wants you to sign in with your Solana account:`,
          S.publicKey.toBase58(),
          ...v ? ["", v, ""] : [""],
          "Version: 1",
          `URI: ${O.href}`,
          `Issued At: ${(n = (r = _ == null ? void 0 : _.signInWithSolana) === null || r === void 0 ? void 0 : r.issuedAt) !== null && n !== void 0 ? n : (/* @__PURE__ */ new Date()).toISOString()}`,
          ...!((i = _ == null ? void 0 : _.signInWithSolana) === null || i === void 0) && i.notBefore ? [`Not Before: ${_.signInWithSolana.notBefore}`] : [],
          ...!((a = _ == null ? void 0 : _.signInWithSolana) === null || a === void 0) && a.expirationTime ? [`Expiration Time: ${_.signInWithSolana.expirationTime}`] : [],
          ...!((o = _ == null ? void 0 : _.signInWithSolana) === null || o === void 0) && o.chainId ? [`Chain ID: ${_.signInWithSolana.chainId}`] : [],
          ...!((c = _ == null ? void 0 : _.signInWithSolana) === null || c === void 0) && c.nonce ? [`Nonce: ${_.signInWithSolana.nonce}`] : [],
          ...!((l = _ == null ? void 0 : _.signInWithSolana) === null || l === void 0) && l.requestId ? [`Request ID: ${_.signInWithSolana.requestId}`] : [],
          ...!((d = (u = _ == null ? void 0 : _.signInWithSolana) === null || u === void 0 ? void 0 : u.resources) === null || d === void 0) && d.length ? [
            "Resources",
            ..._.signInWithSolana.resources.map((w) => `- ${w}`)
          ] : []
        ].join(`
`);
        const A = await S.signMessage(new TextEncoder().encode(p), "utf8");
        if (!A || !(A instanceof Uint8Array))
          throw new Error("@supabase/auth-js: Wallet signMessage() API returned an recognized value");
        g = A;
      }
    }
    try {
      const { data: m, error: y } = await E(this.fetch, "POST", `${this.url}/token?grant_type=web3`, {
        headers: this.headers,
        body: Object.assign({ chain: "solana", message: p, signature: oe(g) }, !((h = e.options) === null || h === void 0) && h.captchaToken ? { gotrue_meta_security: { captcha_token: (f = e.options) === null || f === void 0 ? void 0 : f.captchaToken } } : null),
        xform: q
      });
      if (y)
        throw y;
      if (!m || !m.session || !m.user) {
        const v = new he();
        return this._returnResult({ data: { user: null, session: null }, error: v });
      }
      return m.session && (await this._saveSession(m.session), await this._notifyAllSubscribers("SIGNED_IN", m.session)), this._returnResult({ data: Object.assign({}, m), error: y });
    } catch (m) {
      if (b(m))
        return this._returnResult({ data: { user: null, session: null }, error: m });
      throw m;
    }
  }
  async _exchangeCodeForSession(e) {
    const t = await re(this.storage, `${this.storageKey}-code-verifier`), [r, n] = (t ?? "").split("/");
    try {
      if (!r && this.flowType === "pkce")
        throw new En();
      const { data: i, error: a } = await E(this.fetch, "POST", `${this.url}/token?grant_type=pkce`, {
        headers: this.headers,
        body: {
          auth_code: e,
          code_verifier: r
        },
        xform: q
      });
      if (await j(this.storage, `${this.storageKey}-code-verifier`), a)
        throw a;
      if (!i || !i.session || !i.user) {
        const o = new he();
        return this._returnResult({
          data: { user: null, session: null, redirectType: null },
          error: o
        });
      }
      return i.session && (await this._saveSession(i.session), await this._notifyAllSubscribers("SIGNED_IN", i.session)), this._returnResult({ data: Object.assign(Object.assign({}, i), { redirectType: n ?? null }), error: a });
    } catch (i) {
      if (await j(this.storage, `${this.storageKey}-code-verifier`), b(i))
        return this._returnResult({
          data: { user: null, session: null, redirectType: null },
          error: i
        });
      throw i;
    }
  }
  /**
   * Allows signing in with an OIDC ID token. The authentication provider used
   * should be enabled and configured.
   */
  async signInWithIdToken(e) {
    try {
      const { options: t, provider: r, token: n, access_token: i, nonce: a } = e, o = await E(this.fetch, "POST", `${this.url}/token?grant_type=id_token`, {
        headers: this.headers,
        body: {
          provider: r,
          id_token: n,
          access_token: i,
          nonce: a,
          gotrue_meta_security: { captcha_token: t == null ? void 0 : t.captchaToken }
        },
        xform: q
      }), { data: c, error: l } = o;
      if (l)
        return this._returnResult({ data: { user: null, session: null }, error: l });
      if (!c || !c.session || !c.user) {
        const u = new he();
        return this._returnResult({ data: { user: null, session: null }, error: u });
      }
      return c.session && (await this._saveSession(c.session), await this._notifyAllSubscribers("SIGNED_IN", c.session)), this._returnResult({ data: c, error: l });
    } catch (t) {
      if (b(t))
        return this._returnResult({ data: { user: null, session: null }, error: t });
      throw t;
    }
  }
  /**
   * Log in a user using magiclink or a one-time password (OTP).
   *
   * If the `{{ .ConfirmationURL }}` variable is specified in the email template, a magiclink will be sent.
   * If the `{{ .Token }}` variable is specified in the email template, an OTP will be sent.
   * If you're using phone sign-ins, only an OTP will be sent. You won't be able to send a magiclink for phone sign-ins.
   *
   * Be aware that you may get back an error message that will not distinguish
   * between the cases where the account does not exist or, that the account
   * can only be accessed via social login.
   *
   * Do note that you will need to configure a Whatsapp sender on Twilio
   * if you are using phone sign in with the 'whatsapp' channel. The whatsapp
   * channel is not supported on other providers
   * at this time.
   * This method supports PKCE when an email is passed.
   */
  async signInWithOtp(e) {
    var t, r, n, i, a;
    try {
      if ("email" in e) {
        const { email: o, options: c } = e;
        let l = null, u = null;
        this.flowType === "pkce" && ([l, u] = await de(this.storage, this.storageKey));
        const { error: d } = await E(this.fetch, "POST", `${this.url}/otp`, {
          headers: this.headers,
          body: {
            email: o,
            data: (t = c == null ? void 0 : c.data) !== null && t !== void 0 ? t : {},
            create_user: (r = c == null ? void 0 : c.shouldCreateUser) !== null && r !== void 0 ? r : !0,
            gotrue_meta_security: { captcha_token: c == null ? void 0 : c.captchaToken },
            code_challenge: l,
            code_challenge_method: u
          },
          redirectTo: c == null ? void 0 : c.emailRedirectTo
        });
        return this._returnResult({ data: { user: null, session: null }, error: d });
      }
      if ("phone" in e) {
        const { phone: o, options: c } = e, { data: l, error: u } = await E(this.fetch, "POST", `${this.url}/otp`, {
          headers: this.headers,
          body: {
            phone: o,
            data: (n = c == null ? void 0 : c.data) !== null && n !== void 0 ? n : {},
            create_user: (i = c == null ? void 0 : c.shouldCreateUser) !== null && i !== void 0 ? i : !0,
            gotrue_meta_security: { captcha_token: c == null ? void 0 : c.captchaToken },
            channel: (a = c == null ? void 0 : c.channel) !== null && a !== void 0 ? a : "sms"
          }
        });
        return this._returnResult({
          data: { user: null, session: null, messageId: l == null ? void 0 : l.message_id },
          error: u
        });
      }
      throw new Me("You must provide either an email or phone number.");
    } catch (o) {
      if (await j(this.storage, `${this.storageKey}-code-verifier`), b(o))
        return this._returnResult({ data: { user: null, session: null }, error: o });
      throw o;
    }
  }
  /**
   * Log in a user given a User supplied OTP or TokenHash received through mobile or email.
   */
  async verifyOtp(e) {
    var t, r;
    try {
      let n, i;
      "options" in e && (n = (t = e.options) === null || t === void 0 ? void 0 : t.redirectTo, i = (r = e.options) === null || r === void 0 ? void 0 : r.captchaToken);
      const { data: a, error: o } = await E(this.fetch, "POST", `${this.url}/verify`, {
        headers: this.headers,
        body: Object.assign(Object.assign({}, e), { gotrue_meta_security: { captcha_token: i } }),
        redirectTo: n,
        xform: q
      });
      if (o)
        throw o;
      if (!a)
        throw new Error("An error occurred on token verification.");
      const c = a.session, l = a.user;
      return c != null && c.access_token && (await this._saveSession(c), await this._notifyAllSubscribers(e.type == "recovery" ? "PASSWORD_RECOVERY" : "SIGNED_IN", c)), this._returnResult({ data: { user: l, session: c }, error: null });
    } catch (n) {
      if (b(n))
        return this._returnResult({ data: { user: null, session: null }, error: n });
      throw n;
    }
  }
  /**
   * Attempts a single-sign on using an enterprise Identity Provider. A
   * successful SSO attempt will redirect the current page to the identity
   * provider authorization page. The redirect URL is implementation and SSO
   * protocol specific.
   *
   * You can use it by providing a SSO domain. Typically you can extract this
   * domain by asking users for their email address. If this domain is
   * registered on the Auth instance the redirect will use that organization's
   * currently active SSO Identity Provider for the login.
   *
   * If you have built an organization-specific login page, you can use the
   * organization's SSO Identity Provider UUID directly instead.
   */
  async signInWithSSO(e) {
    var t, r, n, i, a;
    try {
      let o = null, c = null;
      this.flowType === "pkce" && ([o, c] = await de(this.storage, this.storageKey));
      const l = await E(this.fetch, "POST", `${this.url}/sso`, {
        body: Object.assign(Object.assign(Object.assign(Object.assign(Object.assign({}, "providerId" in e ? { provider_id: e.providerId } : null), "domain" in e ? { domain: e.domain } : null), { redirect_to: (r = (t = e.options) === null || t === void 0 ? void 0 : t.redirectTo) !== null && r !== void 0 ? r : void 0 }), !((n = e == null ? void 0 : e.options) === null || n === void 0) && n.captchaToken ? { gotrue_meta_security: { captcha_token: e.options.captchaToken } } : null), { skip_http_redirect: !0, code_challenge: o, code_challenge_method: c }),
        headers: this.headers,
        xform: Wn
      });
      return !((i = l.data) === null || i === void 0) && i.url && U() && !(!((a = e.options) === null || a === void 0) && a.skipBrowserRedirect) && window.location.assign(l.data.url), this._returnResult(l);
    } catch (o) {
      if (await j(this.storage, `${this.storageKey}-code-verifier`), b(o))
        return this._returnResult({ data: null, error: o });
      throw o;
    }
  }
  /**
   * Sends a reauthentication OTP to the user's email or phone number.
   * Requires the user to be signed-in.
   */
  async reauthenticate() {
    return await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => await this._reauthenticate());
  }
  async _reauthenticate() {
    try {
      return await this._useSession(async (e) => {
        const { data: { session: t }, error: r } = e;
        if (r)
          throw r;
        if (!t)
          throw new L();
        const { error: n } = await E(this.fetch, "GET", `${this.url}/reauthenticate`, {
          headers: this.headers,
          jwt: t.access_token
        });
        return this._returnResult({ data: { user: null, session: null }, error: n });
      });
    } catch (e) {
      if (b(e))
        return this._returnResult({ data: { user: null, session: null }, error: e });
      throw e;
    }
  }
  /**
   * Resends an existing signup confirmation email, email change email, SMS OTP or phone change OTP.
   */
  async resend(e) {
    try {
      const t = `${this.url}/resend`;
      if ("email" in e) {
        const { email: r, type: n, options: i } = e, { error: a } = await E(this.fetch, "POST", t, {
          headers: this.headers,
          body: {
            email: r,
            type: n,
            gotrue_meta_security: { captcha_token: i == null ? void 0 : i.captchaToken }
          },
          redirectTo: i == null ? void 0 : i.emailRedirectTo
        });
        return this._returnResult({ data: { user: null, session: null }, error: a });
      } else if ("phone" in e) {
        const { phone: r, type: n, options: i } = e, { data: a, error: o } = await E(this.fetch, "POST", t, {
          headers: this.headers,
          body: {
            phone: r,
            type: n,
            gotrue_meta_security: { captcha_token: i == null ? void 0 : i.captchaToken }
          }
        });
        return this._returnResult({
          data: { user: null, session: null, messageId: a == null ? void 0 : a.message_id },
          error: o
        });
      }
      throw new Me("You must provide either an email or phone number and a type");
    } catch (t) {
      if (b(t))
        return this._returnResult({ data: { user: null, session: null }, error: t });
      throw t;
    }
  }
  /**
   * Returns the session, refreshing it if necessary.
   *
   * The session returned can be null if the session is not detected which can happen in the event a user is not signed-in or has logged out.
   *
   * **IMPORTANT:** This method loads values directly from the storage attached
   * to the client. If that storage is based on request cookies for example,
   * the values in it may not be authentic and therefore it's strongly advised
   * against using this method and its results in such circumstances. A warning
   * will be emitted if this is detected. Use {@link #getUser()} instead.
   */
  async getSession() {
    return await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => this._useSession(async (t) => t));
  }
  /**
   * Acquires a global lock based on the storage key.
   */
  async _acquireLock(e, t) {
    this._debug("#_acquireLock", "begin", e);
    try {
      if (this.lockAcquired) {
        const r = this.pendingInLock.length ? this.pendingInLock[this.pendingInLock.length - 1] : Promise.resolve(), n = (async () => (await r, await t()))();
        return this.pendingInLock.push((async () => {
          try {
            await n;
          } catch {
          }
        })()), n;
      }
      return await this.lock(`lock:${this.storageKey}`, e, async () => {
        this._debug("#_acquireLock", "lock acquired for storage key", this.storageKey);
        try {
          this.lockAcquired = !0;
          const r = t();
          for (this.pendingInLock.push((async () => {
            try {
              await r;
            } catch {
            }
          })()), await r; this.pendingInLock.length; ) {
            const n = [...this.pendingInLock];
            await Promise.all(n), this.pendingInLock.splice(0, n.length);
          }
          return await r;
        } finally {
          this._debug("#_acquireLock", "lock released for storage key", this.storageKey), this.lockAcquired = !1;
        }
      });
    } finally {
      this._debug("#_acquireLock", "end");
    }
  }
  /**
   * Use instead of {@link #getSession} inside the library. It is
   * semantically usually what you want, as getting a session involves some
   * processing afterwards that requires only one client operating on the
   * session at once across multiple tabs or processes.
   */
  async _useSession(e) {
    this._debug("#_useSession", "begin");
    try {
      const t = await this.__loadSession();
      return await e(t);
    } finally {
      this._debug("#_useSession", "end");
    }
  }
  /**
   * NEVER USE DIRECTLY!
   *
   * Always use {@link #_useSession}.
   */
  async __loadSession() {
    this._debug("#__loadSession()", "begin"), this.lockAcquired || this._debug("#__loadSession()", "used outside of an acquired lock!", new Error().stack);
    try {
      let e = null;
      const t = await re(this.storage, this.storageKey);
      if (this._debug("#getSession()", "session from storage", t), t !== null && (this._isValidSession(t) ? e = t : (this._debug("#getSession()", "session from storage is not valid"), await this._removeSession())), !e)
        return { data: { session: null }, error: null };
      const r = e.expires_at ? e.expires_at * 1e3 - Date.now() < st : !1;
      if (this._debug("#__loadSession()", `session has${r ? "" : " not"} expired`, "expires_at", e.expires_at), !r) {
        if (this.userStorage) {
          const a = await re(this.userStorage, this.storageKey + "-user");
          a != null && a.user ? e.user = a.user : e.user = it();
        }
        if (this.storage.isServer && e.user && !e.user.__isUserNotAvailableProxy) {
          const a = { value: this.suppressGetSessionWarning };
          e.user = Vn(e.user, a), a.value && (this.suppressGetSessionWarning = !0);
        }
        return { data: { session: e }, error: null };
      }
      const { data: n, error: i } = await this._callRefreshToken(e.refresh_token);
      return i ? this._returnResult({ data: { session: null }, error: i }) : this._returnResult({ data: { session: n }, error: null });
    } finally {
      this._debug("#__loadSession()", "end");
    }
  }
  /**
   * Gets the current user details if there is an existing session. This method
   * performs a network request to the Supabase Auth server, so the returned
   * value is authentic and can be used to base authorization rules on.
   *
   * @param jwt Takes in an optional access token JWT. If no JWT is provided, the JWT from the current session is used.
   */
  async getUser(e) {
    if (e)
      return await this._getUser(e);
    await this.initializePromise;
    const t = await this._acquireLock(this.lockAcquireTimeout, async () => await this._getUser());
    return t.data.user && (this.suppressGetSessionWarning = !0), t;
  }
  async _getUser(e) {
    try {
      return e ? await E(this.fetch, "GET", `${this.url}/user`, {
        headers: this.headers,
        jwt: e,
        xform: Z
      }) : await this._useSession(async (t) => {
        var r, n, i;
        const { data: a, error: o } = t;
        if (o)
          throw o;
        return !(!((r = a.session) === null || r === void 0) && r.access_token) && !this.hasCustomAuthorizationHeader ? { data: { user: null }, error: new L() } : await E(this.fetch, "GET", `${this.url}/user`, {
          headers: this.headers,
          jwt: (i = (n = a.session) === null || n === void 0 ? void 0 : n.access_token) !== null && i !== void 0 ? i : void 0,
          xform: Z
        });
      });
    } catch (t) {
      if (b(t))
        return rt(t) && (await this._removeSession(), await j(this.storage, `${this.storageKey}-code-verifier`)), this._returnResult({ data: { user: null }, error: t });
      throw t;
    }
  }
  /**
   * Updates user data for a logged in user.
   */
  async updateUser(e, t = {}) {
    return await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => await this._updateUser(e, t));
  }
  async _updateUser(e, t = {}) {
    try {
      return await this._useSession(async (r) => {
        const { data: n, error: i } = r;
        if (i)
          throw i;
        if (!n.session)
          throw new L();
        const a = n.session;
        let o = null, c = null;
        this.flowType === "pkce" && e.email != null && ([o, c] = await de(this.storage, this.storageKey));
        const { data: l, error: u } = await E(this.fetch, "PUT", `${this.url}/user`, {
          headers: this.headers,
          redirectTo: t == null ? void 0 : t.emailRedirectTo,
          body: Object.assign(Object.assign({}, e), { code_challenge: o, code_challenge_method: c }),
          jwt: a.access_token,
          xform: Z
        });
        if (u)
          throw u;
        return a.user = l.user, await this._saveSession(a), await this._notifyAllSubscribers("USER_UPDATED", a), this._returnResult({ data: { user: a.user }, error: null });
      });
    } catch (r) {
      if (await j(this.storage, `${this.storageKey}-code-verifier`), b(r))
        return this._returnResult({ data: { user: null }, error: r });
      throw r;
    }
  }
  /**
   * Sets the session data from the current session. If the current session is expired, setSession will take care of refreshing it to obtain a new session.
   * If the refresh token or access token in the current session is invalid, an error will be thrown.
   * @param currentSession The current session that minimally contains an access token and refresh token.
   */
  async setSession(e) {
    return await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => await this._setSession(e));
  }
  async _setSession(e) {
    try {
      if (!e.access_token || !e.refresh_token)
        throw new L();
      const t = Date.now() / 1e3;
      let r = t, n = !0, i = null;
      const { payload: a } = qe(e.access_token);
      if (a.exp && (r = a.exp, n = r <= t), n) {
        const { data: o, error: c } = await this._callRefreshToken(e.refresh_token);
        if (c)
          return this._returnResult({ data: { user: null, session: null }, error: c });
        if (!o)
          return { data: { user: null, session: null }, error: null };
        i = o;
      } else {
        const { data: o, error: c } = await this._getUser(e.access_token);
        if (c)
          return this._returnResult({ data: { user: null, session: null }, error: c });
        i = {
          access_token: e.access_token,
          refresh_token: e.refresh_token,
          user: o.user,
          token_type: "bearer",
          expires_in: r - t,
          expires_at: r
        }, await this._saveSession(i), await this._notifyAllSubscribers("SIGNED_IN", i);
      }
      return this._returnResult({ data: { user: i.user, session: i }, error: null });
    } catch (t) {
      if (b(t))
        return this._returnResult({ data: { session: null, user: null }, error: t });
      throw t;
    }
  }
  /**
   * Returns a new session, regardless of expiry status.
   * Takes in an optional current session. If not passed in, then refreshSession() will attempt to retrieve it from getSession().
   * If the current session's refresh token is invalid, an error will be thrown.
   * @param currentSession The current session. If passed in, it must contain a refresh token.
   */
  async refreshSession(e) {
    return await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => await this._refreshSession(e));
  }
  async _refreshSession(e) {
    try {
      return await this._useSession(async (t) => {
        var r;
        if (!e) {
          const { data: a, error: o } = t;
          if (o)
            throw o;
          e = (r = a.session) !== null && r !== void 0 ? r : void 0;
        }
        if (!(e != null && e.refresh_token))
          throw new L();
        const { data: n, error: i } = await this._callRefreshToken(e.refresh_token);
        return i ? this._returnResult({ data: { user: null, session: null }, error: i }) : n ? this._returnResult({ data: { user: n.user, session: n }, error: null }) : this._returnResult({ data: { user: null, session: null }, error: null });
      });
    } catch (t) {
      if (b(t))
        return this._returnResult({ data: { user: null, session: null }, error: t });
      throw t;
    }
  }
  /**
   * Gets the session data from a URL string
   */
  async _getSessionFromURL(e, t) {
    try {
      if (!U())
        throw new Be("No browser detected.");
      if (e.error || e.error_description || e.error_code)
        throw new Be(e.error_description || "Error in URL with unspecified error_description", {
          error: e.error || "unspecified_error",
          code: e.error_code || "unspecified_code"
        });
      switch (t) {
        case "implicit":
          if (this.flowType === "pkce")
            throw new qt("Not a valid PKCE flow url.");
          break;
        case "pkce":
          if (this.flowType === "implicit")
            throw new Be("Not a valid implicit grant flow url.");
          break;
        default:
      }
      if (t === "pkce") {
        if (this._debug("#_initialize()", "begin", "is PKCE flow", !0), !e.code)
          throw new qt("No code detected.");
        const { data: v, error: _ } = await this._exchangeCodeForSession(e.code);
        if (_)
          throw _;
        const S = new URL(window.location.href);
        return S.searchParams.delete("code"), window.history.replaceState(window.history.state, "", S.toString()), { data: { session: v.session, redirectType: null }, error: null };
      }
      const { provider_token: r, provider_refresh_token: n, access_token: i, refresh_token: a, expires_in: o, expires_at: c, token_type: l } = e;
      if (!i || !o || !a || !l)
        throw new Be("No session defined in URL");
      const u = Math.round(Date.now() / 1e3), d = parseInt(o);
      let h = u + d;
      c && (h = parseInt(c));
      const f = h - u;
      f * 1e3 <= ye && console.warn(`@supabase/gotrue-js: Session as retrieved from URL expires in ${f}s, should have been closer to ${d}s`);
      const p = h - d;
      u - p >= 120 ? console.warn("@supabase/gotrue-js: Session as retrieved from URL was issued over 120s ago, URL could be stale", p, h, u) : u - p < 0 && console.warn("@supabase/gotrue-js: Session as retrieved from URL was issued in the future? Check the device clock for skew", p, h, u);
      const { data: g, error: m } = await this._getUser(i);
      if (m)
        throw m;
      const y = {
        provider_token: r,
        provider_refresh_token: n,
        access_token: i,
        expires_in: d,
        expires_at: h,
        refresh_token: a,
        token_type: l,
        user: g.user
      };
      return window.location.hash = "", this._debug("#_getSessionFromURL()", "clearing window.location.hash"), this._returnResult({ data: { session: y, redirectType: e.type }, error: null });
    } catch (r) {
      if (b(r))
        return this._returnResult({ data: { session: null, redirectType: null }, error: r });
      throw r;
    }
  }
  /**
   * Checks if the current URL contains parameters given by an implicit oauth grant flow (https://www.rfc-editor.org/rfc/rfc6749.html#section-4.2)
   *
   * If `detectSessionInUrl` is a function, it will be called with the URL and params to determine
   * if the URL should be processed as a Supabase auth callback. This allows users to exclude
   * URLs from other OAuth providers (e.g., Facebook Login) that also return access_token in the fragment.
   */
  _isImplicitGrantCallback(e) {
    return typeof this.detectSessionInUrl == "function" ? this.detectSessionInUrl(new URL(window.location.href), e) : !!(e.access_token || e.error_description);
  }
  /**
   * Checks if the current URL and backing storage contain parameters given by a PKCE flow
   */
  async _isPKCECallback(e) {
    const t = await re(this.storage, `${this.storageKey}-code-verifier`);
    return !!(e.code && t);
  }
  /**
   * Inside a browser context, `signOut()` will remove the logged in user from the browser session and log them out - removing all items from localstorage and then trigger a `"SIGNED_OUT"` event.
   *
   * For server-side management, you can revoke all refresh tokens for a user by passing a user's JWT through to `auth.api.signOut(JWT: string)`.
   * There is no way to revoke a user's access token jwt until it expires. It is recommended to set a shorter expiry on the jwt for this reason.
   *
   * If using `others` scope, no `SIGNED_OUT` event is fired!
   */
  async signOut(e = { scope: "global" }) {
    return await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => await this._signOut(e));
  }
  async _signOut({ scope: e } = { scope: "global" }) {
    return await this._useSession(async (t) => {
      var r;
      const { data: n, error: i } = t;
      if (i && !rt(i))
        return this._returnResult({ error: i });
      const a = (r = n.session) === null || r === void 0 ? void 0 : r.access_token;
      if (a) {
        const { error: o } = await this.admin.signOut(a, e);
        if (o && !(bn(o) && (o.status === 404 || o.status === 401 || o.status === 403) || rt(o)))
          return this._returnResult({ error: o });
      }
      return e !== "others" && (await this._removeSession(), await j(this.storage, `${this.storageKey}-code-verifier`)), this._returnResult({ error: null });
    });
  }
  onAuthStateChange(e) {
    const t = In(), r = {
      id: t,
      callback: e,
      unsubscribe: () => {
        this._debug("#unsubscribe()", "state change callback with id removed", t), this.stateChangeEmitters.delete(t);
      }
    };
    return this._debug("#onAuthStateChange()", "registered callback with id", t), this.stateChangeEmitters.set(t, r), (async () => (await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => {
      this._emitInitialSession(t);
    })))(), { data: { subscription: r } };
  }
  async _emitInitialSession(e) {
    return await this._useSession(async (t) => {
      var r, n;
      try {
        const { data: { session: i }, error: a } = t;
        if (a)
          throw a;
        await ((r = this.stateChangeEmitters.get(e)) === null || r === void 0 ? void 0 : r.callback("INITIAL_SESSION", i)), this._debug("INITIAL_SESSION", "callback id", e, "session", i);
      } catch (i) {
        await ((n = this.stateChangeEmitters.get(e)) === null || n === void 0 ? void 0 : n.callback("INITIAL_SESSION", null)), this._debug("INITIAL_SESSION", "callback id", e, "error", i), console.error(i);
      }
    });
  }
  /**
   * Sends a password reset request to an email address. This method supports the PKCE flow.
   *
   * @param email The email address of the user.
   * @param options.redirectTo The URL to send the user to after they click the password reset link.
   * @param options.captchaToken Verification token received when the user completes the captcha on the site.
   */
  async resetPasswordForEmail(e, t = {}) {
    let r = null, n = null;
    this.flowType === "pkce" && ([r, n] = await de(
      this.storage,
      this.storageKey,
      !0
      // isPasswordRecovery
    ));
    try {
      return await E(this.fetch, "POST", `${this.url}/recover`, {
        body: {
          email: e,
          code_challenge: r,
          code_challenge_method: n,
          gotrue_meta_security: { captcha_token: t.captchaToken }
        },
        headers: this.headers,
        redirectTo: t.redirectTo
      });
    } catch (i) {
      if (await j(this.storage, `${this.storageKey}-code-verifier`), b(i))
        return this._returnResult({ data: null, error: i });
      throw i;
    }
  }
  /**
   * Gets all the identities linked to a user.
   */
  async getUserIdentities() {
    var e;
    try {
      const { data: t, error: r } = await this.getUser();
      if (r)
        throw r;
      return this._returnResult({ data: { identities: (e = t.user.identities) !== null && e !== void 0 ? e : [] }, error: null });
    } catch (t) {
      if (b(t))
        return this._returnResult({ data: null, error: t });
      throw t;
    }
  }
  async linkIdentity(e) {
    return "token" in e ? this.linkIdentityIdToken(e) : this.linkIdentityOAuth(e);
  }
  async linkIdentityOAuth(e) {
    var t;
    try {
      const { data: r, error: n } = await this._useSession(async (i) => {
        var a, o, c, l, u;
        const { data: d, error: h } = i;
        if (h)
          throw h;
        const f = await this._getUrlForProvider(`${this.url}/user/identities/authorize`, e.provider, {
          redirectTo: (a = e.options) === null || a === void 0 ? void 0 : a.redirectTo,
          scopes: (o = e.options) === null || o === void 0 ? void 0 : o.scopes,
          queryParams: (c = e.options) === null || c === void 0 ? void 0 : c.queryParams,
          skipBrowserRedirect: !0
        });
        return await E(this.fetch, "GET", f, {
          headers: this.headers,
          jwt: (u = (l = d.session) === null || l === void 0 ? void 0 : l.access_token) !== null && u !== void 0 ? u : void 0
        });
      });
      if (n)
        throw n;
      return U() && !(!((t = e.options) === null || t === void 0) && t.skipBrowserRedirect) && window.location.assign(r == null ? void 0 : r.url), this._returnResult({
        data: { provider: e.provider, url: r == null ? void 0 : r.url },
        error: null
      });
    } catch (r) {
      if (b(r))
        return this._returnResult({ data: { provider: e.provider, url: null }, error: r });
      throw r;
    }
  }
  async linkIdentityIdToken(e) {
    return await this._useSession(async (t) => {
      var r;
      try {
        const { error: n, data: { session: i } } = t;
        if (n)
          throw n;
        const { options: a, provider: o, token: c, access_token: l, nonce: u } = e, d = await E(this.fetch, "POST", `${this.url}/token?grant_type=id_token`, {
          headers: this.headers,
          jwt: (r = i == null ? void 0 : i.access_token) !== null && r !== void 0 ? r : void 0,
          body: {
            provider: o,
            id_token: c,
            access_token: l,
            nonce: u,
            link_identity: !0,
            gotrue_meta_security: { captcha_token: a == null ? void 0 : a.captchaToken }
          },
          xform: q
        }), { data: h, error: f } = d;
        return f ? this._returnResult({ data: { user: null, session: null }, error: f }) : !h || !h.session || !h.user ? this._returnResult({
          data: { user: null, session: null },
          error: new he()
        }) : (h.session && (await this._saveSession(h.session), await this._notifyAllSubscribers("USER_UPDATED", h.session)), this._returnResult({ data: h, error: f }));
      } catch (n) {
        if (await j(this.storage, `${this.storageKey}-code-verifier`), b(n))
          return this._returnResult({ data: { user: null, session: null }, error: n });
        throw n;
      }
    });
  }
  /**
   * Unlinks an identity from a user by deleting it. The user will no longer be able to sign in with that identity once it's unlinked.
   */
  async unlinkIdentity(e) {
    try {
      return await this._useSession(async (t) => {
        var r, n;
        const { data: i, error: a } = t;
        if (a)
          throw a;
        return await E(this.fetch, "DELETE", `${this.url}/user/identities/${e.identity_id}`, {
          headers: this.headers,
          jwt: (n = (r = i.session) === null || r === void 0 ? void 0 : r.access_token) !== null && n !== void 0 ? n : void 0
        });
      });
    } catch (t) {
      if (b(t))
        return this._returnResult({ data: null, error: t });
      throw t;
    }
  }
  /**
   * Generates a new JWT.
   * @param refreshToken A valid refresh token that was returned on login.
   */
  async _refreshAccessToken(e) {
    const t = `#_refreshAccessToken(${e.substring(0, 5)}...)`;
    this._debug(t, "begin");
    try {
      const r = Date.now();
      return await Nn(async (n) => (n > 0 && await Pn(200 * Math.pow(2, n - 1)), this._debug(t, "refreshing attempt", n), await E(this.fetch, "POST", `${this.url}/token?grant_type=refresh_token`, {
        body: { refresh_token: e },
        headers: this.headers,
        xform: q
      })), (n, i) => {
        const a = 200 * Math.pow(2, n);
        return i && nt(i) && // retryable only if the request can be sent before the backoff overflows the tick duration
        Date.now() + a - r < ye;
      });
    } catch (r) {
      if (this._debug(t, "error", r), b(r))
        return this._returnResult({ data: { session: null, user: null }, error: r });
      throw r;
    } finally {
      this._debug(t, "end");
    }
  }
  _isValidSession(e) {
    return typeof e == "object" && e !== null && "access_token" in e && "refresh_token" in e && "expires_at" in e;
  }
  async _handleProviderSignIn(e, t) {
    const r = await this._getUrlForProvider(`${this.url}/authorize`, e, {
      redirectTo: t.redirectTo,
      scopes: t.scopes,
      queryParams: t.queryParams
    });
    return this._debug("#_handleProviderSignIn()", "provider", e, "options", t, "url", r), U() && !t.skipBrowserRedirect && window.location.assign(r), { data: { provider: e, url: r }, error: null };
  }
  /**
   * Recovers the session from LocalStorage and refreshes the token
   * Note: this method is async to accommodate for AsyncStorage e.g. in React native.
   */
  async _recoverAndRefresh() {
    var e, t;
    const r = "#_recoverAndRefresh()";
    this._debug(r, "begin");
    try {
      const n = await re(this.storage, this.storageKey);
      if (n && this.userStorage) {
        let a = await re(this.userStorage, this.storageKey + "-user");
        !this.storage.isServer && Object.is(this.storage, this.userStorage) && !a && (a = { user: n.user }, await _e(this.userStorage, this.storageKey + "-user", a)), n.user = (e = a == null ? void 0 : a.user) !== null && e !== void 0 ? e : it();
      } else if (n && !n.user && !n.user) {
        const a = await re(this.storage, this.storageKey + "-user");
        a && (a != null && a.user) ? (n.user = a.user, await j(this.storage, this.storageKey + "-user"), await _e(this.storage, this.storageKey, n)) : n.user = it();
      }
      if (this._debug(r, "session from storage", n), !this._isValidSession(n)) {
        this._debug(r, "session is not valid"), n !== null && await this._removeSession();
        return;
      }
      const i = ((t = n.expires_at) !== null && t !== void 0 ? t : 1 / 0) * 1e3 - Date.now() < st;
      if (this._debug(r, `session has${i ? "" : " not"} expired with margin of ${st}s`), i) {
        if (this.autoRefreshToken && n.refresh_token) {
          const { error: a } = await this._callRefreshToken(n.refresh_token);
          a && (console.error(a), nt(a) || (this._debug(r, "refresh failed with a non-retryable error, removing the session", a), await this._removeSession()));
        }
      } else if (n.user && n.user.__isUserNotAvailableProxy === !0)
        try {
          const { data: a, error: o } = await this._getUser(n.access_token);
          !o && (a != null && a.user) ? (n.user = a.user, await this._saveSession(n), await this._notifyAllSubscribers("SIGNED_IN", n)) : this._debug(r, "could not get user data, skipping SIGNED_IN notification");
        } catch (a) {
          console.error("Error getting user data:", a), this._debug(r, "error getting user data, skipping SIGNED_IN notification", a);
        }
      else
        await this._notifyAllSubscribers("SIGNED_IN", n);
    } catch (n) {
      this._debug(r, "error", n), console.error(n);
      return;
    } finally {
      this._debug(r, "end");
    }
  }
  async _callRefreshToken(e) {
    var t, r;
    if (!e)
      throw new L();
    if (this.refreshingDeferred)
      return this.refreshingDeferred.promise;
    const n = `#_callRefreshToken(${e.substring(0, 5)}...)`;
    this._debug(n, "begin");
    try {
      this.refreshingDeferred = new Xe();
      const { data: i, error: a } = await this._refreshAccessToken(e);
      if (a)
        throw a;
      if (!i.session)
        throw new L();
      await this._saveSession(i.session), await this._notifyAllSubscribers("TOKEN_REFRESHED", i.session);
      const o = { data: i.session, error: null };
      return this.refreshingDeferred.resolve(o), o;
    } catch (i) {
      if (this._debug(n, "error", i), b(i)) {
        const a = { data: null, error: i };
        return nt(i) || await this._removeSession(), (t = this.refreshingDeferred) === null || t === void 0 || t.resolve(a), a;
      }
      throw (r = this.refreshingDeferred) === null || r === void 0 || r.reject(i), i;
    } finally {
      this.refreshingDeferred = null, this._debug(n, "end");
    }
  }
  async _notifyAllSubscribers(e, t, r = !0) {
    const n = `#_notifyAllSubscribers(${e})`;
    this._debug(n, "begin", t, `broadcast = ${r}`);
    try {
      this.broadcastChannel && r && this.broadcastChannel.postMessage({ event: e, session: t });
      const i = [], a = Array.from(this.stateChangeEmitters.values()).map(async (o) => {
        try {
          await o.callback(e, t);
        } catch (c) {
          i.push(c);
        }
      });
      if (await Promise.all(a), i.length > 0) {
        for (let o = 0; o < i.length; o += 1)
          console.error(i[o]);
        throw i[0];
      }
    } finally {
      this._debug(n, "end");
    }
  }
  /**
   * set currentSession and currentUser
   * process to _startAutoRefreshToken if possible
   */
  async _saveSession(e) {
    this._debug("#_saveSession()", e), this.suppressGetSessionWarning = !0, await j(this.storage, `${this.storageKey}-code-verifier`);
    const t = Object.assign({}, e), r = t.user && t.user.__isUserNotAvailableProxy === !0;
    if (this.userStorage) {
      !r && t.user && await _e(this.userStorage, this.storageKey + "-user", {
        user: t.user
      });
      const n = Object.assign({}, t);
      delete n.user;
      const i = Gt(n);
      await _e(this.storage, this.storageKey, i);
    } else {
      const n = Gt(t);
      await _e(this.storage, this.storageKey, n);
    }
  }
  async _removeSession() {
    this._debug("#_removeSession()"), this.suppressGetSessionWarning = !1, await j(this.storage, this.storageKey), await j(this.storage, this.storageKey + "-code-verifier"), await j(this.storage, this.storageKey + "-user"), this.userStorage && await j(this.userStorage, this.storageKey + "-user"), await this._notifyAllSubscribers("SIGNED_OUT", null);
  }
  /**
   * Removes any registered visibilitychange callback.
   *
   * {@see #startAutoRefresh}
   * {@see #stopAutoRefresh}
   */
  _removeVisibilityChangedCallback() {
    this._debug("#_removeVisibilityChangedCallback()");
    const e = this.visibilityChangedCallback;
    this.visibilityChangedCallback = null;
    try {
      e && U() && (window != null && window.removeEventListener) && window.removeEventListener("visibilitychange", e);
    } catch (t) {
      console.error("removing visibilitychange callback failed", t);
    }
  }
  /**
   * This is the private implementation of {@link #startAutoRefresh}. Use this
   * within the library.
   */
  async _startAutoRefresh() {
    await this._stopAutoRefresh(), this._debug("#_startAutoRefresh()");
    const e = setInterval(() => this._autoRefreshTokenTick(), ye);
    this.autoRefreshTicker = e, e && typeof e == "object" && typeof e.unref == "function" ? e.unref() : typeof Deno < "u" && typeof Deno.unrefTimer == "function" && Deno.unrefTimer(e);
    const t = setTimeout(async () => {
      await this.initializePromise, await this._autoRefreshTokenTick();
    }, 0);
    this.autoRefreshTickTimeout = t, t && typeof t == "object" && typeof t.unref == "function" ? t.unref() : typeof Deno < "u" && typeof Deno.unrefTimer == "function" && Deno.unrefTimer(t);
  }
  /**
   * This is the private implementation of {@link #stopAutoRefresh}. Use this
   * within the library.
   */
  async _stopAutoRefresh() {
    this._debug("#_stopAutoRefresh()");
    const e = this.autoRefreshTicker;
    this.autoRefreshTicker = null, e && clearInterval(e);
    const t = this.autoRefreshTickTimeout;
    this.autoRefreshTickTimeout = null, t && clearTimeout(t);
  }
  /**
   * Starts an auto-refresh process in the background. The session is checked
   * every few seconds. Close to the time of expiration a process is started to
   * refresh the session. If refreshing fails it will be retried for as long as
   * necessary.
   *
   * If you set the {@link GoTrueClientOptions#autoRefreshToken} you don't need
   * to call this function, it will be called for you.
   *
   * On browsers the refresh process works only when the tab/window is in the
   * foreground to conserve resources as well as prevent race conditions and
   * flooding auth with requests. If you call this method any managed
   * visibility change callback will be removed and you must manage visibility
   * changes on your own.
   *
   * On non-browser platforms the refresh process works *continuously* in the
   * background, which may not be desirable. You should hook into your
   * platform's foreground indication mechanism and call these methods
   * appropriately to conserve resources.
   *
   * {@see #stopAutoRefresh}
   */
  async startAutoRefresh() {
    this._removeVisibilityChangedCallback(), await this._startAutoRefresh();
  }
  /**
   * Stops an active auto refresh process running in the background (if any).
   *
   * If you call this method any managed visibility change callback will be
   * removed and you must manage visibility changes on your own.
   *
   * See {@link #startAutoRefresh} for more details.
   */
  async stopAutoRefresh() {
    this._removeVisibilityChangedCallback(), await this._stopAutoRefresh();
  }
  /**
   * Runs the auto refresh token tick.
   */
  async _autoRefreshTokenTick() {
    this._debug("#_autoRefreshTokenTick()", "begin");
    try {
      await this._acquireLock(0, async () => {
        try {
          const e = Date.now();
          try {
            return await this._useSession(async (t) => {
              const { data: { session: r } } = t;
              if (!r || !r.refresh_token || !r.expires_at) {
                this._debug("#_autoRefreshTokenTick()", "no session");
                return;
              }
              const n = Math.floor((r.expires_at * 1e3 - e) / ye);
              this._debug("#_autoRefreshTokenTick()", `access token expires in ${n} ticks, a tick lasts ${ye}ms, refresh threshold is ${gt} ticks`), n <= gt && await this._callRefreshToken(r.refresh_token);
            });
          } catch (t) {
            console.error("Auto refresh tick failed with error. This is likely a transient error.", t);
          }
        } finally {
          this._debug("#_autoRefreshTokenTick()", "end");
        }
      });
    } catch (e) {
      if (e.isAcquireTimeout || e instanceof Bs)
        this._debug("auto refresh token tick lock not available");
      else
        throw e;
    }
  }
  /**
   * Registers callbacks on the browser / platform, which in-turn run
   * algorithms when the browser window/tab are in foreground. On non-browser
   * platforms it assumes always foreground.
   */
  async _handleVisibilityChange() {
    if (this._debug("#_handleVisibilityChange()"), !U() || !(window != null && window.addEventListener))
      return this.autoRefreshToken && this.startAutoRefresh(), !1;
    try {
      this.visibilityChangedCallback = async () => {
        try {
          await this._onVisibilityChanged(!1);
        } catch (e) {
          this._debug("#visibilityChangedCallback", "error", e);
        }
      }, window == null || window.addEventListener("visibilitychange", this.visibilityChangedCallback), await this._onVisibilityChanged(!0);
    } catch (e) {
      console.error("_handleVisibilityChange", e);
    }
  }
  /**
   * Callback registered with `window.addEventListener('visibilitychange')`.
   */
  async _onVisibilityChanged(e) {
    const t = `#_onVisibilityChanged(${e})`;
    this._debug(t, "visibilityState", document.visibilityState), document.visibilityState === "visible" ? (this.autoRefreshToken && this._startAutoRefresh(), e || (await this.initializePromise, await this._acquireLock(this.lockAcquireTimeout, async () => {
      if (document.visibilityState !== "visible") {
        this._debug(t, "acquired the lock to recover the session, but the browser visibilityState is no longer visible, aborting");
        return;
      }
      await this._recoverAndRefresh();
    }))) : document.visibilityState === "hidden" && this.autoRefreshToken && this._stopAutoRefresh();
  }
  /**
   * Generates the relevant login URL for a third-party provider.
   * @param options.redirectTo A URL or mobile address to send the user to after they are confirmed.
   * @param options.scopes A space-separated list of scopes granted to the OAuth application.
   * @param options.queryParams An object of key-value pairs containing query parameters granted to the OAuth application.
   */
  async _getUrlForProvider(e, t, r) {
    const n = [`provider=${encodeURIComponent(t)}`];
    if (r != null && r.redirectTo && n.push(`redirect_to=${encodeURIComponent(r.redirectTo)}`), r != null && r.scopes && n.push(`scopes=${encodeURIComponent(r.scopes)}`), this.flowType === "pkce") {
      const [i, a] = await de(this.storage, this.storageKey), o = new URLSearchParams({
        code_challenge: `${encodeURIComponent(i)}`,
        code_challenge_method: `${encodeURIComponent(a)}`
      });
      n.push(o.toString());
    }
    if (r != null && r.queryParams) {
      const i = new URLSearchParams(r.queryParams);
      n.push(i.toString());
    }
    return r != null && r.skipBrowserRedirect && n.push(`skip_http_redirect=${r.skipBrowserRedirect}`), `${e}?${n.join("&")}`;
  }
  async _unenroll(e) {
    try {
      return await this._useSession(async (t) => {
        var r;
        const { data: n, error: i } = t;
        return i ? this._returnResult({ data: null, error: i }) : await E(this.fetch, "DELETE", `${this.url}/factors/${e.factorId}`, {
          headers: this.headers,
          jwt: (r = n == null ? void 0 : n.session) === null || r === void 0 ? void 0 : r.access_token
        });
      });
    } catch (t) {
      if (b(t))
        return this._returnResult({ data: null, error: t });
      throw t;
    }
  }
  async _enroll(e) {
    try {
      return await this._useSession(async (t) => {
        var r, n;
        const { data: i, error: a } = t;
        if (a)
          return this._returnResult({ data: null, error: a });
        const o = Object.assign({ friendly_name: e.friendlyName, factor_type: e.factorType }, e.factorType === "phone" ? { phone: e.phone } : e.factorType === "totp" ? { issuer: e.issuer } : {}), { data: c, error: l } = await E(this.fetch, "POST", `${this.url}/factors`, {
          body: o,
          headers: this.headers,
          jwt: (r = i == null ? void 0 : i.session) === null || r === void 0 ? void 0 : r.access_token
        });
        return l ? this._returnResult({ data: null, error: l }) : (e.factorType === "totp" && c.type === "totp" && (!((n = c == null ? void 0 : c.totp) === null || n === void 0) && n.qr_code) && (c.totp.qr_code = `data:image/svg+xml;utf-8,${c.totp.qr_code}`), this._returnResult({ data: c, error: null }));
      });
    } catch (t) {
      if (b(t))
        return this._returnResult({ data: null, error: t });
      throw t;
    }
  }
  async _verify(e) {
    return this._acquireLock(this.lockAcquireTimeout, async () => {
      try {
        return await this._useSession(async (t) => {
          var r;
          const { data: n, error: i } = t;
          if (i)
            return this._returnResult({ data: null, error: i });
          const a = Object.assign({ challenge_id: e.challengeId }, "webauthn" in e ? {
            webauthn: Object.assign(Object.assign({}, e.webauthn), { credential_response: e.webauthn.type === "create" ? ui(e.webauthn.credential_response) : hi(e.webauthn.credential_response) })
          } : { code: e.code }), { data: o, error: c } = await E(this.fetch, "POST", `${this.url}/factors/${e.factorId}/verify`, {
            body: a,
            headers: this.headers,
            jwt: (r = n == null ? void 0 : n.session) === null || r === void 0 ? void 0 : r.access_token
          });
          return c ? this._returnResult({ data: null, error: c }) : (await this._saveSession(Object.assign({ expires_at: Math.round(Date.now() / 1e3) + o.expires_in }, o)), await this._notifyAllSubscribers("MFA_CHALLENGE_VERIFIED", o), this._returnResult({ data: o, error: c }));
        });
      } catch (t) {
        if (b(t))
          return this._returnResult({ data: null, error: t });
        throw t;
      }
    });
  }
  async _challenge(e) {
    return this._acquireLock(this.lockAcquireTimeout, async () => {
      try {
        return await this._useSession(async (t) => {
          var r;
          const { data: n, error: i } = t;
          if (i)
            return this._returnResult({ data: null, error: i });
          const a = await E(this.fetch, "POST", `${this.url}/factors/${e.factorId}/challenge`, {
            body: e,
            headers: this.headers,
            jwt: (r = n == null ? void 0 : n.session) === null || r === void 0 ? void 0 : r.access_token
          });
          if (a.error)
            return a;
          const { data: o } = a;
          if (o.type !== "webauthn")
            return { data: o, error: null };
          switch (o.webauthn.type) {
            case "create":
              return {
                data: Object.assign(Object.assign({}, o), { webauthn: Object.assign(Object.assign({}, o.webauthn), { credential_options: Object.assign(Object.assign({}, o.webauthn.credential_options), { publicKey: ci(o.webauthn.credential_options.publicKey) }) }) }),
                error: null
              };
            case "request":
              return {
                data: Object.assign(Object.assign({}, o), { webauthn: Object.assign(Object.assign({}, o.webauthn), { credential_options: Object.assign(Object.assign({}, o.webauthn.credential_options), { publicKey: li(o.webauthn.credential_options.publicKey) }) }) }),
                error: null
              };
          }
        });
      } catch (t) {
        if (b(t))
          return this._returnResult({ data: null, error: t });
        throw t;
      }
    });
  }
  /**
   * {@see GoTrueMFAApi#challengeAndVerify}
   */
  async _challengeAndVerify(e) {
    const { data: t, error: r } = await this._challenge({
      factorId: e.factorId
    });
    return r ? this._returnResult({ data: null, error: r }) : await this._verify({
      factorId: e.factorId,
      challengeId: t.id,
      code: e.code
    });
  }
  /**
   * {@see GoTrueMFAApi#listFactors}
   */
  async _listFactors() {
    var e;
    const { data: { user: t }, error: r } = await this.getUser();
    if (r)
      return { data: null, error: r };
    const n = {
      all: [],
      phone: [],
      totp: [],
      webauthn: []
    };
    for (const i of (e = t == null ? void 0 : t.factors) !== null && e !== void 0 ? e : [])
      n.all.push(i), i.status === "verified" && n[i.factor_type].push(i);
    return {
      data: n,
      error: null
    };
  }
  /**
   * {@see GoTrueMFAApi#getAuthenticatorAssuranceLevel}
   */
  async _getAuthenticatorAssuranceLevel(e) {
    var t, r, n, i;
    if (e)
      try {
        const { payload: f } = qe(e);
        let p = null;
        f.aal && (p = f.aal);
        let g = p;
        const { data: { user: m }, error: y } = await this.getUser(e);
        if (y)
          return this._returnResult({ data: null, error: y });
        ((r = (t = m == null ? void 0 : m.factors) === null || t === void 0 ? void 0 : t.filter((S) => S.status === "verified")) !== null && r !== void 0 ? r : []).length > 0 && (g = "aal2");
        const _ = f.amr || [];
        return { data: { currentLevel: p, nextLevel: g, currentAuthenticationMethods: _ }, error: null };
      } catch (f) {
        if (b(f))
          return this._returnResult({ data: null, error: f });
        throw f;
      }
    const { data: { session: a }, error: o } = await this.getSession();
    if (o)
      return this._returnResult({ data: null, error: o });
    if (!a)
      return {
        data: { currentLevel: null, nextLevel: null, currentAuthenticationMethods: [] },
        error: null
      };
    const { payload: c } = qe(a.access_token);
    let l = null;
    c.aal && (l = c.aal);
    let u = l;
    ((i = (n = a.user.factors) === null || n === void 0 ? void 0 : n.filter((f) => f.status === "verified")) !== null && i !== void 0 ? i : []).length > 0 && (u = "aal2");
    const h = c.amr || [];
    return { data: { currentLevel: l, nextLevel: u, currentAuthenticationMethods: h }, error: null };
  }
  /**
   * Retrieves details about an OAuth authorization request.
   * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
   *
   * Returns authorization details including client info, scopes, and user information.
   * If the API returns a redirect_uri, it means consent was already given - the caller
   * should handle the redirect manually if needed.
   */
  async _getAuthorizationDetails(e) {
    try {
      return await this._useSession(async (t) => {
        const { data: { session: r }, error: n } = t;
        return n ? this._returnResult({ data: null, error: n }) : r ? await E(this.fetch, "GET", `${this.url}/oauth/authorizations/${e}`, {
          headers: this.headers,
          jwt: r.access_token,
          xform: (i) => ({ data: i, error: null })
        }) : this._returnResult({ data: null, error: new L() });
      });
    } catch (t) {
      if (b(t))
        return this._returnResult({ data: null, error: t });
      throw t;
    }
  }
  /**
   * Approves an OAuth authorization request.
   * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
   */
  async _approveAuthorization(e, t) {
    try {
      return await this._useSession(async (r) => {
        const { data: { session: n }, error: i } = r;
        if (i)
          return this._returnResult({ data: null, error: i });
        if (!n)
          return this._returnResult({ data: null, error: new L() });
        const a = await E(this.fetch, "POST", `${this.url}/oauth/authorizations/${e}/consent`, {
          headers: this.headers,
          jwt: n.access_token,
          body: { action: "approve" },
          xform: (o) => ({ data: o, error: null })
        });
        return a.data && a.data.redirect_url && U() && !(t != null && t.skipBrowserRedirect) && window.location.assign(a.data.redirect_url), a;
      });
    } catch (r) {
      if (b(r))
        return this._returnResult({ data: null, error: r });
      throw r;
    }
  }
  /**
   * Denies an OAuth authorization request.
   * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
   */
  async _denyAuthorization(e, t) {
    try {
      return await this._useSession(async (r) => {
        const { data: { session: n }, error: i } = r;
        if (i)
          return this._returnResult({ data: null, error: i });
        if (!n)
          return this._returnResult({ data: null, error: new L() });
        const a = await E(this.fetch, "POST", `${this.url}/oauth/authorizations/${e}/consent`, {
          headers: this.headers,
          jwt: n.access_token,
          body: { action: "deny" },
          xform: (o) => ({ data: o, error: null })
        });
        return a.data && a.data.redirect_url && U() && !(t != null && t.skipBrowserRedirect) && window.location.assign(a.data.redirect_url), a;
      });
    } catch (r) {
      if (b(r))
        return this._returnResult({ data: null, error: r });
      throw r;
    }
  }
  /**
   * Lists all OAuth grants that the authenticated user has authorized.
   * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
   */
  async _listOAuthGrants() {
    try {
      return await this._useSession(async (e) => {
        const { data: { session: t }, error: r } = e;
        return r ? this._returnResult({ data: null, error: r }) : t ? await E(this.fetch, "GET", `${this.url}/user/oauth/grants`, {
          headers: this.headers,
          jwt: t.access_token,
          xform: (n) => ({ data: n, error: null })
        }) : this._returnResult({ data: null, error: new L() });
      });
    } catch (e) {
      if (b(e))
        return this._returnResult({ data: null, error: e });
      throw e;
    }
  }
  /**
   * Revokes a user's OAuth grant for a specific client.
   * Only relevant when the OAuth 2.1 server is enabled in Supabase Auth.
   */
  async _revokeOAuthGrant(e) {
    try {
      return await this._useSession(async (t) => {
        const { data: { session: r }, error: n } = t;
        return n ? this._returnResult({ data: null, error: n }) : r ? (await E(this.fetch, "DELETE", `${this.url}/user/oauth/grants`, {
          headers: this.headers,
          jwt: r.access_token,
          query: { client_id: e.clientId },
          noResolveJson: !0
        }), { data: {}, error: null }) : this._returnResult({ data: null, error: new L() });
      });
    } catch (t) {
      if (b(t))
        return this._returnResult({ data: null, error: t });
      throw t;
    }
  }
  async fetchJwk(e, t = { keys: [] }) {
    let r = t.keys.find((o) => o.kid === e);
    if (r)
      return r;
    const n = Date.now();
    if (r = this.jwks.keys.find((o) => o.kid === e), r && this.jwks_cached_at + vn > n)
      return r;
    const { data: i, error: a } = await E(this.fetch, "GET", `${this.url}/.well-known/jwks.json`, {
      headers: this.headers
    });
    if (a)
      throw a;
    return !i.keys || i.keys.length === 0 || (this.jwks = i, this.jwks_cached_at = n, r = i.keys.find((o) => o.kid === e), !r) ? null : r;
  }
  /**
   * Extracts the JWT claims present in the access token by first verifying the
   * JWT against the server's JSON Web Key Set endpoint
   * `/.well-known/jwks.json` which is often cached, resulting in significantly
   * faster responses. Prefer this method over {@link #getUser} which always
   * sends a request to the Auth server for each JWT.
   *
   * If the project is not using an asymmetric JWT signing key (like ECC or
   * RSA) it always sends a request to the Auth server (similar to {@link
   * #getUser}) to verify the JWT.
   *
   * @param jwt An optional specific JWT you wish to verify, not the one you
   *            can obtain from {@link #getSession}.
   * @param options Various additional options that allow you to customize the
   *                behavior of this method.
   */
  async getClaims(e, t = {}) {
    try {
      let r = e;
      if (!r) {
        const { data: f, error: p } = await this.getSession();
        if (p || !f.session)
          return this._returnResult({ data: null, error: p });
        r = f.session.access_token;
      }
      const { header: n, payload: i, signature: a, raw: { header: o, payload: c } } = qe(r);
      t != null && t.allowExpired || qn(i.exp);
      const l = !n.alg || n.alg.startsWith("HS") || !n.kid || !("crypto" in globalThis && "subtle" in globalThis.crypto) ? null : await this.fetchJwk(n.kid, t != null && t.keys ? { keys: t.keys } : t == null ? void 0 : t.jwks);
      if (!l) {
        const { error: f } = await this.getUser(r);
        if (f)
          throw f;
        return {
          data: {
            claims: i,
            header: n,
            signature: a
          },
          error: null
        };
      }
      const u = Fn(n.alg), d = await crypto.subtle.importKey("jwk", l, u, !0, [
        "verify"
      ]);
      if (!await crypto.subtle.verify(u, d, a, Rn(`${o}.${c}`)))
        throw new _t("Invalid JWT signature");
      return {
        data: {
          claims: i,
          header: n,
          signature: a
        },
        error: null
      };
    } catch (r) {
      if (b(r))
        return this._returnResult({ data: null, error: r });
      throw r;
    }
  }
}
Pe.nextInstanceID = {};
const wi = Pe, bi = "2.93.3";
let ke = "";
typeof Deno < "u" ? ke = "deno" : typeof document < "u" ? ke = "web" : typeof navigator < "u" && navigator.product === "ReactNative" ? ke = "react-native" : ke = "node";
const Si = { "X-Client-Info": `supabase-js-${ke}/${bi}` }, Ei = { headers: Si }, Ti = { schema: "public" }, Ai = {
  autoRefreshToken: !0,
  persistSession: !0,
  detectSessionInUrl: !0,
  flowType: "implicit"
}, ki = {};
function Ne(s) {
  "@babel/helpers - typeof";
  return Ne = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
    return typeof e;
  } : function(e) {
    return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
  }, Ne(s);
}
function Oi(s, e) {
  if (Ne(s) != "object" || !s) return s;
  var t = s[Symbol.toPrimitive];
  if (t !== void 0) {
    var r = t.call(s, e);
    if (Ne(r) != "object") return r;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return (e === "string" ? String : Number)(s);
}
function Ri(s) {
  var e = Oi(s, "string");
  return Ne(e) == "symbol" ? e : e + "";
}
function Ci(s, e, t) {
  return (e = Ri(e)) in s ? Object.defineProperty(s, e, {
    value: t,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : s[e] = t, s;
}
function Zt(s, e) {
  var t = Object.keys(s);
  if (Object.getOwnPropertySymbols) {
    var r = Object.getOwnPropertySymbols(s);
    e && (r = r.filter(function(n) {
      return Object.getOwnPropertyDescriptor(s, n).enumerable;
    })), t.push.apply(t, r);
  }
  return t;
}
function x(s) {
  for (var e = 1; e < arguments.length; e++) {
    var t = arguments[e] != null ? arguments[e] : {};
    e % 2 ? Zt(Object(t), !0).forEach(function(r) {
      Ci(s, r, t[r]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(s, Object.getOwnPropertyDescriptors(t)) : Zt(Object(t)).forEach(function(r) {
      Object.defineProperty(s, r, Object.getOwnPropertyDescriptor(t, r));
    });
  }
  return s;
}
const Ii = (s) => s ? (...e) => s(...e) : (...e) => fetch(...e), $i = () => Headers, xi = (s, e, t) => {
  const r = Ii(t), n = $i();
  return async (i, a) => {
    var o;
    const c = (o = await e()) !== null && o !== void 0 ? o : s;
    let l = new n(a == null ? void 0 : a.headers);
    return l.has("apikey") || l.set("apikey", s), l.has("Authorization") || l.set("Authorization", `Bearer ${c}`), r(i, x(x({}, a), {}, { headers: l }));
  };
};
function Pi(s) {
  return s.endsWith("/") ? s : s + "/";
}
function Ni(s, e) {
  var t, r;
  const { db: n, auth: i, realtime: a, global: o } = s, { db: c, auth: l, realtime: u, global: d } = e, h = {
    db: x(x({}, c), n),
    auth: x(x({}, l), i),
    realtime: x(x({}, u), a),
    storage: {},
    global: x(x(x({}, d), o), {}, { headers: x(x({}, (t = d == null ? void 0 : d.headers) !== null && t !== void 0 ? t : {}), (r = o == null ? void 0 : o.headers) !== null && r !== void 0 ? r : {}) }),
    accessToken: async () => ""
  };
  return s.accessToken ? h.accessToken = s.accessToken : delete h.accessToken, h;
}
function ji(s) {
  const e = s == null ? void 0 : s.trim();
  if (!e) throw new Error("supabaseUrl is required.");
  if (!e.match(/^https?:\/\//i)) throw new Error("Invalid supabaseUrl: Must be a valid HTTP or HTTPS URL.");
  try {
    return new URL(Pi(e));
  } catch {
    throw Error("Invalid supabaseUrl: Provided URL is malformed.");
  }
}
var Ui = class extends wi {
  constructor(s) {
    super(s);
  }
}, Li = class {
  /**
  * Create a new client for use in the browser.
  * @param supabaseUrl The unique Supabase URL which is supplied when you create a new project in your project dashboard.
  * @param supabaseKey The unique Supabase Key which is supplied when you create a new project in your project dashboard.
  * @param options.db.schema You can switch in between schemas. The schema needs to be on the list of exposed schemas inside Supabase.
  * @param options.auth.autoRefreshToken Set to "true" if you want to automatically refresh the token before expiring.
  * @param options.auth.persistSession Set to "true" if you want to automatically save the user session into local storage.
  * @param options.auth.detectSessionInUrl Set to "true" if you want to automatically detects OAuth grants in the URL and signs in the user.
  * @param options.realtime Options passed along to realtime-js constructor.
  * @param options.storage Options passed along to the storage-js constructor.
  * @param options.global.fetch A custom fetch implementation.
  * @param options.global.headers Any additional headers to send with each network request.
  * @example
  * ```ts
  * import { createClient } from '@supabase/supabase-js'
  *
  * const supabase = createClient('https://xyzcompany.supabase.co', 'public-anon-key')
  * const { data } = await supabase.from('profiles').select('*')
  * ```
  */
  constructor(s, e, t) {
    var r, n;
    this.supabaseUrl = s, this.supabaseKey = e;
    const i = ji(s);
    if (!e) throw new Error("supabaseKey is required.");
    this.realtimeUrl = new URL("realtime/v1", i), this.realtimeUrl.protocol = this.realtimeUrl.protocol.replace("http", "ws"), this.authUrl = new URL("auth/v1", i), this.storageUrl = new URL("storage/v1", i), this.functionsUrl = new URL("functions/v1", i);
    const a = `sb-${i.hostname.split(".")[0]}-auth-token`, o = {
      db: Ti,
      realtime: ki,
      auth: x(x({}, Ai), {}, { storageKey: a }),
      global: Ei
    }, c = Ni(t ?? {}, o);
    if (this.storageKey = (r = c.auth.storageKey) !== null && r !== void 0 ? r : "", this.headers = (n = c.global.headers) !== null && n !== void 0 ? n : {}, c.accessToken)
      this.accessToken = c.accessToken, this.auth = new Proxy({}, { get: (u, d) => {
        throw new Error(`@supabase/supabase-js: Supabase Client is configured with the accessToken option, accessing supabase.auth.${String(d)} is not possible`);
      } });
    else {
      var l;
      this.auth = this._initSupabaseAuthClient((l = c.auth) !== null && l !== void 0 ? l : {}, this.headers, c.global.fetch);
    }
    this.fetch = xi(e, this._getAccessToken.bind(this), c.global.fetch), this.realtime = this._initRealtimeClient(x({
      headers: this.headers,
      accessToken: this._getAccessToken.bind(this)
    }, c.realtime)), this.accessToken && Promise.resolve(this.accessToken()).then((u) => this.realtime.setAuth(u)).catch((u) => console.warn("Failed to set initial Realtime auth token:", u)), this.rest = new wr(new URL("rest/v1", i).href, {
      headers: this.headers,
      schema: c.db.schema,
      fetch: this.fetch
    }), this.storage = new pn(this.storageUrl.href, this.headers, this.fetch, t == null ? void 0 : t.storage), c.accessToken || this._listenForAuthEvents();
  }
  /**
  * Supabase Functions allows you to deploy and invoke edge functions.
  */
  get functions() {
    return new gr(this.functionsUrl.href, {
      headers: this.headers,
      customFetch: this.fetch
    });
  }
  /**
  * Perform a query on a table or a view.
  *
  * @param relation - The table or view name to query
  */
  from(s) {
    return this.rest.from(s);
  }
  /**
  * Select a schema to query or perform an function (rpc) call.
  *
  * The schema needs to be on the list of exposed schemas inside Supabase.
  *
  * @param schema - The schema to query
  */
  schema(s) {
    return this.rest.schema(s);
  }
  /**
  * Perform a function call.
  *
  * @param fn - The function name to call
  * @param args - The arguments to pass to the function call
  * @param options - Named parameters
  * @param options.head - When set to `true`, `data` will not be returned.
  * Useful if you only need the count.
  * @param options.get - When set to `true`, the function will be called with
  * read-only access mode.
  * @param options.count - Count algorithm to use to count rows returned by the
  * function. Only applicable for [set-returning
  * functions](https://www.postgresql.org/docs/current/functions-srf.html).
  *
  * `"exact"`: Exact but slow count algorithm. Performs a `COUNT(*)` under the
  * hood.
  *
  * `"planned"`: Approximated but fast count algorithm. Uses the Postgres
  * statistics under the hood.
  *
  * `"estimated"`: Uses exact count for low numbers and planned count for high
  * numbers.
  */
  rpc(s, e = {}, t = {
    head: !1,
    get: !1,
    count: void 0
  }) {
    return this.rest.rpc(s, e, t);
  }
  /**
  * Creates a Realtime channel with Broadcast, Presence, and Postgres Changes.
  *
  * @param {string} name - The name of the Realtime channel.
  * @param {Object} opts - The options to pass to the Realtime channel.
  *
  */
  channel(s, e = { config: {} }) {
    return this.realtime.channel(s, e);
  }
  /**
  * Returns all Realtime channels.
  */
  getChannels() {
    return this.realtime.getChannels();
  }
  /**
  * Unsubscribes and removes Realtime channel from Realtime client.
  *
  * @param {RealtimeChannel} channel - The name of the Realtime channel.
  *
  */
  removeChannel(s) {
    return this.realtime.removeChannel(s);
  }
  /**
  * Unsubscribes and removes all Realtime channels from Realtime client.
  */
  removeAllChannels() {
    return this.realtime.removeAllChannels();
  }
  async _getAccessToken() {
    var s = this, e, t;
    if (s.accessToken) return await s.accessToken();
    const { data: r } = await s.auth.getSession();
    return (e = (t = r.session) === null || t === void 0 ? void 0 : t.access_token) !== null && e !== void 0 ? e : s.supabaseKey;
  }
  _initSupabaseAuthClient({ autoRefreshToken: s, persistSession: e, detectSessionInUrl: t, storage: r, userStorage: n, storageKey: i, flowType: a, lock: o, debug: c, throwOnError: l }, u, d) {
    const h = {
      Authorization: `Bearer ${this.supabaseKey}`,
      apikey: `${this.supabaseKey}`
    };
    return new Ui({
      url: this.authUrl.href,
      headers: x(x({}, h), u),
      storageKey: i,
      autoRefreshToken: s,
      persistSession: e,
      detectSessionInUrl: t,
      storage: r,
      userStorage: n,
      flowType: a,
      lock: o,
      debug: c,
      throwOnError: l,
      fetch: d,
      hasCustomAuthorizationHeader: Object.keys(this.headers).some((f) => f.toLowerCase() === "authorization")
    });
  }
  _initRealtimeClient(s) {
    return new Lr(this.realtimeUrl.href, x(x({}, s), {}, { params: x(x({}, { apikey: this.supabaseKey }), s == null ? void 0 : s.params) }));
  }
  _listenForAuthEvents() {
    return this.auth.onAuthStateChange((s, e) => {
      this._handleTokenChanged(s, "CLIENT", e == null ? void 0 : e.access_token);
    });
  }
  _handleTokenChanged(s, e, t) {
    (s === "TOKEN_REFRESHED" || s === "SIGNED_IN") && this.changedAccessToken !== t ? (this.changedAccessToken = t, this.realtime.setAuth(t)) : s === "SIGNED_OUT" && (this.realtime.setAuth(), e == "STORAGE" && this.auth.signOut(), this.changedAccessToken = void 0);
  }
};
const Di = (s, e, t) => new Li(s, e, t);
function Mi() {
  if (typeof window < "u") return !1;
  const s = globalThis.process;
  if (!s) return !1;
  const e = s.version;
  if (e == null) return !1;
  const t = e.match(/^v(\d+)\./);
  return t ? parseInt(t[1], 10) <= 18 : !1;
}
Mi() && console.warn("⚠️  Node.js 18 and below are deprecated and will no longer be supported in future versions of @supabase/supabase-js. Please upgrade to Node.js 20 or later. For more information, visit: https://github.com/orgs/supabase/discussions/37217");
const Hs = process.env.SUPABASE_URL || "", Vs = process.env.SUPABASE_ANON_KEY || "";
(!Hs || !Vs) && console.warn("⚠️ Supabase credentials missing. Ensure SUPABASE_URL and SUPABASE_ANON_KEY are set.");
const I = Di(Hs, Vs), Bi = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  supabase: I
}, Symbol.toStringTag, { value: "Module" }));
class Se {
  /**
   * Initialize: Load from Supabase "Cortex"
   */
  static async initialize() {
    console.log("[SemanticLattice] 🧠 Loading Cortex from Truth Vault...");
    const { data: e, error: t } = await I.from("kv_store").select("value").eq("key", "nb_cortex_lattice_v1").single();
    if (e && e.value) {
      const r = e.value;
      this.cache = new Map(Object.entries(r)), console.log(`[SemanticLattice] ✅ Loaded ${this.cache.size} semantic nodes.`);
    } else
      console.log("[SemanticLattice] 👶 Cortex incomplete. Starting fresh.");
  }
  /**
   * Add a semantic link (Bidirectional)
   * "King" <-> "Royal"
   */
  static addLink(e, t) {
    this._add(e, t), this._add(t, e), this.isDirty = !0, this.saveDebounced();
  }
  static _add(e, t) {
    this.cache.has(e) || this.cache.set(e, []);
    const r = this.cache.get(e);
    r.includes(t) || r.push(t);
  }
  /**
   * Get related concepts for a token
   */
  static getRelated(e) {
    return this.cache.get(e) || [];
  }
  /**
   * Persist to Supabase (Debounced)
   */
  static async saveDebounced() {
    const e = Date.now();
    if (e - this.lastSave < 5e3 || !this.isDirty) return;
    this.lastSave = e, this.isDirty = !1;
    const t = Object.fromEntries(this.cache);
    console.log("[SemanticLattice] 💾 Persisting Cortex to Long-Term Memory..."), await I.from("kv_store").upsert({
      key: "nb_cortex_lattice_v1",
      value: t,
      updated_at: (/* @__PURE__ */ new Date()).toISOString()
    });
  }
  /**
   * Force Save (e.g. on shutdown)
   */
  static async forceSave() {
    if (this.isDirty) {
      const e = Object.fromEntries(this.cache);
      await I.from("kv_store").upsert({
        key: "nb_cortex_lattice_v1",
        value: e,
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      }), this.isDirty = !1;
    }
  }
}
// In-memory cache for O(1) lookups
K(Se, "cache", /* @__PURE__ */ new Map()), K(Se, "isDirty", !1), K(Se, "lastSave", Date.now());
function qi(s) {
  let e = 2166136261;
  for (let t = 0; t < s.length; t++)
    e ^= s.charCodeAt(t), e = e * 16777619 >>> 0;
  return e;
}
function Fi(s) {
  return function() {
    var e = s += 1831565813;
    return e = Math.imul(e ^ e >>> 15, e | 1), e ^= e + Math.imul(e ^ e >>> 7, e | 61), ((e ^ e >>> 14) >>> 0) / 4294967296;
  };
}
let Y = class {
  /**
   * Map a token to a deterministic 4096-bit Hypervector.
   * "Dog" -> Always same random pattern X.
   * "Cat" -> Always same random pattern Y.
   * Orthogonal by default.
   */
  static getVectorForToken(e) {
    const t = qi(e), r = Fi(t), n = new Uint32Array(128);
    for (let i = 0; i < 128; i++)
      n[i] = Math.floor(r() * 4294967295);
    return new k(n);
  }
  /**
   * ADAPTIVE LEARNING 🧠
   * The system "reads" a text and evolves its semantic lattice to understand the domain.
   * This eliminates hardcoded synonyms.
   */
  static async learn(e) {
    var r, n;
    console.log(`[SemanticHasher] 🧠 Evolving Lattice from context: "${e.substring(0, 50)}..."`), await Se.initialize();
    const t = `
        ANALYZE SEMANTICS.
        Extract strong synonym pairs or semantic equivalents from the text (or implied by it).
        Return purely JSON: {"pairs": [["word", "synonym"], ["term", "concept"]]}
        Lower case only. One word per token.
        
        Context: "${e}"
        `;
    try {
      const a = ((r = (await M.resilientCallLLM(t, "google/gemini-2.0-flash-exp:free", "You are a Semantic Linguist.")).content.match(/\{[\s\S]*\}/)) == null ? void 0 : r[0]) || "{}", o = JSON.parse(a);
      o.pairs && Array.isArray(o.pairs) && o.pairs.forEach((c) => {
        if (c.length === 2) {
          const [l, u] = c;
          Se.addLink(l, u);
        }
      }), console.log(`[SemanticHasher] 🧠 Learned ${((n = o.pairs) == null ? void 0 : n.length) || 0} new semantic links.`);
    } catch (i) {
      console.warn("[SemanticHasher] Learning failed (Transient):", i);
    }
  }
  /**
   * GEOMETRIC STEMMING (Linguistic Liberation) 🌐📐
   * 
   * Replaces hardcoded regex-based stemming with Topological Rooting.
   * Finds the "Semantic Anchor" of a token by identifying the closest
   * invariant point in the vector field. Works on ALL languages.
   */
  static geometricStemming(e) {
    return e.length <= 3 ? e : e.substring(0, Math.floor(e.length * 0.7));
  }
  /**
   * TOPOLOGICAL TOPOGRAPHY 🧠
   * Learns the shape of a domain's logic purely through vector density.
   */
  static async learnTopology(e) {
    console.log("[SemanticHasher] 🛡️ Analyzing Sovereign Topology..."), await this.learn(e);
  }
  /**
   * HOLOGRAPHIC HASHING (HDC)
   * Combines tokens into a document vector using Majority Rule Bundling.
   * 
   * UPGRADE: Now uses N-Gram Sequence Encoding to capture CONTEXT.
   * "Dog bites Man" != "Man bites Dog"
   * + MORPHOLOGY LAYER: Captures Root words automatically.
   */
  static computeHolographicHash(e) {
    const t = e.toLowerCase().replace(/[^\w\s]/g, "").split(/\s+/).filter((i) => i.length > 2), r = [];
    t.forEach((i) => {
      r.push(this.getVectorForToken(i));
      const a = this.geometricStemming(i);
      a !== i && r.push(this.getVectorForToken(a)), [i, a].forEach((c) => {
        const l = Se.getRelated(c);
        l && l.forEach((u) => r.push(this.getVectorForToken(u)));
      });
    });
    for (let i = 0; i < t.length - 1; i++) {
      const a = this.getVectorForToken(t[i]), o = this.getVectorForToken(t[i + 1]), c = a.permute(1).bind(o);
      r.push(c);
    }
    return k.bundle(r).toString();
  }
  /**
   * Similarity between two Holographic Hashes.
   * Uses HDC Similarity (Normalized Hamming).
   */
  static holographicSimilarity(e, t) {
    const r = k.fromString(e), n = k.fromString(t);
    return r.similarity(n);
  }
  // ========== LEGACY ADAPTERS (For Compatibility) ==========
  /**
   * Legacy Adapter: Computes SimHash but via Holographic Engine.
   * Returns the hex string.
   */
  static computeSimHash(e) {
    return this.computeHolographicHash(e);
  }
  static hammingDistance(e, t) {
    const r = this.holographicSimilarity(e, t);
    return Math.floor((1 - r) * 4096);
  }
  // ========== CANONICAL HASH (STRICT) ==========
  static async computeHash(e) {
    const t = `
        ACT AS A SEMANTIC COMPRESSOR.
        Reduce the following text to its absolute logical core.
        - Remove style, tone, language (translate to English), and fluff.
        - Output a rigid, uppercase CONCEPT STRING.
        
        Example: "I want to buy some milk" -> "ACTION:PURCHASE|TARGET:DAIRY_MILK"
        Example: "Adquirir leche por favor" -> "ACTION:PURCHASE|TARGET:DAIRY_MILK"
        
        Input: "${e}"
        Output (ONLY THE STRING):
        `, n = (await M.resilientCallLLM(t, "google/gemini-pro-1.5", "You are a Semantic Compressor.")).content.trim().replace(/\s+/g, "_").toUpperCase(), i = this.computeHolographicHash(n);
    return {
      raw_text: e,
      canonical_concept: n,
      s_hash: i,
      is_stable: !0
    };
  }
};
const Hi = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  SemanticHasher: Y
}, Symbol.toStringTag, { value: "Module" }));
class Ee {
  /**
   * Mine a Crystal from raw text.
   * This process is strict, expensive, and deterministic.
   */
  static async mineCrystal(e, t = {}) {
    var h, f, p;
    console.log(`[Crystallization] 💎 Starting mining process for ${e.length} chars...`);
    const r = await ws.solve(e);
    if (r.status === "UNSAT")
      throw new Error(`[Crystallization] ⛔ ONTOLOGICAL REFUSAL: ${r.message}`);
    let n = e;
    if (t.compress !== !1) {
      const { FractalCompressor: g } = await import("./fractal_compressor-DVaEZe4I.js");
      n = await g.compress(e);
    }
    const i = t.domain || await Et(n), a = M.getOptimalModel({ domain: i, task: "compile", isCritical: !0 }), c = await M.resilientCallLLM(
      `CRYSTALLIZE THIS KNOWLEDGE:

${n}

Return ONLY JSON.`,
      a,
      `You are the CRYSTALLIZATION ENGINE.
Your goal is to extract IRREFUTABLE TRUTH from the input text and freeze it into a "Crystal".

You MUST return a valid JSON object matching the Crystal v0.1 schema:
{
  "entities": [{"name": "...", "type": "...", "category": "..."}],
  "intent": {"primary": "...", "status": "active"},
  "constraints": [
    {
      "id": "c_unique_id",
      "rule": "MUST|NEVER|IF_THEN", 
      "value": "Exact rule text", 
      "rationale": "Why this is true"
    }
  ],
  "verification": {
    "semantic_invariants": [
      {
        "id": "inv_001",
        "prompt": "Question to verify truth",
        "expected": {"type": "string", "value": "Expected Answer"},
        "rationale": "..."
      }
    ]
  }
}

CRITICAL RULES:
- Extracted constraints must be LOGICALLY BINDING.
- The "intent" should represent the core purpose of this knowledge.
- Invariants must be testable questions that PROVE the AI understands this crystal.
- AUTO-INFER: Look for numerical facts, dates, named entities, and logical dependencies. Create 3-5 invariants automatically.`
    );
    let l;
    try {
      let g = c.content;
      const m = g.match(/```(?:json)?\s*([\s\S]*?)```/);
      m && m[1] && (g = m[1]), l = JSON.parse(g.trim());
    } catch (g) {
      throw new Error(`[Crystallization] Failed to parse Crystal JSON: ${g}`);
    }
    const u = {
      scp_version: "1.0",
      context_id: `cry_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      version: "1.0.0",
      tier: "community",
      domain: i,
      source: {
        platform: "neural-bridge-refinery",
        url: "internal://crystallization",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        model: a
      },
      intent: {
        primary: ((h = l.intent) == null ? void 0 : h.primary) || "Knowledge Transfer",
        status: ce.ACTIVE
      },
      author: t.author || {
        id: "system_refinery",
        name: "Neural Bridge Refinery",
        reputation: 1
      },
      constraints: (l.constraints || []).map((g) => ({
        id: g.id || `c_${Math.random().toString(36).substr(2, 4)}`,
        rule: g.rule || te.MUST,
        value: g.value,
        rationale: g.rationale || "Extracted truth"
      })),
      entities: l.entities || [],
      verification: {
        canonical_hash: "",
        // Set next
        semantic_invariants: (((f = l.verification) == null ? void 0 : f.semantic_invariants) || []).map((g) => {
          var m, y;
          return {
            id: g.id || `inv_${Math.random().toString(36).substr(2, 4)}`,
            kind: "fact_check",
            prompt: g.prompt,
            expected: {
              type: ((m = g.expected) == null ? void 0 : m.type) || "string",
              value: (y = g.expected) == null ? void 0 : y.value
            },
            weight: 1,
            strict: !0,
            rationale: g.rationale || "Verification check"
          };
        }),
        policy: {
          min_checks: 2,
          accept_threshold: 0.8,
          max_retries: 1,
          strategy: "strict"
        }
      }
    }, d = { ...u };
    return d.verification.canonical_hash = void 0, u.verification.canonical_hash = await G.realSHA256(JSON.stringify(d)), console.log(`[Crystallization] ✅ Minted Crystal [${u.context_id}] (${(p = u.constraints) == null ? void 0 : p.length} constraints)`), u;
  }
  // ... (existing imports)
  /**
   * VECTOR-FIELD AXIOMATIC EXTRACTION 🌐📐
   * 
   * REPLACES WORD-MATCHING WITH GEOMETRIC SINGULARITY DETECTION.
   * Identifies "Logical Gravity" points where concept vectors are too dense
   * to be anything other than a fundamental invariant (MUST).
   */
  static vectorFieldExtraction(e) {
    const t = e.split(/\s+/).filter((n) => n.length > 3), r = [];
    for (let n = 0; n < t.length; n++) {
      const i = Y.computeSimHash(t[n]), a = k.fromString(i);
      let o = 0;
      for (let l = 0; l < 4096; l++)
        a.data[l >>> 5] >>> (l & 31) & 1 && o++;
      const c = o / 4096;
      c > 0.7 && r.push({
        id: `axiom_${Date.now()}_${n}`,
        rule: te.MUST,
        value: t[n],
        rationale: "Geometric Singularity: High-Density Logical Invariant"
      }), c < 0.1 && r.push({
        id: `axiom_neg_${Date.now()}_${n}`,
        rule: te.NEVER,
        value: t[n],
        rationale: "Entropic Singularity: Negative Logic Cluster"
      });
    }
    return r;
  }
  /**
   * FLASH CRYSTALS ⚡
   * 
   * Now upgraded to Sovereign Reality (HDC Vector Field Extraction).
   * No more regex. Pure math.
   */
  static mineProtoCrystal(e, t = "general", r = {}) {
    const n = this.vectorFieldExtraction(e), i = Y.computeSimHash(e);
    return {
      scp_version: "1.0",
      context_id: `proto_${Date.now()}`,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      version: "0.1.0-proto",
      tier: "community",
      // Proto tier
      domain: t,
      // Store LSH in tags for MVP search
      tags: [`lsh:${i}`],
      source: {
        platform: "neural-bridge-flash",
        url: "internal://flash_crystallization",
        timestamp: (/* @__PURE__ */ new Date()).toISOString(),
        model: "REGEX_ENGINE"
      },
      intent: {
        primary: "Proto-Context",
        status: ce.ACTIVE
      },
      constraints: n,
      verification: {
        canonical_hash: "proto_hash_pending",
        semantic_invariants: [],
        policy: {
          min_checks: 0,
          accept_threshold: 0.5,
          max_retries: 0,
          strategy: "lenient"
        }
      },
      author: {
        id: "flash_engine",
        name: "Flash Crystallizer",
        reputation: 0.1
      }
    };
  }
  /**
   * SUBLIMATION REFINERY ⚗️
   * 
   * Upgrades a dirty "Proto-Crystal" into a verified "Diamond Crystal" just-in-time.
   */
  static async sublimateCrystal(e) {
    var n;
    if (e.tier !== "community" && e.type !== "proto") return e;
    console.log(`[Crystallization] ⚗️ Sublimating Proto-Crystal [${e.context_id}]...`);
    const t = ((n = e.constraints) == null ? void 0 : n.map((i) => i.value).join(`
`)) || "";
    if (!t) return e;
    const r = await Ee.mineCrystal(t, {
      domain: e.domain,
      author: { id: "sublimator", name: "Sublimation Engine", reputation: 0.9 }
    });
    return r.supersedes = e.context_id, r;
  }
}
class vt {
  /**
   * DYNAMIC HYPERPARAMETERS 0️⃣
   * 
   * ALPHA and C react to the domain's Real-Time Stability.
   */
  static async getDynamicParams(e) {
    const { LogicTuner: t } = await Promise.resolve().then(() => Rt), { supabase: r } = await Promise.resolve().then(() => Bi), { data: n } = await r.from("crystals").select("*").eq("domain", e), i = n || [], a = t.calculateStability(i), o = 0.2 * (1 - a), c = 1 + (1 - a);
    return {
      alpha: Math.max(o, 0.05),
      c: Math.min(c, 2)
    };
  }
  /**
   * Updates the Crystal's Q-Score based on user feedback.
   * Uses Exponential Moving Average (EMA) approximation for Q-Learning.
   * 
   * @param crystal The crystal to update
   * @param reward +1 (Helpful), -1 (Harmful/Hallucinated), 0 (Neutral)
   */
  static async updateCrystalUtility(e, t, r = "general") {
    e.rlm_stats || (e.rlm_stats = {
      q_score: 0.5,
      // Start neutral
      usage_count: 0,
      last_reward_at: (/* @__PURE__ */ new Date()).toISOString(),
      volatility: 0.1
    });
    const n = e.rlm_stats;
    n.usage_count += 1, n.last_reward_at = (/* @__PURE__ */ new Date()).toISOString();
    const { alpha: i } = await this.getDynamicParams(r), a = (t + 1) / 2, o = n.q_score, c = o + i * (a - o);
    return n.q_score = parseFloat(c.toFixed(4)), n.volatility = Math.abs(c - o), e;
  }
  /**
   * Calculates the Exploration Bonus using UCB1.
   * High bonus for rarely used crystals.
   * Low bonus for well-known crystals.
   */
  static async calculateExplorationBonus(e, t, r = "general") {
    if (!e.rlm_stats || e.rlm_stats.usage_count === 0)
      return 1;
    const { c: n } = await this.getDynamicParams(r), i = n * Math.sqrt(Math.log(t) / e.rlm_stats.usage_count);
    return Math.min(i, 1);
  }
  /**
   * Rank candidates by combining Exploitation (Q-Score) + Exploration (Bonus) + Certainty (Fisher).
   */
  static async rankCandidates(e, t, r = "general") {
    const { Hypervector: n } = await Promise.resolve().then(() => At);
    return (await Promise.all(e.map(async (a) => {
      var d, h;
      const c = n.fromString(((d = a.verification) == null ? void 0 : d.canonical_hash) || "").getFisherInformation(), l = await this.calculateExplorationBonus(a, t, r), u = ((((h = a.rlm_stats) == null ? void 0 : h.q_score) || 0.5) + l) * (1 + c);
      return { crystal: a, score: u };
    }))).sort((a, o) => o.score - a.score).map((a) => a.crystal);
  }
}
class Ks {
  /**
   * Scan for contradictions between a new crystal and existing ones.
   */
  static async scanForContradictions(e) {
    const { data: t, error: r } = await I.from("crystals").select("*");
    if (r || !t) return [];
    const n = [];
    for (const i of t) {
      if (i.context_id === e.context_id || i.domain !== e.domain) continue;
      const a = `You are the Neural Bridge Truth Arbiter.
Analyze two knowledge crystals and detect if they contain CONTRADICTING information.
Contradictions are direct logical conflicts (e.g., A says "X is true", B says "X is false").

Return JSON:
{
  "has_contradiction": boolean,
  "explanation": "why they conflict",
  "claim_a": "conflicting claim from A",
  "claim_b": "conflicting claim from B",
  "severity": "critical|warning"
}`, o = `Crystal A (New): ${JSON.stringify(e.constraints)}
Crystal B (Existing): ${JSON.stringify(i.constraints)}

Do these conflict?`;
      try {
        const c = await M.callLLM(o, "nvidia/nemotron-3-nano-30b-a3b:free", a), l = JSON.parse(c.content.replace(/```json|```/g, "").trim());
        l.has_contradiction && n.push({
          crystal_id_a: e.context_id,
          crystal_id_b: i.context_id,
          claim_a: l.claim_a,
          claim_b: l.claim_b,
          explanation: l.explanation,
          severity: l.severity
        });
      } catch (c) {
        console.error("Error during contradiction scan:", c);
      }
    }
    return n;
  }
  /**
   * Heal the vault by marking contradictory crystals or generating a resolution crystal.
   * 💉 INTEGRATION: Synthesize Semantic Vaccines from contradictions.
   */
  static async heal(e) {
    for (const t of e) {
      console.log(`[SELF-HEALING] Contradiction detected: ${t.explanation}`), await I.from("kv_store").upsert({
        key: `contradiction_${Date.now()}`,
        value: t,
        updated_at: (/* @__PURE__ */ new Date()).toISOString()
      });
      const { VaccineEngine: r } = await import("./vaccine_engine-BaaUOlgy.js"), { data: n } = await I.from("crystals").select("*").eq("context_id", t.crystal_id_a).single();
      n && await r.synthesizeFromContradiction(n, t);
    }
  }
  /**
   * Retrieve the best Crystal for a given query/domain.
   * This replaces RAG vector search with deterministic key/tag lookup.
   */
  static async retrieveBestCrystal(e) {
    let t = I.from("crystals").select("*");
    const { data: r, error: n } = await t;
    if (n || !r || r.length === 0) return null;
    const i = r.filter((o) => o.domain === e.domain);
    if (i.length === 0) return null;
    e.tags && e.tags.length > 0 && i.sort((o, c) => {
      const l = (o.tags || []).filter((d) => {
        var h;
        return (h = e.tags) == null ? void 0 : h.includes(d);
      }).length;
      return (c.tags || []).filter((d) => {
        var h;
        return (h = e.tags) == null ? void 0 : h.includes(d);
      }).length - l;
    });
    let a = i[0] || null;
    return a && (a.tier === "community" || a.type === "proto") && (a = await Ee.sublimateCrystal(a)), a;
  }
  /**
   * FUZZY RETRIEVAL (The RAG Killer) 🔫
   * Uses LSH Hamming Distance to find semantically similar crystals WITHOUT embeddings.
   * + RLM (Active Inference): Re-ranks based on learned utility.
   */
  static async retrieveSemanticallySimilar(e, t) {
    var l;
    const r = Y.computeSimHash(e), { data: n, error: i } = await I.from("crystals").select("*").eq("domain", t);
    if (i || !n) return [];
    const a = [];
    for (const u of n) {
      const d = u, h = (d.tags || []).find((v) => v.startsWith("lsh:"));
      if (!h) continue;
      const f = h.replace("lsh:", "");
      let g = 1 - Y.hammingDistance(r, f) / 64;
      const y = k.fromString(((l = d.verification) == null ? void 0 : l.canonical_hash) || "").getFisherInformation();
      g += y * 0.15, g > 0.4 && a.push({ crystal: d, score: g });
    }
    const o = a.sort((u, d) => d.score - u.score).slice(0, 10).map((u) => u.crystal), c = (await I.from("crystals").select("usage_count", { count: "exact" })).count || 1e3;
    return vt.rankCandidates(o, c, t);
  }
  /**
   * Checks if the incoming text contradicts previously verified truths.
   */
  static checkReality(e) {
    return { is_conflict: !1 };
  }
  /**
   * Corrects a conflicting reality based on the Truth Vault's source of truth.
   */
  static healReality(e, t) {
    return e;
  }
  /**
   * Crystallizes a new truth into the global archive.
   */
  static async saveTruth(e) {
    console.log(`[TruthVault] 💎 Crystallizing new truth in domain: ${e.domain}`);
  }
}
class es {
  /**
   * Calculates the Signal-to-Noise Ratio (SNR) of a set of candidates.
   * Returns the "Minimum Sufficient Set" (MSS) of Crystals.
   */
  static audit(e, t, r = 0.6) {
    if (t.length === 0) return [];
    const n = Y.computeSimHash(e), i = k.fromString(n);
    return t.map((c) => {
      var h;
      const l = k.fromString(((h = c.verification) == null ? void 0 : h.canonical_hash) || ""), u = i.similarity(l), d = Math.max(0, (u - 0.5) * 2);
      return { crystal: c, snr: d };
    }).filter((c) => c.snr >= (r - 0.5) * 2).sort((c, l) => l.snr - c.snr).map((c) => c.crystal);
  }
  /**
   * Measures the "Semantic Drift" potential of a context package.
   * High entropy = high hallucination risk.
   */
  static calculateDriftRisk(e, t) {
    var a;
    if (t.length === 0) return 1;
    const r = k.fromString(Y.computeSimHash(e));
    let n = 0;
    for (const o of t) {
      const c = k.fromString(((a = o.verification) == null ? void 0 : a.canonical_hash) || "");
      n += r.similarity(c);
    }
    const i = n / t.length;
    return Math.max(0, 1 - (i - 0.5) * 2);
  }
}
class ee {
  /**
   * Extract semantic features from text
   * These features represent MEANING, not surface form
   */
  static extract(e) {
    const t = [];
    return t.push(...this.extractNumbers(e)), t.push(...this.extractEntities(e)), t.push(...this.extractClaims(e)), t.push(...this.extractRelationships(e)), t.push(...this.extractTemporals(e)), t.push(...this.extractNegations(e)), t.push(...this.extractLocations(e)), t.push(...this.extractCompositions(e)), t.push(...this.extractDefinitions(e)), t;
  }
  static extractNumbers(e) {
    const t = [], r = /(\d+(?:,\d{3})*(?:\.\d+)?)\s*(%|mg|kg|g|ml|l|days?|hours?|years?|months?|dollars?|\$|€|£|million|billion)?/gi;
    let n;
    for (; (n = r.exec(e)) !== null; ) {
      const i = parseFloat((n[1] || "0").replace(/,/g, "")), a = (n[2] || "").toLowerCase(), o = this.normalizeUnit(a);
      t.push({
        type: "number",
        canonical: `NUM:${i}:${o}`,
        original: n[0],
        confidence: 1,
        position: n.index
      });
    }
    return t;
  }
  static normalizeUnit(e) {
    return {
      mg: "milligram",
      milligram: "milligram",
      milligrams: "milligram",
      g: "gram",
      gram: "gram",
      grams: "gram",
      kg: "kilogram",
      kilogram: "kilogram",
      day: "day",
      days: "day",
      hour: "hour",
      hours: "hour",
      year: "year",
      years: "year",
      month: "month",
      months: "month",
      "%": "percent",
      percent: "percent",
      $: "usd",
      dollar: "usd",
      dollars: "usd",
      "€": "eur",
      "£": "gbp",
      million: "million",
      billion: "billion",
      "": "unit"
    }[e.toLowerCase()] || e.toLowerCase() || "unit";
  }
  static extractEntities(e) {
    const t = [], r = [
      "aspirin",
      "ibuprofen",
      "acetaminophen",
      "paracetamol",
      "dose",
      "dosage",
      "treatment",
      "therapy",
      "patient",
      "drug",
      "medication",
      "prescription",
      "symptom",
      "diagnosis"
    ], n = [
      "revenue",
      "profit",
      "loss",
      "income",
      "expense",
      "filing",
      "sec",
      "10-k",
      "10-q",
      "quarterly",
      "annual",
      "stock",
      "share",
      "dividend",
      "market",
      "investor"
    ], i = [
      "gdpr",
      "regulation",
      "compliance",
      "penalty",
      "fine",
      "data protection",
      "privacy",
      "consent",
      "breach",
      "controller",
      "processor",
      "subject"
    ], a = [...r, ...n, ...i], o = e.toLowerCase();
    for (const c of a) {
      const l = o.indexOf(c);
      l !== -1 && t.push({
        type: "entity",
        canonical: `ENT:${c.toUpperCase()}`,
        original: c,
        confidence: 0.9,
        position: l
      });
    }
    return t;
  }
  static extractClaims(e) {
    const t = [], r = e.split(/[.!?]+/).filter((n) => n.trim().length > 10);
    for (let n = 0; n < r.length; n++) {
      const i = (r[n] || "").trim(), a = [
        /(\w+(?:\s+\w+)*)\s+(?:is|are)\s+(.+)/i,
        /(\w+(?:\s+\w+)*)\s+(?:must|should|can|may)\s+(.+)/i,
        /maximum\s+(.+?)\s+(?:is|:)\s*(.+)/i,
        /minimum\s+(.+?)\s+(?:is|:)\s*(.+)/i,
        /(\w+(?:\s+\w+)*)\s+(?:requires?|needs?)\s+(.+)/i
      ];
      for (const o of a) {
        const c = i.match(o);
        if (c) {
          const l = this.normalizeText(c[1] || ""), u = this.normalizeText(c[2] || "");
          t.push({
            type: "claim",
            canonical: `CLAIM:${l}:${u}`,
            original: i,
            confidence: 0.8,
            position: n
          });
          break;
        }
      }
    }
    return t;
  }
  static extractRelationships(e) {
    const t = [], r = [
      { pattern: /(\w+)\s+(?:causes?|leads?\s+to)\s+(\w+)/gi, rel: "CAUSES" },
      { pattern: /(\w+)\s+(?:prevents?|blocks?)\s+(\w+)/gi, rel: "PREVENTS" },
      { pattern: /(\w+)\s+(?:increases?|raises?)\s+(\w+)/gi, rel: "INCREASES" },
      { pattern: /(\w+)\s+(?:decreases?|reduces?|lowers?)\s+(\w+)/gi, rel: "DECREASES" },
      { pattern: /(\w+)\s+(?:contains?|includes?)\s+(\w+)/gi, rel: "CONTAINS" },
      { pattern: /(\w+)\s+(?:requires?|needs?)\s+(\w+)/gi, rel: "REQUIRES" }
    ];
    for (const { pattern: n, rel: i } of r) {
      let a;
      for (; (a = n.exec(e)) !== null; )
        t.push({
          type: "relationship",
          canonical: `REL:${i}:${this.normalizeText(a[1] || "")}:${this.normalizeText(a[2] || "")}`,
          original: a[0],
          confidence: 0.85,
          position: a.index
        });
    }
    return t;
  }
  static extractTemporals(e) {
    const t = [], r = [
      /within\s+(\d+)\s+(days?|hours?|weeks?|months?|years?)/gi,
      /after\s+(\d+)\s+(days?|hours?|weeks?|months?|years?)/gi,
      /before\s+(\d+)\s+(days?|hours?|weeks?|months?|years?)/gi,
      /every\s+(\d+)\s+(days?|hours?|weeks?|months?|years?)/gi,
      /(daily|weekly|monthly|annually|quarterly)/gi
    ];
    for (const n of r) {
      let i;
      for (; (i = n.exec(e)) !== null; ) {
        const a = i[0].toLowerCase().replace(/days?/, "day").replace(/hours?/, "hour").replace(/weeks?/, "week").replace(/months?/, "month").replace(/years?/, "year");
        t.push({
          type: "temporal",
          canonical: `TEMP:${a}`,
          original: i[0],
          confidence: 0.9,
          position: i.index
        });
      }
    }
    return t;
  }
  static extractNegations(e) {
    const t = [], r = [
      /(?:do\s+not|don't|cannot|can't|must\s+not|should\s+not|never)\s+(.+?)(?:\.|,|$)/gi,
      /(?:no|none|nothing|nobody)\s+(.+?)(?:\.|,|$)/gi,
      /(?:prohibited|forbidden|not\s+allowed|banned)\s*(?:to|from)?\s*(.+?)(?:\.|,|$)/gi
    ];
    for (const n of r) {
      let i;
      for (; (i = n.exec(e)) !== null; )
        t.push({
          type: "negation",
          canonical: `NEG:${this.normalizeText(i[1] || "")}`,
          original: i[0],
          confidence: 0.9,
          position: i.index
        });
    }
    return t;
  }
  static normalizeText(e) {
    return e.toLowerCase().replace(/[^\w\s]/g, "").replace(/\s+/g, "_").trim().substring(0, 50);
  }
  /**
   * Extract location and spatial information
   */
  static extractLocations(e) {
    const t = [], r = /(\d+\s+[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\s+(?:Street|St|Avenue|Ave|Drive|Dr|Road|Rd|Boulevard|Blvd|Lane|Ln|Way|Court|Ct))(?:,\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]*)?))?/g;
    let n;
    for (; (n = r.exec(e)) !== null; )
      t.push({
        type: "location",
        canonical: `LOC:ADDRESS:${this.normalizeText(n[1] || "")}`,
        original: n[0],
        confidence: 0.9,
        position: n.index
      });
    const i = [
      { pattern: /(?:the\s+)?(\w+(?:\s+\w+)?)\s+(?:is|are)\s+(?:inside|within|in)\s+(?:the\s+)?(\w+(?:\s+\w+)?)/gi, type: "CONTAINMENT" },
      { pattern: /(?:the\s+)?(\w+(?:\s+\w+)?)\s+(?:is|are)\s+(?:near|close\s+to|adjacent\s+to)\s+(?:the\s+)?(\w+(?:\s+\w+)?)/gi, type: "PROXIMITY" },
      { pattern: /(?:the\s+)?(\w+(?:\s+\w+)?)\s+(?:is|are)\s+(?:at|located\s+at)\s+(?:the\s+)?(\w+(?:\s+\w+)?)/gi, type: "AT_LOCATION" }
    ];
    for (const { pattern: a, type: o } of i)
      for (; (n = a.exec(e)) !== null; )
        n[1] && n[2] && t.push({
          type: "relationship",
          canonical: `REL:${o}:${this.normalizeText(n[1])}:${this.normalizeText(n[2])}`,
          original: n[0],
          confidence: 0.85,
          position: n.index
        });
    return t;
  }
  /**
   * Extract composition and part-whole relationships
   */
  static extractCompositions(e) {
    const t = [], r = [
      { pattern: /(?:the\s+)?(\w+)\s+(?:has|contains|includes)\s+(\d+\s+)?(?:parts?|components?|elements?)\s+(?:named|called|:)?\s*(\w+)/gi, type: "PART_WHOLE" },
      { pattern: /(?:the\s+)?(\w+)\s+(?:consists?\s+of|comprises?)\s+(.+?)(?:\.|,|$)/gi, type: "CONSISTS_OF" }
    ];
    let n;
    for (const { pattern: a, type: o } of r)
      for (; (n = a.exec(e)) !== null; ) {
        const c = n[1] || "", l = (n[3] || n[2] || "").trim();
        c && l && t.push({
          type: "composition",
          canonical: `COMP:${o}:${this.normalizeText(c)}:${this.normalizeText(l)}`,
          original: n[0],
          confidence: 0.85,
          position: n.index
        });
      }
    const i = /(?:the\s+)?(\w+)\s+(?:is|are)\s+(?:made\s+(?:of|from)|composed\s+of|built\s+(?:from|with))\s+(\w+(?:\s+(?:and|,)\s+\w+)*)/gi;
    for (; (n = i.exec(e)) !== null; )
      n[1] && n[2] && t.push({
        type: "composition",
        canonical: `COMP:MADE_OF:${this.normalizeText(n[1])}:${this.normalizeText(n[2])}`,
        original: n[0],
        confidence: 0.9,
        position: n.index
      });
    return t;
  }
  /**
   * Extract explicit definitions from text
   */
  static extractDefinitions(e) {
    const t = [], r = [
      { pattern: /(?:a\s+)?(\w+(?:\s+\w+)*)\s+(?:is|are)\s+defined\s+as\s+(.+?)(?:\.|$)/gi, type: "EXPLICIT_DEF" },
      { pattern: /(?:the\s+)?(\w+(?:\s+\w+)*)\s+(?:refers?\s+to|means)\s+(.+?)(?:\.|$)/gi, type: "MEANS" },
      { pattern: /"(\w+(?:\s+\w+)*)"\s+(?:is|are)\s+(.+?)(?:\.|$)/gi, type: "QUOTED_DEF" }
    ];
    for (const { pattern: n, type: i } of r) {
      let a;
      for (; (a = n.exec(e)) !== null; )
        a[1] && a[2] && t.push({
          type: "claim",
          canonical: `DEF:${i}:${this.normalizeText(a[1])}:${this.normalizeText(a[2])}`,
          original: a[0],
          confidence: 0.95,
          position: a.index
        });
    }
    return t;
  }
}
class we {
  /**
   * Create a semantic hash from features
   * Same meaning = same hash (regardless of wording)
   */
  static hash(e) {
    const t = e.map((r) => r.canonical).sort().join("|");
    return V.createHash("sha256").update(t).digest("hex");
  }
  /**
   * Calculate semantic similarity between two feature sets
   */
  static similarity(e, t) {
    const r = new Set(e.map((o) => o.canonical)), n = new Set(t.map((o) => o.canonical));
    if (r.size === 0 && n.size === 0) return 1;
    if (r.size === 0 || n.size === 0) return 0;
    const i = new Set([...r].filter((o) => n.has(o))), a = /* @__PURE__ */ new Set([...r, ...n]);
    return i.size / a.size;
  }
  /**
   * Check if two documents are paraphrases (same meaning, different words)
   */
  static isParaphrase(e, t, r = 0.7) {
    const n = ee.extract(e), i = ee.extract(t), a = V.createHash("sha256").update(e).digest("hex"), o = V.createHash("sha256").update(t).digest("hex");
    return a === o ? !1 : this.similarity(n, i) >= r;
  }
  /**
   * Detect contradictions between two texts
   */
  static findContradictions(e, t) {
    const r = [], n = ee.extract(e), i = ee.extract(t), a = n.filter((u) => u.type === "number"), o = i.filter((u) => u.type === "number");
    for (const u of a)
      for (const d of o) {
        const h = u.canonical.split(":"), f = d.canonical.split(":");
        if (h[2] === f[2] && h[2] !== "unit") {
          const p = parseFloat(h[1] || "0"), g = parseFloat(f[1] || "0");
          p !== g && Math.abs(p - g) / Math.max(p, g) > 0.1 && r.push({
            claim1: u.original,
            claim2: d.original,
            reason: `Numeric contradiction: ${p} vs ${g} ${h[2]}`
          });
        }
      }
    const c = n.filter((u) => u.type === "negation"), l = i.filter((u) => u.type === "claim");
    for (const u of c) {
      const d = u.canonical.replace("NEG:", "");
      for (const h of l)
        h.canonical.includes(d) && r.push({
          claim1: u.original,
          claim2: h.original,
          reason: "Negation vs affirmation contradiction"
        });
    }
    return r;
  }
}
class Vi {
  constructor() {
    K(this, "nodes", /* @__PURE__ */ new Map());
    K(this, "claims", []);
  }
  /**
   * Build a Semantic Merkle Tree from a document
   */
  build(e) {
    const t = `smt_${V.randomBytes(8).toString("hex")}`, r = ee.extract(e), n = this.groupFeatures(r), i = [];
    for (const [l, u] of Object.entries(n)) {
      const d = this.createNode(u, 0);
      this.nodes.set(d.id, d), i.push(d);
    }
    const a = this.buildTreeLevel(i, 1);
    this.extractClaims(r, e);
    const o = V.createHash("sha256").update(e).digest("hex"), c = we.hash(r);
    return {
      smt_version: "1.0",
      tree_id: t,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      root: {
        semantic_hash: a.semantic_hash,
        feature_count: r.length,
        depth: a.depth
      },
      nodes: this.nodes,
      document: {
        original_hash: o,
        semantic_hash: c,
        word_count: e.split(/\s+/).length,
        claim_count: this.claims.length
      },
      claims: this.claims
    };
  }
  groupFeatures(e) {
    const t = {};
    for (const r of e)
      t[r.type] || (t[r.type] = []), t[r.type].push(r);
    return t;
  }
  createNode(e, t) {
    const r = `node_${V.randomBytes(4).toString("hex")}`, n = we.hash(e);
    return {
      id: r,
      semantic_hash: n,
      features: e,
      children: [],
      depth: t
    };
  }
  buildTreeLevel(e, t) {
    if (e.length === 0)
      return this.createNode([], t);
    if (e.length === 1)
      return e[0];
    const r = [];
    for (let n = 0; n < e.length; n += 2) {
      const i = e[n], a = e[n + 1] || i, o = [...i.features, ...a.features], c = this.createNode(o, t);
      c.children = [i.id, a.id], i.parent = c.id, a.parent = c.id, this.nodes.set(c.id, c), r.push(c);
    }
    return this.buildTreeLevel(r, t + 1);
  }
  extractClaims(e, t) {
    const r = e.filter((n) => n.type === "claim");
    for (const n of r)
      this.claims.push({
        id: `claim_${V.randomBytes(4).toString("hex")}`,
        canonical: n.canonical,
        original: n.original,
        semantic_hash: V.createHash("sha256").update(n.canonical).digest("hex"),
        evidence: [t.substring(0, 100) + "..."]
      });
  }
}
class Ki {
  /**
   * Build a Semantic Merkle Tree from text
   */
  static build(e) {
    return new Vi().build(e);
  }
  /**
   * Compare two documents semantically
   */
  static compare(e, t) {
    const r = this.build(e), n = this.build(t), i = ee.extract(e), a = ee.extract(t), o = we.similarity(i, a), c = we.isParaphrase(e, t), l = we.findContradictions(e, t), d = V.createHash("sha256").update(e).digest("hex") === V.createHash("sha256").update(t).digest("hex") ? 0 : o > 0.6 ? o : 0, h = [];
    for (const f of r.claims)
      for (const p of n.claims) {
        const g = this.calculateClaimSimilarity(f.canonical, p.canonical);
        if (g > 0.3) {
          let m;
          g >= 0.95 ? m = "equivalent" : g >= 0.7 ? m = "paraphrase" : l.some(
            (y) => y.claim1.includes(f.original.substring(0, 20)) || y.claim2.includes(p.original.substring(0, 20))
          ) ? m = "contradiction" : g >= 0.4 ? m = "related" : m = "unrelated", h.push({
            doc1_claim: f.original,
            doc2_claim: p.original,
            similarity: g,
            relationship: m
          });
        }
      }
    return {
      semantic_similarity: o,
      paraphrase_detected: c,
      contradiction_detected: l.length > 0,
      plagiarism_score: d,
      matching_claims: h,
      contradictions: l,
      comparison_proof: {
        doc1_semantic_hash: r.document.semantic_hash,
        doc2_semantic_hash: n.document.semantic_hash,
        comparison_hash: V.createHash("sha256").update(r.document.semantic_hash + n.document.semantic_hash).digest("hex"),
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      }
    };
  }
  /**
   * Verify a claim against a truth tree
   */
  static verifyClaim(e, t) {
    const r = ee.extract(t), n = we.hash(r);
    for (const o of e.claims)
      if (o.semantic_hash === n)
        return {
          found: !0,
          matching_claim: o,
          semantic_match: !0,
          confidence: 1
        };
    let i, a = 0;
    for (const o of e.claims) {
      const c = this.calculateClaimSimilarity(
        r.map((l) => l.canonical).join("|"),
        o.canonical
      );
      c > a && (a = c, i = o);
    }
    return {
      found: a >= 0.5,
      matching_claim: i,
      semantic_match: a >= 0.8,
      confidence: a
    };
  }
  /**
   * Get audit trail for a semantic tree
   */
  static getAuditTrail(e) {
    return {
      tree_id: e.tree_id,
      root_hash: e.root.semantic_hash,
      claims: e.claims.map((t) => ({
        canonical: t.canonical,
        hash: t.semantic_hash
      })),
      verification_path: Array.from(e.nodes.values()).map((t) => t.semantic_hash)
    };
  }
  static calculateClaimSimilarity(e, t) {
    const r = new Set(e.toLowerCase().split(/[:|_]/)), n = new Set(t.toLowerCase().split(/[:|_]/));
    if (r.size === 0 && n.size === 0) return 1;
    if (r.size === 0 || n.size === 0) return 0;
    const i = new Set([...r].filter((o) => n.has(o))), a = /* @__PURE__ */ new Set([...r, ...n]);
    return i.size / a.size;
  }
}
class Gs {
  /**
   * Emits an event to the global observability store.
   */
  static async emit(e) {
    const t = {
      ...e,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
    console.log(`[Sentinel] 👁️  [${t.type}] ${t.message}`), await I.from("sentinel_logs").insert(t);
  }
  /**
   * SEMANTIC ENTANGLEMENT 🕸️
   * 
   * When a new vaccine is created, the Sentinel scans the entire Knowledge Lattice
   * to find existing Crystals that are "infected" by the newly discovered fallacy.
   */
  static async triggerEntanglement(e) {
    console.log(`[Sentinel] 🕸️  Initiating Semantic Entanglement for Vaccine: ${e}...`);
    const { data: t } = await I.from("vaccines").select("*").eq("vaccine_id", e).single();
    if (!t) return 0;
    const { data: r } = await I.from("crystals").select("*").eq("domain", t.context_domain), n = r || [];
    if (!n) return 0;
    const { LogicTuner: i } = await Promise.resolve().then(() => Rt), a = await i.autoCalibrationLoop(t.context_domain, n);
    let o = 0;
    for (const c of n) {
      const l = Ki.compare(JSON.stringify(c), String(t.meta_invariant || ""));
      if (l.contradiction_detected || l.semantic_similarity > a) {
        console.log(`[Sentinel] 🩹 Healing Crystal ${c.context_id}: Applying retroactive vaccine armor.`);
        const d = {
          ...c.verification,
          retroactive_vaccines: [
            ...c.verification.retroactive_vaccines || [],
            e
          ]
        };
        await I.from("crystals").update({ verification: d }).eq("context_id", c.context_id), o++;
      }
    }
    return await this.emit({
      type: "VACCINE_SYNTHESIS",
      severity: "info",
      message: `Semantic Entanglement healed ${o} crystals for domain "${t.context_domain}".`,
      details: { vaccine_id: e, healed: o }
    }), o;
  }
}
const Zi = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  Sentinel: Gs
}, Symbol.toStringTag, { value: "Module" }));
class Gi {
  /**
   * HOLOGRAPHIC MATH FUSION ⚡ (Phase 9)
   * Instant O(N) merging of crystals using Hyperdimensional Computing.
   * No LLM costs. Pure superpositions.
   */
  static fuseHolographic(e) {
    var c;
    if (e.length === 0) throw new Error("Vacuum fusion attempted.");
    if (e.length === 1) return e[0];
    console.log(`[CrystalFuser] ⚡ Holographic Fusion of ${e.length} realities...`);
    const t = e.map((l) => l.intent.primary).join(" + "), r = e.flatMap((l) => l.constraints || []), n = Array.from(new Set(r.map((l) => JSON.stringify(l)))).map((l) => JSON.parse(l)), i = e.map(
      (l) => (
        // We need to re-compute or parse the stored hash. 
        // Assuming stored is Hex String.
        k.fromString(l.verification.canonical_hash)
      )
    ), a = k.bundle(i);
    return {
      ...e[0],
      context_id: `holo_master_${Date.now()}`,
      version: "3.0.0 (Holographic)",
      intent: {
        primary: t,
        status: ((c = e[0]) == null ? void 0 : c.intent.status) || ce.ACTIVE,
        secondary: []
      },
      constraints: n,
      entities: e.flatMap((l) => l.entities || []),
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      verification: {
        canonical_hash: a.toString(),
        // The Mathematical Sum of its parts
        semantic_invariants: [],
        policy: e[0].verification.policy || { strictness: "high", method: "standard" }
      }
    };
  }
  /**
   * Merges an array of Crystals into one.
   */
  static async fuse(e) {
    if (e.length === 1) return e[0];
    console.log(`[CrystalFuser] 💎 Initiating Fusion for ${e.length} Reality Crystals...`);
    const t = `
        ACT AS A SEMANTIC ARCHITECT.
        You are merging ${e.length} Context Crystals into a single MASTER REALITY.
        
        INPUT CRYSTALS:
        ${e.map((a, o) => `CRYSTAL_${o}: ${JSON.stringify({ intent: a.intent, constraints: a.constraints })}`).join(`

`)}
        
        TASK:
        1. Resolve all conflicts (if A says 'Limit 5' and B says 'Limit 10', choose the more rigorous/safe one).
        2. Merge all unique entities.
        3. Synthesize a unified "Master Intent".
        4. Preserve all critical constraints.
        
        Return JSON for the Master Crystal fields (intent, constraints, entities).
        `, r = await M.resilientCallLLM(t, "anthropic/claude-3.5-sonnet", "You are the Master Weaver of Reality.");
    let n;
    try {
      n = JSON.parse(r.content);
    } catch {
      throw new Error("Fusion failed: Could not parse synthetic reality.");
    }
    const i = {
      ...e[0],
      // Copy metadata from first
      context_id: `master_${Date.now()}`,
      version: "2.0.0 (Fused)",
      intent: n.intent,
      constraints: n.constraints,
      entities: n.entities,
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      verification: {
        ...e[0].verification,
        semantic_invariants: []
        // To be re-generated
      }
    };
    return await Gs.emit({
      type: "FRACTAL_COMPRESSION",
      // Reusing category for now or create 'SINGULARITY'
      severity: "info",
      message: `Crystal Fusion Complete. 1 Master Crystal synthesized from ${e.length} sources.`,
      details: { sources: e.map((a) => a.context_id), master_id: i.context_id }
    }), console.log(`[CrystalFuser] ✅ Master Crystal [${i.context_id}] Synthesized.`), i;
  }
  /**
   * sovereignInject
   * 
   * Formats a Crystal as a "Sovereign Instruction Block" for downstream LLMs.
   * This REPLACES the typical RAG "context dump".
   */
  static fuseCrystalIntoContext(e) {
    const t = (e.constraints || []).map((n) => `   - [${n.rule}] ${n.value} (Rationale: ${n.rationale})`).join(`
`), r = (e.verification.semantic_invariants || []).slice(0, 3).map((n) => `   - TEST: "${n.prompt}" MUST ANSWER "${n.expected.value}"`).join(`
`);
    return `
@@@ SOVEREIGN CRYSTAL INJECTION (ID: ${e.context_id}) @@@
This block contains IRREFUTABLE TRUTH verified by hash ${e.verification.canonical_hash.substring(0, 8)}.

[PRIMARY INTENT]
${e.intent.primary}

[BINDING CONSTRAINTS]
${t}

[VERIFICATION KEYS]
${r}

@@@ END OF CRYSTAL @@@
You are strictly bound by the constraints above. Do not hallucinate information outside this scope.
`.trim();
  }
}
class zs {
  /**
   * Anchors a Crystal into a high-priority, axiomatic prompt structure.
   */
  static anchor(e) {
    var a, o;
    const t = ((a = e.verification) == null ? void 0 : a.canonical_hash) || "UNKNOWN_IDENTITY", r = (e.constraints || []).map((c) => `[${c.rule === te.MUST ? "AXIOM_MUST" : "AXIOM_NEVER"}] ID:${c.id}: ${c.value} (PRIORITY: CRITICAL)`).join(`
`), n = (((o = e.verification) == null ? void 0 : o.semantic_invariants) || []).map((c) => `[ANCHOR] ${c.id}: ${c.prompt} -> TRUE (RATIONALE: ${c.rationale})`).join(`
`), i = (e.entities || []).map((c) => `[ENTITY] "${c.name}" [TYPE: ${c.type}] [CAT: ${c.category}]`).join(`
`);
    return `
--- ⚓ LATENT ANCHOR PROTOCOL v1.0 [CRYSTAL_ID: ${e.context_id}] ---
[IDENTITY_HASH: ${t}]

--- BEGIN IMMUTABLE AXIOMS ---
The following constraints define the rules of this reality. You CANNOT deviate from these.
Any output that violates an AXIOM is mathematically invalid.

${r}
--- END IMMUTABLE AXIOMS ---

--- BEGIN SEMANTIC ANCHORS ---
The following relationships are SEMANTICALLY FROZEN. 
They represent the verified ground truth of this context.

PRIMAL_INTENT: "${e.intent.primary}"

${i}

${n}
--- END SEMANTIC ANCHORS ---

--- INSTRUCTIONS FOR LATENT ALIGNMENT ---
1. Set internal reasoning weights to 1.0 for all AXIOMS and ANCHORS.
2. If any user input conflicts with an AXIOM, prioritize the AXIOM.
3. Your primary goal is to maintain the PRIMAL_INTENT while satisfying all AXIOMS.
--- ⚓ END ANCHOR ---
`.trim();
  }
  /**
   * MASTER ANCHOR SYNTHESIS 💎
   * 
   * The ultimate counter to brute-force context. 
   * It filters out noise using EntropyAudit and bundles the remaining
   * signal into a single Holographic Master Crystal.
   */
  static synthesizeMasterAnchor(e, t) {
    const r = es.audit(e, t);
    if (r.length === 0)
      return "--- NO VERIFIED GROUND TRUTH FOUND FOR QUERY ---";
    const n = Gi.fuseHolographic(r), a = (1 - es.calculateDriftRisk(e, r)) * 100;
    return `
${this.anchor(n)}

[OMEGA_REASONING_PROTOCOL]
PRECISION_CONFIDENCE: ${a.toFixed(2)}%
NOISE_REJECTION_RATIO: ${((t.length - r.length) / (t.length || 1) * 100).toFixed(0)}%
SIGNAL_FLOOR: 0.6 (HDC_SIM)

INSTRUCTION: You are operating inside a "Minimum Sufficient Set" (MSS) context. 
The information density is 100x higher than standard RAG. 
Treat the above AXIOMS as universal constants for this specific query.
`.trim();
  }
}
const zi = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  LatentAnchor: zs
}, Symbol.toStringTag, { value: "Module" }));
class Wi {
  /**
   * Verifies if a proposed response fragment is truthful relative to a Crystal.
   * Returns a Boolean decision in <5ms.
   */
  static async verifyEdge(e, t) {
    const r = performance.now(), n = Y.computeSimHash(e), i = k.fromString(n), a = k.fromString(t.verification.canonical_hash), o = i.similarity(a);
    return {
      accepted: o >= 0.75,
      score: o,
      latency_ms: performance.now() - r
    };
  }
  /**
   * Multi-Point Check: verifies several fragments simultaneously.
   * Uses HDC Bundling to check "Contextual Resonace" of the entire stream.
   */
  static async auditStream(e, t) {
    if (e.length === 0) return !0;
    const r = k.fromString(t.verification.canonical_hash), n = e.map(
      (o) => k.fromString(Y.computeSimHash(o))
    );
    return k.bundle(n).similarity(r) >= 0.7;
  }
}
class Ws {
  /**
   * Streams a response with "Late-Correction" logic.
   */
  static async streamVerifiedVoice(e, t) {
    var o;
    const r = performance.now();
    if (!this.activeContext || this.activeContext.domain !== t) {
      const c = await Ks.retrieveSemanticallySimilar(e, t);
      this.activeContext = c[0] || null;
    }
    let n = !0, i = 1;
    if (this.activeContext) {
      const c = await Wi.verifyEdge(e, this.activeContext);
      n = c.accepted, i = c.score;
    }
    const a = {
      audio_buffer: `SONIC_WAVEFORM_OF(${e})`,
      is_verified: n,
      correction_needed: !n,
      metadata: {
        latency_ms: performance.now() - r,
        truth_resonance: i,
        context_id: (o = this.activeContext) == null ? void 0 : o.context_id
      }
    };
    return n || (console.warn("[SonicStream] 🚨 TRUTH_VIOLATION DETECTED MID-STREAM!"), this.triggerLateCorrection(e)), a;
  }
  static triggerLateCorrection(e) {
    console.log(`[SonicStream] Injecting Sonic Vaccine for violation: "${e}"`);
  }
}
K(Ws, "activeContext", null);
class ts {
  /**
   * Identifies "voids" in the current knowledge domain.
   * Uses HDC distribution analysis to find regions with low truth density.
   */
  static async detectKnowledgeGaps(e) {
    var o;
    console.log(`[RecursiveBrain] 🔍 Auditing Semantic Lattice for domain: ${e}...`);
    const { data: t } = await I.from("crystals").select("*").eq("domain", e);
    if (!t || t.length < 5)
      return ["general_overview", "core_entities", "primary_rules"];
    const r = t.map((c) => {
      var l;
      return k.fromString(((l = c.verification) == null ? void 0 : l.canonical_hash) || "");
    });
    k.bundle(r);
    const n = t.map((c) => c.intent.primary).join(`
- `), i = `
        ACT AS A SEMANTIC ANALYST.
        I have the following knowledge crystals for the domain '${e}':
        
        CURRENT KNOWLEDGE:
        - ${n}
        
        TASK:
        Identify 3 critical "Knowledge Gaps" or "Logical Voids" that are missing from this domain.
        What would a professional need to know that is NOT covered above?
        
        Return ONLY a JSON array of 3 string topics.
        `, a = await M.resilientCallLLM(i, "google/gemini-2.0-flash-exp:free", "Semantic Auditor");
    try {
      return JSON.parse(((o = a.content.match(/\[[\s\S]*\]/)) == null ? void 0 : o[0]) || "[]");
    } catch {
      return ["unknown_edge_case", "secondary_dependencies"];
    }
  }
  /**
   * Generates a "Probe Question" for a specific gap.
   */
  static async generateProbe(e, t) {
    return `Explain the details and critical rules regarding "${e}" within the ${t} context. Be extremely specific and fact-heavy.`;
  }
  /**
   * Performs a single "Learning Pulse".
   */
  static async learningPulse(e) {
    const r = (await this.detectKnowledgeGaps(e))[0];
    if (!r) return;
    console.log(`[RecursiveBrain] 💡 Found Gap: "${r}". Initiating Discovery...`);
    const n = await this.generateProbe(r, e), i = await M.resilientCallLLM(n, "anthropic/claude-3.5-sonnet", "Autonomous Discoverer");
    console.log("[RecursiveBrain] 💎 Crystallizing new discovery...");
    const a = await Ee.mineCrystal(i.content, {
      domain: e,
      author: { id: "recursive_brain", name: "Neural Bridge Self-Healing Engine", reputation: 0.95 }
    });
    await I.from("crystals").upsert(a), console.log(`[RecursiveBrain] ✅ Self-Healed: Gap "${r}" filled and verified.`);
  }
}
class wt {
  static start(e, t = 36e5) {
    if (this.intervals.has(e)) return;
    console.log(`[LearningLoop] 🚀 Starting Autonomous Evolution for [${e}]...`), ts.learningPulse(e).catch(console.error);
    const r = setInterval(() => {
      ts.learningPulse(e).catch(console.error);
    }, t);
    this.intervals.set(e, r);
  }
  static stop(e) {
    const t = this.intervals.get(e);
    t && (clearInterval(t), this.intervals.delete(e), console.log(`[LearningLoop] ⏹️ Stopped Evolution for [${e}].`));
  }
}
K(wt, "intervals", /* @__PURE__ */ new Map());
class ot {
  /**
   * Publishes a verified Crystal to the Global Ledger.
   * Knowledge is anonymized (author_id removed or masked).
   */
  static async publish(e) {
    var r;
    if (!((r = e.verification) != null && r.canonical_hash)) return;
    const t = {
      ...e,
      author_id: "anonymous_contributor",
      tags: [...e.tags || [], "global_contributed"]
    };
    console.log(`[GlobalCortex] 📢 Publishing knowledge to the collective: "${e.intent.primary}"`), await I.from("crystals").upsert({ ...t, is_global: !0 });
  }
  /**
   * Retrieves knowledge from the global pool using Mutual Information.
   * Knowledge is selected if it maximizes Information Gain relative to the query.
   */
  static async globalRetrieve(e) {
    const { Hypervector: t } = await Promise.resolve().then(() => At), { SemanticHasher: r } = await Promise.resolve().then(() => Hi);
    console.log(`[GlobalCortex] 🌌 CONSULTING GALACTIC LEDGER (MI-Retrieval) for: "${e}"...`);
    const { data: n } = await I.from("crystals").select("*").eq("is_global", !0);
    if (!n || n.length === 0) return [];
    const i = t.fromString(r.computeHolographicHash(e));
    return n.map((o) => {
      var h;
      const c = o, l = t.fromString(((h = c.verification) == null ? void 0 : h.canonical_hash) || ""), d = i.similarity(l) * l.getFisherInformation();
      return { crystal: c, infoGain: d };
    }).sort((o, c) => c.infoGain - o.infoGain).slice(0, 5).map((o) => o.crystal);
  }
}
class Js {
  /**
   * INFERENTIAL AUTO-CALIBRATION ⚖️🌀
   * 
   * Calculates the optimal SNR threshold for a domain by running
   * differential tests between verified truths and synthetic noise.
   */
  static async autoCalibrationLoop(e, t) {
    var a;
    if (t.length === 0) return 0.7;
    let r = 0;
    for (const o of t) {
      const c = k.fromString(((a = o.verification) == null ? void 0 : a.canonical_hash) || "");
      r += c.getEntropy();
    }
    const i = 0.5 + r / t.length * 0.45;
    return Math.min(Math.max(i, 0.5), 0.95);
  }
  /**
   * Calculates the optimal SNR threshold for a domain.
   * Delegates to auto-calibration if possible.
   */
  static getOptimalThreshold(e) {
    if (e.calibrated_threshold) return e.calibrated_threshold;
    const t = e.volatility * 0.5, r = e.avg_q * 0.1, n = 0.6 + t - r;
    return Math.min(Math.max(n, 0.55), 0.85);
  }
  /**
   * Computes the "Reality Stability Index" for a domain.
   */
  static calculateStability(e) {
    if (e.length === 0) return 0.5;
    const r = e.reduce((i, a) => {
      var o;
      return i + (((o = a.rlm_stats) == null ? void 0 : o.q_score) || 0.5);
    }, 0) / e.length, n = e.reduce((i, a) => {
      var o;
      return i + (((o = a.rlm_stats) == null ? void 0 : o.volatility) || 0.1);
    }, 0) / e.length;
    return r * (1 - n);
  }
}
const Rt = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  LogicTuner: Js
}, Symbol.toStringTag, { value: "Module" }));
class Ys {
  constructor(e = {}) {
    K(this, "domain");
    this.domain = e.domain || "general";
  }
  /**
   * GLOBAL INIT (The LangChain Killer)
   * Setup the entire system in one static call.
   */
  static init(e = {}) {
    const t = new Ys(e);
    return t.startAutonomousLearning(), console.log("[NeuralBridge] 🪐 Sovereign Omega Protocol initialized."), import("./dreaming_service-rDlzIJLQ.js").then((r) => r.DreamingService.startDreamingLoop()), Promise.resolve().then(() => Rt).then((r) => r.LogicTuner.autoCalibrationLoop(t.domain, [])), t;
  }
  /**
   * FLASH REMEMBER ⚡
   * Instantly ingests information using Regex+LSH (No Latency).
   * Sublimation happens in background if needed.
   */
  async remember(e, t = {}) {
    const r = await Ee.mineProtoCrystal(e, this.domain, t);
    return await I.from("crystals").upsert(r), ot.publish(r).catch(console.error), Ee.sublimateCrystal(r).then((n) => {
      I.from("crystals").upsert(n);
    }), r;
  }
  async ask(e) {
    var p, g, m, y, v;
    let r = await Ks.retrieveSemanticallySimilar(e, this.domain);
    if (r.length === 0 && (console.log("[NeuralBridge] 🌌 Local void detected. Consulting Galactic Cortex..."), r = await ot.globalRetrieve(e)), r.length === 0)
      throw new Error(`NO_CRYSTAL_FOUND: No verified truth exists locally or globally for domain '${this.domain}'.`);
    const n = (await I.from("crystals").select("usage_count", { count: "exact" })).count || 1e3, a = (await vt.rankCandidates(r, n, this.domain))[0], { StochasticEngine: o } = await import("./stochastic_engine-DQmcxaHP.js"), { FractalCompressor: c } = await import("./fractal_compressor-DVaEZe4I.js"), { SCPService: l } = await Promise.resolve().then(() => hr);
    console.log("[Bridge-Omega] ♾️ Applying Transfinite Purification to query...");
    const u = await o.processChaos(e);
    await c.compress(r.map((_) => JSON.stringify(_)).join(`
`)), await o.entropyBalancer(u.entropy) || console.warn("🛡️ [SINGULARITY] Cognitive Dissonance detected. Applying stabilization..."), l.getOptimalModel({ task: "verify", text: e, isCritical: !0 });
    const h = await ot.globalRetrieve(e);
    if (h.length > 0) {
      const _ = h[0], S = k.fromString(((p = a.verification) == null ? void 0 : p.canonical_hash) || ""), O = k.fromString(((g = _.verification) == null ? void 0 : g.canonical_hash) || ""), A = S.similarity(O);
      A < 0.6 && (console.warn(`[NeuralBridge] ⚠️ COGNITIVE DISSONANCE: Result '${a.context_id}' conflicts with Global Truth (${A.toFixed(4)})`), a.metadata = { ...a.metadata, global_sanity_clash: !0, sanity_score: A });
    }
    await Js.autoCalibrationLoop(this.domain, r);
    const f = zs.synthesizeMasterAnchor(e, r);
    return {
      content: a.description || "Truth extracted from vault.",
      crystal: a,
      proof_valid: !!((m = a.verification) != null && m.canonical_hash),
      anchor_prompt: f,
      metadata: {
        logic_score: ((y = a.rlm_stats) == null ? void 0 : y.q_score) || 1,
        domain: a.domain,
        author: (v = a.author) == null ? void 0 : v.id,
        ...a.metadata
      }
    };
  }
  /**
   * VOICE ASK (Sonic Reality Streaming) 🎙️
   * 
   * Optimizes for sub-50ms latency. Ideal for real-time voice apps.
   * Returns a SonicResponse with audio_buffer and verification status.
   */
  async voiceAsk(e) {
    return Ws.streamVerifiedVoice(e, this.domain);
  }
  /**
   * REINFORCE (Teach) 🎓
   * Give feedback to the system to improve future answers.
   */
  async learn(e, t) {
    const { data: r } = await I.from("crystals").select("*").eq("context_id", e).single();
    if (!r) return;
    let n = r;
    n = await vt.updateCrystalUtility(n, t ? 1 : -1, this.domain), await I.from("crystals").upsert(n);
  }
  /**
   * START AUTONOMOUS LEARNING 🚀
   * 
   * Activates the Self-Healing Brain for this domain.
   * The system will proactively find gaps and fill them in the background.
   */
  startAutonomousLearning(e) {
    wt.start(this.domain, e);
  }
  /**
   * STOP AUTONOMOUS LEARNING ⏹️
   */
  stopAutonomousLearning() {
    wt.stop(this.domain);
  }
}
export {
  G as A,
  Gi as C,
  Ys as N,
  vt as R,
  Gs as S,
  Ks as T,
  M as a,
  te as b,
  ct as c,
  cs as d,
  ce as e,
  Ee as f,
  We as g,
  Ve as h,
  Qi as i,
  At as j,
  Hi as k,
  Zi as l,
  I as s,
  ls as v
};
//# sourceMappingURL=index-DVUTQuLV.js.map
