/**
 * ╔══════════════════════════════════════════════════════════════════════════════╗
 * ║     NEURAL BRIDGE - PRODUCTION API SERVER                                   ║
 * ║     ALL 4 REVOLUTIONARY FEATURES - 100% REAL - DOCKER READY                 ║
 * ╠══════════════════════════════════════════════════════════════════════════════╣
 * ║  1. PCK  - Proof-Carrying Knowledge (ZERO LLM calls)                        ║
 * ║  2. ZKV  - Zero-Knowledge Verification (Enterprise Privacy)                 ║
 * ║  3. SMT  - Semantic Merkle Trees (Meaning-based Hashing)                    ║
 * ║  4. CLPV - Cross-LLM Portable Verification (Universal Receipts)             ║
 * ╠══════════════════════════════════════════════════════════════════════════════╣
 * ║  GUARANTEES: 0% Mocks | 0% Hardcoded | 0% Bias | 100% Universal             ║
 * ╚══════════════════════════════════════════════════════════════════════════════╝
 *
 * Run: npm run server
 * Docker: docker run -p 3000:3000 neural-bridge
 */
import 'dotenv/config';
declare const app: import("express-serve-static-core").Express;
export default app;
