"use strict";var l=Object.defineProperty;var p=(i,e,t)=>e in i?l(i,e,{enumerable:!0,configurable:!0,writable:!0,value:t}):i[e]=t;var o=(i,e,t)=>p(i,typeof e!="symbol"?e+"":e,t);Object.defineProperty(exports,Symbol.toStringTag,{value:"Module"});const g=require("./index-BcNYtQwH.cjs");class c{static async findBestJudges(e,t=3){var s;if(this.capabilityCache.has(e))return this.capabilityCache.get(e);console.log(`[ExpertRegistry] 🔍 Discovering elite models for domain: [${e}]...`);const n=`
        ACT AS AN AI CAPABILITY ARCHITECT.
        Identify the top 3 LLMs that have the HIGHEST ZERO-SHOT REASONING accuracy for the domain: "${e}".
        Consider models like: claude-3.5-sonnet, gpt-4o, o1, gemini-1.5-pro, deepseek-v3, nemotron.
        
        Return ONLY a JSON array of OpenRouter model strings.
        `;try{const r=await g.SCPService.resilientCallLLM(n,"google/gemini-2.0-flash-exp:free","Capability Auditor"),a=JSON.parse(((s=r.content.match(/\[[\s\S]*\]/))==null?void 0:s[0])||"[]");if(a.length>0)return this.capabilityCache.set(e,a.slice(0,t)),a.slice(0,t)}catch{console.warn("[ExpertRegistry] Meta-discovery failed. Falling back to robust defaults.")}return["anthropic/claude-3.5-sonnet","openai/gpt-4o","google/gemini-pro-1.5"]}static flush(){this.capabilityCache.clear()}}o(c,"capabilityCache",new Map);exports.ExpertRegistry=c;
//# sourceMappingURL=expert_registry-BkUz4LeI.cjs.map
