import type { DecisionReceipt } from './services/decision_receipts';
/**
 * Visualizer for Neural Bridge Decision Receipts.
 * Helps developers verify and display the "Zero Mock" proof in their own consoles or UIs.
 */
export declare class ReceiptVisualizer {
    /**
     * Render a receipt as a Markdown-formatted report string.
     * Useful for server logs or CLI output.
     */
    static toMarkdown(receipt: DecisionReceipt): string;
    /**
     * Render a receipt as an HTML string (for web dashboards).
     */
    static toHTML(receipt: DecisionReceipt): string;
}
