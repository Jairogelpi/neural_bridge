import type { HostAdapterV2 } from "./types";
export declare const ChatGPTV2: HostAdapterV2;
