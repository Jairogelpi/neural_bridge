import type { InputHandle } from "./types";
export declare function makeTextareaHandle(el: HTMLTextAreaElement): InputHandle;
export declare function makeContentEditableHandle(el: HTMLElement): InputHandle;
export declare function isEditableCandidate(el: Element): el is HTMLElement;
export declare function findBestInput(textareaCandidates: HTMLTextAreaElement[], contentEditableCandidates: HTMLElement[]): InputHandle | null;
