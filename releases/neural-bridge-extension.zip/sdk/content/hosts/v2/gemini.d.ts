import type { HostAdapterV2 } from "./types";
export declare const GeminiV2: HostAdapterV2;
