export type HostName = "chatgpt" | "gemini" | "claude" | "unknown";
export interface InputHandle {
    kind: "textarea" | "contenteditable";
    el: HTMLElement;
    setText(text: string): void;
    getText(): string;
    focus(): void;
}
export interface HostAdapterV2 {
    name: HostName;
    detect(): boolean;
    findInput(): InputHandle | null;
    clickSend(): boolean;
    findAssistantMessages(): HTMLElement[];
    getLastAssistantText(): string;
    waitForAssistantTurn(opts?: {
        timeoutMs?: number;
    }): Promise<string>;
    enableNetworkTap?(): Promise<void>;
    popLastNetworkAnswer?(): string | null;
    debugSnapshot(): HostDebugSnapshot;
}
export interface HostDebugSnapshot {
    host: HostName;
    url: string;
    inputKind?: string | null;
    lastAssistantLen?: number;
    assistantCount?: number;
}
