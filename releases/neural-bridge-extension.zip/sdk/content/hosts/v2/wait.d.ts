/**
 * Wait for text to stabilize (stop changing)
 * Uses polling instead of MutationObserver for reliability across hosts
 */
export declare function waitForStableText(getText: () => string, opts?: {
    timeoutMs?: number;
    stableMs?: number;
}): Promise<string>;
/**
 * Wait for new content to appear (different from initial)
 */
export declare function waitForNewContent(getText: () => string, initialText: string, opts?: {
    timeoutMs?: number;
    stableMs?: number;
}): Promise<string>;
/**
 * Wait using MutationObserver (more efficient but less reliable)
 */
export declare function waitForMutation(target: Node, opts?: {
    timeoutMs?: number;
    subtree?: boolean;
}): Promise<void>;
