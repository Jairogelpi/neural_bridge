import type { HostAdapterV2 } from "./types";
export declare const ClaudeV2: HostAdapterV2;
