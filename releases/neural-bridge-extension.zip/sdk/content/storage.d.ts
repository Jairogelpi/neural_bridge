import type { Transcript } from "../transcript/transcript";
import type { ContextCrystal } from "../core/scp_types";
export type BridgeCard = {
    id: string;
    created_at: string;
    platform: "chatgpt" | "gemini" | "claude" | "other";
    title: string;
    preview: string;
    transcript_id: string;
    context_id: string;
};
export declare function loadCards(): Promise<BridgeCard[]>;
export declare function saveCard(card: BridgeCard): Promise<void>;
export declare function saveTranscript(t: Transcript): Promise<void>;
export declare function loadTranscript(id: string): Promise<Transcript | null>;
export declare function saveCrystal(c: ContextCrystal): Promise<void>;
export declare function loadCrystal(id: string): Promise<ContextCrystal | null>;
export declare function getActiveContextId(): Promise<string | undefined>;
export declare function setActiveContextId(id: string): Promise<void>;
