export type ExpectedType = "boolean" | "enum" | "set" | "regex" | "short_text";
export interface Expected {
    type: ExpectedType;
    value: unknown;
}
export interface Invariant {
    id: string;
    kind: string;
    prompt: string;
    expected: Expected;
    weight: number;
    strict: boolean;
    tags?: string[];
    rationale?: string;
}
export interface VerifyResult {
    score: number;
    strictFailures: string[];
    perInvariant: Array<{
        id: string;
        score: number;
        reason: string;
    }>;
}
/**
 * Verify LLM answers against invariants
 * @param params.invariants - Array of invariants to check
 * @param params.parsed - Parsed JSON from challenge response { answers: {...}, ... }
 * @returns VerifyResult with score, strictFailures, and per-invariant details
 */
export declare function verifyAnswers(params: {
    invariants: Invariant[];
    parsed: Record<string, unknown>;
}): VerifyResult;
/**
 * Calculate scientific metrics for the verification
 * Returns SRI, PAC bounds, and fidelity badge
 */
export declare function calculateScientificMetrics(result: VerifyResult, invariantCount: number): {
    sri: number;
    pac_epsilon: number;
    fidelity_badge: string;
    pac_delta: number;
};
