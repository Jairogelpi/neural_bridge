export type TrustState = 'idle' | 'scanning' | 'verified' | 'warning' | 'blocked';
export interface FirewallVerdict {
    state: TrustState;
    sri: number;
    reason?: string | undefined;
    invariants?: Array<{
        id: string;
        passed: boolean;
        reason?: string;
    }>;
    features?: {
        pck: {
            enabled: boolean;
            llm_calls_saved: number;
            cost_saved: string;
        };
        zkv: {
            enabled: boolean;
            proofs_generated: number;
            data_protected: boolean;
        };
        smt: {
            enabled: boolean;
            contradictions_found: number;
            semantic_hash: string;
        };
        clpv: {
            enabled: boolean;
            receipts_generated: number;
            cross_llm_compatible: boolean;
        };
    };
    healing?: {
        needed: boolean;
        corrected_text: string;
        source_truth_id: string;
        reason: string;
    } | undefined;
    verification_time_ms?: number;
    pck_enabled?: boolean;
    llm_calls_saved?: number;
    cost_saved?: string;
}
export declare class FirewallAgent {
    private host;
    private activeDomain;
    private mountedCrystals;
    private mountedPCKs;
    private lastProcessedText;
    private checkInterval;
    private strictMode;
    private pckMode;
    private zkvMode;
    private smtMode;
    private totalLLMCallsSaved;
    private totalCostSaved;
    private totalZKProofs;
    private totalContradictionsFound;
    private lastSemanticHash;
    private lastZKProof;
    private lastSMT;
    private lastPortableReceipt;
    private totalPortableReceipts;
    private clpvMode;
    constructor();
    setConfig(config: {
        strictMode?: boolean;
        pckMode?: boolean;
        zkvMode?: boolean;
        smtMode?: boolean;
    }): void;
    getStats(): {
        pck: {
            enabled: boolean;
            llm_calls_saved: number;
            cost_saved: string;
        };
        zkv: {
            enabled: boolean;
            proofs_generated: number;
            data_protected: boolean;
        };
        smt: {
            enabled: boolean;
            contradictions_found: number;
            last_semantic_hash: string;
        };
    };
    private detectHost;
    mountDomainCrystals(): Promise<void>;
    startSilentMonitoring(onVerdict: (v: FirewallVerdict) => void): void;
    stop(): void;
    private pulse;
    /**
     * PCK Verification - ZERO external API calls
     * This is the revolutionary part that makes Neural Bridge unique
     */
    private verifyWithPCK;
    /**
     * SMT Analysis - Semantic Merkle Tree for contradiction detection
     * Hash of MEANING, not bytes
     */
    private analyzeWithSMT;
    /**
     * ZKV Proof Generation - Zero-Knowledge proof for enterprise privacy
     * Proves verification happened WITHOUT revealing source data
     */
    private generateZKProof;
    /**
     * CLPV Receipt Generation - Cross-LLM portable receipt
     * Works with GPT-4, Claude, Gemini, Llama - ANY LLM
     */
    private generatePortableReceipt;
    /**
     * Extract relevant context from the page for PCK compilation
     */
    private extractPageContext;
}
