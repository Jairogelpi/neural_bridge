import type { Transcript } from "../transcript/transcript";
import type { SaaSClient } from "../rlm/saas_client";
/**
 * Capture and Store using SaaS Engine.
 * This offloads the RLM loop to the cloud.
 */
export declare function captureAndStoreSaaS(params: {
    platform: "chatgpt" | "gemini" | "claude" | "other";
    saas: SaaSClient;
}): Promise<{
    transcript: Transcript;
    context_id: string;
    notes: string[];
}>;
