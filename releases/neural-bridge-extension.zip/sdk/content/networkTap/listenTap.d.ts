export declare function startTapListener(): void;
export declare function popLastTapText(): string | null;
export declare function peekLastTapText(): string | null;
