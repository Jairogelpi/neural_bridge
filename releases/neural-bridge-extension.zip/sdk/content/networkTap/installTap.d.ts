export declare function installNetworkTap(): Promise<void>;
