var y = Object.defineProperty;
var R = (c, t, e) => t in c ? y(c, t, { enumerable: !0, configurable: !0, writable: !0, value: e }) : c[t] = e;
var d = (c, t, e) => R(c, typeof t != "symbol" ? t + "" : t, e);
import { g as m, a as h } from "./index-kfgM1LPn.js";
class A {
  // Target 80% reduction per layer
  /**
   * Entry point for Fractal Compression.
   * Recursively shrinks context until it fits the target size or hits recursion depth.
   */
  static async compress(t, e = 0) {
    if (t.length <= this.MAX_TOKEN_TARGET || e > 4)
      return t;
    console.log(`[Fractal] 🌀 Layer ${e}: Distilling ${Math.round(t.length / 1024)}KB into Meta-Invariants...`);
    const i = await this.shardReality(t), s = m({ task: "compile" }), l = i.map((r) => this.distillToAxioms(r, s, e)), a = (await Promise.all(l)).join(`

--- LAYER SEPARATOR ---

`), o = await this.fuseAndRefine(a, s, e);
    return this.compress(o, e + 1);
  }
  /**
   * Extracts absolute logic ("Invariants") from a text chunk.
   */
  static async distillToAxioms(t, e, i) {
    const s = `
        ACT AS A FRACTAL ENCODER (Layer ${i}).
        Goal: Extract the "Axiomatic Core" of this context.
        
        Rules:
        1. NO SUMMARIES. Use high-density bullet points.
        2. Identify INVARIANTS: Facts that MUST be true for this reality to remain consistent.
        3. Identify RELATIONSHIPS: How entities interact.
        4. Identify CONSTRAINTS: Forbidden actions or impossible states.
        
        SHARD DATA:
        "${t.substring(0, 1e4)}..."
        
        Output ONLY the extracted logic. Preserve technical precision.
        `;
    return (await h.resilientCallLLM(s, e, "You are a Fractal Distiller.")).content.trim();
  }
  /**
   * Fuses multiple axiomatic shards into a coherent "Meta-Reality".
   */
  static async fuseAndRefine(t, e, i) {
    const s = `
        ACT AS A SEMANTIC FUSION ENGINE.
        You are looking at several abstraction shards from Layer ${i}.
        
        Goal: Merge these into a single, cohesive "Meta-Invariant" block.
        Identify redundancies and collapse them. 
        Focus on the "Platonic Ideal" of the knowledge.
        
        SHARDS:
        ${t.substring(0, 2e4)}
        
        Return the Refined Meta-Reality.
        `;
    return (await h.resilientCallLLM(s, e, "You are a Reality Synthesizer.")).content.trim();
  }
  /**
   * TOPOLOGICAL SHARDING: Shards reality at Vector Phase Shifts.
   * Uses HDC Trajectory Analysis to identify semantic boundaries.
   */
  static async shardReality(t) {
    const { SemanticHasher: e } = await import("./index-kfgM1LPn.js").then((o) => o.k), { Hypervector: i } = await import("./index-kfgM1LPn.js").then((o) => o.j);
    console.log("[Fractal] 📐 Analyzing Topological Trajectory for optimal sharding...");
    const s = [], l = t.split(/\s+/);
    let n = [], a = i.random();
    for (const o of l)
      if (n.push(o), n.length % 50 === 0 && n.length > 100) {
        const r = n.join(" "), u = i.fromString(e.computeHolographicHash(r));
        a.similarity(u) < 0.6 && (s.push(r), n = [], a = u);
      }
    return n.length > 0 && s.push(n.join(" ")), s;
  }
  /**
   * INTEGRITY CHECK (Recall Challenge)
   * Proof that the compression is "Zero-Loss" in a logical sense.
   */
  static async verifyIntegrity(t, e) {
    const i = m({ task: "verify" }), s = `Generate 3 hard questions based on deep facts in this text: "${t.substring(0, 5e3)}"`, n = (await h.resilientCallLLM(s, i)).content.split(`
`).filter((o) => o.includes("?"));
    let a = 0;
    for (const o of n) {
      const r = await h.resilientCallLLM(
        `Use ONLY this context to answer: ${e}
Question: ${o}`,
        i
      );
      !r.content.toLowerCase().includes("i don't know") && !r.content.toLowerCase().includes("not mentioned") && a++;
    }
    return a / (n.length || 1) * 100;
  }
}
d(A, "MAX_TOKEN_TARGET", 3e3), // Target characters for the final core
d(A, "LAYER_REDUCTION_FACTOR", 0.8);
export {
  A as FractalCompressor
};
//# sourceMappingURL=fractal_compressor-CZ0MuIYX.js.map
