import { b as c, a as l } from "./index-CIIX_jvs.js";
class d {
  /**
   * BREEDING (Sexual Reproduction) 🌹
   * Combines two high-performing crystals to create a superior offspring.
   * Strategy:
   * - Intent: Synthesis of both.
   * - Constraints: Crossover (Random mix from both).
   * - Evidence: Union of non-duplicate evidence.
   */
  static breed(t, n) {
    var i, a;
    console.log(`[EvolutionEngine] 🌹 Breeding Generation ${t.version} & ${n.version}...`);
    const o = this.crossoverConstraints(t.constraints || [], n.constraints || []), e = {
      ...t.intent,
      primary: `${t.intent.primary} + ${n.intent.primary} [SYNTHESIS]`,
      status: c.ACTIVE
    };
    return {
      ...t,
      // Inherit base properties from A
      context_id: `child_${Date.now()}_gen`,
      version: `${parseInt(t.version) + 1}.0.0`,
      intent: e,
      constraints: o,
      // Inherit RLM stats (Start with parents' average potential)
      rlm_stats: {
        q_score: ((((i = t.rlm_stats) == null ? void 0 : i.q_score) || 0.5) + (((a = n.rlm_stats) == null ? void 0 : a.q_score) || 0.5)) / 2,
        usage_count: 0,
        last_reward_at: (/* @__PURE__ */ new Date()).toISOString(),
        volatility: 0.1
        // High volatility initially (Newborn)
      },
      created_at: (/* @__PURE__ */ new Date()).toISOString(),
      verification: {
        ...t.verification,
        canonical_hash: "PENDING_REHASH"
        // Needs re-verification
      }
    };
  }
  /**
   * NATURAL SELECTION (The Reaper) 💀
   * Identifies weak crystals that should be culled from the population.
   * Criteria: High Usage but Low Q-Score (Proven to be bad).
   */
  static reap(t) {
    const n = t.filter((o) => {
      const e = o.rlm_stats || { q_score: 0.5, usage_count: 0 };
      return e.usage_count > 10 && e.q_score < 0.2;
    });
    return console.log(`[EvolutionEngine] 💀 Reaping ${n.length} weak crystals.`), n.map((o) => o.context_id);
  }
  // ========== GENETIC HELPERS ==========
  static crossoverConstraints(t, n) {
    const o = [...t, ...n];
    return Array.from(new Map(o.map((s) => [s.id, s])).values()).filter(() => Math.random() > 0.1);
  }
  // ========== LEGACY PROMPT EVOLUTION ==========
  /**
   * Evolve a better prompt strategy based on failure context.
   * @param intent The original user intent
   * @param currentPrompt The prompt that failed (or performed poorly)
   * @param reliabilityScore The low score that triggered evolution
   * @returns The mutated, optimized prompt (or null if evolution failed)
   */
  static async evolve(t, n, o) {
    console.log(`
🧬 [EvolutionEngine] DETECTED WEAKNESS (Score: ${o}). Initiating Evolution...`);
    try {
      const e = `
            ACT AS AN AI EVOLUTION ENGINEER.
            
            CONTEXT:
            User Intent: "${t}"
            Failed Prompt: "${n}"
            Reliability Score: ${o} (Too Low)

            TASK:
            Analyze WHY this prompt failed to generate a valid Crystal.
            Is it ambiguous? Missing constraints? Too complex?
            
            Return a single sentence diagnosis.
            `;
      console.log("🔬 [EvolutionEngine] Diagnosing failure logic...");
      const i = (await l.resilientCallLLM(e, "anthropic/claude-3-haiku", "Evolution Engineer")).content;
      console.log(`   > Diagnosis: ${i.substring(0, 100)}...`);
      const a = `
            ACT AS A GENETIC ALGORITH FOR PROMPTS.

            DIAGNOSIS: ${i}
            ORIGINAL PROMPT: "${n}"

            TASK:
            Rewrite the ORIGINAL PROMPT to fix the diagnosed issue.
            - Make it more robust.
            - Add explicit constraints if needed.
            - Optimize for machine-readability.

            Return ONLY the new prompt text. Do not explain.
            `;
      console.log("🧪 [EvolutionEngine] Mutating prompt DNA...");
      const r = (await l.resilientCallLLM(a, "google/gemini-2.0-flash-exp:free", "Genetic Mutation Algo")).content;
      return r && r.length > 10 ? (console.log("✨ [EvolutionEngine] EVOLUTION COMPLETE. New Strategy Generated."), r) : null;
    } catch (e) {
      return console.error("💀 [EvolutionEngine] Evolution failed:", e), null;
    }
  }
}
export {
  d as EvolutionEngine
};
//# sourceMappingURL=evolution_engine-BYvJr0pB.js.map
