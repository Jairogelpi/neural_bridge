import { Tool } from "@langchain/core/tools";
import type { Crystal } from "../types/crystal_format";
export interface NeuralBridgeToolParams {
    apiKey: string;
    crystal: Crystal;
    mode?: 'fast' | 'strict';
}
/**
 * Neural Bridge Safety Tool for LangChain.
 * Use this to verify LLM outputs within a Chain or Agent.
 */
export declare class NeuralBridgeSafetyTool extends Tool {
    name: string;
    description: string;
    private nb;
    private crystal;
    private mode;
    constructor(params: NeuralBridgeToolParams);
    /**
     * Input should be a JSON string with "question" and "answer".
     */
    _call(input: string): Promise<string>;
}
