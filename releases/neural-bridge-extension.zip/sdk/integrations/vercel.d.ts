import { generateText, streamText } from "ai";
import type { Crystal } from "../types/crystal_format";
export interface NeuralBridgeVercelParams {
    apiKey: string;
    crystal: Crystal;
    failOnBlock?: boolean;
}
/**
 * Neural Bridge Middleware for Vercel AI SDK.
 * Wraps the generateText function to add verification.
 */
export declare function generateTextWithBridge(params: Parameters<typeof generateText>[0] & {
    bridge: NeuralBridgeVercelParams;
}): Promise<any>;
/**
 * Stream wrapper - Verifies AFTER stream completes (Async Verification).
 * Note: Real-time interruption requires chunk-based invariant checking which is advanced.
 * This implementation verifies the FULL response at the end for auditing.
 */
export declare function streamTextWithAudit(params: Parameters<typeof streamText>[0] & {
    bridge: NeuralBridgeVercelParams;
}): Promise<any>;
