/**
 * HYPERDIMENSIONAL COMPUTING (HDC) CORE 🌌
 *
 * Implements "Holographic Reduced Representations" (HRR) using 4096-bit Hypervectors.
 * This math allows us to encode infinite semantic meaning into fixed-size binary vectors
 * with O(N) operations (XOR, Shift, Add), crushing RAG's O(N^2) matrix multiplication.
 *
 * Dimensions: 4096 (D)
 * Implementation: Uint32Array(128) -> 128 * 32 bits = 4096 bits.
 */
export declare class Hypervector {
    data: Uint32Array;
    constructor(data?: Uint32Array);
    /**
     * Creates a random hypervector (Independent & Identically Distributed - i.i.d)
     * Each bit has 50% chance of being 0 or 1.
     * This ensures orthogonality between unrelated concepts.
     */
    static random(): Hypervector;
    /**
     * Binds this vector with another using XOR (Involutory).
     * Used for Role-Filler pairs (e.g., Action * Purchase).
     */
    bind(other: Hypervector): Hypervector;
    /**
     * UNBIND (Reasoning) 🧠
     * Queries the structure.
     * If C = A * B, then C.unbind(A) = B.
     * Since XOR is self-inverse, this is functionally identical to bind(),
     * but semantically distinct for "Question Answering".
     */
    unbind(other: Hypervector): Hypervector;
    /**
     * ARITHMETICAL SUPERPOSITION (HDC 2.0) 🌌📈
     *
     * Instead of raw binary majority, we use weighted arithmetic bundling.
     * This allows us to "sum" realities with different weights (e.g., trust scores).
     * For now, we use a bit-wise counter to simulate a "graded" consensus.
     */
    static bundle(vectors: Hypervector[]): Hypervector;
    /**
     * Permutation (Rotation) Π
     * Used to encode sequence/order.
     * permute(A) != A.
     */
    /**
     * Permutation (Rotation) Π
     *
     * RIGOROUS 4096-BIT CYCLIC SHIFT 🔄
     * Shifts every bit in the 128-word array as a single contiguous 4096-bit register.
     * This is essential for sequence encoding (e.g., A -> B != B -> A).
     */
    permute(shifts?: number): Hypervector;
    /**
     * Dot Product (Hamming Similarity)
     * Measures the overlap between two vectors.
     */
    dotProduct(other: Hypervector): number;
    /**
     * Similarity Metric (Normalized Hamming Distance)
     * Returns 0.0 (Orthogonal/Different) to 1.0 (Identical).
     */
    similarity(other: Hypervector): number;
    toString(): string;
    static fromString(hex: string): Hypervector;
    /**
     * SPARSE DISTRIBUTED REPRESENTATION (SDR) THINNING 🧠🧬
     *
     * Mimics the human neocortex by reducing active bits to ~2% (Sparse).
     * This exponentially increases the system's ability to distinguish between
     * similar concepts and makes it virtually immune to noise.
     */
    static sdrThinning(v: Hypervector, sparsity?: number): Hypervector;
    /**
     * OVERLAP ⋂
     *
     * The SDR equivalent of Similarity.
     * Measures the absolute intersection of active bits.
     */
    /**
     * OVERLAP ⋂
     *
     * The SDR equivalent of Similarity.
     * Measures the absolute intersection of active bits.
     */
    static overlap(a: Hypervector, b: Hypervector): number;
    /**
     * CIRCULAR CONVOLUTION (*)
     *
     * HDC 3.0: High-order binding.
     * Allows recursive nesting of concepts without semantic collapse.
     * Implemented via bit-wise circular shifts and XOR superposition.
     */
    static bind(a: Hypervector, b: Hypervector): Hypervector;
    /**
     * CIRCULAR UNBINDING (/)
     *
     * If R = A * B, then B ≈ R / A.
     * Reconstitutes the original concept from a bound relationship.
     */
    static unbind(bound: Hypervector, basis: Hypervector): Hypervector;
    /**
     * SHANNON ENTROPY (H) 📉
     *
     * Calculates the information density of the hypervector.
     * H = -p*log2(p) - (1-p)*log2(1-p)
     */
    getEntropy(): number;
    /**
     * FISHER INFORMATION (F) 🏛️
     *
     * Measures the "Certainty" of the vector.
     */
    getFisherInformation(): number;
}
