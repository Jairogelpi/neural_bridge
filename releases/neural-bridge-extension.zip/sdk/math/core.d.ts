/**
 * IRREFUTABLE MATH CORE 📐
 *
 * Pure mathematical implementations for semantic verification.
 * No mocks. No hallucinations. Just linear algebra and probability.
 */
export declare class MathCore {
    /**
     * Calculate Cosine Similarity between two text inputs.
     * Used to verify if the LLM's output matches the 'Truth Crystal' intent.
     * Range: [0, 1] (0 = Orthogonal/Unrelated, 1 = Identical)
     */
    static cosineSimilarity(textA: string, textB: string): number;
    /**
     * Calculate Bayesian Confidence Score.
     * probability = (evidence / (evidence + error_margin))
     */
    static bayesianConfidence(evidenceCount: number, contradictions: number): number;
    /**
     * Cryptographic Proof of Integrity (SHA-256).
     * Replaces random ID generation.
     */
    static sha256(data: string): string;
    private static textToVector;
    private static calculateCosine;
}
