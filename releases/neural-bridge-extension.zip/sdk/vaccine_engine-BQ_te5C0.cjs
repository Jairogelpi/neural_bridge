"use strict";Object.defineProperty(exports,Symbol.toStringTag,{value:"Module"});const s=require("./index-BY80Pwat.cjs");class v{static async synthesizeFromContradiction(n,t){console.log(`[VaccineEngine] 💉 Analyzing contradiction for context ${n.context_id}...`);const{SemanticHasher:c}=await Promise.resolve().then(()=>require("./index-BY80Pwat.cjs")).then(h=>h.semantic_hashing),{Hypervector:o}=await Promise.resolve().then(()=>require("./index-BY80Pwat.cjs")).then(h=>h.hypervector),l=o.fromString(c.computeHolographicHash(t.claim_a)),g=o.fromString(c.computeHolographicHash(t.claim_b)),i=l.bind(g),e=await s.Attestation.realSHA256(i.toString()),{data:r}=await s.supabase.from("vaccines").select("*").eq("error_signature_hash",e).single();if(r)return console.log("[VaccineEngine] ⚡ Vaccine already exists for this pattern. Strengthening..."),await s.supabase.rpc("increment_vaccine_potency",{vid:r.vaccine_id}),r;const u=`
        LOGICAL DNA EXTRACTION
        
        A contradiction was found in an AI-generated knowledge crystal:
        CLAIM A: "${t.claim_a}"
        CLAIM B: "${t.claim_b}"
        
        Task: Identify the underlying LOGICAL FALLACY (e.g., Causal Reversal, Temporal Inconsistency, Scope Creep).
        Then, write a UNIVERSAL RULE (Meta-Invariant) that prevents this specific logical error.
        
        Return JSON:
        {
            "fallacy": "string",
            "rule": "High-level human readable rule",
            "logical_constraint": "Precise mathematical/logical constraint",
            "pattern_to_block": "Semantic pattern that triggers this error"
        }
        `,p=await s.SCPService.resilientCallLLM(u,"google/gemini-pro","You are a Formal Logician.");let a;try{a=JSON.parse(p.content)}catch{return null}const m={error_signature_hash:e,fallacy_type:a.fallacy,meta_invariant:{rule:a.rule,logical_constraint:a.logical_constraint,prohibited_pattern:a.pattern_to_block},context_domain:n.domain||"general"},{error:_}=await s.supabase.from("vaccines").insert({...m,meta_invariant:m.meta_invariant});if(_)return console.error("[VaccineEngine] ❌ Failed to store vaccine:",_.message),null;console.log(`[VaccineEngine] ✅ New Vaccine synthesized: ${a.fallacy} ("${a.rule}")`);const{Sentinel:d}=await Promise.resolve().then(()=>require("./index-BY80Pwat.cjs")).then(h=>h.sentinel);return await d.emit({type:"VACCINE_SYNTHESIS",severity:"info",message:`New Vaccine synthesized for ${a.fallacy}: "${a.rule}"`,details:{fallacy:a.fallacy,rule:a.rule,domain:n.domain}}),await d.triggerEntanglement(m.vaccine_id||e),m}static async synthesizePrecognitiveVaccine(n,t){console.log(`[VaccineEngine] 🔮 Precognitive synthesis for predicted error: "${t}"`);const c=`PRECOGNITIVE_FAILURE: [${t}] in DOMAIN: [${n.domain}]`,o=await(await Promise.resolve().then(()=>require("./index-BY80Pwat.cjs")).then(r=>r.attestation)).Attestation.realSHA256(c),l=`
        PRECOGNITIVE DNA EXTRACTION
        
        The Oracle predicted a future failure in an AI knowledge crystal:
        PREDICTED FAILURE: "${t}"
        DOMAIN: "${n.domain}"
        
        Task: Identify the underlying LOGICAL FALLACY that would cause this.
        Write a UNIVERSAL RULE (Meta-Invariant) to BLOCK this failure before it ever happens.
        
        Return JSON:
        {
            "fallacy": "string",
            "rule": "High-level human readable rule",
            "logical_constraint": "Precise mathematical/logical constraint",
            "pattern_to_block": "Semantic pattern that triggers this error"
        }
        `,g=await s.SCPService.resilientCallLLM(l,"google/gemini-pro","You are a Precognitive Logician.");let i;try{i=JSON.parse(g.content)}catch{return null}const e={error_signature_hash:o,fallacy_type:i.fallacy,meta_invariant:{rule:i.rule,logical_constraint:i.logical_constraint,prohibited_pattern:i.pattern_to_block},context_domain:n.domain||"general"};return await s.supabase.from("vaccines").insert({...e,meta_invariant:e.meta_invariant}),console.log(`[VaccineEngine] 💉 PRE-IMMUNIZED: System is now protected against "${i.fallacy}" (Oracle Prediction).`),e}static async getActiveGuards(n,t){const{SemanticHasher:c}=await Promise.resolve().then(()=>require("./index-BY80Pwat.cjs")).then(e=>e.semantic_hashing),{data:o,error:l}=await s.supabase.from("vaccines").select("*").eq("context_domain",t).limit(20);if(l||!o||o.length===0)return[];const g=c.computeHolographicHash(n);return o.map(e=>{var a;const r=((a=e.meta_invariant)==null?void 0:a.prohibited_pattern)||e.fallacy_type,u=c.computeHolographicHash(r),p=c.holographicSimilarity(g,u);return{vaccine:e,similarity:p}}).filter(e=>e.similarity>.4).sort((e,r)=>r.similarity-e.similarity).slice(0,5).map(e=>e.vaccine)}}exports.VaccineEngine=v;
//# sourceMappingURL=vaccine_engine-BQ_te5C0.cjs.map
