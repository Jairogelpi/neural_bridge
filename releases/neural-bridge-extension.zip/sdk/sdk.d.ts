/**
 * Neural Bridge SDK (Official Reference Implementation)
 *
 * This is the public entry point for developers integrating the
 * Semantic Context Protocol (SCP) into their own AI applications.
 *
 * Usage:
 * import { NeuralBridge, SCP } from '@neural-bridge/sdk';
 */
import type { CrystalExecutionResult } from './services/crystal_runtime';
import type { Crystal } from './types/crystal_format';
import type { DecisionReceipt } from './services/decision_receipts';
import { ReceiptVisualizer } from './visualizer';
import { type ProofCarryingKnowledge } from './pck';
import { type ZKProof, type ZKVerificationResult } from './zkv';
import { type SemanticMerkleTree, type SemanticComparisonResult } from './smt';
import { type PortableReceipt, type CrossVerificationResult } from './clpv';
export type { CrystalExecutionResult } from './services/crystal_runtime';
export type { VerificationResult } from './services/llm';
export type { DecisionReceipt } from './services/decision_receipts';
export type { ProofCarryingKnowledge } from './pck';
export type { ZKProof, ZKVerificationResult } from './zkv';
export type { SemanticMerkleTree, SemanticComparisonResult } from './smt';
export type { PortableReceipt, CrossVerificationResult } from './clpv';
export interface SDKConfig {
    apiKey?: string;
    cloudUrl?: string;
    mode?: 'local' | 'cloud' | 'hybrid' | 'pck' | 'zkv';
}
/**
 * The Standard Neural Bridge Client
 * Supports both Local (Private) and Cloud (Enterprise) execution.
 */
export declare class NeuralBridge {
    private config;
    private cloud?;
    constructor(config?: SDKConfig);
    /**
     * Compile raw text (PDFs, protocols, laws) into a Verifiable Crystal.
     * Uses Cloud Compiler if available for maximum quality (RLM Loop).
     */
    compile(content: string, domain?: string): Promise<Crystal>;
    /**
     * Verify an LLM response against a Crystal.
     * This is the "Shield" function to wrap your LLM calls with.
     */
    verify(params: {
        crystal: Crystal;
        question: string;
        answer: string;
        mode?: 'fast' | 'strict';
    }): Promise<CrystalExecutionResult>;
    /**
     * Register a Knowledge Author Identity.
     * Required to earn Reputation Scores on the network.
     */
    registerIdentity(name: string, handle: string): Promise<unknown>;
    /**
     * Cryptographically verify a Decision Receipt.
     * This proves the verification actually happened and wasn't faked.
     */
    verifyReceipt(receipt: DecisionReceipt): Promise<boolean>;
    /**
     * Validate if a JSON object is a valid Crystal (Schema Check + Hash Verification)
     */
    validateCrystal(data: unknown): Promise<{
        valid: boolean;
        errors: string[];
    }>;
    /**
     * Compile source document into Proof-Carrying Knowledge.
     * The PCK contains embedded proofs - verification costs ZERO API calls.
     *
     * @example
     * const pck = nb.compilePCK(gdprText, 'law');
     * // Later, verify any answer with ZERO cost:
     * const result = nb.verifyWithPCK(pck, llmAnswer);
     */
    compilePCK(source: string, domain?: string): ProofCarryingKnowledge;
    /**
     * Verify an answer using Proof-Carrying Knowledge.
     * THIS IS THE REVOLUTIONARY PART: Zero external API calls.
     *
     * @returns Verification result with confidence score
     */
    verifyWithPCK(pck: ProofCarryingKnowledge, answer: string): {
        valid: boolean;
        confidence: number;
        supported_claims: string[];
        unsupported_claims: string[];
        contradictions: string[];
        llm_calls_made: 0;
        verification_time_ms: number;
    };
    /**
     * Verify PCK integrity - ensure proofs haven't been tampered with.
     */
    verifyPCKIntegrity(pck: ProofCarryingKnowledge): {
        valid: boolean;
        checks_performed: number;
        failed_checks: string[];
    };
    /**
     * Create a Zero-Knowledge Proof for an answer.
     * ENTERPRISE FEATURE: Verify AI outputs without exposing proprietary data.
     *
     * @param source - CONFIDENTIAL source document (NEVER leaves your system)
     * @param answer - The LLM answer to verify
     * @param domain - Knowledge domain
     * @returns ZK proof that can be shared without revealing source
     */
    createZKProof(params: {
        source: string;
        answer: string;
        domain: string;
        constraints?: Array<{
            type: string;
            value: unknown;
        }>;
    }): Promise<ZKProof>;
    /**
     * Verify a ZK proof WITHOUT seeing the source document.
     * The verifier learns ONLY: Is the answer correct? (yes/no + confidence)
     * The verifier does NOT learn: Source content, verification logic
     */
    verifyZKProof(proof: ZKProof, answer?: string): Promise<ZKVerificationResult>;
    /**
     * Full ZKV workflow: Prove and verify in one call.
     * Demonstrates complete zero-knowledge verification pipeline.
     */
    proveAndVerifyZK(params: {
        source: string;
        answer: string;
        domain: string;
        constraints?: Array<{
            type: string;
            value: unknown;
        }>;
    }): Promise<{
        proof: ZKProof;
        verification: ZKVerificationResult;
        source_revealed: false;
        logic_revealed: false;
    }>;
    /**
     * Build a Semantic Merkle Tree from text.
     * Creates a hash of MEANING, not bytes.
     */
    buildSemanticTree(text: string): SemanticMerkleTree;
    /**
     * Compare two documents semantically.
     * Detects paraphrases, contradictions, and plagiarism.
     */
    compareSemantics(text1: string, text2: string): SemanticComparisonResult;
    /**
     * Verify a claim against a semantic truth tree.
     */
    verifyClaimAgainstTree(smt: SemanticMerkleTree, claim: string): {
        found: boolean;
        semantic_match: boolean;
        confidence: number;
    };
    /**
     * Get audit trail for a semantic tree.
     */
    getSemanticAuditTrail(smt: SemanticMerkleTree): {
        tree_id: string;
        root_hash: string;
        claims: Array<{
            canonical: string;
            hash: string;
        }>;
        verification_path: string[];
    };
    /**
     * Create a portable receipt from any LLM response.
     * The receipt works with GPT-4, Claude, Gemini, Llama - ANY model.
     */
    createPortableReceipt(params: {
        question: string;
        answer: string;
        llm?: string;
    }): PortableReceipt;
    /**
     * Verify a portable receipt.
     * Works regardless of which LLM created the original response.
     */
    verifyPortableReceipt(receipt: PortableReceipt, answer?: string): CrossVerificationResult;
    /**
     * Cross-verify: Compare a receipt from one LLM against another LLM's response.
     * Detects if different LLMs agree on the same facts.
     */
    crossVerifyLLMs(params: {
        original_receipt: PortableReceipt;
        new_answer: string;
        new_llm: string;
    }): CrossVerificationResult;
    /**
     * Check if a receipt is portable to a specific LLM.
     */
    isReceiptPortableTo(receipt: PortableReceipt, targetLLM: string): boolean;
}
/**
 * Direct access to Protocol Utilities
 */
export declare const SCP: {
    Schema: {
        $schema: string;
        title: string;
        type: string;
        required: string[];
        properties: {
            scp_version: {
                type: string;
                pattern: string;
                description: string;
            };
            context_id: {
                type: string;
                minLength: number;
                description: string;
            };
            created_at: {
                type: string;
                format: string;
                description: string;
            };
            name: {
                type: string;
                description: string;
            };
            description: {
                type: string;
                description: string;
            };
            domain: {
                type: string;
                description: string;
            };
            source: {
                type: string;
                required: string[];
                properties: {
                    platform: {
                        type: string;
                    };
                    url: {
                        type: string;
                    };
                    timestamp: {
                        type: string;
                        format: string;
                    };
                    model: {
                        type: string;
                    };
                    creator: {
                        type: string;
                    };
                };
            };
            intent: {
                type: string;
                required: string[];
                properties: {
                    primary: {
                        type: string;
                    };
                    status: {
                        type: string;
                        enum: string[];
                    };
                    secondary: {
                        type: string;
                        items: {
                            type: string;
                        };
                    };
                    limitations: {
                        type: string;
                        items: {
                            type: string;
                        };
                    };
                };
            };
            constraints: {
                type: string;
                items: {
                    type: string;
                    required: string[];
                    properties: {
                        id: {
                            type: string;
                        };
                        rule: {
                            type: string;
                            enum: string[];
                        };
                        value: {
                            type: string;
                        };
                        rationale: {
                            type: string;
                        };
                        severity: {
                            type: string;
                            enum: string[];
                        };
                        reference: {
                            type: string;
                        };
                    };
                };
            };
            entities: {
                type: string;
                items: {
                    type: string;
                    required: string[];
                    properties: {
                        name: {
                            type: string;
                        };
                        type: {
                            type: string;
                        };
                        category: {
                            type: string;
                        };
                        attributes: {
                            type: string;
                        };
                        relationships: {
                            type: string;
                            items: {
                                type: string;
                                properties: {
                                    type: {
                                        type: string;
                                    };
                                    target: {
                                        type: string;
                                    };
                                };
                            };
                        };
                    };
                };
            };
            evidence: {
                type: string;
                items: {
                    type: string;
                    required: string[];
                    properties: {
                        type: {
                            type: string;
                            enum: string[];
                        };
                        content: {
                            type: string;
                        };
                        source: {
                            type: string;
                        };
                        timestamp: {
                            type: string;
                        };
                        confidence: {
                            type: string;
                            minimum: number;
                            maximum: number;
                        };
                    };
                };
            };
            verification: {
                type: string;
                required: string[];
                properties: {
                    canonical_hash: {
                        type: string;
                    };
                    semantic_invariants: {
                        type: string;
                        items: {
                            type: string;
                            required: string[];
                        };
                    };
                    policy: {
                        type: string;
                        required: string[];
                    };
                };
            };
            dependencies: {
                type: string;
                items: {
                    type: string;
                    required: string[];
                    properties: {
                        crystal_id: {
                            type: string;
                        };
                        version: {
                            type: string;
                        };
                        type: {
                            type: string;
                            enum: string[];
                        };
                        scope: {
                            type: string;
                            enum: string[];
                        };
                        reason: {
                            type: string;
                        };
                    };
                };
            };
            version: {
                type: string;
                pattern: string;
            };
            tier: {
                type: string;
                enum: string[];
            };
            author: {
                type: string;
                required: string[];
                properties: {
                    id: {
                        type: string;
                    };
                    name: {
                        type: string;
                    };
                    reputation: {
                        type: string;
                        minimum: number;
                        maximum: number;
                    };
                    verified_credentials: {
                        type: string;
                        items: {
                            type: string;
                        };
                    };
                };
            };
            supersedes: {
                type: string;
            };
            deprecated: {
                type: string;
            };
            tags: {
                type: string;
                items: {
                    type: string;
                };
            };
            extensions: {
                type: string;
            };
            metadata: {
                type: string;
            };
        };
        additionalProperties: boolean;
    };
    Format: {
        version: string;
        schema: {
            $schema: string;
            title: string;
            type: string;
            required: string[];
            properties: {
                scp_version: {
                    type: string;
                    pattern: string;
                    description: string;
                };
                context_id: {
                    type: string;
                    minLength: number;
                    description: string;
                };
                created_at: {
                    type: string;
                    format: string;
                    description: string;
                };
                name: {
                    type: string;
                    description: string;
                };
                description: {
                    type: string;
                    description: string;
                };
                domain: {
                    type: string;
                    description: string;
                };
                source: {
                    type: string;
                    required: string[];
                    properties: {
                        platform: {
                            type: string;
                        };
                        url: {
                            type: string;
                        };
                        timestamp: {
                            type: string;
                            format: string;
                        };
                        model: {
                            type: string;
                        };
                        creator: {
                            type: string;
                        };
                    };
                };
                intent: {
                    type: string;
                    required: string[];
                    properties: {
                        primary: {
                            type: string;
                        };
                        status: {
                            type: string;
                            enum: string[];
                        };
                        secondary: {
                            type: string;
                            items: {
                                type: string;
                            };
                        };
                        limitations: {
                            type: string;
                            items: {
                                type: string;
                            };
                        };
                    };
                };
                constraints: {
                    type: string;
                    items: {
                        type: string;
                        required: string[];
                        properties: {
                            id: {
                                type: string;
                            };
                            rule: {
                                type: string;
                                enum: string[];
                            };
                            value: {
                                type: string;
                            };
                            rationale: {
                                type: string;
                            };
                            severity: {
                                type: string;
                                enum: string[];
                            };
                            reference: {
                                type: string;
                            };
                        };
                    };
                };
                entities: {
                    type: string;
                    items: {
                        type: string;
                        required: string[];
                        properties: {
                            name: {
                                type: string;
                            };
                            type: {
                                type: string;
                            };
                            category: {
                                type: string;
                            };
                            attributes: {
                                type: string;
                            };
                            relationships: {
                                type: string;
                                items: {
                                    type: string;
                                    properties: {
                                        type: {
                                            type: string;
                                        };
                                        target: {
                                            type: string;
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
                evidence: {
                    type: string;
                    items: {
                        type: string;
                        required: string[];
                        properties: {
                            type: {
                                type: string;
                                enum: string[];
                            };
                            content: {
                                type: string;
                            };
                            source: {
                                type: string;
                            };
                            timestamp: {
                                type: string;
                            };
                            confidence: {
                                type: string;
                                minimum: number;
                                maximum: number;
                            };
                        };
                    };
                };
                verification: {
                    type: string;
                    required: string[];
                    properties: {
                        canonical_hash: {
                            type: string;
                        };
                        semantic_invariants: {
                            type: string;
                            items: {
                                type: string;
                                required: string[];
                            };
                        };
                        policy: {
                            type: string;
                            required: string[];
                        };
                    };
                };
                dependencies: {
                    type: string;
                    items: {
                        type: string;
                        required: string[];
                        properties: {
                            crystal_id: {
                                type: string;
                            };
                            version: {
                                type: string;
                            };
                            type: {
                                type: string;
                                enum: string[];
                            };
                            scope: {
                                type: string;
                                enum: string[];
                            };
                            reason: {
                                type: string;
                            };
                        };
                    };
                };
                version: {
                    type: string;
                    pattern: string;
                };
                tier: {
                    type: string;
                    enum: string[];
                };
                author: {
                    type: string;
                    required: string[];
                    properties: {
                        id: {
                            type: string;
                        };
                        name: {
                            type: string;
                        };
                        reputation: {
                            type: string;
                            minimum: number;
                            maximum: number;
                        };
                        verified_credentials: {
                            type: string;
                            items: {
                                type: string;
                            };
                        };
                    };
                };
                supersedes: {
                    type: string;
                };
                deprecated: {
                    type: string;
                };
                tags: {
                    type: string;
                    items: {
                        type: string;
                    };
                };
                extensions: {
                    type: string;
                };
                metadata: {
                    type: string;
                };
            };
            additionalProperties: boolean;
        };
        validate: typeof import(".").validateCrystalFormat;
        canonicalStringify: typeof import(".").canonicalStringify;
    };
    Visualizer: typeof ReceiptVisualizer;
    Metrics: {
        calculateSRI: (score: number, risk: number) => number;
    };
};
