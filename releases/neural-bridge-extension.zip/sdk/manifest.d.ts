export declare function buildManifest(): {
    readonly manifest_version: 3;
    readonly name: "Neural Bridge";
    readonly version: "2.0.0";
    readonly description: "Semantic Continuity Protocol (SCP) bridge with verifiable context transfer.";
    readonly action: {
        readonly default_title: "Neural Bridge";
        readonly default_popup: "src/ui/popup.html";
    };
    readonly icons: {
        readonly "16": "icons/icon16.png";
        readonly "32": "icons/icon32.png";
        readonly "48": "icons/icon48.png";
        readonly "128": "icons/icon128.png";
    };
    readonly background: {
        readonly service_worker: "background/service_worker.js";
        readonly type: "module";
    };
    readonly permissions: readonly ["storage", "activeTab", "scripting", "tabs"];
    readonly host_permissions: readonly ["https://chatgpt.com/*", "https://chat.openai.com/*", "https://gemini.google.com/*", "https://claude.ai/*"];
    readonly content_scripts: readonly [{
        readonly matches: readonly ["<all_urls>"];
        readonly js: readonly ["content/index.js"];
        readonly run_at: "document_idle";
    }, {
        readonly matches: readonly ["<all_urls>"];
        readonly js: readonly ["content/silent_monitor.js"];
        readonly run_at: "document_start";
    }];
    readonly web_accessible_resources: readonly [{
        readonly resources: readonly ["src/ui/popup.html", "assets/*", "icons/*"];
        readonly matches: readonly ["<all_urls>"];
    }];
};
