import type { HostProfile, CompileRequest, CompileResponse, VerifyTelemetryRequest, Platform, VerifyRequest, VerifyResponse, Crystal, GenerateInvariantsResponse, LoginRequest, RegisterRequest, AuthResponse } from "./types";
/** Ensure we have a valid session token. Refresh if expired. */
export declare function ensureSession(extensionVersion: string): Promise<string>;
export declare function getHostProfile(params: {
    platform: Platform;
    extensionVersion: string;
}): Promise<HostProfile>;
export declare function compile(params: {
    req: CompileRequest;
    extensionVersion: string;
    idemKey?: string;
}): Promise<CompileResponse>;
export declare function reportVerifyTelemetry(params: {
    body: VerifyTelemetryRequest;
    extensionVersion: string;
}): Promise<{
    ok: boolean;
}>;
export declare function verify(params: {
    req: VerifyRequest;
    extensionVersion: string;
}): Promise<VerifyResponse>;
export declare function generateInvariants(params: {
    crystal: Crystal;
    extensionVersion: string;
}): Promise<GenerateInvariantsResponse>;
export declare function registerAuthor(params: {
    name: string;
    handle: string;
    extensionVersion: string;
}): Promise<{
    author_id: string;
    status: string;
}>;
export declare function getAuthor(params: {
    authorId: string;
    extensionVersion: string;
}): Promise<{
    id: string;
    name: string;
    reputation: number;
    tier: string;
}>;
export declare function loginAuthor(params: LoginRequest): Promise<AuthResponse>;
export declare function registerAuthorV2(params: RegisterRequest): Promise<AuthResponse>;
import { type ProofCarryingKnowledge } from '../pck';
/**
 * Compile source into PCK locally - NO API call needed.
 * This runs entirely in the browser/node with zero network cost.
 */
/**
 * Compile source into PCK locally - NO API call needed.
 * This runs entirely in the browser/node with zero network cost.
 */
export declare function compilePCKLocal(source: string, domain: string): Promise<ProofCarryingKnowledge>;
/**
 * Verify answer against PCK locally - ZERO API calls.
 * This is the revolutionary part: verification without external services.
 */
export declare function verifyWithPCKLocal(pck: ProofCarryingKnowledge, answer: string): Promise<{
    valid: boolean;
    confidence: number;
    supported_claims: string[];
    unsupported_claims: string[];
    contradictions: string[];
    llm_calls_made: 0;
    verification_time_ms: number;
    cost_saved: string;
}>;
/**
 * Verify PCK integrity - ensure proofs haven't been tampered with.
 */
export declare function verifyPCKIntegrity(pck: ProofCarryingKnowledge): Promise<{
    valid: boolean;
    checks_performed: number;
    failed_checks: string[];
}>;
export type { ProofCarryingKnowledge };
