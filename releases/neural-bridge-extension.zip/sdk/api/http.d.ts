export declare class ApiError extends Error {
    status?: number | undefined;
    code?: string | undefined;
    details?: unknown;
    constructor(message: string, opts?: {
        status?: number;
        code?: string;
        details?: unknown;
    });
}
export declare function fetchJSON<T>(url: string, init?: RequestInit & {
    timeoutMs?: number;
}): Promise<T>;
