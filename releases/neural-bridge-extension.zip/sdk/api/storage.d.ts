export declare function getStorage(keys: string | string[]): Promise<Record<string, unknown>>;
export declare function setStorage(data: Record<string, unknown>): Promise<void>;
export declare function getOrCreateInstallId(): Promise<string>;
export declare function getSession(): Promise<{
    token?: string | undefined;
    expiresAt?: string | undefined;
    policy?: unknown | undefined;
}>;
export declare function setSession(token: string, expiresAtISO: string, policy?: unknown): Promise<void>;
export declare function isExpired(expiresAtISO?: string, skewSeconds?: number): boolean;
