import { SonicResponse } from './services/sonic_stream';
import type { Crystal } from './types/crystal_format';
/**
 * 🌉 NEURAL BRIDGE OMEGA
 * The Zero-Friction Universal SDK.
 *
 * Usage:
 * const nb = new NeuralBridge({ domain: 'medical' });
 * await nb.remember("Patient has penicillin allergy");
 * const advice = await nb.ask("Can I prescribe Amoxicillin?");
 */
export declare class NeuralBridge {
    private domain;
    /**
     * GLOBAL INIT (The LangChain Killer)
     * Setup the entire system in one static call.
     */
    static init(config?: {
        domain?: string;
    }): NeuralBridge;
    constructor(config?: {
        domain?: string;
    });
    /**
     * FLASH REMEMBER ⚡
     * Instantly ingests information using Regex+LSH (No Latency).
     * Sublimation happens in background if needed.
     */
    remember(text: string, metadata?: any): Promise<Crystal>;
    ask(query: string): Promise<{
        content: string;
        crystal: Crystal;
        proof_valid: boolean;
        anchor_prompt: string;
        metadata: any;
    }>;
    /**
     * VOICE ASK (Sonic Reality Streaming) 🎙️
     *
     * Optimizes for sub-50ms latency. Ideal for real-time voice apps.
     * Returns a SonicResponse with audio_buffer and verification status.
     */
    voiceAsk(query: string): Promise<SonicResponse>;
    /**
     * REINFORCE (Teach) 🎓
     * Give feedback to the system to improve future answers.
     */
    learn(crystalId: string, helpful: boolean): Promise<void>;
    /**
     * START AUTONOMOUS LEARNING 🚀
     *
     * Activates the Self-Healing Brain for this domain.
     * The system will proactively find gaps and fill them in the background.
     */
    startAutonomousLearning(intervalMs?: number): void;
    /**
     * STOP AUTONOMOUS LEARNING ⏹️
     */
    stopAutonomousLearning(): void;
}
export * from './types/crystal_format';
export { CrystallizationService } from './services/crystallization';
export { TruthVault } from './services/truth_vault';
export { RLMEngine } from './services/rlm_engine';
