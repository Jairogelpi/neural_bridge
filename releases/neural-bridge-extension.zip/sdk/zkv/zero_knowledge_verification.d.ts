/**
 * ZERO-KNOWLEDGE VERIFICATION (ZKV) - Browser Compatible Version
 *
 * Revolutionary feature: Prove an answer is correct WITHOUT revealing:
 * 1. The source document (proprietary data protection)
 * 2. The verification logic (trade secret)
 *
 * Use case: Enterprises with sensitive data can verify LLM outputs
 * without exposing their proprietary knowledge bases.
 *
 * How it works:
 * 1. Prover has: source document + answer
 * 2. Prover generates: ZK commitment (hash-based proof)
 * 3. Verifier receives: commitment + claim
 * 4. Verifier can verify: the answer matches the source
 * 5. Verifier CANNOT see: the actual source content
 */
export interface ZKCommitment {
    commitment_id: string;
    timestamp: string;
    claim_hash: string;
    source_commitment: string;
    verification_hash: string;
    merkle_root: string;
    proof_path: string[];
    nonce: string;
}
export interface ZKProof {
    zkp_version: '1.0';
    proof_id: string;
    created_at: string;
    claim: {
        statement: string;
        answer_hash: string;
        domain: string;
    };
    commitments: {
        source_exists: ZKCommitment;
        answer_matches: ZKCommitment;
        constraints_satisfied: ZKCommitment;
    };
    verification_result: {
        is_valid: boolean;
        confidence: number;
        constraints_checked: number;
        constraints_passed: boolean;
    };
    signature: {
        algorithm: 'SHA256-HMAC';
        prover_commitment: string;
        value: string;
    };
}
export interface ZKVerificationResult {
    valid: boolean;
    proof_verified: boolean;
    commitments_valid: boolean;
    signature_valid: boolean;
    learned: {
        answer_is_factual: boolean;
        confidence_level: number;
        source_exists: boolean;
    };
    not_revealed: {
        source_content: true;
        verification_logic: true;
        internal_data: true;
    };
    verification_time_ms: number;
}
export declare class ZKProver {
    private secretKey;
    private sourceHash;
    constructor(secretKey?: string);
    /**
     * Commit to a source document without revealing it
     * Returns a commitment that proves the source exists
     */
    commitToSource(source: string): Promise<string>;
    /**
     * Generate a Zero-Knowledge Proof that an answer is correct
     * WITHOUT revealing the source document or verification logic
     */
    generateProof(params: {
        source: string;
        answer: string;
        domain: string;
        constraints?: Array<{
            type: string;
            value: unknown;
        }>;
    }): Promise<ZKProof>;
    /**
     * Internal verification - only the prover can do this
     */
    private internalVerify;
    private extractNumbers;
    private calculateKeywordOverlap;
    private checkConstraint;
    /**
     * Create a ZK commitment that hides the secret
     */
    private createZKCommitment;
    private createCommitment;
    private splitIntoChunks;
    private computeMerkleRoot;
    private hash;
    private sign;
}
export declare class ZKVerifier {
    /**
     * Verify a ZK proof WITHOUT seeing the source document
     * The verifier learns only: is the answer correct? (yes/no)
     * The verifier does NOT learn: source content, verification logic
     */
    verify(proof: ZKProof, answer?: string): Promise<ZKVerificationResult>;
    private verifyStructure;
    private verifyCommitments;
    private verifySignature;
}
export declare class ZKVRuntime {
    /**
     * Create a ZK proof for an answer
     * Enterprise use: Prove answer correctness without revealing proprietary data
     */
    static createProof(params: {
        source: string;
        answer: string;
        domain: string;
        constraints?: Array<{
            type: string;
            value: unknown;
        }>;
        secretKey?: string;
    }): Promise<ZKProof>;
    /**
     * Verify a ZK proof WITHOUT seeing the source
     * Returns: Is the answer correct? (yes/no + confidence)
     * Does NOT reveal: Source content, verification logic
     */
    static verifyProof(proof: ZKProof, answer?: string): Promise<ZKVerificationResult>;
    /**
     * Full workflow: Prove and verify in one call
     * Demonstrates the complete ZKV pipeline
     */
    static proveAndVerify(params: {
        source: string;
        answer: string;
        domain: string;
        constraints?: Array<{
            type: string;
            value: unknown;
        }>;
    }): Promise<{
        proof: ZKProof;
        verification: ZKVerificationResult;
        source_revealed: false;
        logic_revealed: false;
    }>;
}
