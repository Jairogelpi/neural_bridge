var Es = Object.defineProperty;
var Cs = (t, e, r) => e in t ? Es(t, e, { enumerable: !0, configurable: !0, writable: !0, value: r }) : t[e] = r;
var Ue = (t, e, r) => Cs(t, typeof e != "symbol" ? e + "" : e, r);
import He from "crypto";
var ar = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function _s(t) {
  return t && t.__esModule && Object.prototype.hasOwnProperty.call(t, "default") ? t.default : t;
}
function xs(t) {
  if (t.__esModule) return t;
  var e = t.default;
  if (typeof e == "function") {
    var r = function i() {
      return this instanceof i ? Reflect.construct(e, arguments, this.constructor) : e.apply(this, arguments);
    };
    r.prototype = e.prototype;
  } else r = {};
  return Object.defineProperty(r, "__esModule", { value: !0 }), Object.keys(t).forEach(function(i) {
    var o = Object.getOwnPropertyDescriptor(t, i);
    Object.defineProperty(r, i, o.get ? o : {
      enumerable: !0,
      get: function() {
        return t[i];
      }
    });
  }), r;
}
var Et = { exports: {} }, je = {}, ve = {};
const vs = {
  arity: -2,
  flags: [],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, As = {
  arity: 3,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Bs = {
  arity: 1,
  flags: [
    "fast"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Ts = {
  arity: -2,
  flags: [
    "noscript",
    "loading",
    "stale",
    "fast",
    "no_auth",
    "allow_busy"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Rs = {
  arity: 1,
  flags: [
    "admin",
    "noscript",
    "no_async_loading"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Ms = {
  arity: -1,
  flags: [
    "admin",
    "noscript",
    "no_async_loading"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Os = {
  arity: -2,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Is = {
  arity: -2,
  flags: [
    "write",
    "denyoom"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Fs = {
  arity: -2,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Ps = {
  arity: -4,
  flags: [
    "write",
    "denyoom"
  ],
  keyStart: 2,
  keyStop: -1,
  step: 1
}, Ns = {
  arity: -3,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Ds = {
  arity: 6,
  flags: [
    "write",
    "denyoom",
    "noscript",
    "blocking"
  ],
  keyStart: 1,
  keyStop: 2,
  step: 1
}, Ls = {
  arity: -5,
  flags: [
    "write",
    "blocking",
    "movablekeys"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Us = {
  arity: -3,
  flags: [
    "write",
    "noscript",
    "blocking"
  ],
  keyStart: 1,
  keyStop: -2,
  step: 1
}, js = {
  arity: -3,
  flags: [
    "write",
    "noscript",
    "blocking"
  ],
  keyStart: 1,
  keyStop: -2,
  step: 1
}, Qs = {
  arity: 4,
  flags: [
    "write",
    "denyoom",
    "noscript",
    "blocking"
  ],
  keyStart: 1,
  keyStop: 2,
  step: 1
}, zs = {
  arity: -5,
  flags: [
    "write",
    "blocking",
    "movablekeys"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Gs = {
  arity: -3,
  flags: [
    "write",
    "noscript",
    "blocking",
    "fast"
  ],
  keyStart: 1,
  keyStop: -2,
  step: 1
}, qs = {
  arity: -3,
  flags: [
    "write",
    "noscript",
    "blocking",
    "fast"
  ],
  keyStart: 1,
  keyStop: -2,
  step: 1
}, Ks = {
  arity: -2,
  flags: [],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Hs = {
  arity: -2,
  flags: [],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Ys = {
  arity: -1,
  flags: [
    "loading",
    "stale"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Vs = {
  arity: -2,
  flags: [],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Ws = {
  arity: -3,
  flags: [
    "write",
    "denyoom"
  ],
  keyStart: 1,
  keyStop: 2,
  step: 1
}, Js = {
  arity: 1,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Xs = {
  arity: -2,
  flags: [
    "admin",
    "noscript",
    "loading",
    "stale"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Zs = {
  arity: 2,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, $s = {
  arity: 3,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, en = {
  arity: -2,
  flags: [
    "write"
  ],
  keyStart: 1,
  keyStop: -1,
  step: 1
}, tn = {
  arity: 1,
  flags: [
    "noscript",
    "loading",
    "stale",
    "fast",
    "allow_busy"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, rn = {
  arity: 2,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, sn = {
  arity: 2,
  flags: [
    "fast"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, nn = {
  arity: -3,
  flags: [
    "readonly",
    "noscript",
    "stale",
    "skip_monitor",
    "no_mandatory_keys",
    "movablekeys"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, on = {
  arity: -3,
  flags: [
    "noscript",
    "stale",
    "skip_monitor",
    "no_mandatory_keys",
    "movablekeys"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, an = {
  arity: -3,
  flags: [
    "readonly",
    "noscript",
    "stale",
    "skip_monitor",
    "no_mandatory_keys",
    "movablekeys"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, cn = {
  arity: 1,
  flags: [
    "noscript",
    "loading",
    "stale",
    "skip_slowlog"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, un = {
  arity: -2,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: -1,
  step: 1
}, ln = {
  arity: -3,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, fn = {
  arity: -3,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, hn = {
  arity: 2,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, dn = {
  arity: -1,
  flags: [
    "admin",
    "noscript",
    "stale"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, pn = {
  arity: -3,
  flags: [
    "noscript",
    "stale",
    "skip_monitor",
    "no_mandatory_keys",
    "movablekeys"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, yn = {
  arity: -3,
  flags: [
    "readonly",
    "noscript",
    "stale",
    "skip_monitor",
    "no_mandatory_keys",
    "movablekeys"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, gn = {
  arity: -1,
  flags: [
    "write"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, mn = {
  arity: -1,
  flags: [
    "write"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, bn = {
  arity: -5,
  flags: [
    "write",
    "denyoom"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Sn = {
  arity: -4,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, kn = {
  arity: -2,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, wn = {
  arity: -2,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, En = {
  arity: -6,
  flags: [
    "write",
    "denyoom",
    "movablekeys"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Cn = {
  arity: -6,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, _n = {
  arity: -5,
  flags: [
    "write",
    "denyoom",
    "movablekeys"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, xn = {
  arity: -5,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, vn = {
  arity: -7,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, An = {
  arity: -8,
  flags: [
    "write",
    "denyoom"
  ],
  keyStart: 1,
  keyStop: 2,
  step: 1
}, Bn = {
  arity: 2,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Tn = {
  arity: 3,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Rn = {
  arity: 2,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Mn = {
  arity: -2,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, On = {
  arity: 4,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, In = {
  arity: 3,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Fn = {
  arity: -3,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Pn = {
  arity: -1,
  flags: [
    "noscript",
    "loading",
    "stale",
    "fast",
    "no_auth",
    "allow_busy"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Nn = {
  arity: 3,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Dn = {
  arity: -6,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Ln = {
  arity: -6,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Un = {
  arity: 3,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, jn = {
  arity: 2,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Qn = {
  arity: 4,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, zn = {
  arity: 4,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Gn = {
  arity: 2,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, qn = {
  arity: 2,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Kn = {
  arity: -3,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Hn = {
  arity: -4,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Yn = {
  arity: -2,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Vn = {
  arity: -3,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Wn = {
  arity: -4,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Jn = {
  arity: 4,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Xn = {
  arity: 3,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Zn = {
  arity: 2,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, $n = {
  arity: 2,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, ei = {
  arity: 3,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, ti = {
  arity: 3,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, ri = {
  arity: -1,
  flags: [
    "loading",
    "stale"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, si = {
  arity: 2,
  flags: [
    "readonly"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, ni = {
  arity: 1,
  flags: [
    "loading",
    "stale",
    "fast"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, ii = {
  arity: -2,
  flags: [],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, oi = {
  arity: -3,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 2,
  step: 1
}, ai = {
  arity: 3,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, ci = {
  arity: 5,
  flags: [
    "write",
    "denyoom"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, ui = {
  arity: 2,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, li = {
  arity: 5,
  flags: [
    "write",
    "denyoom"
  ],
  keyStart: 1,
  keyStop: 2,
  step: 1
}, fi = {
  arity: -4,
  flags: [
    "write",
    "movablekeys"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, hi = {
  arity: -1,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, di = {
  arity: -2,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, pi = {
  arity: -3,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, yi = {
  arity: -3,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, gi = {
  arity: -3,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, mi = {
  arity: 4,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, bi = {
  arity: 4,
  flags: [
    "write"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Si = {
  arity: 4,
  flags: [
    "write",
    "denyoom"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, ki = {
  arity: 4,
  flags: [
    "write"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, wi = {
  arity: -2,
  flags: [],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Ei = {
  arity: -2,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: -1,
  step: 1
}, Ci = {
  arity: -6,
  flags: [
    "write",
    "movablekeys"
  ],
  keyStart: 3,
  keyStop: 3,
  step: 1
}, _i = {
  arity: -2,
  flags: [],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, xi = {
  arity: 1,
  flags: [
    "admin",
    "noscript",
    "loading",
    "stale"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, vi = {
  arity: 3,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Ai = {
  arity: -3,
  flags: [
    "write",
    "denyoom"
  ],
  keyStart: 1,
  keyStop: -1,
  step: 2
}, Bi = {
  arity: -3,
  flags: [
    "write",
    "denyoom"
  ],
  keyStart: 1,
  keyStop: -1,
  step: 2
}, Ti = {
  arity: 1,
  flags: [
    "noscript",
    "loading",
    "stale",
    "fast",
    "allow_busy"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Ri = {
  arity: -2,
  flags: [],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Mi = {
  arity: 2,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Oi = {
  arity: -3,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Ii = {
  arity: -3,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Fi = {
  arity: 2,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Pi = {
  arity: -2,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Ni = {
  arity: -2,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: -1,
  step: 1
}, Di = {
  arity: 3,
  flags: [
    "write",
    "denyoom",
    "admin"
  ],
  keyStart: 2,
  keyStop: 2,
  step: 1
}, Li = {
  arity: -2,
  flags: [
    "write",
    "denyoom"
  ],
  keyStart: 1,
  keyStop: -1,
  step: 1
}, Ui = {
  arity: 1,
  flags: [
    "admin"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, ji = {
  arity: -1,
  flags: [
    "fast"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Qi = {
  arity: 4,
  flags: [
    "write",
    "denyoom"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, zi = {
  arity: -2,
  flags: [
    "pubsub",
    "noscript",
    "loading",
    "stale"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Gi = {
  arity: -3,
  flags: [
    "admin",
    "noscript",
    "no_async_loading",
    "no_multi"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, qi = {
  arity: 2,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Ki = {
  arity: 3,
  flags: [
    "pubsub",
    "loading",
    "stale",
    "fast"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Hi = {
  arity: -2,
  flags: [],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Yi = {
  arity: -1,
  flags: [
    "pubsub",
    "noscript",
    "loading",
    "stale"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Vi = {
  arity: -1,
  flags: [
    "noscript",
    "loading",
    "stale",
    "fast",
    "no_auth",
    "allow_busy"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Wi = {
  arity: 1,
  flags: [
    "readonly"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Ji = {
  arity: 1,
  flags: [
    "loading",
    "stale",
    "fast"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Xi = {
  arity: 1,
  flags: [
    "loading",
    "stale",
    "fast"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Zi = {
  arity: 3,
  flags: [
    "write"
  ],
  keyStart: 1,
  keyStop: 2,
  step: 1
}, $i = {
  arity: 3,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 2,
  step: 1
}, eo = {
  arity: -1,
  flags: [
    "admin",
    "noscript",
    "loading",
    "stale",
    "allow_busy"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, to = {
  arity: 3,
  flags: [
    "admin",
    "noscript",
    "stale",
    "no_async_loading"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, ro = {
  arity: 1,
  flags: [
    "noscript",
    "loading",
    "stale",
    "fast",
    "no_auth",
    "allow_busy"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, so = {
  arity: -4,
  flags: [
    "write",
    "denyoom"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, no = {
  arity: 1,
  flags: [
    "noscript",
    "loading",
    "stale",
    "fast"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, io = {
  arity: -2,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, oo = {
  arity: 3,
  flags: [
    "write",
    "denyoom"
  ],
  keyStart: 1,
  keyStop: 2,
  step: 1
}, ao = {
  arity: -3,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, co = {
  arity: -3,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, uo = {
  arity: -3,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, lo = {
  arity: 1,
  flags: [
    "admin",
    "noscript",
    "no_async_loading",
    "no_multi"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, fo = {
  arity: -2,
  flags: [
    "readonly"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, ho = {
  arity: 2,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, po = {
  arity: -2,
  flags: [],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, yo = {
  arity: -2,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: -1,
  step: 1
}, go = {
  arity: -3,
  flags: [
    "write",
    "denyoom"
  ],
  keyStart: 1,
  keyStop: -1,
  step: 1
}, mo = {
  arity: 2,
  flags: [
    "loading",
    "stale",
    "fast"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, bo = {
  arity: -3,
  flags: [
    "write",
    "denyoom"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, So = {
  arity: 4,
  flags: [
    "write",
    "denyoom"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, ko = {
  arity: 4,
  flags: [
    "write",
    "denyoom"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, wo = {
  arity: 3,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Eo = {
  arity: 4,
  flags: [
    "write",
    "denyoom"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Co = {
  arity: -1,
  flags: [
    "admin",
    "noscript",
    "loading",
    "stale",
    "no_multi",
    "allow_busy"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, _o = {
  arity: -2,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: -1,
  step: 1
}, xo = {
  arity: -3,
  flags: [
    "readonly",
    "movablekeys"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, vo = {
  arity: -3,
  flags: [
    "write",
    "denyoom"
  ],
  keyStart: 1,
  keyStop: -1,
  step: 1
}, Ao = {
  arity: 3,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Bo = {
  arity: 3,
  flags: [
    "admin",
    "noscript",
    "stale",
    "no_async_loading"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, To = {
  arity: -2,
  flags: [],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Ro = {
  arity: 2,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Mo = {
  arity: -3,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Oo = {
  arity: 4,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 2,
  step: 1
}, Io = {
  arity: -2,
  flags: [
    "write",
    "denyoom",
    "movablekeys"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Fo = {
  arity: -2,
  flags: [
    "readonly",
    "movablekeys"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Po = {
  arity: -2,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, No = {
  arity: 3,
  flags: [
    "pubsub",
    "loading",
    "stale",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Do = {
  arity: -2,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Lo = {
  arity: -3,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Uo = {
  arity: -3,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, jo = {
  arity: -2,
  flags: [
    "pubsub",
    "noscript",
    "loading",
    "stale"
  ],
  keyStart: 1,
  keyStop: -1,
  step: 1
}, Qo = {
  arity: 2,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, zo = {
  arity: -2,
  flags: [
    "pubsub",
    "noscript",
    "loading",
    "stale"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Go = {
  arity: 4,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, qo = {
  arity: -2,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: -1,
  step: 1
}, Ko = {
  arity: -3,
  flags: [
    "write",
    "denyoom"
  ],
  keyStart: 1,
  keyStop: -1,
  step: 1
}, Ho = {
  arity: -1,
  flags: [
    "pubsub",
    "noscript",
    "loading",
    "stale"
  ],
  keyStart: 1,
  keyStop: -1,
  step: 1
}, Yo = {
  arity: 3,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Vo = {
  arity: 1,
  flags: [
    "admin",
    "noscript",
    "no_async_loading",
    "no_multi"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Wo = {
  arity: 1,
  flags: [
    "loading",
    "stale",
    "fast"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Jo = {
  arity: -2,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: -1,
  step: 1
}, Xo = {
  arity: 2,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Zo = {
  arity: 2,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, $o = {
  arity: -2,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: -1,
  step: 1
}, ea = {
  arity: -1,
  flags: [
    "pubsub",
    "noscript",
    "loading",
    "stale"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, ta = {
  arity: 1,
  flags: [
    "noscript",
    "loading",
    "stale",
    "fast",
    "allow_busy"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, ra = {
  arity: 3,
  flags: [
    "noscript"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, sa = {
  arity: -2,
  flags: [
    "noscript",
    "loading",
    "stale",
    "fast",
    "allow_busy"
  ],
  keyStart: 1,
  keyStop: -1,
  step: 1
}, na = {
  arity: -4,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, ia = {
  arity: -5,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, oa = {
  arity: -6,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, aa = {
  arity: -6,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, ca = {
  arity: -3,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, ua = {
  arity: -5,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, la = {
  arity: -2,
  flags: [],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, fa = {
  arity: -2,
  flags: [],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, ha = {
  arity: 2,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, da = {
  arity: -3,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, pa = {
  arity: -4,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, ya = {
  arity: -4,
  flags: [
    "readonly",
    "blocking",
    "movablekeys"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, ga = {
  arity: -7,
  flags: [
    "write",
    "blocking",
    "movablekeys"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, ma = {
  arity: -4,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, ba = {
  arity: -3,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Sa = {
  arity: -4,
  flags: [
    "write"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, ka = {
  arity: -4,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, wa = {
  arity: 2,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Ea = {
  arity: 4,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Ca = {
  arity: -3,
  flags: [
    "readonly",
    "movablekeys"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, _a = {
  arity: -4,
  flags: [
    "write",
    "denyoom",
    "movablekeys"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, xa = {
  arity: 4,
  flags: [
    "write",
    "denyoom",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, va = {
  arity: -3,
  flags: [
    "readonly",
    "movablekeys"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Aa = {
  arity: -3,
  flags: [
    "readonly",
    "movablekeys"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Ba = {
  arity: -4,
  flags: [
    "write",
    "denyoom",
    "movablekeys"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Ta = {
  arity: 4,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Ra = {
  arity: -4,
  flags: [
    "write",
    "movablekeys"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Ma = {
  arity: -3,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Oa = {
  arity: -2,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Ia = {
  arity: -2,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Fa = {
  arity: -2,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Pa = {
  arity: -4,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Na = {
  arity: -4,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Da = {
  arity: -4,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, La = {
  arity: -5,
  flags: [
    "write",
    "denyoom"
  ],
  keyStart: 1,
  keyStop: 2,
  step: 1
}, Ua = {
  arity: 3,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, ja = {
  arity: -3,
  flags: [
    "write",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Qa = {
  arity: 4,
  flags: [
    "write"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, za = {
  arity: 4,
  flags: [
    "write"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Ga = {
  arity: 4,
  flags: [
    "write"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, qa = {
  arity: -4,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Ka = {
  arity: -4,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Ha = {
  arity: -4,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Ya = {
  arity: 3,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Va = {
  arity: -3,
  flags: [
    "readonly"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Wa = {
  arity: 3,
  flags: [
    "readonly",
    "fast"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Ja = {
  arity: -3,
  flags: [
    "readonly",
    "movablekeys"
  ],
  keyStart: 0,
  keyStop: 0,
  step: 0
}, Xa = {
  arity: -4,
  flags: [
    "write",
    "denyoom",
    "movablekeys"
  ],
  keyStart: 1,
  keyStop: 1,
  step: 1
}, Za = {
  acl: vs,
  append: As,
  asking: Bs,
  auth: Ts,
  bgrewriteaof: Rs,
  bgsave: Ms,
  bitcount: Os,
  bitfield: Is,
  bitfield_ro: Fs,
  bitop: Ps,
  bitpos: Ns,
  blmove: Ds,
  blmpop: Ls,
  blpop: Us,
  brpop: js,
  brpoplpush: Qs,
  bzmpop: zs,
  bzpopmax: Gs,
  bzpopmin: qs,
  client: Ks,
  cluster: Hs,
  command: Ys,
  config: Vs,
  copy: Ws,
  dbsize: Js,
  debug: Xs,
  decr: Zs,
  decrby: $s,
  del: en,
  discard: tn,
  dump: rn,
  echo: sn,
  eval: {
    arity: -3,
    flags: [
      "noscript",
      "stale",
      "skip_monitor",
      "no_mandatory_keys",
      "movablekeys"
    ],
    keyStart: 0,
    keyStop: 0,
    step: 0
  },
  eval_ro: nn,
  evalsha: on,
  evalsha_ro: an,
  exec: cn,
  exists: un,
  expire: ln,
  expireat: fn,
  expiretime: hn,
  failover: dn,
  fcall: pn,
  fcall_ro: yn,
  flushall: gn,
  flushdb: mn,
  function: {
    arity: -2,
    flags: [],
    keyStart: 0,
    keyStop: 0,
    step: 0
  },
  geoadd: bn,
  geodist: Sn,
  geohash: kn,
  geopos: wn,
  georadius: En,
  georadius_ro: Cn,
  georadiusbymember: _n,
  georadiusbymember_ro: xn,
  geosearch: vn,
  geosearchstore: An,
  get: Bn,
  getbit: Tn,
  getdel: Rn,
  getex: Mn,
  getrange: On,
  getset: In,
  hdel: Fn,
  hello: Pn,
  hexists: Nn,
  hexpire: Dn,
  hpexpire: Ln,
  hget: Un,
  hgetall: jn,
  hincrby: Qn,
  hincrbyfloat: zn,
  hkeys: Gn,
  hlen: qn,
  hmget: Kn,
  hmset: Hn,
  hrandfield: Yn,
  hscan: Vn,
  hset: Wn,
  hsetnx: Jn,
  hstrlen: Xn,
  hvals: Zn,
  incr: $n,
  incrby: ei,
  incrbyfloat: ti,
  info: ri,
  keys: si,
  lastsave: ni,
  latency: ii,
  lcs: oi,
  lindex: ai,
  linsert: ci,
  llen: ui,
  lmove: li,
  lmpop: fi,
  lolwut: hi,
  lpop: di,
  lpos: pi,
  lpush: yi,
  lpushx: gi,
  lrange: mi,
  lrem: bi,
  lset: Si,
  ltrim: ki,
  memory: wi,
  mget: Ei,
  migrate: Ci,
  module: _i,
  monitor: xi,
  move: vi,
  mset: Ai,
  msetnx: Bi,
  multi: Ti,
  object: Ri,
  persist: Mi,
  pexpire: Oi,
  pexpireat: Ii,
  pexpiretime: Fi,
  pfadd: Pi,
  pfcount: Ni,
  pfdebug: Di,
  pfmerge: Li,
  pfselftest: Ui,
  ping: ji,
  psetex: Qi,
  psubscribe: zi,
  psync: Gi,
  pttl: qi,
  publish: Ki,
  pubsub: Hi,
  punsubscribe: Yi,
  quit: Vi,
  randomkey: Wi,
  readonly: Ji,
  readwrite: Xi,
  rename: Zi,
  renamenx: $i,
  replconf: eo,
  replicaof: to,
  reset: ro,
  restore: so,
  "restore-asking": {
    arity: -4,
    flags: [
      "write",
      "denyoom",
      "asking"
    ],
    keyStart: 1,
    keyStop: 1,
    step: 1
  },
  role: no,
  rpop: io,
  rpoplpush: oo,
  rpush: ao,
  rpushx: co,
  sadd: uo,
  save: lo,
  scan: fo,
  scard: ho,
  script: po,
  sdiff: yo,
  sdiffstore: go,
  select: mo,
  set: bo,
  setbit: So,
  setex: ko,
  setnx: wo,
  setrange: Eo,
  shutdown: Co,
  sinter: _o,
  sintercard: xo,
  sinterstore: vo,
  sismember: Ao,
  slaveof: Bo,
  slowlog: To,
  smembers: Ro,
  smismember: Mo,
  smove: Oo,
  sort: Io,
  sort_ro: Fo,
  spop: Po,
  spublish: No,
  srandmember: Do,
  srem: Lo,
  sscan: Uo,
  ssubscribe: jo,
  strlen: Qo,
  subscribe: zo,
  substr: Go,
  sunion: qo,
  sunionstore: Ko,
  sunsubscribe: Ho,
  swapdb: Yo,
  sync: Vo,
  time: Wo,
  touch: Jo,
  ttl: Xo,
  type: Zo,
  unlink: $o,
  unsubscribe: ea,
  unwatch: ta,
  wait: ra,
  watch: sa,
  xack: na,
  xadd: ia,
  xautoclaim: oa,
  xclaim: aa,
  xdel: ca,
  xdelex: ua,
  xgroup: la,
  xinfo: fa,
  xlen: ha,
  xpending: da,
  xrange: pa,
  xread: ya,
  xreadgroup: ga,
  xrevrange: ma,
  xsetid: ba,
  xtrim: Sa,
  zadd: ka,
  zcard: wa,
  zcount: Ea,
  zdiff: Ca,
  zdiffstore: _a,
  zincrby: xa,
  zinter: va,
  zintercard: Aa,
  zinterstore: Ba,
  zlexcount: Ta,
  zmpop: Ra,
  zmscore: Ma,
  zpopmax: Oa,
  zpopmin: Ia,
  zrandmember: Fa,
  zrange: Pa,
  zrangebylex: Na,
  zrangebyscore: Da,
  zrangestore: La,
  zrank: Ua,
  zrem: ja,
  zremrangebylex: Qa,
  zremrangebyrank: za,
  zremrangebyscore: Ga,
  zrevrange: qa,
  zrevrangebylex: Ka,
  zrevrangebyscore: Ha,
  zrevrank: Ya,
  zscan: Va,
  zscore: Wa,
  zunion: Ja,
  zunionstore: Xa
};
(function(t) {
  var e = ar && ar.__importDefault || function(u) {
    return u && u.__esModule ? u : { default: u };
  };
  Object.defineProperty(t, "__esModule", { value: !0 }), t.getKeyIndexes = t.hasFlag = t.exists = t.list = void 0;
  const r = e(Za);
  t.list = Object.keys(r.default);
  const i = {};
  t.list.forEach((u) => {
    i[u] = r.default[u].flags.reduce(function(y, g) {
      return y[g] = !0, y;
    }, {});
  });
  function o(u, y) {
    return u = y != null && y.caseInsensitive ? String(u).toLowerCase() : u, !!r.default[u];
  }
  t.exists = o;
  function f(u, y, g) {
    if (u = g != null && g.nameCaseInsensitive ? String(u).toLowerCase() : u, !i[u])
      throw new Error("Unknown command " + u);
    return !!i[u][y];
  }
  t.hasFlag = f;
  function l(u, y, g) {
    u = g != null && g.nameCaseInsensitive ? String(u).toLowerCase() : u;
    const k = r.default[u];
    if (!k)
      throw new Error("Unknown command " + u);
    if (!Array.isArray(y))
      throw new Error("Expect args to be an array");
    const w = [], x = !!(g && g.parseExternalKey), p = (_, A) => {
      const I = [], S = Number(_[A]);
      for (let T = 0; T < S; T++)
        I.push(T + A + 1);
      return I;
    }, R = (_, A, I) => {
      for (let S = A; S < _.length - 1; S += 1)
        if (String(_[S]).toLowerCase() === I.toLowerCase())
          return S + 1;
      return null;
    };
    switch (u) {
      case "zunionstore":
      case "zinterstore":
      case "zdiffstore":
        w.push(0, ...p(y, 1));
        break;
      case "eval":
      case "evalsha":
      case "eval_ro":
      case "evalsha_ro":
      case "fcall":
      case "fcall_ro":
      case "blmpop":
      case "bzmpop":
        w.push(...p(y, 1));
        break;
      case "sintercard":
      case "lmpop":
      case "zunion":
      case "zinter":
      case "zmpop":
      case "zintercard":
      case "zdiff": {
        w.push(...p(y, 0));
        break;
      }
      case "georadius": {
        w.push(0);
        const _ = R(y, 5, "STORE");
        _ && w.push(_);
        const A = R(y, 5, "STOREDIST");
        A && w.push(A);
        break;
      }
      case "georadiusbymember": {
        w.push(0);
        const _ = R(y, 4, "STORE");
        _ && w.push(_);
        const A = R(y, 4, "STOREDIST");
        A && w.push(A);
        break;
      }
      case "sort":
      case "sort_ro":
        w.push(0);
        for (let _ = 1; _ < y.length - 1; _++) {
          let A = y[_];
          if (typeof A != "string")
            continue;
          const I = A.toUpperCase();
          I === "GET" ? (_ += 1, A = y[_], A !== "#" && (x ? w.push([_, a(A)]) : w.push(_))) : I === "BY" ? (_ += 1, x ? w.push([_, a(y[_])]) : w.push(_)) : I === "STORE" && (_ += 1, w.push(_));
        }
        break;
      case "migrate":
        if (y[2] === "")
          for (let _ = 5; _ < y.length - 1; _++) {
            const A = y[_];
            if (typeof A == "string" && A.toUpperCase() === "KEYS") {
              for (let I = _ + 1; I < y.length; I++)
                w.push(I);
              break;
            }
          }
        else
          w.push(2);
        break;
      case "xreadgroup":
      case "xread":
        for (let _ = u === "xread" ? 0 : 3; _ < y.length - 1; _++)
          if (String(y[_]).toUpperCase() === "STREAMS") {
            for (let A = _ + 1; A <= _ + (y.length - 1 - _) / 2; A++)
              w.push(A);
            break;
          }
        break;
      default:
        if (k.step > 0) {
          const _ = k.keyStart - 1, A = k.keyStop > 0 ? k.keyStop : y.length + k.keyStop + 1;
          for (let I = _; I < A; I += k.step)
            w.push(I);
        }
        break;
    }
    return w;
  }
  t.getKeyIndexes = l;
  function a(u) {
    typeof u != "string" && (u = String(u));
    const y = u.indexOf("->");
    return y === -1 ? u.length : y;
  }
})(ve);
var Tt = { exports: {} }, _e = typeof Reflect == "object" ? Reflect : null, cr = _e && typeof _e.apply == "function" ? _e.apply : function(e, r, i) {
  return Function.prototype.apply.call(e, r, i);
}, Ye;
_e && typeof _e.ownKeys == "function" ? Ye = _e.ownKeys : Object.getOwnPropertySymbols ? Ye = function(e) {
  return Object.getOwnPropertyNames(e).concat(Object.getOwnPropertySymbols(e));
} : Ye = function(e) {
  return Object.getOwnPropertyNames(e);
};
function $a(t) {
  console && console.warn && console.warn(t);
}
var Lr = Number.isNaN || function(e) {
  return e !== e;
};
function z() {
  z.init.call(this);
}
Tt.exports = z;
Tt.exports.once = sc;
z.EventEmitter = z;
z.prototype._events = void 0;
z.prototype._eventsCount = 0;
z.prototype._maxListeners = void 0;
var ur = 10;
function Xe(t) {
  if (typeof t != "function")
    throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof t);
}
Object.defineProperty(z, "defaultMaxListeners", {
  enumerable: !0,
  get: function() {
    return ur;
  },
  set: function(t) {
    if (typeof t != "number" || t < 0 || Lr(t))
      throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + t + ".");
    ur = t;
  }
});
z.init = function() {
  (this._events === void 0 || this._events === Object.getPrototypeOf(this)._events) && (this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0), this._maxListeners = this._maxListeners || void 0;
};
z.prototype.setMaxListeners = function(e) {
  if (typeof e != "number" || e < 0 || Lr(e))
    throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + e + ".");
  return this._maxListeners = e, this;
};
function Ur(t) {
  return t._maxListeners === void 0 ? z.defaultMaxListeners : t._maxListeners;
}
z.prototype.getMaxListeners = function() {
  return Ur(this);
};
z.prototype.emit = function(e) {
  for (var r = [], i = 1; i < arguments.length; i++) r.push(arguments[i]);
  var o = e === "error", f = this._events;
  if (f !== void 0)
    o = o && f.error === void 0;
  else if (!o)
    return !1;
  if (o) {
    var l;
    if (r.length > 0 && (l = r[0]), l instanceof Error)
      throw l;
    var a = new Error("Unhandled error." + (l ? " (" + l.message + ")" : ""));
    throw a.context = l, a;
  }
  var u = f[e];
  if (u === void 0)
    return !1;
  if (typeof u == "function")
    cr(u, this, r);
  else
    for (var y = u.length, g = qr(u, y), i = 0; i < y; ++i)
      cr(g[i], this, r);
  return !0;
};
function jr(t, e, r, i) {
  var o, f, l;
  if (Xe(r), f = t._events, f === void 0 ? (f = t._events = /* @__PURE__ */ Object.create(null), t._eventsCount = 0) : (f.newListener !== void 0 && (t.emit(
    "newListener",
    e,
    r.listener ? r.listener : r
  ), f = t._events), l = f[e]), l === void 0)
    l = f[e] = r, ++t._eventsCount;
  else if (typeof l == "function" ? l = f[e] = i ? [r, l] : [l, r] : i ? l.unshift(r) : l.push(r), o = Ur(t), o > 0 && l.length > o && !l.warned) {
    l.warned = !0;
    var a = new Error("Possible EventEmitter memory leak detected. " + l.length + " " + String(e) + " listeners added. Use emitter.setMaxListeners() to increase limit");
    a.name = "MaxListenersExceededWarning", a.emitter = t, a.type = e, a.count = l.length, $a(a);
  }
  return t;
}
z.prototype.addListener = function(e, r) {
  return jr(this, e, r, !1);
};
z.prototype.on = z.prototype.addListener;
z.prototype.prependListener = function(e, r) {
  return jr(this, e, r, !0);
};
function ec() {
  if (!this.fired)
    return this.target.removeListener(this.type, this.wrapFn), this.fired = !0, arguments.length === 0 ? this.listener.call(this.target) : this.listener.apply(this.target, arguments);
}
function Qr(t, e, r) {
  var i = { fired: !1, wrapFn: void 0, target: t, type: e, listener: r }, o = ec.bind(i);
  return o.listener = r, i.wrapFn = o, o;
}
z.prototype.once = function(e, r) {
  return Xe(r), this.on(e, Qr(this, e, r)), this;
};
z.prototype.prependOnceListener = function(e, r) {
  return Xe(r), this.prependListener(e, Qr(this, e, r)), this;
};
z.prototype.removeListener = function(e, r) {
  var i, o, f, l, a;
  if (Xe(r), o = this._events, o === void 0)
    return this;
  if (i = o[e], i === void 0)
    return this;
  if (i === r || i.listener === r)
    --this._eventsCount === 0 ? this._events = /* @__PURE__ */ Object.create(null) : (delete o[e], o.removeListener && this.emit("removeListener", e, i.listener || r));
  else if (typeof i != "function") {
    for (f = -1, l = i.length - 1; l >= 0; l--)
      if (i[l] === r || i[l].listener === r) {
        a = i[l].listener, f = l;
        break;
      }
    if (f < 0)
      return this;
    f === 0 ? i.shift() : tc(i, f), i.length === 1 && (o[e] = i[0]), o.removeListener !== void 0 && this.emit("removeListener", e, a || r);
  }
  return this;
};
z.prototype.off = z.prototype.removeListener;
z.prototype.removeAllListeners = function(e) {
  var r, i, o;
  if (i = this._events, i === void 0)
    return this;
  if (i.removeListener === void 0)
    return arguments.length === 0 ? (this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0) : i[e] !== void 0 && (--this._eventsCount === 0 ? this._events = /* @__PURE__ */ Object.create(null) : delete i[e]), this;
  if (arguments.length === 0) {
    var f = Object.keys(i), l;
    for (o = 0; o < f.length; ++o)
      l = f[o], l !== "removeListener" && this.removeAllListeners(l);
    return this.removeAllListeners("removeListener"), this._events = /* @__PURE__ */ Object.create(null), this._eventsCount = 0, this;
  }
  if (r = i[e], typeof r == "function")
    this.removeListener(e, r);
  else if (r !== void 0)
    for (o = r.length - 1; o >= 0; o--)
      this.removeListener(e, r[o]);
  return this;
};
function zr(t, e, r) {
  var i = t._events;
  if (i === void 0)
    return [];
  var o = i[e];
  return o === void 0 ? [] : typeof o == "function" ? r ? [o.listener || o] : [o] : r ? rc(o) : qr(o, o.length);
}
z.prototype.listeners = function(e) {
  return zr(this, e, !0);
};
z.prototype.rawListeners = function(e) {
  return zr(this, e, !1);
};
z.listenerCount = function(t, e) {
  return typeof t.listenerCount == "function" ? t.listenerCount(e) : Gr.call(t, e);
};
z.prototype.listenerCount = Gr;
function Gr(t) {
  var e = this._events;
  if (e !== void 0) {
    var r = e[t];
    if (typeof r == "function")
      return 1;
    if (r !== void 0)
      return r.length;
  }
  return 0;
}
z.prototype.eventNames = function() {
  return this._eventsCount > 0 ? Ye(this._events) : [];
};
function qr(t, e) {
  for (var r = new Array(e), i = 0; i < e; ++i)
    r[i] = t[i];
  return r;
}
function tc(t, e) {
  for (; e + 1 < t.length; e++)
    t[e] = t[e + 1];
  t.pop();
}
function rc(t) {
  for (var e = new Array(t.length), r = 0; r < e.length; ++r)
    e[r] = t[r].listener || t[r];
  return e;
}
function sc(t, e) {
  return new Promise(function(r, i) {
    function o(l) {
      t.removeListener(e, f), i(l);
    }
    function f() {
      typeof t.removeListener == "function" && t.removeListener("error", o), r([].slice.call(arguments));
    }
    Kr(t, e, f, { once: !0 }), e !== "error" && nc(t, o, { once: !0 });
  });
}
function nc(t, e, r) {
  typeof t.on == "function" && Kr(t, "error", e, r);
}
function Kr(t, e, r, i) {
  if (typeof t.on == "function")
    i.once ? t.once(e, r) : t.on(e, r);
  else if (typeof t.addEventListener == "function")
    t.addEventListener(e, function o(f) {
      i.once && t.removeEventListener(e, o), r(f);
    });
  else
    throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof t);
}
var Rt = Tt.exports, fe = {}, Hr = {};
(function(t) {
  Object.defineProperty(t, "__esModule", { value: !0 }), t.tryCatch = t.errorObj = void 0, t.errorObj = { e: {} };
  let e;
  function r(o, f) {
    try {
      const l = e;
      return e = null, l.apply(this, arguments);
    } catch (l) {
      return t.errorObj.e = l, t.errorObj;
    }
  }
  function i(o) {
    return e = o, r;
  }
  t.tryCatch = i;
})(Hr);
Object.defineProperty(fe, "__esModule", { value: !0 });
const we = Hr;
function lr(t) {
  setTimeout(function() {
    throw t;
  }, 0);
}
function ic(t, e, r) {
  return typeof e == "function" && t.then((i) => {
    let o;
    r !== void 0 && Object(r).spread && Array.isArray(i) ? o = we.tryCatch(e).apply(void 0, [null].concat(i)) : o = i === void 0 ? we.tryCatch(e)(null) : we.tryCatch(e)(null, i), o === we.errorObj && lr(o.e);
  }, (i) => {
    if (!i) {
      const f = new Error(i + "");
      Object.assign(f, { cause: i }), i = f;
    }
    const o = we.tryCatch(e)(i);
    o === we.errorObj && lr(o.e);
  }), t;
}
fe.default = ic;
var Qe = {};
const oc = {}, ac = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: oc
}, Symbol.toStringTag, { value: "Module" })), se = /* @__PURE__ */ xs(ac);
var lt, fr;
function cc() {
  if (fr) return lt;
  fr = 1;
  const t = se, e = se;
  function r(a) {
    Object.defineProperty(this, "message", {
      value: a || "",
      configurable: !0,
      writable: !0
    }), Error.captureStackTrace(this, this.constructor);
  }
  e.inherits(r, Error), Object.defineProperty(r.prototype, "name", {
    value: "RedisError",
    configurable: !0,
    writable: !0
  });
  function i(a, u, y) {
    t(u), t.strictEqual(typeof y, "number"), Object.defineProperty(this, "message", {
      value: a || "",
      configurable: !0,
      writable: !0
    });
    const g = Error.stackTraceLimit;
    Error.stackTraceLimit = 2, Error.captureStackTrace(this, this.constructor), Error.stackTraceLimit = g, this.offset = y, this.buffer = u;
  }
  e.inherits(i, r), Object.defineProperty(i.prototype, "name", {
    value: "ParserError",
    configurable: !0,
    writable: !0
  });
  function o(a) {
    Object.defineProperty(this, "message", {
      value: a || "",
      configurable: !0,
      writable: !0
    });
    const u = Error.stackTraceLimit;
    Error.stackTraceLimit = 2, Error.captureStackTrace(this, this.constructor), Error.stackTraceLimit = u;
  }
  e.inherits(o, r), Object.defineProperty(o.prototype, "name", {
    value: "ReplyError",
    configurable: !0,
    writable: !0
  });
  function f(a) {
    Object.defineProperty(this, "message", {
      value: a || "",
      configurable: !0,
      writable: !0
    }), Error.captureStackTrace(this, this.constructor);
  }
  e.inherits(f, r), Object.defineProperty(f.prototype, "name", {
    value: "AbortError",
    configurable: !0,
    writable: !0
  });
  function l(a) {
    Object.defineProperty(this, "message", {
      value: a || "",
      configurable: !0,
      writable: !0
    }), Error.captureStackTrace(this, this.constructor);
  }
  return e.inherits(l, f), Object.defineProperty(l.prototype, "name", {
    value: "InterruptError",
    configurable: !0,
    writable: !0
  }), lt = {
    RedisError: r,
    ParserError: i,
    ReplyError: o,
    AbortError: f,
    InterruptError: l
  }, lt;
}
var ft, hr;
function uc() {
  if (hr) return ft;
  hr = 1;
  const t = se;
  class e extends Error {
    get name() {
      return this.constructor.name;
    }
  }
  class r extends e {
    constructor(a, u, y) {
      t(u), t.strictEqual(typeof y, "number");
      const g = Error.stackTraceLimit;
      Error.stackTraceLimit = 2, super(a), Error.stackTraceLimit = g, this.offset = y, this.buffer = u;
    }
    get name() {
      return this.constructor.name;
    }
  }
  class i extends e {
    constructor(a) {
      const u = Error.stackTraceLimit;
      Error.stackTraceLimit = 2, super(a), Error.stackTraceLimit = u;
    }
    get name() {
      return this.constructor.name;
    }
  }
  class o extends e {
    get name() {
      return this.constructor.name;
    }
  }
  class f extends o {
    get name() {
      return this.constructor.name;
    }
  }
  return ft = {
    RedisError: e,
    ParserError: r,
    ReplyError: i,
    AbortError: o,
    InterruptError: f
  }, ft;
}
const lc = process.version.charCodeAt(1) < 55 && process.version.charCodeAt(2) === 46 ? cc() : uc();
var Ae = lc, ue = {}, Mt = { exports: {} }, dr = [
  0,
  4129,
  8258,
  12387,
  16516,
  20645,
  24774,
  28903,
  33032,
  37161,
  41290,
  45419,
  49548,
  53677,
  57806,
  61935,
  4657,
  528,
  12915,
  8786,
  21173,
  17044,
  29431,
  25302,
  37689,
  33560,
  45947,
  41818,
  54205,
  50076,
  62463,
  58334,
  9314,
  13379,
  1056,
  5121,
  25830,
  29895,
  17572,
  21637,
  42346,
  46411,
  34088,
  38153,
  58862,
  62927,
  50604,
  54669,
  13907,
  9842,
  5649,
  1584,
  30423,
  26358,
  22165,
  18100,
  46939,
  42874,
  38681,
  34616,
  63455,
  59390,
  55197,
  51132,
  18628,
  22757,
  26758,
  30887,
  2112,
  6241,
  10242,
  14371,
  51660,
  55789,
  59790,
  63919,
  35144,
  39273,
  43274,
  47403,
  23285,
  19156,
  31415,
  27286,
  6769,
  2640,
  14899,
  10770,
  56317,
  52188,
  64447,
  60318,
  39801,
  35672,
  47931,
  43802,
  27814,
  31879,
  19684,
  23749,
  11298,
  15363,
  3168,
  7233,
  60846,
  64911,
  52716,
  56781,
  44330,
  48395,
  36200,
  40265,
  32407,
  28342,
  24277,
  20212,
  15891,
  11826,
  7761,
  3696,
  65439,
  61374,
  57309,
  53244,
  48923,
  44858,
  40793,
  36728,
  37256,
  33193,
  45514,
  41451,
  53516,
  49453,
  61774,
  57711,
  4224,
  161,
  12482,
  8419,
  20484,
  16421,
  28742,
  24679,
  33721,
  37784,
  41979,
  46042,
  49981,
  54044,
  58239,
  62302,
  689,
  4752,
  8947,
  13010,
  16949,
  21012,
  25207,
  29270,
  46570,
  42443,
  38312,
  34185,
  62830,
  58703,
  54572,
  50445,
  13538,
  9411,
  5280,
  1153,
  29798,
  25671,
  21540,
  17413,
  42971,
  47098,
  34713,
  38840,
  59231,
  63358,
  50973,
  55100,
  9939,
  14066,
  1681,
  5808,
  26199,
  30326,
  17941,
  22068,
  55628,
  51565,
  63758,
  59695,
  39368,
  35305,
  47498,
  43435,
  22596,
  18533,
  30726,
  26663,
  6336,
  2273,
  14466,
  10403,
  52093,
  56156,
  60223,
  64286,
  35833,
  39896,
  43963,
  48026,
  19061,
  23124,
  27191,
  31254,
  2801,
  6864,
  10931,
  14994,
  64814,
  60687,
  56684,
  52557,
  48554,
  44427,
  40424,
  36297,
  31782,
  27655,
  23652,
  19525,
  15522,
  11395,
  7392,
  3265,
  61215,
  65342,
  53085,
  57212,
  44955,
  49082,
  36825,
  40952,
  28183,
  32310,
  20053,
  24180,
  11923,
  16050,
  3793,
  7920
], fc = function(e) {
  for (var r, i = 0, o = 0, f = [], l = e.length; i < l; i++)
    r = e.charCodeAt(i), r < 128 ? f[o++] = r : r < 2048 ? (f[o++] = r >> 6 | 192, f[o++] = r & 63 | 128) : (r & 64512) === 55296 && i + 1 < e.length && (e.charCodeAt(i + 1) & 64512) === 56320 ? (r = 65536 + ((r & 1023) << 10) + (e.charCodeAt(++i) & 1023), f[o++] = r >> 18 | 240, f[o++] = r >> 12 & 63 | 128, f[o++] = r >> 6 & 63 | 128, f[o++] = r & 63 | 128) : (f[o++] = r >> 12 | 224, f[o++] = r >> 6 & 63 | 128, f[o++] = r & 63 | 128);
  return f;
}, pr = Mt.exports = function(e) {
  for (var r, i = 0, o = -1, f = 0, l = 0, a = typeof e == "string" ? fc(e) : e, u = a.length; i < u; ) {
    if (r = a[i++], o === -1)
      r === 123 && (o = i);
    else if (r !== 125)
      l = dr[(r ^ l >> 8) & 255] ^ l << 8;
    else if (i - 1 !== o)
      return l & 16383;
    f = dr[(r ^ f >> 8) & 255] ^ f << 8;
  }
  return f & 16383;
};
Mt.exports.generateMulti = function(e) {
  for (var r = 1, i = e.length, o = pr(e[0]); r < i; )
    if (pr(e[r++]) !== o) return -1;
  return o;
};
var Ze = Mt.exports, Z = {}, ce = {}, Yr = 9007199254740991, hc = "[object Arguments]", dc = "[object Function]", pc = "[object GeneratorFunction]", yc = /^(?:0|[1-9]\d*)$/;
function Vr(t, e, r) {
  switch (r.length) {
    case 0:
      return t.call(e);
    case 1:
      return t.call(e, r[0]);
    case 2:
      return t.call(e, r[0], r[1]);
    case 3:
      return t.call(e, r[0], r[1], r[2]);
  }
  return t.apply(e, r);
}
function gc(t, e) {
  for (var r = -1, i = Array(t); ++r < t; )
    i[r] = e(r);
  return i;
}
var Oe = Object.prototype, $e = Oe.hasOwnProperty, Wr = Oe.toString, mc = Oe.propertyIsEnumerable, yr = Math.max;
function bc(t, e) {
  var r = Bc(t) || Ac(t) ? gc(t.length, String) : [], i = r.length, o = !!i;
  for (var f in t)
    o && (f == "length" || Xr(f, i)) || r.push(f);
  return r;
}
function Sc(t, e, r, i) {
  return t === void 0 || Ot(t, Oe[r]) && !$e.call(i, r) ? e : t;
}
function kc(t, e, r) {
  var i = t[e];
  (!($e.call(t, e) && Ot(i, r)) || r === void 0 && !(e in t)) && (t[e] = r);
}
function wc(t) {
  if (!Ft(t))
    return vc(t);
  var e = xc(t), r = [];
  for (var i in t)
    i == "constructor" && (e || !$e.call(t, i)) || r.push(i);
  return r;
}
function Jr(t, e) {
  return e = yr(e === void 0 ? t.length - 1 : e, 0), function() {
    for (var r = arguments, i = -1, o = yr(r.length - e, 0), f = Array(o); ++i < o; )
      f[i] = r[e + i];
    i = -1;
    for (var l = Array(e + 1); ++i < e; )
      l[i] = r[i];
    return l[e] = f, Vr(t, this, l);
  };
}
function Ec(t, e, r, i) {
  r || (r = {});
  for (var o = -1, f = e.length; ++o < f; ) {
    var l = e[o], a = i ? i(r[l], t[l], l, r, t) : void 0;
    kc(r, l, a === void 0 ? t[l] : a);
  }
  return r;
}
function Cc(t) {
  return Jr(function(e, r) {
    var i = -1, o = r.length, f = o > 1 ? r[o - 1] : void 0, l = o > 2 ? r[2] : void 0;
    for (f = t.length > 3 && typeof f == "function" ? (o--, f) : void 0, l && _c(r[0], r[1], l) && (f = o < 3 ? void 0 : f, o = 1), e = Object(e); ++i < o; ) {
      var a = r[i];
      a && t(e, a, i, f);
    }
    return e;
  });
}
function Xr(t, e) {
  return e = e ?? Yr, !!e && (typeof t == "number" || yc.test(t)) && t > -1 && t % 1 == 0 && t < e;
}
function _c(t, e, r) {
  if (!Ft(r))
    return !1;
  var i = typeof e;
  return (i == "number" ? It(r) && Xr(e, r.length) : i == "string" && e in r) ? Ot(r[e], t) : !1;
}
function xc(t) {
  var e = t && t.constructor, r = typeof e == "function" && e.prototype || Oe;
  return t === r;
}
function vc(t) {
  var e = [];
  if (t != null)
    for (var r in Object(t))
      e.push(r);
  return e;
}
function Ot(t, e) {
  return t === e || t !== t && e !== e;
}
function Ac(t) {
  return Tc(t) && $e.call(t, "callee") && (!mc.call(t, "callee") || Wr.call(t) == hc);
}
var Bc = Array.isArray;
function It(t) {
  return t != null && Mc(t.length) && !Rc(t);
}
function Tc(t) {
  return Oc(t) && It(t);
}
function Rc(t) {
  var e = Ft(t) ? Wr.call(t) : "";
  return e == dc || e == pc;
}
function Mc(t) {
  return typeof t == "number" && t > -1 && t % 1 == 0 && t <= Yr;
}
function Ft(t) {
  var e = typeof t;
  return !!t && (e == "object" || e == "function");
}
function Oc(t) {
  return !!t && typeof t == "object";
}
var Ic = Cc(function(t, e, r, i) {
  Ec(e, Pc(e), t, i);
}), Fc = Jr(function(t) {
  return t.push(void 0, Sc), Vr(Ic, void 0, t);
});
function Pc(t) {
  return It(t) ? bc(t) : wc(t);
}
var Nc = Fc, Dc = 9007199254740991, Lc = "[object Arguments]", Uc = "[object Function]", jc = "[object GeneratorFunction]", Pt = Object.prototype, Qc = Pt.hasOwnProperty, Zr = Pt.toString, zc = Pt.propertyIsEnumerable;
function Gc(t) {
  return Kc(t) && Qc.call(t, "callee") && (!zc.call(t, "callee") || Zr.call(t) == Lc);
}
function qc(t) {
  return t != null && Yc(t.length) && !Hc(t);
}
function Kc(t) {
  return Wc(t) && qc(t);
}
function Hc(t) {
  var e = Vc(t) ? Zr.call(t) : "";
  return e == Uc || e == jc;
}
function Yc(t) {
  return typeof t == "number" && t > -1 && t % 1 == 0 && t <= Dc;
}
function Vc(t) {
  var e = typeof t;
  return !!t && (e == "object" || e == "function");
}
function Wc(t) {
  return !!t && typeof t == "object";
}
var Jc = Gc;
Object.defineProperty(ce, "__esModule", { value: !0 });
ce.isArguments = ce.defaults = ce.noop = void 0;
const Xc = Nc;
ce.defaults = Xc;
const Zc = Jc;
ce.isArguments = Zc;
function $c() {
}
ce.noop = $c;
var le = {}, Ct = { exports: {} }, ht, gr;
function eu() {
  if (gr) return ht;
  gr = 1;
  var t = 1e3, e = t * 60, r = e * 60, i = r * 24, o = i * 7, f = i * 365.25;
  ht = function(g, k) {
    k = k || {};
    var w = typeof g;
    if (w === "string" && g.length > 0)
      return l(g);
    if (w === "number" && isFinite(g))
      return k.long ? u(g) : a(g);
    throw new Error(
      "val is not a non-empty string or a valid number. val=" + JSON.stringify(g)
    );
  };
  function l(g) {
    if (g = String(g), !(g.length > 100)) {
      var k = /^(-?(?:\d+)?\.?\d+) *(milliseconds?|msecs?|ms|seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)?$/i.exec(
        g
      );
      if (k) {
        var w = parseFloat(k[1]), x = (k[2] || "ms").toLowerCase();
        switch (x) {
          case "years":
          case "year":
          case "yrs":
          case "yr":
          case "y":
            return w * f;
          case "weeks":
          case "week":
          case "w":
            return w * o;
          case "days":
          case "day":
          case "d":
            return w * i;
          case "hours":
          case "hour":
          case "hrs":
          case "hr":
          case "h":
            return w * r;
          case "minutes":
          case "minute":
          case "mins":
          case "min":
          case "m":
            return w * e;
          case "seconds":
          case "second":
          case "secs":
          case "sec":
          case "s":
            return w * t;
          case "milliseconds":
          case "millisecond":
          case "msecs":
          case "msec":
          case "ms":
            return w;
          default:
            return;
        }
      }
    }
  }
  function a(g) {
    var k = Math.abs(g);
    return k >= i ? Math.round(g / i) + "d" : k >= r ? Math.round(g / r) + "h" : k >= e ? Math.round(g / e) + "m" : k >= t ? Math.round(g / t) + "s" : g + "ms";
  }
  function u(g) {
    var k = Math.abs(g);
    return k >= i ? y(g, k, i, "day") : k >= r ? y(g, k, r, "hour") : k >= e ? y(g, k, e, "minute") : k >= t ? y(g, k, t, "second") : g + " ms";
  }
  function y(g, k, w, x) {
    var p = k >= w * 1.5;
    return Math.round(g / w) + " " + x + (p ? "s" : "");
  }
  return ht;
}
function tu(t) {
  r.debug = r, r.default = r, r.coerce = u, r.disable = l, r.enable = o, r.enabled = a, r.humanize = eu(), r.destroy = y, Object.keys(t).forEach((g) => {
    r[g] = t[g];
  }), r.names = [], r.skips = [], r.formatters = {};
  function e(g) {
    let k = 0;
    for (let w = 0; w < g.length; w++)
      k = (k << 5) - k + g.charCodeAt(w), k |= 0;
    return r.colors[Math.abs(k) % r.colors.length];
  }
  r.selectColor = e;
  function r(g) {
    let k, w = null, x, p;
    function R(..._) {
      if (!R.enabled)
        return;
      const A = R, I = Number(/* @__PURE__ */ new Date()), S = I - (k || I);
      A.diff = S, A.prev = k, A.curr = I, k = I, _[0] = r.coerce(_[0]), typeof _[0] != "string" && _.unshift("%O");
      let T = 0;
      _[0] = _[0].replace(/%([a-zA-Z%])/g, (N, d) => {
        if (N === "%%")
          return "%";
        T++;
        const m = r.formatters[d];
        if (typeof m == "function") {
          const E = _[T];
          N = m.call(A, E), _.splice(T, 1), T--;
        }
        return N;
      }), r.formatArgs.call(A, _), (A.log || r.log).apply(A, _);
    }
    return R.namespace = g, R.useColors = r.useColors(), R.color = r.selectColor(g), R.extend = i, R.destroy = r.destroy, Object.defineProperty(R, "enabled", {
      enumerable: !0,
      configurable: !1,
      get: () => w !== null ? w : (x !== r.namespaces && (x = r.namespaces, p = r.enabled(g)), p),
      set: (_) => {
        w = _;
      }
    }), typeof r.init == "function" && r.init(R), R;
  }
  function i(g, k) {
    const w = r(this.namespace + (typeof k > "u" ? ":" : k) + g);
    return w.log = this.log, w;
  }
  function o(g) {
    r.save(g), r.namespaces = g, r.names = [], r.skips = [];
    const k = (typeof g == "string" ? g : "").trim().replace(/\s+/g, ",").split(",").filter(Boolean);
    for (const w of k)
      w[0] === "-" ? r.skips.push(w.slice(1)) : r.names.push(w);
  }
  function f(g, k) {
    let w = 0, x = 0, p = -1, R = 0;
    for (; w < g.length; )
      if (x < k.length && (k[x] === g[w] || k[x] === "*"))
        k[x] === "*" ? (p = x, R = w, x++) : (w++, x++);
      else if (p !== -1)
        x = p + 1, R++, w = R;
      else
        return !1;
    for (; x < k.length && k[x] === "*"; )
      x++;
    return x === k.length;
  }
  function l() {
    const g = [
      ...r.names,
      ...r.skips.map((k) => "-" + k)
    ].join(",");
    return r.enable(""), g;
  }
  function a(g) {
    for (const k of r.skips)
      if (f(g, k))
        return !1;
    for (const k of r.names)
      if (f(g, k))
        return !0;
    return !1;
  }
  function u(g) {
    return g instanceof Error ? g.stack || g.message : g;
  }
  function y() {
    console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`.");
  }
  return r.enable(r.load()), r;
}
var ru = tu;
(function(t, e) {
  e.formatArgs = i, e.save = o, e.load = f, e.useColors = r, e.storage = l(), e.destroy = /* @__PURE__ */ (() => {
    let u = !1;
    return () => {
      u || (u = !0, console.warn("Instance method `debug.destroy()` is deprecated and no longer does anything. It will be removed in the next major version of `debug`."));
    };
  })(), e.colors = [
    "#0000CC",
    "#0000FF",
    "#0033CC",
    "#0033FF",
    "#0066CC",
    "#0066FF",
    "#0099CC",
    "#0099FF",
    "#00CC00",
    "#00CC33",
    "#00CC66",
    "#00CC99",
    "#00CCCC",
    "#00CCFF",
    "#3300CC",
    "#3300FF",
    "#3333CC",
    "#3333FF",
    "#3366CC",
    "#3366FF",
    "#3399CC",
    "#3399FF",
    "#33CC00",
    "#33CC33",
    "#33CC66",
    "#33CC99",
    "#33CCCC",
    "#33CCFF",
    "#6600CC",
    "#6600FF",
    "#6633CC",
    "#6633FF",
    "#66CC00",
    "#66CC33",
    "#9900CC",
    "#9900FF",
    "#9933CC",
    "#9933FF",
    "#99CC00",
    "#99CC33",
    "#CC0000",
    "#CC0033",
    "#CC0066",
    "#CC0099",
    "#CC00CC",
    "#CC00FF",
    "#CC3300",
    "#CC3333",
    "#CC3366",
    "#CC3399",
    "#CC33CC",
    "#CC33FF",
    "#CC6600",
    "#CC6633",
    "#CC9900",
    "#CC9933",
    "#CCCC00",
    "#CCCC33",
    "#FF0000",
    "#FF0033",
    "#FF0066",
    "#FF0099",
    "#FF00CC",
    "#FF00FF",
    "#FF3300",
    "#FF3333",
    "#FF3366",
    "#FF3399",
    "#FF33CC",
    "#FF33FF",
    "#FF6600",
    "#FF6633",
    "#FF9900",
    "#FF9933",
    "#FFCC00",
    "#FFCC33"
  ];
  function r() {
    if (typeof window < "u" && window.process && (window.process.type === "renderer" || window.process.__nwjs))
      return !0;
    if (typeof navigator < "u" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/(edge|trident)\/(\d+)/))
      return !1;
    let u;
    return typeof document < "u" && document.documentElement && document.documentElement.style && document.documentElement.style.WebkitAppearance || // Is firebug? http://stackoverflow.com/a/398120/376773
    typeof window < "u" && window.console && (window.console.firebug || window.console.exception && window.console.table) || // Is firefox >= v31?
    // https://developer.mozilla.org/en-US/docs/Tools/Web_Console#Styling_messages
    typeof navigator < "u" && navigator.userAgent && (u = navigator.userAgent.toLowerCase().match(/firefox\/(\d+)/)) && parseInt(u[1], 10) >= 31 || // Double check webkit in userAgent just in case we are in a worker
    typeof navigator < "u" && navigator.userAgent && navigator.userAgent.toLowerCase().match(/applewebkit\/(\d+)/);
  }
  function i(u) {
    if (u[0] = (this.useColors ? "%c" : "") + this.namespace + (this.useColors ? " %c" : " ") + u[0] + (this.useColors ? "%c " : " ") + "+" + t.exports.humanize(this.diff), !this.useColors)
      return;
    const y = "color: " + this.color;
    u.splice(1, 0, y, "color: inherit");
    let g = 0, k = 0;
    u[0].replace(/%[a-zA-Z%]/g, (w) => {
      w !== "%%" && (g++, w === "%c" && (k = g));
    }), u.splice(k, 0, y);
  }
  e.log = console.debug || console.log || (() => {
  });
  function o(u) {
    try {
      u ? e.storage.setItem("debug", u) : e.storage.removeItem("debug");
    } catch {
    }
  }
  function f() {
    let u;
    try {
      u = e.storage.getItem("debug") || e.storage.getItem("DEBUG");
    } catch {
    }
    return !u && typeof process < "u" && "env" in process && (u = process.env.DEBUG), u;
  }
  function l() {
    try {
      return localStorage;
    } catch {
    }
  }
  t.exports = ru(e);
  const { formatters: a } = t.exports;
  a.j = function(u) {
    try {
      return JSON.stringify(u);
    } catch (y) {
      return "[UnexpectedJSONParseError]: " + y.message;
    }
  };
})(Ct, Ct.exports);
var su = Ct.exports;
Object.defineProperty(le, "__esModule", { value: !0 });
le.genRedactedString = le.getStringValue = le.MAX_ARGUMENT_LENGTH = void 0;
const nu = su, _t = 200;
le.MAX_ARGUMENT_LENGTH = _t;
const iu = "ioredis";
function $r(t) {
  if (t !== null)
    switch (typeof t) {
      case "boolean":
        return;
      case "number":
        return;
      case "object":
        if (Buffer.isBuffer(t))
          return t.toString("hex");
        if (Array.isArray(t))
          return t.join(",");
        try {
          return JSON.stringify(t);
        } catch {
          return;
        }
      case "string":
        return t;
    }
}
le.getStringValue = $r;
function es(t, e) {
  const { length: r } = t;
  return r <= e ? t : t.slice(0, e) + ' ... <REDACTED full-length="' + r + '">';
}
le.genRedactedString = es;
function ou(t) {
  const e = (0, nu.default)(`${iu}:${t}`);
  function r(...i) {
    if (e.enabled) {
      for (let o = 1; o < i.length; o++) {
        const f = $r(i[o]);
        typeof f == "string" && f.length > _t && (i[o] = es(f, _t));
      }
      return e.apply(null, i);
    }
  }
  return Object.defineProperties(r, {
    namespace: {
      get() {
        return e.namespace;
      }
    },
    enabled: {
      get() {
        return e.enabled;
      }
    },
    destroy: {
      get() {
        return e.destroy;
      }
    },
    log: {
      get() {
        return e.log;
      },
      set(i) {
        e.log = i;
      }
    }
  }), r;
}
le.default = ou;
var Nt = {};
Object.defineProperty(Nt, "__esModule", { value: !0 });
const mr = `-----BEGIN CERTIFICATE-----
MIIDTzCCAjegAwIBAgIJAKSVpiDswLcwMA0GCSqGSIb3DQEBBQUAMD4xFjAUBgNV
BAoMDUdhcmFudGlhIERhdGExJDAiBgNVBAMMG1NTTCBDZXJ0aWZpY2F0aW9uIEF1
dGhvcml0eTAeFw0xMzEwMDExMjE0NTVaFw0yMzA5MjkxMjE0NTVaMD4xFjAUBgNV
BAoMDUdhcmFudGlhIERhdGExJDAiBgNVBAMMG1NTTCBDZXJ0aWZpY2F0aW9uIEF1
dGhvcml0eTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALZqkh/DczWP
JnxnHLQ7QL0T4B4CDKWBKCcisriGbA6ZePWVNo4hfKQC6JrzfR+081NeD6VcWUiz
rmd+jtPhIY4c+WVQYm5PKaN6DT1imYdxQw7aqO5j2KUCEh/cznpLxeSHoTxlR34E
QwF28Wl3eg2vc5ct8LjU3eozWVk3gb7alx9mSA2SgmuX5lEQawl++rSjsBStemY2
BDwOpAMXIrdEyP/cVn8mkvi/BDs5M5G+09j0gfhyCzRWMQ7Hn71u1eolRxwVxgi3
TMn+/vTaFSqxKjgck6zuAYjBRPaHe7qLxHNr1So/Mc9nPy+3wHebFwbIcnUojwbp
4nctkWbjb2cCAwEAAaNQME4wHQYDVR0OBBYEFP1whtcrydmW3ZJeuSoKZIKjze3w
MB8GA1UdIwQYMBaAFP1whtcrydmW3ZJeuSoKZIKjze3wMAwGA1UdEwQFMAMBAf8w
DQYJKoZIhvcNAQEFBQADggEBAG2erXhwRAa7+ZOBs0B6X57Hwyd1R4kfmXcs0rta
lbPpvgULSiB+TCbf3EbhJnHGyvdCY1tvlffLjdA7HJ0PCOn+YYLBA0pTU/dyvrN6
Su8NuS5yubnt9mb13nDGYo1rnt0YRfxN+8DM3fXIVr038A30UlPX2Ou1ExFJT0MZ
uFKY6ZvLdI6/1cbgmguMlAhM+DhKyV6Sr5699LM3zqeI816pZmlREETYkGr91q7k
BpXJu/dtHaGxg1ZGu6w/PCsYGUcECWENYD4VQPd8N32JjOfu6vEgoEAwfPP+3oGp
Z4m3ewACcWOAenqflb+cQYC4PsF7qbXDmRaWrbKntOlZ3n0=
-----END CERTIFICATE-----
-----BEGIN CERTIFICATE-----
MIIGMTCCBBmgAwIBAgICEAAwDQYJKoZIhvcNAQELBQAwajELMAkGA1UEBhMCVVMx
CzAJBgNVBAgMAkNBMQswCQYDVQQHDAJDQTESMBAGA1UECgwJUmVkaXNMYWJzMS0w
KwYDVQQDDCRSZWRpc0xhYnMgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwHhcN
MTgwMjI1MTUzNzM3WhcNMjgwMjIzMTUzNzM3WjBfMQswCQYDVQQGEwJVUzELMAkG
A1UECAwCQ0ExEjAQBgNVBAoMCVJlZGlzTGFiczEvMC0GA1UEAwwmUkNQIEludGVy
bWVkaWF0ZSBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkwggIiMA0GCSqGSIb3DQEBAQUA
A4ICDwAwggIKAoICAQDf9dqbxc8Bq7Ctq9rWcxrGNKKHivqLAFpPq02yLPx6fsOv
Tq7GsDChAYBBc4v7Y2Ap9RD5Vs3dIhEANcnolf27QwrG9RMnnvzk8pCvp1o6zSU4
VuOE1W66/O1/7e2rVxyrnTcP7UgK43zNIXu7+tiAqWsO92uSnuMoGPGpeaUm1jym
hjWKtkAwDFSqvHY+XL5qDVBEjeUe+WHkYUg40cAXjusAqgm2hZt29c2wnVrxW25W
P0meNlzHGFdA2AC5z54iRiqj57dTfBTkHoBczQxcyw6hhzxZQ4e5I5zOKjXXEhZN
r0tA3YC14CTabKRus/JmZieyZzRgEy2oti64tmLYTqSlAD78pRL40VNoaSYetXLw
hhNsXCHgWaY6d5bLOc/aIQMAV5oLvZQKvuXAF1IDmhPA+bZbpWipp0zagf1P1H3s
UzsMdn2KM0ejzgotbtNlj5TcrVwpmvE3ktvUAuA+hi3FkVx1US+2Gsp5x4YOzJ7u
P1WPk6ShF0JgnJH2ILdj6kttTWwFzH17keSFICWDfH/+kM+k7Y1v3EXMQXE7y0T9
MjvJskz6d/nv+sQhY04xt64xFMGTnZjlJMzfQNi7zWFLTZnDD0lPowq7l3YiPoTT
t5Xky83lu0KZsZBo0WlWaDG00gLVdtRgVbcuSWxpi5BdLb1kRab66JptWjxwXQID
AQABo4HrMIHoMDoGA1UdHwQzMDEwL6AtoCuGKWh0dHBzOi8vcmwtY2Etc2VydmVy
LnJlZGlzbGFicy5jb20vdjEvY3JsMEYGCCsGAQUFBwEBBDowODA2BggrBgEFBQcw
AYYqaHR0cHM6Ly9ybC1jYS1zZXJ2ZXIucmVkaXNsYWJzLmNvbS92MS9vY3NwMB0G
A1UdDgQWBBQHar5OKvQUpP2qWt6mckzToeCOHDAfBgNVHSMEGDAWgBQi42wH6hM4
L2sujEvLM0/u8lRXTzASBgNVHRMBAf8ECDAGAQH/AgEAMA4GA1UdDwEB/wQEAwIB
hjANBgkqhkiG9w0BAQsFAAOCAgEAirEn/iTsAKyhd+pu2W3Z5NjCko4NPU0EYUbr
AP7+POK2rzjIrJO3nFYQ/LLuC7KCXG+2qwan2SAOGmqWst13Y+WHp44Kae0kaChW
vcYLXXSoGQGC8QuFSNUdaeg3RbMDYFT04dOkqufeWVccoHVxyTSg9eD8LZuHn5jw
7QDLiEECBmIJHk5Eeo2TAZrx4Yx6ufSUX5HeVjlAzqwtAqdt99uCJ/EL8bgpWbe+
XoSpvUv0SEC1I1dCAhCKAvRlIOA6VBcmzg5Am12KzkqTul12/VEFIgzqu0Zy2Jbc
AUPrYVu/+tOGXQaijy7YgwH8P8n3s7ZeUa1VABJHcxrxYduDDJBLZi+MjheUDaZ1
jQRHYevI2tlqeSBqdPKG4zBY5lS0GiAlmuze5oENt0P3XboHoZPHiqcK3VECgTVh
/BkJcuudETSJcZDmQ8YfoKfBzRQNg2sv/hwvUv73Ss51Sco8GEt2lD8uEdib1Q6z
zDT5lXJowSzOD5ZA9OGDjnSRL+2riNtKWKEqvtEG3VBJoBzu9GoxbAc7wIZLxmli
iF5a/Zf5X+UXD3s4TMmy6C4QZJpAA2egsSQCnraWO2ULhh7iXMysSkF/nzVfZn43
iqpaB8++9a37hWq14ZmOv0TJIDz//b2+KC4VFXWQ5W5QC6whsjT+OlG4p5ZYG0jo
616pxqo=
-----END CERTIFICATE-----
-----BEGIN CERTIFICATE-----
MIIFujCCA6KgAwIBAgIJAJ1aTT1lu2ScMA0GCSqGSIb3DQEBCwUAMGoxCzAJBgNV
BAYTAlVTMQswCQYDVQQIDAJDQTELMAkGA1UEBwwCQ0ExEjAQBgNVBAoMCVJlZGlz
TGFiczEtMCsGA1UEAwwkUmVkaXNMYWJzIFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9y
aXR5MB4XDTE4MDIyNTE1MjA0MloXDTM4MDIyMDE1MjA0MlowajELMAkGA1UEBhMC
VVMxCzAJBgNVBAgMAkNBMQswCQYDVQQHDAJDQTESMBAGA1UECgwJUmVkaXNMYWJz
MS0wKwYDVQQDDCRSZWRpc0xhYnMgUm9vdCBDZXJ0aWZpY2F0ZSBBdXRob3JpdHkw
ggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDLEjXy7YrbN5Waau5cd6g1
G5C2tMmeTpZ0duFAPxNU4oE3RHS5gGiok346fUXuUxbZ6QkuzeN2/2Z+RmRcJhQY
Dm0ZgdG4x59An1TJfnzKKoWj8ISmoHS/TGNBdFzXV7FYNLBuqZouqePI6ReC6Qhl
pp45huV32Q3a6IDrrvx7Wo5ZczEQeFNbCeCOQYNDdTmCyEkHqc2AGo8eoIlSTutT
ULOC7R5gzJVTS0e1hesQ7jmqHjbO+VQS1NAL4/5K6cuTEqUl+XhVhPdLWBXJQ5ag
54qhX4v+ojLzeU1R/Vc6NjMvVtptWY6JihpgplprN0Yh2556ewcXMeturcKgXfGJ
xeYzsjzXerEjrVocX5V8BNrg64NlifzTMKNOOv4fVZszq1SIHR8F9ROrqiOdh8iC
JpUbLpXH9hWCSEO6VRMB2xJoKu3cgl63kF30s77x7wLFMEHiwsQRKxooE1UhgS9K
2sO4TlQ1eWUvFvHSTVDQDlGQ6zu4qjbOpb3Q8bQwoK+ai2alkXVR4Ltxe9QlgYK3
StsnPhruzZGA0wbXdpw0bnM+YdlEm5ffSTpNIfgHeaa7Dtb801FtA71ZlH7A6TaI
SIQuUST9EKmv7xrJyx0W1pGoPOLw5T029aTjnICSLdtV9bLwysrLhIYG5bnPq78B
cS+jZHFGzD7PUVGQD01nOQIDAQABo2MwYTAdBgNVHQ4EFgQUIuNsB+oTOC9rLoxL
yzNP7vJUV08wHwYDVR0jBBgwFoAUIuNsB+oTOC9rLoxLyzNP7vJUV08wDwYDVR0T
AQH/BAUwAwEB/zAOBgNVHQ8BAf8EBAMCAYYwDQYJKoZIhvcNAQELBQADggIBAHfg
z5pMNUAKdMzK1aS1EDdK9yKz4qicILz5czSLj1mC7HKDRy8cVADUxEICis++CsCu
rYOvyCVergHQLREcxPq4rc5Nq1uj6J6649NEeh4WazOOjL4ZfQ1jVznMbGy+fJm3
3Hoelv6jWRG9iqeJZja7/1s6YC6bWymI/OY1e4wUKeNHAo+Vger7MlHV+RuabaX+
hSJ8bJAM59NCM7AgMTQpJCncrcdLeceYniGy5Q/qt2b5mJkQVkIdy4TPGGB+AXDJ
D0q3I/JDRkDUFNFdeW0js7fHdsvCR7O3tJy5zIgEV/o/BCkmJVtuwPYOrw/yOlKj
TY/U7ATAx9VFF6/vYEOMYSmrZlFX+98L6nJtwDqfLB5VTltqZ4H/KBxGE3IRSt9l
FXy40U+LnXzhhW+7VBAvyYX8GEXhHkKU8Gqk1xitrqfBXY74xKgyUSTolFSfFVgj
mcM/X4K45bka+qpkj7Kfv/8D4j6aZekwhN2ly6hhC1SmQ8qjMjpG/mrWOSSHZFmf
ybu9iD2AYHeIOkshIl6xYIa++Q/00/vs46IzAbQyriOi0XxlSMMVtPx0Q3isp+ji
n8Mq9eOuxYOEQ4of8twUkUDd528iwGtEdwf0Q01UyT84S62N8AySl1ZBKXJz6W4F
UhWfa/HQYOAPDdEjNgnVwLI23b8t0TozyCWw7q8h
-----END CERTIFICATE-----

-----BEGIN CERTIFICATE-----
MIIEjzCCA3egAwIBAgIQe55B/ALCKJDZtdNT8kD6hTANBgkqhkiG9w0BAQsFADBM
MSAwHgYDVQQLExdHbG9iYWxTaWduIFJvb3QgQ0EgLSBSMzETMBEGA1UEChMKR2xv
YmFsU2lnbjETMBEGA1UEAxMKR2xvYmFsU2lnbjAeFw0yMjAxMjYxMjAwMDBaFw0y
NTAxMjYwMDAwMDBaMFgxCzAJBgNVBAYTAkJFMRkwFwYDVQQKExBHbG9iYWxTaWdu
IG52LXNhMS4wLAYDVQQDEyVHbG9iYWxTaWduIEF0bGFzIFIzIE9WIFRMUyBDQSAy
MDIyIFEyMIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAmGmg1LW9b7Lf
8zDD83yBDTEkt+FOxKJZqF4veWc5KZsQj9HfnUS2e5nj/E+JImlGPsQuoiosLuXD
BVBNAMcUFa11buFMGMeEMwiTmCXoXRrXQmH0qjpOfKgYc5gHG3BsRGaRrf7VR4eg
ofNMG9wUBw4/g/TT7+bQJdA4NfE7Y4d5gEryZiBGB/swaX6Jp/8MF4TgUmOWmalK
dZCKyb4sPGQFRTtElk67F7vU+wdGcrcOx1tDcIB0ncjLPMnaFicagl+daWGsKqTh
counQb6QJtYHa91KvCfKWocMxQ7OIbB5UARLPmC4CJ1/f8YFm35ebfzAeULYdGXu
jE9CLor0OwIDAQABo4IBXzCCAVswDgYDVR0PAQH/BAQDAgGGMB0GA1UdJQQWMBQG
CCsGAQUFBwMBBggrBgEFBQcDAjASBgNVHRMBAf8ECDAGAQH/AgEAMB0GA1UdDgQW
BBSH5Zq7a7B/t95GfJWkDBpA8HHqdjAfBgNVHSMEGDAWgBSP8Et/qC5FJK5NUPpj
move4t0bvDB7BggrBgEFBQcBAQRvMG0wLgYIKwYBBQUHMAGGImh0dHA6Ly9vY3Nw
Mi5nbG9iYWxzaWduLmNvbS9yb290cjMwOwYIKwYBBQUHMAKGL2h0dHA6Ly9zZWN1
cmUuZ2xvYmFsc2lnbi5jb20vY2FjZXJ0L3Jvb3QtcjMuY3J0MDYGA1UdHwQvMC0w
K6ApoCeGJWh0dHA6Ly9jcmwuZ2xvYmFsc2lnbi5jb20vcm9vdC1yMy5jcmwwIQYD
VR0gBBowGDAIBgZngQwBAgIwDAYKKwYBBAGgMgoBAjANBgkqhkiG9w0BAQsFAAOC
AQEAKRic9/f+nmhQU/wz04APZLjgG5OgsuUOyUEZjKVhNGDwxGTvKhyXGGAMW2B/
3bRi+aElpXwoxu3pL6fkElbX3B0BeS5LoDtxkyiVEBMZ8m+sXbocwlPyxrPbX6mY
0rVIvnuUeBH8X0L5IwfpNVvKnBIilTbcebfHyXkPezGwz7E1yhUULjJFm2bt0SdX
y+4X/WeiiYIv+fTVgZZgl+/2MKIsu/qdBJc3f3TvJ8nz+Eax1zgZmww+RSQWeOj3
15Iw6Z5FX+NwzY/Ab+9PosR5UosSeq+9HhtaxZttXG1nVh+avYPGYddWmiMT90J5
ZgKnO/Fx2hBgTxhOTMYaD312kg==
-----END CERTIFICATE-----

-----BEGIN CERTIFICATE-----
MIIDXzCCAkegAwIBAgILBAAAAAABIVhTCKIwDQYJKoZIhvcNAQELBQAwTDEgMB4G
A1UECxMXR2xvYmFsU2lnbiBSb290IENBIC0gUjMxEzARBgNVBAoTCkdsb2JhbFNp
Z24xEzARBgNVBAMTCkdsb2JhbFNpZ24wHhcNMDkwMzE4MTAwMDAwWhcNMjkwMzE4
MTAwMDAwWjBMMSAwHgYDVQQLExdHbG9iYWxTaWduIFJvb3QgQ0EgLSBSMzETMBEG
A1UEChMKR2xvYmFsU2lnbjETMBEGA1UEAxMKR2xvYmFsU2lnbjCCASIwDQYJKoZI
hvcNAQEBBQADggEPADCCAQoCggEBAMwldpB5BngiFvXAg7aEyiie/QV2EcWtiHL8
RgJDx7KKnQRfJMsuS+FggkbhUqsMgUdwbN1k0ev1LKMPgj0MK66X17YUhhB5uzsT
gHeMCOFJ0mpiLx9e+pZo34knlTifBtc+ycsmWQ1z3rDI6SYOgxXG71uL0gRgykmm
KPZpO/bLyCiR5Z2KYVc3rHQU3HTgOu5yLy6c+9C7v/U9AOEGM+iCK65TpjoWc4zd
QQ4gOsC0p6Hpsk+QLjJg6VfLuQSSaGjlOCZgdbKfd/+RFO+uIEn8rUAVSNECMWEZ
XriX7613t2Saer9fwRPvm2L7DWzgVGkWqQPabumDk3F2xmmFghcCAwEAAaNCMEAw
DgYDVR0PAQH/BAQDAgEGMA8GA1UdEwEB/wQFMAMBAf8wHQYDVR0OBBYEFI/wS3+o
LkUkrk1Q+mOai97i3Ru8MA0GCSqGSIb3DQEBCwUAA4IBAQBLQNvAUKr+yAzv95ZU
RUm7lgAJQayzE4aGKAczymvmdLm6AC2upArT9fHxD4q/c2dKg8dEe3jgr25sbwMp
jjM5RcOO5LlXbKr8EpbsU8Yt5CRsuZRj+9xTaGdWPoO4zzUhw8lo/s7awlOqzJCK
6fBdRoyV3XpYKBovHd7NADdBj+1EbddTKJd+82cEHhXXipa0095MJ6RMG3NzdvQX
mcIfeg7jLQitChws/zyrVQ4PkX4268NXSb7hLi18YIvDQVETI53O9zJrlAGomecs
Mx86OyXShkDOOyyGeMlhLxS67ttVb9+E7gUJTb0o2HLO02JQZR7rkpeDMdmztcpH
WD9f
-----END CERTIFICATE-----`, au = {
  RedisCloudFixed: { ca: mr },
  RedisCloudFlexible: { ca: mr }
};
Nt.default = au;
(function(t) {
  Object.defineProperty(t, "__esModule", { value: !0 }), t.noop = t.defaults = t.Debug = t.getPackageMeta = t.zipMap = t.CONNECTION_CLOSED_ERROR_MSG = t.shuffle = t.sample = t.resolveTLSProfile = t.parseURL = t.optimizeErrorStack = t.toArg = t.convertMapToArray = t.convertObjectToArray = t.timeout = t.packObject = t.isInt = t.wrapMultiResult = t.convertBufferToString = void 0;
  const e = se, r = se, i = se, o = ce;
  Object.defineProperty(t, "defaults", { enumerable: !0, get: function() {
    return o.defaults;
  } }), Object.defineProperty(t, "noop", { enumerable: !0, get: function() {
    return o.noop;
  } });
  const f = le;
  t.Debug = f.default;
  const l = Nt;
  function a(d, m) {
    if (d instanceof Buffer)
      return d.toString(m);
    if (Array.isArray(d)) {
      const E = d.length, v = Array(E);
      for (let M = 0; M < E; ++M)
        v[M] = d[M] instanceof Buffer && m === "utf8" ? d[M].toString() : a(d[M], m);
      return v;
    }
    return d;
  }
  t.convertBufferToString = a;
  function u(d) {
    if (!d)
      return null;
    const m = [], E = d.length;
    for (let v = 0; v < E; ++v) {
      const M = d[v];
      M instanceof Error ? m.push([M]) : m.push([null, M]);
    }
    return m;
  }
  t.wrapMultiResult = u;
  function y(d) {
    const m = parseFloat(d);
    return !isNaN(d) && (m | 0) === m;
  }
  t.isInt = y;
  function g(d) {
    const m = {}, E = d.length;
    for (let v = 1; v < E; v += 2)
      m[d[v - 1]] = d[v];
    return m;
  }
  t.packObject = g;
  function k(d, m) {
    let E = null;
    const v = function() {
      E && (clearTimeout(E), E = null, d.apply(this, arguments));
    };
    return E = setTimeout(v, m, new Error("timeout")), v;
  }
  t.timeout = k;
  function w(d) {
    const m = [], E = Object.keys(d);
    for (let v = 0, M = E.length; v < M; v++)
      m.push(E[v], d[E[v]]);
    return m;
  }
  t.convertObjectToArray = w;
  function x(d) {
    const m = [];
    let E = 0;
    return d.forEach(function(v, M) {
      m[E] = M, m[E + 1] = v, E += 2;
    }), m;
  }
  t.convertMapToArray = x;
  function p(d) {
    return d === null || typeof d > "u" ? "" : String(d);
  }
  t.toArg = p;
  function R(d, m, E) {
    const v = m.split(`
`);
    let M = "", L;
    for (L = 1; L < v.length && v[L].indexOf(E) !== -1; ++L)
      ;
    for (let F = L; F < v.length; ++F)
      M += `
` + v[F];
    if (d.stack) {
      const F = d.stack.indexOf(`
`);
      d.stack = d.stack.slice(0, F) + M;
    }
    return d;
  }
  t.optimizeErrorStack = R;
  function _(d) {
    if (y(d))
      return { port: d };
    let m = (0, i.parse)(d, !0, !0);
    !m.slashes && d[0] !== "/" && (d = "//" + d, m = (0, i.parse)(d, !0, !0));
    const E = m.query || {}, v = {};
    if (m.auth) {
      const M = m.auth.indexOf(":");
      v.username = M === -1 ? m.auth : m.auth.slice(0, M), v.password = M === -1 ? "" : m.auth.slice(M + 1);
    }
    if (m.pathname && (m.protocol === "redis:" || m.protocol === "rediss:" ? m.pathname.length > 1 && (v.db = m.pathname.slice(1)) : v.path = m.pathname), m.host && (v.host = m.hostname), m.port && (v.port = m.port), typeof E.family == "string") {
      const M = Number.parseInt(E.family, 10);
      Number.isNaN(M) || (v.family = M);
    }
    return (0, o.defaults)(v, E), v;
  }
  t.parseURL = _;
  function A(d) {
    let m = d == null ? void 0 : d.tls;
    typeof m == "string" && (m = { profile: m });
    const E = l.default[m == null ? void 0 : m.profile];
    return E && (m = Object.assign({}, E, m), delete m.profile, d = Object.assign({}, d, { tls: m })), d;
  }
  t.resolveTLSProfile = A;
  function I(d, m = 0) {
    const E = d.length;
    return m >= E ? null : d[m + Math.floor(Math.random() * (E - m))];
  }
  t.sample = I;
  function S(d) {
    let m = d.length;
    for (; m > 0; ) {
      const E = Math.floor(Math.random() * m);
      m--, [d[m], d[E]] = [d[E], d[m]];
    }
    return d;
  }
  t.shuffle = S, t.CONNECTION_CLOSED_ERROR_MSG = "Connection is closed.";
  function T(d, m) {
    const E = /* @__PURE__ */ new Map();
    return d.forEach((v, M) => {
      E.set(v, m[M]);
    }), E;
  }
  t.zipMap = T;
  let O = null;
  async function N() {
    if (O)
      return O;
    try {
      const d = (0, r.resolve)(__dirname, "..", "..", "package.json"), m = await e.promises.readFile(d, "utf8");
      return O = {
        version: JSON.parse(m).version
      }, O;
    } catch {
      return O = {
        version: "error-fetching-version"
      }, O;
    }
  }
  t.getPackageMeta = N;
})(Z);
var xe = {};
Object.defineProperty(xe, "__esModule", { value: !0 });
xe.parseBlockOption = xe.parseSecondsArgument = void 0;
const Dt = (t) => {
  if (typeof t == "number")
    return t;
  if (Buffer.isBuffer(t))
    return Dt(t.toString());
  if (typeof t == "string") {
    const e = Number(t);
    return Number.isFinite(e) ? e : void 0;
  }
}, cu = (t) => {
  if (typeof t == "string")
    return t;
  if (Buffer.isBuffer(t))
    return t.toString();
}, uu = (t) => {
  const e = Dt(t);
  if (e !== void 0)
    return e <= 0 ? 0 : e * 1e3;
};
xe.parseSecondsArgument = uu;
const lu = (t) => {
  for (let e = 0; e < t.length; e++) {
    const r = cu(t[e]);
    if (r && r.toLowerCase() === "block") {
      const i = Dt(t[e + 1]);
      return i === void 0 ? void 0 : i <= 0 ? 0 : i;
    }
  }
  return null;
};
xe.parseBlockOption = lu;
Object.defineProperty(ue, "__esModule", { value: !0 });
const br = ve, fu = Ze, hu = fe, me = Z, dt = xe;
class $ {
  /**
   * Creates an instance of Command.
   * @param name Command name
   * @param args An array of command arguments
   * @param options
   * @param callback The callback that handles the response.
   * If omit, the response will be handled via Promise
   */
  constructor(e, r = [], i = {}, o) {
    if (this.name = e, this.inTransaction = !1, this.isResolved = !1, this.transformed = !1, this.replyEncoding = i.replyEncoding, this.errorStack = i.errorStack, this.args = r.flat(), this.callback = o, this.initPromise(), i.keyPrefix) {
      const f = i.keyPrefix instanceof Buffer;
      let l = f ? i.keyPrefix : null;
      this._iterateKeys((a) => a instanceof Buffer ? (l === null && (l = Buffer.from(i.keyPrefix)), Buffer.concat([l, a])) : f ? Buffer.concat([i.keyPrefix, Buffer.from(String(a))]) : i.keyPrefix + a);
    }
    i.readOnly && (this.isReadOnly = !0);
  }
  /**
   * Check whether the command has the flag
   */
  static checkFlag(e, r) {
    return r = r.toLowerCase(), !!this.getFlagMap()[e][r];
  }
  static setArgumentTransformer(e, r) {
    this._transformer.argument[e] = r;
  }
  static setReplyTransformer(e, r) {
    this._transformer.reply[e] = r;
  }
  static getFlagMap() {
    return this.flagMap || (this.flagMap = Object.keys($.FLAGS).reduce((e, r) => (e[r] = {}, $.FLAGS[r].forEach((i) => {
      e[r][i] = !0;
    }), e), {})), this.flagMap;
  }
  getSlot() {
    if (typeof this.slot > "u") {
      const e = this.getKeys()[0];
      this.slot = e == null ? null : fu(e);
    }
    return this.slot;
  }
  getKeys() {
    return this._iterateKeys();
  }
  /**
   * Convert command to writable buffer or string
   */
  toWritable(e) {
    let r;
    const i = "*" + (this.args.length + 1) + `\r
$` + Buffer.byteLength(this.name) + `\r
` + this.name + `\r
`;
    if (this.bufferMode) {
      const o = new du();
      o.push(i);
      for (let f = 0; f < this.args.length; ++f) {
        const l = this.args[f];
        l instanceof Buffer ? l.length === 0 ? o.push(`$0\r
\r
`) : (o.push("$" + l.length + `\r
`), o.push(l), o.push(`\r
`)) : o.push("$" + Buffer.byteLength(l) + `\r
` + l + `\r
`);
      }
      r = o.toBuffer();
    } else {
      r = i;
      for (let o = 0; o < this.args.length; ++o) {
        const f = this.args[o];
        r += "$" + Buffer.byteLength(f) + `\r
` + f + `\r
`;
      }
    }
    return r;
  }
  stringifyArguments() {
    for (let e = 0; e < this.args.length; ++e) {
      const r = this.args[e];
      typeof r == "string" || (r instanceof Buffer ? this.bufferMode = !0 : this.args[e] = (0, me.toArg)(r));
    }
  }
  /**
   * Convert buffer/buffer[] to string/string[],
   * and apply reply transformer.
   */
  transformReply(e) {
    this.replyEncoding && (e = (0, me.convertBufferToString)(e, this.replyEncoding));
    const r = $._transformer.reply[this.name];
    return r && (e = r(e)), e;
  }
  /**
   * Set the wait time before terminating the attempt to execute a command
   * and generating an error.
   */
  setTimeout(e) {
    this._commandTimeoutTimer || (this._commandTimeoutTimer = setTimeout(() => {
      this.isResolved || this.reject(new Error("Command timed out"));
    }, e));
  }
  /**
   * Set a timeout for blocking commands.
   * When the timeout expires, the command resolves with null (matching Redis behavior).
   * This handles the case of undetectable network failures (e.g., docker network disconnect)
   * where the TCP connection becomes a zombie and no close event fires.
   */
  setBlockingTimeout(e) {
    if (e <= 0)
      return;
    this._blockingTimeoutTimer && (clearTimeout(this._blockingTimeoutTimer), this._blockingTimeoutTimer = void 0);
    const r = Date.now();
    this._blockingDeadline === void 0 && (this._blockingDeadline = r + e);
    const i = this._blockingDeadline - r;
    if (i <= 0) {
      this.resolve(null);
      return;
    }
    this._blockingTimeoutTimer = setTimeout(() => {
      if (this.isResolved) {
        this._blockingTimeoutTimer = void 0;
        return;
      }
      this._blockingTimeoutTimer = void 0, this.resolve(null);
    }, i);
  }
  /**
   * Extract the blocking timeout from the command arguments.
   *
   * @returns The timeout in seconds, null for indefinite blocking (timeout of 0),
   *          or undefined if this is not a blocking command
   */
  extractBlockingTimeout() {
    const e = this.args;
    if (!e || e.length === 0)
      return;
    const r = this.name.toLowerCase();
    if ($.checkFlag("LAST_ARG_TIMEOUT_COMMANDS", r))
      return (0, dt.parseSecondsArgument)(e[e.length - 1]);
    if ($.checkFlag("FIRST_ARG_TIMEOUT_COMMANDS", r))
      return (0, dt.parseSecondsArgument)(e[0]);
    if ($.checkFlag("BLOCK_OPTION_COMMANDS", r))
      return (0, dt.parseBlockOption)(e);
  }
  /**
   * Clear the command and blocking timers
   */
  _clearTimers() {
    const e = this._commandTimeoutTimer;
    e && (clearTimeout(e), delete this._commandTimeoutTimer);
    const r = this._blockingTimeoutTimer;
    r && (clearTimeout(r), delete this._blockingTimeoutTimer);
  }
  initPromise() {
    const e = new Promise((r, i) => {
      if (!this.transformed) {
        this.transformed = !0;
        const o = $._transformer.argument[this.name];
        o && (this.args = o(this.args)), this.stringifyArguments();
      }
      this.resolve = this._convertValue(r), this.reject = (o) => {
        this._clearTimers(), this.errorStack ? i((0, me.optimizeErrorStack)(o, this.errorStack.stack, __dirname)) : i(o);
      };
    });
    this.promise = (0, hu.default)(e, this.callback);
  }
  /**
   * Iterate through the command arguments that are considered keys.
   */
  _iterateKeys(e = (r) => r) {
    if (typeof this.keys > "u" && (this.keys = [], (0, br.exists)(this.name, { caseInsensitive: !0 }))) {
      const r = (0, br.getKeyIndexes)(this.name, this.args, {
        nameCaseInsensitive: !0
      });
      for (const i of r)
        this.args[i] = e(this.args[i]), this.keys.push(this.args[i]);
    }
    return this.keys;
  }
  /**
   * Convert the value from buffer to the target encoding.
   */
  _convertValue(e) {
    return (r) => {
      try {
        this._clearTimers(), e(this.transformReply(r)), this.isResolved = !0;
      } catch (i) {
        this.reject(i);
      }
      return this.promise;
    };
  }
}
ue.default = $;
$.FLAGS = {
  VALID_IN_SUBSCRIBER_MODE: [
    "subscribe",
    "psubscribe",
    "unsubscribe",
    "punsubscribe",
    "ssubscribe",
    "sunsubscribe",
    "ping",
    "quit"
  ],
  VALID_IN_MONITOR_MODE: ["monitor", "auth"],
  ENTER_SUBSCRIBER_MODE: ["subscribe", "psubscribe", "ssubscribe"],
  EXIT_SUBSCRIBER_MODE: ["unsubscribe", "punsubscribe", "sunsubscribe"],
  WILL_DISCONNECT: ["quit"],
  HANDSHAKE_COMMANDS: ["auth", "select", "client", "readonly", "info"],
  IGNORE_RECONNECT_ON_ERROR: ["client"],
  BLOCKING_COMMANDS: [
    "blpop",
    "brpop",
    "brpoplpush",
    "blmove",
    "bzpopmin",
    "bzpopmax",
    "bzmpop",
    "blmpop",
    "xread",
    "xreadgroup"
  ],
  LAST_ARG_TIMEOUT_COMMANDS: [
    "blpop",
    "brpop",
    "brpoplpush",
    "blmove",
    "bzpopmin",
    "bzpopmax"
  ],
  FIRST_ARG_TIMEOUT_COMMANDS: ["bzmpop", "blmpop"],
  BLOCK_OPTION_COMMANDS: ["xread", "xreadgroup"]
};
$._transformer = {
  argument: {},
  reply: {}
};
const ts = function(t) {
  if (t.length === 1) {
    if (t[0] instanceof Map)
      return (0, me.convertMapToArray)(t[0]);
    if (typeof t[0] == "object" && t[0] !== null)
      return (0, me.convertObjectToArray)(t[0]);
  }
  return t;
}, rs = function(t) {
  if (t.length === 2) {
    if (t[1] instanceof Map)
      return [t[0]].concat((0, me.convertMapToArray)(t[1]));
    if (typeof t[1] == "object" && t[1] !== null)
      return [t[0]].concat((0, me.convertObjectToArray)(t[1]));
  }
  return t;
};
$.setArgumentTransformer("mset", ts);
$.setArgumentTransformer("msetnx", ts);
$.setArgumentTransformer("hset", rs);
$.setArgumentTransformer("hmset", rs);
$.setReplyTransformer("hgetall", function(t) {
  if (Array.isArray(t)) {
    const e = {};
    for (let r = 0; r < t.length; r += 2) {
      const i = t[r], o = t[r + 1];
      i in e ? Object.defineProperty(e, i, {
        value: o,
        configurable: !0,
        enumerable: !0,
        writable: !0
      }) : e[i] = o;
    }
    return e;
  }
  return t;
});
class du {
  constructor() {
    this.length = 0, this.items = [];
  }
  push(e) {
    this.length += Buffer.byteLength(e), this.items.push(e);
  }
  toBuffer() {
    const e = Buffer.allocUnsafe(this.length);
    let r = 0;
    for (const i of this.items) {
      const o = Buffer.byteLength(i);
      Buffer.isBuffer(i) ? i.copy(e, r) : e.write(i, r, o), r += o;
    }
    return e;
  }
}
var Lt = {};
Object.defineProperty(Lt, "__esModule", { value: !0 });
const pu = Ae;
class ss extends pu.RedisError {
  constructor(e, r) {
    super(e), this.lastNodeError = r, Error.captureStackTrace(this, this.constructor);
  }
  get name() {
    return this.constructor.name;
  }
}
Lt.default = ss;
ss.defaultMessage = "Failed to refresh slots cache.";
var Ie = {};
Object.defineProperty(Ie, "__esModule", { value: !0 });
const yu = se;
class gu extends yu.Readable {
  constructor(e) {
    super(e), this.opt = e, this._redisCursor = "0", this._redisDrained = !1;
  }
  _read() {
    if (this._redisDrained) {
      this.push(null);
      return;
    }
    const e = [this._redisCursor];
    this.opt.key && e.unshift(this.opt.key), this.opt.match && e.push("MATCH", this.opt.match), this.opt.type && e.push("TYPE", this.opt.type), this.opt.count && e.push("COUNT", String(this.opt.count)), this.opt.noValues && e.push("NOVALUES"), this.opt.redis[this.opt.command](e, (r, i) => {
      if (r) {
        this.emit("error", r);
        return;
      }
      this._redisCursor = i[0] instanceof Buffer ? i[0].toString() : i[0], this._redisCursor === "0" && (this._redisDrained = !0), this.push(i[1]);
    });
  }
  close() {
    this._redisDrained = !0;
  }
}
Ie.default = gu;
var Fe = {}, et = {}, Pe = {}, ns = {};
(function(t) {
  Object.defineProperty(t, "__esModule", { value: !0 }), t.executeWithAutoPipelining = t.getFirstValueInFlattenedArray = t.shouldUseAutoPipelining = t.notAllowedAutoPipelineCommands = t.kCallbacks = t.kExec = void 0;
  const e = ce, r = Ze, i = fe;
  t.kExec = Symbol("exec"), t.kCallbacks = Symbol("callbacks"), t.notAllowedAutoPipelineCommands = [
    "auth",
    "info",
    "script",
    "quit",
    "cluster",
    "pipeline",
    "multi",
    "subscribe",
    "psubscribe",
    "unsubscribe",
    "unpsubscribe",
    "select",
    "client"
  ];
  function o(u, y) {
    if (u._runningAutoPipelines.has(y) || !u._autoPipelines.has(y))
      return;
    u._runningAutoPipelines.add(y);
    const g = u._autoPipelines.get(y);
    u._autoPipelines.delete(y);
    const k = g[t.kCallbacks];
    g[t.kCallbacks] = null, g.exec(function(w, x) {
      if (u._runningAutoPipelines.delete(y), w)
        for (let p = 0; p < k.length; p++)
          process.nextTick(k[p], w);
      else
        for (let p = 0; p < k.length; p++)
          process.nextTick(k[p], ...x[p]);
      u._autoPipelines.has(y) && o(u, y);
    });
  }
  function f(u, y, g) {
    return y && u.options.enableAutoPipelining && !u.isPipeline && !t.notAllowedAutoPipelineCommands.includes(g) && !u.options.autoPipeliningIgnoredCommands.includes(g);
  }
  t.shouldUseAutoPipelining = f;
  function l(u) {
    for (let y = 0; y < u.length; y++) {
      const g = u[y];
      if (typeof g == "string")
        return g;
      if (Array.isArray(g) || (0, e.isArguments)(g)) {
        if (g.length === 0)
          continue;
        return g[0];
      }
      const k = [g].flat();
      if (k.length > 0)
        return k[0];
    }
  }
  t.getFirstValueInFlattenedArray = l;
  function a(u, y, g, k, w) {
    if (u.isCluster && !u.slots.length)
      return u.status === "wait" && u.connect().catch(e.noop), (0, i.default)(new Promise(function(A, I) {
        u.delayUntilReady((S) => {
          if (S) {
            I(S);
            return;
          }
          a(u, y, g, k, null).then(A, I);
        });
      }), w);
    const x = u.options.keyPrefix || "", p = u.isCluster ? u.slots[r(`${x}${l(k)}`)].join(",") : "main";
    if (!u._autoPipelines.has(p)) {
      const A = u.pipeline();
      A[t.kExec] = !1, A[t.kCallbacks] = [], u._autoPipelines.set(p, A);
    }
    const R = u._autoPipelines.get(p);
    R[t.kExec] || (R[t.kExec] = !0, setImmediate(o, u, p));
    const _ = new Promise(function(A, I) {
      R[t.kCallbacks].push(function(S, T) {
        if (S) {
          I(S);
          return;
        }
        A(T);
      }), y === "call" && k.unshift(g), R[y](...k);
    });
    return (0, i.default)(_, w);
  }
  t.executeWithAutoPipelining = a;
})(ns);
var Ut = {};
Object.defineProperty(Ut, "__esModule", { value: !0 });
const mu = He, bu = ue, Su = fe;
class ku {
  constructor(e, r = null, i = "", o = !1) {
    this.lua = e, this.numberOfKeys = r, this.keyPrefix = i, this.readOnly = o, this.sha = (0, mu.createHash)("sha1").update(e).digest("hex");
    const f = this.sha, l = /* @__PURE__ */ new WeakSet();
    this.Command = class extends bu.default {
      toWritable(u) {
        const y = this.reject;
        return this.reject = (g) => {
          g.message.indexOf("NOSCRIPT") !== -1 && l.delete(u), y.call(this, g);
        }, l.has(u) ? this.name === "eval" && (this.name = "evalsha", this.args[0] = f) : (l.add(u), this.name = "eval", this.args[0] = e), super.toWritable(u);
      }
    };
  }
  execute(e, r, i, o) {
    typeof this.numberOfKeys == "number" && r.unshift(this.numberOfKeys), this.keyPrefix && (i.keyPrefix = this.keyPrefix), this.readOnly && (i.readOnly = !0);
    const f = new this.Command("evalsha", [this.sha, ...r], i);
    return f.promise = f.promise.catch((l) => {
      if (l.message.indexOf("NOSCRIPT") === -1)
        throw l;
      const a = new this.Command("evalsha", [this.sha, ...r], i);
      return (e.isPipeline ? e.redis : e).sendCommand(a);
    }), (0, Su.default)(f.promise, o), e.sendCommand(f);
  }
}
Ut.default = ku;
Object.defineProperty(Pe, "__esModule", { value: !0 });
const wu = ve, We = ns, Eu = ue, Cu = Ut;
class be {
  constructor() {
    this.options = {}, this.scriptsSet = {}, this.addedBuiltinSet = /* @__PURE__ */ new Set();
  }
  /**
   * Return supported builtin commands
   */
  getBuiltinCommands() {
    return jt.slice(0);
  }
  /**
   * Create a builtin command
   */
  createBuiltinCommand(e) {
    return {
      string: de(null, e, "utf8"),
      buffer: de(null, e, null)
    };
  }
  /**
   * Create add builtin command
   */
  addBuiltinCommand(e) {
    this.addedBuiltinSet.add(e), this[e] = de(e, e, "utf8"), this[e + "Buffer"] = de(e + "Buffer", e, null);
  }
  /**
   * Define a custom command using lua script
   */
  defineCommand(e, r) {
    const i = new Cu.default(r.lua, r.numberOfKeys, this.options.keyPrefix, r.readOnly);
    this.scriptsSet[e] = i, this[e] = Sr(e, e, i, "utf8"), this[e + "Buffer"] = Sr(e + "Buffer", e, i, null);
  }
  /**
   * @ignore
   */
  sendCommand(e, r, i) {
    throw new Error('"sendCommand" is not implemented');
  }
}
const jt = wu.list.filter((t) => t !== "monitor");
jt.push("sentinel");
jt.forEach(function(t) {
  be.prototype[t] = de(t, t, "utf8"), be.prototype[t + "Buffer"] = de(t + "Buffer", t, null);
});
be.prototype.call = de("call", "utf8");
be.prototype.callBuffer = de("callBuffer", null);
be.prototype.send_command = be.prototype.call;
function de(t, e, r) {
  return typeof r > "u" && (r = e, e = null), function(...i) {
    const o = e || i.shift();
    let f = i[i.length - 1];
    typeof f == "function" ? i.pop() : f = void 0;
    const l = {
      errorStack: this.options.showFriendlyErrorStack ? new Error() : void 0,
      keyPrefix: this.options.keyPrefix,
      replyEncoding: r
    };
    return (0, We.shouldUseAutoPipelining)(this, t, o) ? (0, We.executeWithAutoPipelining)(
      this,
      t,
      o,
      // @ts-expect-error
      i,
      f
    ) : this.sendCommand(
      // @ts-expect-error
      new Eu.default(o, i, l, f)
    );
  };
}
function Sr(t, e, r, i) {
  return function(...o) {
    const f = typeof o[o.length - 1] == "function" ? o.pop() : void 0, l = {
      replyEncoding: i
    };
    return this.options.showFriendlyErrorStack && (l.errorStack = new Error()), (0, We.shouldUseAutoPipelining)(this, t, e) ? (0, We.executeWithAutoPipelining)(this, t, e, o, f) : r.execute(this, o, l, f);
  };
}
Pe.default = be;
Object.defineProperty(et, "__esModule", { value: !0 });
const xt = Ze, kr = ve, wr = fe, _u = se, xu = ue, vu = Z, Au = Pe;
function Bu(t, e) {
  const r = xt(e[0]), i = t._groupsBySlot[r];
  for (let o = 1; o < e.length; o++)
    if (t._groupsBySlot[xt(e[o])] !== i)
      return -1;
  return r;
}
class Be extends Au.default {
  constructor(e) {
    super(), this.redis = e, this.isPipeline = !0, this.replyPending = 0, this._queue = [], this._result = [], this._transactions = 0, this._shaToScript = {}, this.isCluster = this.redis.constructor.name === "Cluster" || this.redis.isCluster, this.options = e.options, Object.keys(e.scriptsSet).forEach((i) => {
      const o = e.scriptsSet[i];
      this._shaToScript[o.sha] = o, this[i] = e[i], this[i + "Buffer"] = e[i + "Buffer"];
    }), e.addedBuiltinSet.forEach((i) => {
      this[i] = e[i], this[i + "Buffer"] = e[i + "Buffer"];
    }), this.promise = new Promise((i, o) => {
      this.resolve = i, this.reject = o;
    });
    const r = this;
    Object.defineProperty(this, "length", {
      get: function() {
        return r._queue.length;
      }
    });
  }
  fillResult(e, r) {
    if (this._queue[r].name === "exec" && Array.isArray(e[1])) {
      const o = e[1].length;
      for (let f = 0; f < o; f++) {
        if (e[1][f] instanceof Error)
          continue;
        const l = this._queue[r - (o - f)];
        try {
          e[1][f] = l.transformReply(e[1][f]);
        } catch (a) {
          e[1][f] = a;
        }
      }
    }
    if (this._result[r] = e, --this.replyPending)
      return;
    if (this.isCluster) {
      let o = !0, f;
      for (let l = 0; l < this._result.length; ++l) {
        const a = this._result[l][0], u = this._queue[l];
        if (a) {
          if (u.name === "exec" && a.message === "EXECABORT Transaction discarded because of previous errors.")
            continue;
          if (!f)
            f = {
              name: a.name,
              message: a.message
            };
          else if (f.name !== a.name || f.message !== a.message) {
            o = !1;
            break;
          }
        } else if (!u.inTransaction && !((0, kr.exists)(u.name, { caseInsensitive: !0 }) && (0, kr.hasFlag)(u.name, "readonly", { nameCaseInsensitive: !0 }))) {
          o = !1;
          break;
        }
      }
      if (f && o) {
        const l = this, a = f.message.split(" "), u = this._queue;
        let y = !1;
        this._queue = [];
        for (let x = 0; x < u.length; ++x) {
          if (a[0] === "ASK" && !y && u[x].name !== "asking" && (!u[x - 1] || u[x - 1].name !== "asking")) {
            const p = new xu.default("asking");
            p.ignore = !0, this.sendCommand(p);
          }
          u[x].initPromise(), this.sendCommand(u[x]), y = u[x].inTransaction;
        }
        let g = !0;
        typeof this.leftRedirections > "u" && (this.leftRedirections = {});
        const k = function() {
          l.exec();
        }, w = this.redis;
        if (w.handleError(f, this.leftRedirections, {
          moved: function(x, p) {
            l.preferKey = p, w.slots[a[1]] = [p], w._groupsBySlot[a[1]] = w._groupsIds[w.slots[a[1]].join(";")], w.refreshSlotsCache(), l.exec();
          },
          ask: function(x, p) {
            l.preferKey = p, l.exec();
          },
          tryagain: k,
          clusterDown: k,
          connectionClosed: k,
          maxRedirections: () => {
            g = !1;
          },
          defaults: () => {
            g = !1;
          }
        }), g)
          return;
      }
    }
    let i = 0;
    for (let o = 0; o < this._queue.length - i; ++o)
      this._queue[o + i].ignore && (i += 1), this._result[o] = this._result[o + i];
    this.resolve(this._result.slice(0, this._result.length - i));
  }
  sendCommand(e) {
    this._transactions > 0 && (e.inTransaction = !0);
    const r = this._queue.length;
    return e.pipelineIndex = r, e.promise.then((i) => {
      this.fillResult([null, i], r);
    }).catch((i) => {
      this.fillResult([i], r);
    }), this._queue.push(e), this;
  }
  addBatch(e) {
    let r, i, o;
    for (let f = 0; f < e.length; ++f)
      r = e[f], i = r[0], o = r.slice(1), this[i].apply(this, o);
    return this;
  }
}
et.default = Be;
const Tu = Be.prototype.multi;
Be.prototype.multi = function() {
  return this._transactions += 1, Tu.apply(this, arguments);
};
const is = Be.prototype.execBuffer;
Be.prototype.execBuffer = (0, _u.deprecate)(function() {
  return this._transactions > 0 && (this._transactions -= 1), is.apply(this, arguments);
}, "Pipeline#execBuffer: Use Pipeline#exec instead");
Be.prototype.exec = function(t) {
  if (this.isCluster && !this.redis.slots.length)
    return this.redis.status === "wait" && this.redis.connect().catch(vu.noop), t && !this.nodeifiedPromise && (this.nodeifiedPromise = !0, (0, wr.default)(this.promise, t)), this.redis.delayUntilReady((o) => {
      if (o) {
        this.reject(o);
        return;
      }
      this.exec(t);
    }), this.promise;
  if (this._transactions > 0)
    return this._transactions -= 1, is.apply(this, arguments);
  this.nodeifiedPromise || (this.nodeifiedPromise = !0, (0, wr.default)(this.promise, t)), this._queue.length || this.resolve([]);
  let e;
  if (this.isCluster) {
    const o = [];
    for (let f = 0; f < this._queue.length; f++) {
      const l = this._queue[f].getKeys();
      if (l.length && o.push(l[0]), l.length && xt.generateMulti(l) < 0)
        return this.reject(new Error("All the keys in a pipeline command should belong to the same slot")), this.promise;
    }
    if (o.length) {
      if (e = Bu(this.redis, o), e < 0)
        return this.reject(new Error("All keys in the pipeline should belong to the same slots allocation group")), this.promise;
    } else
      e = Math.random() * 16384 | 0;
  }
  const r = this;
  return i(), this.promise;
  function i() {
    let o = r.replyPending = r._queue.length, f;
    r.isCluster && (f = {
      slot: e,
      redis: r.redis.connectionPool.nodes.all[r.preferKey]
    });
    let l = "", a;
    const u = {
      isPipeline: !0,
      destination: r.isCluster ? f : { redis: r.redis },
      write(y) {
        typeof y != "string" ? (a || (a = []), l && (a.push(Buffer.from(l, "utf8")), l = ""), a.push(y)) : l += y, --o || (a ? (l && a.push(Buffer.from(l, "utf8")), u.destination.redis.stream.write(Buffer.concat(a))) : u.destination.redis.stream.write(l), o = r._queue.length, l = "", a = void 0);
      }
    };
    for (let y = 0; y < r._queue.length; ++y)
      r.redis.sendCommand(r._queue[y], u, f);
    return r.promise;
  }
};
Object.defineProperty(Fe, "__esModule", { value: !0 });
Fe.addTransactionSupport = void 0;
const pt = Z, yt = fe, Er = et;
function Ru(t) {
  t.pipeline = function(i) {
    const o = new Er.default(this);
    return Array.isArray(i) && o.addBatch(i), o;
  };
  const { multi: e } = t;
  t.multi = function(i, o) {
    if (typeof o > "u" && !Array.isArray(i) && (o = i, i = null), o && o.pipeline === !1)
      return e.call(this);
    const f = new Er.default(this);
    f.multi(), Array.isArray(i) && f.addBatch(i);
    const l = f.exec;
    f.exec = function(u) {
      if (this.isCluster && !this.redis.slots.length)
        return this.redis.status === "wait" && this.redis.connect().catch(pt.noop), (0, yt.default)(new Promise((g, k) => {
          this.redis.delayUntilReady((w) => {
            if (w) {
              k(w);
              return;
            }
            this.exec(f).then(g, k);
          });
        }), u);
      if (this._transactions > 0 && l.call(f), this.nodeifiedPromise)
        return l.call(f);
      const y = l.call(f);
      return (0, yt.default)(y.then(function(g) {
        const k = g[g.length - 1];
        if (typeof k > "u")
          throw new Error("Pipeline cannot be used to send any commands when the `exec()` has been called on it.");
        if (k[0]) {
          k[0].previousErrors = [];
          for (let w = 0; w < g.length - 1; ++w)
            g[w][0] && k[0].previousErrors.push(g[w][0]);
          throw k[0];
        }
        return (0, pt.wrapMultiResult)(k[1]);
      }), u);
    };
    const { execBuffer: a } = f;
    return f.execBuffer = function(u) {
      return this._transactions > 0 && a.call(f), f.exec(u);
    }, f;
  };
  const { exec: r } = t;
  t.exec = function(i) {
    return (0, yt.default)(r.call(this).then(function(o) {
      return Array.isArray(o) && (o = (0, pt.wrapMultiResult)(o)), o;
    }), i);
  };
}
Fe.addTransactionSupport = Ru;
var tt = {};
Object.defineProperty(tt, "__esModule", { value: !0 });
function Mu(t, e) {
  Object.getOwnPropertyNames(e.prototype).forEach((r) => {
    Object.defineProperty(t.prototype, r, Object.getOwnPropertyDescriptor(e.prototype, r));
  });
}
tt.default = Mu;
var rt = {};
Object.defineProperty(rt, "__esModule", { value: !0 });
rt.DEFAULT_CLUSTER_OPTIONS = void 0;
const Cr = se;
rt.DEFAULT_CLUSTER_OPTIONS = {
  clusterRetryStrategy: (t) => Math.min(100 + t * 2, 2e3),
  enableOfflineQueue: !0,
  enableReadyCheck: !0,
  scaleReads: "master",
  maxRedirections: 16,
  retryDelayOnMoved: 0,
  retryDelayOnFailover: 100,
  retryDelayOnClusterDown: 100,
  retryDelayOnTryAgain: 100,
  slotsRefreshTimeout: 1e3,
  useSRVRecords: !1,
  resolveSrv: Cr.resolveSrv,
  dnsLookup: Cr.lookup,
  enableAutoPipelining: !1,
  autoPipeliningIgnoredCommands: [],
  shardedSubscribers: !1
};
var ze = {}, J = {};
Object.defineProperty(J, "__esModule", { value: !0 });
J.getConnectionName = J.weightSrvRecords = J.groupSrvRecords = J.getUniqueHostnamesFromOptions = J.normalizeNodeOptions = J.nodeKeyToRedisOptions = J.getNodeKey = void 0;
const _r = Z, Ou = se;
function Iu(t) {
  return t.port = t.port || 6379, t.host = t.host || "127.0.0.1", t.host + ":" + t.port;
}
J.getNodeKey = Iu;
function Fu(t) {
  const e = t.lastIndexOf(":");
  if (e === -1)
    throw new Error(`Invalid node key ${t}`);
  return {
    host: t.slice(0, e),
    port: Number(t.slice(e + 1))
  };
}
J.nodeKeyToRedisOptions = Fu;
function Pu(t) {
  return t.map((e) => {
    const r = {};
    if (typeof e == "object")
      Object.assign(r, e);
    else if (typeof e == "string")
      Object.assign(r, (0, _r.parseURL)(e));
    else if (typeof e == "number")
      r.port = e;
    else
      throw new Error("Invalid argument " + e);
    return typeof r.port == "string" && (r.port = parseInt(r.port, 10)), delete r.db, r.port || (r.port = 6379), r.host || (r.host = "127.0.0.1"), (0, _r.resolveTLSProfile)(r);
  });
}
J.normalizeNodeOptions = Pu;
function Nu(t) {
  const e = {};
  return t.forEach((r) => {
    e[r.host] = !0;
  }), Object.keys(e).filter((r) => !(0, Ou.isIP)(r));
}
J.getUniqueHostnamesFromOptions = Nu;
function Du(t) {
  const e = {};
  for (const r of t)
    e.hasOwnProperty(r.priority) ? (e[r.priority].totalWeight += r.weight, e[r.priority].records.push(r)) : e[r.priority] = {
      totalWeight: r.weight,
      records: [r]
    };
  return e;
}
J.groupSrvRecords = Du;
function Lu(t) {
  if (t.records.length === 1)
    return t.totalWeight = 0, t.records.shift();
  const e = Math.floor(Math.random() * (t.totalWeight + t.records.length));
  let r = 0;
  for (const [i, o] of t.records.entries())
    if (r += 1 + o.weight, r > e)
      return t.totalWeight -= o.weight, t.records.splice(i, 1), o;
}
J.weightSrvRecords = Lu;
function Uu(t, e) {
  const r = `ioredis-cluster(${t})`;
  return e ? `${r}:${e}` : r;
}
J.getConnectionName = Uu;
var xr;
function ju() {
  if (xr) return ze;
  xr = 1, Object.defineProperty(ze, "__esModule", { value: !0 });
  const t = J, e = Z, r = ye(), i = (0, e.Debug)("cluster:subscriber");
  let o = class {
    constructor(l, a, u = !1) {
      this.connectionPool = l, this.emitter = a, this.isSharded = u, this.started = !1, this.subscriber = null, this.slotRange = [], this.onSubscriberEnd = () => {
        if (!this.started) {
          i("subscriber has disconnected, but ClusterSubscriber is not started, so not reconnecting.");
          return;
        }
        i("subscriber has disconnected, selecting a new one..."), this.selectSubscriber();
      }, this.connectionPool.on("-node", (y, g) => {
        !this.started || !this.subscriber || (0, t.getNodeKey)(this.subscriber.options) === g && (i("subscriber has left, selecting a new one..."), this.selectSubscriber());
      }), this.connectionPool.on("+node", () => {
        !this.started || this.subscriber || (i("a new node is discovered and there is no subscriber, selecting a new one..."), this.selectSubscriber());
      });
    }
    getInstance() {
      return this.subscriber;
    }
    /**
     * Associate this subscriber to a specific slot range.
     *
     * Returns the range or an empty array if the slot range couldn't be associated.
     *
     * BTW: This is more for debugging and testing purposes.
     *
     * @param range
     */
    associateSlotRange(l) {
      return this.isSharded && (this.slotRange = l), this.slotRange;
    }
    start() {
      this.started = !0, this.selectSubscriber(), i("started");
    }
    stop() {
      this.started = !1, this.subscriber && (this.subscriber.disconnect(), this.subscriber = null);
    }
    isStarted() {
      return this.started;
    }
    selectSubscriber() {
      const l = this.lastActiveSubscriber;
      l && (l.off("end", this.onSubscriberEnd), l.disconnect()), this.subscriber && (this.subscriber.off("end", this.onSubscriberEnd), this.subscriber.disconnect());
      const a = (0, e.sample)(this.connectionPool.getNodes());
      if (!a) {
        i("selecting subscriber failed since there is no node discovered in the cluster yet"), this.subscriber = null;
        return;
      }
      const { options: u } = a;
      i("selected a subscriber %s:%s", u.host, u.port);
      let y = "subscriber";
      this.isSharded && (y = "ssubscriber"), this.subscriber = new r.default({
        port: u.port,
        host: u.host,
        username: u.username,
        password: u.password,
        enableReadyCheck: !0,
        connectionName: (0, t.getConnectionName)(y, u.connectionName),
        lazyConnect: !0,
        tls: u.tls,
        // Don't try to reconnect the subscriber connection. If the connection fails
        // we will get an end event (handled below), at which point we'll pick a new
        // node from the pool and try to connect to that as the subscriber connection.
        retryStrategy: null
      }), this.subscriber.on("error", e.noop), this.subscriber.on("moved", () => {
        this.emitter.emit("forceRefresh");
      }), this.subscriber.once("end", this.onSubscriberEnd);
      const g = { subscribe: [], psubscribe: [], ssubscribe: [] };
      if (l) {
        const k = l.condition || l.prevCondition;
        k && k.subscriber && (g.subscribe = k.subscriber.channels("subscribe"), g.psubscribe = k.subscriber.channels("psubscribe"), g.ssubscribe = k.subscriber.channels("ssubscribe"));
      }
      if (g.subscribe.length || g.psubscribe.length || g.ssubscribe.length) {
        let k = 0;
        for (const w of ["subscribe", "psubscribe", "ssubscribe"]) {
          const x = g[w];
          if (x.length != 0)
            if (i("%s %d channels", w, x.length), w === "ssubscribe")
              for (const p of x)
                k += 1, this.subscriber[w](p).then(() => {
                  --k || (this.lastActiveSubscriber = this.subscriber);
                }).catch(() => {
                  i("failed to ssubscribe to channel: %s", p);
                });
            else
              k += 1, this.subscriber[w](x).then(() => {
                --k || (this.lastActiveSubscriber = this.subscriber);
              }).catch(() => {
                i("failed to %s %d channels", w, x.length);
              });
        }
      } else
        this.lastActiveSubscriber = this.subscriber;
      for (const k of [
        "message",
        "messageBuffer"
      ])
        this.subscriber.on(k, (w, x) => {
          this.emitter.emit(k, w, x);
        });
      for (const k of ["pmessage", "pmessageBuffer"])
        this.subscriber.on(k, (w, x, p) => {
          this.emitter.emit(k, w, x, p);
        });
      if (this.isSharded == !0)
        for (const k of [
          "smessage",
          "smessageBuffer"
        ])
          this.subscriber.on(k, (w, x) => {
            this.emitter.emit(k, w, x);
          });
    }
  };
  return ze.default = o, ze;
}
var Ge = {}, vr;
function Qu() {
  if (vr) return Ge;
  vr = 1, Object.defineProperty(Ge, "__esModule", { value: !0 });
  const t = Rt, e = Z, r = J, i = ye(), o = (0, e.Debug)("cluster:connectionPool");
  let f = class extends t.EventEmitter {
    constructor(a) {
      super(), this.redisOptions = a, this.nodes = {
        all: {},
        master: {},
        slave: {}
      }, this.specifiedOptions = {};
    }
    getNodes(a = "all") {
      const u = this.nodes[a];
      return Object.keys(u).map((y) => u[y]);
    }
    getInstanceByKey(a) {
      return this.nodes.all[a];
    }
    getSampleInstance(a) {
      const u = Object.keys(this.nodes[a]), y = (0, e.sample)(u);
      return this.nodes[a][y];
    }
    /**
     * Add a master node to the pool
     * @param node
     */
    addMasterNode(a) {
      const u = (0, r.getNodeKey)(a.options), y = this.createRedisFromOptions(a, a.options.readOnly);
      return a.options.readOnly ? !1 : (this.nodes.all[u] = y, this.nodes.master[u] = y, !0);
    }
    /**
     * Creates a Redis connection instance from the node options
     * @param node
     * @param readOnly
     */
    createRedisFromOptions(a, u) {
      return new i.default((0, e.defaults)({
        // Never try to reconnect when a node is lose,
        // instead, waiting for a `MOVED` error and
        // fetch the slots again.
        retryStrategy: null,
        // Offline queue should be enabled so that
        // we don't need to wait for the `ready` event
        // before sending commands to the node.
        enableOfflineQueue: !0,
        readOnly: u
      }, a, this.redisOptions, { lazyConnect: !0 }));
    }
    /**
     * Find or create a connection to the node
     */
    findOrCreate(a, u = !1) {
      const y = (0, r.getNodeKey)(a);
      u = !!u, this.specifiedOptions[y] ? Object.assign(a, this.specifiedOptions[y]) : this.specifiedOptions[y] = a;
      let g;
      return this.nodes.all[y] ? (g = this.nodes.all[y], g.options.readOnly !== u && (g.options.readOnly = u, o("Change role of %s to %s", y, u ? "slave" : "master"), g[u ? "readonly" : "readwrite"]().catch(e.noop), u ? (delete this.nodes.master[y], this.nodes.slave[y] = g) : (delete this.nodes.slave[y], this.nodes.master[y] = g))) : (o("Connecting to %s as %s", y, u ? "slave" : "master"), g = this.createRedisFromOptions(a, u), this.nodes.all[y] = g, this.nodes[u ? "slave" : "master"][y] = g, g.once("end", () => {
        this.removeNode(y), this.emit("-node", g, y), Object.keys(this.nodes.all).length || this.emit("drain");
      }), this.emit("+node", g, y), g.on("error", function(k) {
        this.emit("nodeError", k, y);
      })), g;
    }
    /**
     * Reset the pool with a set of nodes.
     * The old node will be removed.
     */
    reset(a) {
      o("Reset with %O", a);
      const u = {};
      a.forEach((y) => {
        const g = (0, r.getNodeKey)(y);
        y.readOnly && u[g] || (u[g] = y);
      }), Object.keys(this.nodes.all).forEach((y) => {
        u[y] || (o("Disconnect %s because the node does not hold any slot", y), this.nodes.all[y].disconnect(), this.removeNode(y));
      }), Object.keys(u).forEach((y) => {
        const g = u[y];
        this.findOrCreate(g, g.readOnly);
      });
    }
    /**
     * Remove a node from the pool.
     */
    removeNode(a) {
      const { nodes: u } = this;
      u.all[a] && (o("Remove %s from the pool", a), delete u.all[a]), delete u.master[a], delete u.slave[a];
    }
  };
  return Ge.default = f, Ge;
}
var Qt = {};
function H(t, r) {
  var r = r || {};
  this._capacity = r.capacity, this._head = 0, this._tail = 0, Array.isArray(t) ? this._fromArray(t) : (this._capacityMask = 3, this._list = new Array(4));
}
H.prototype.peekAt = function(e) {
  var r = e;
  if (r === (r | 0)) {
    var i = this.size();
    if (!(r >= i || r < -i))
      return r < 0 && (r += i), r = this._head + r & this._capacityMask, this._list[r];
  }
};
H.prototype.get = function(e) {
  return this.peekAt(e);
};
H.prototype.peek = function() {
  if (this._head !== this._tail)
    return this._list[this._head];
};
H.prototype.peekFront = function() {
  return this.peek();
};
H.prototype.peekBack = function() {
  return this.peekAt(-1);
};
Object.defineProperty(H.prototype, "length", {
  get: function() {
    return this.size();
  }
});
H.prototype.size = function() {
  return this._head === this._tail ? 0 : this._head < this._tail ? this._tail - this._head : this._capacityMask + 1 - (this._head - this._tail);
};
H.prototype.unshift = function(e) {
  if (arguments.length === 0) return this.size();
  var r = this._list.length;
  return this._head = this._head - 1 + r & this._capacityMask, this._list[this._head] = e, this._tail === this._head && this._growArray(), this._capacity && this.size() > this._capacity && this.pop(), this._head < this._tail ? this._tail - this._head : this._capacityMask + 1 - (this._head - this._tail);
};
H.prototype.shift = function() {
  var e = this._head;
  if (e !== this._tail) {
    var r = this._list[e];
    return this._list[e] = void 0, this._head = e + 1 & this._capacityMask, e < 2 && this._tail > 1e4 && this._tail <= this._list.length >>> 2 && this._shrinkArray(), r;
  }
};
H.prototype.push = function(e) {
  if (arguments.length === 0) return this.size();
  var r = this._tail;
  return this._list[r] = e, this._tail = r + 1 & this._capacityMask, this._tail === this._head && this._growArray(), this._capacity && this.size() > this._capacity && this.shift(), this._head < this._tail ? this._tail - this._head : this._capacityMask + 1 - (this._head - this._tail);
};
H.prototype.pop = function() {
  var e = this._tail;
  if (e !== this._head) {
    var r = this._list.length;
    this._tail = e - 1 + r & this._capacityMask;
    var i = this._list[this._tail];
    return this._list[this._tail] = void 0, this._head < 2 && e > 1e4 && e <= r >>> 2 && this._shrinkArray(), i;
  }
};
H.prototype.removeOne = function(e) {
  var r = e;
  if (r === (r | 0) && this._head !== this._tail) {
    var i = this.size(), o = this._list.length;
    if (!(r >= i || r < -i)) {
      r < 0 && (r += i), r = this._head + r & this._capacityMask;
      var f = this._list[r], l;
      if (e < i / 2) {
        for (l = e; l > 0; l--)
          this._list[r] = this._list[r = r - 1 + o & this._capacityMask];
        this._list[r] = void 0, this._head = this._head + 1 + o & this._capacityMask;
      } else {
        for (l = i - 1 - e; l > 0; l--)
          this._list[r] = this._list[r = r + 1 + o & this._capacityMask];
        this._list[r] = void 0, this._tail = this._tail - 1 + o & this._capacityMask;
      }
      return f;
    }
  }
};
H.prototype.remove = function(e, r) {
  var i = e, o, f = r;
  if (i === (i | 0) && this._head !== this._tail) {
    var l = this.size(), a = this._list.length;
    if (!(i >= l || i < -l || r < 1)) {
      if (i < 0 && (i += l), r === 1 || !r)
        return o = new Array(1), o[0] = this.removeOne(i), o;
      if (i === 0 && i + r >= l)
        return o = this.toArray(), this.clear(), o;
      i + r > l && (r = l - i);
      var u;
      for (o = new Array(r), u = 0; u < r; u++)
        o[u] = this._list[this._head + i + u & this._capacityMask];
      if (i = this._head + i & this._capacityMask, e + r === l) {
        for (this._tail = this._tail - r + a & this._capacityMask, u = r; u > 0; u--)
          this._list[i = i + 1 + a & this._capacityMask] = void 0;
        return o;
      }
      if (e === 0) {
        for (this._head = this._head + r + a & this._capacityMask, u = r - 1; u > 0; u--)
          this._list[i = i + 1 + a & this._capacityMask] = void 0;
        return o;
      }
      if (i < l / 2) {
        for (this._head = this._head + e + r + a & this._capacityMask, u = e; u > 0; u--)
          this.unshift(this._list[i = i - 1 + a & this._capacityMask]);
        for (i = this._head - 1 + a & this._capacityMask; f > 0; )
          this._list[i = i - 1 + a & this._capacityMask] = void 0, f--;
        e < 0 && (this._tail = i);
      } else {
        for (this._tail = i, i = i + r + a & this._capacityMask, u = l - (r + e); u > 0; u--)
          this.push(this._list[i++]);
        for (i = this._tail; f > 0; )
          this._list[i = i + 1 + a & this._capacityMask] = void 0, f--;
      }
      return this._head < 2 && this._tail > 1e4 && this._tail <= a >>> 2 && this._shrinkArray(), o;
    }
  }
};
H.prototype.splice = function(e, r) {
  var i = e;
  if (i === (i | 0)) {
    var o = this.size();
    if (i < 0 && (i += o), !(i > o))
      if (arguments.length > 2) {
        var f, l, a, u = arguments.length, y = this._list.length, g = 2;
        if (!o || i < o / 2) {
          for (l = new Array(i), f = 0; f < i; f++)
            l[f] = this._list[this._head + f & this._capacityMask];
          for (r === 0 ? (a = [], i > 0 && (this._head = this._head + i + y & this._capacityMask)) : (a = this.remove(i, r), this._head = this._head + i + y & this._capacityMask); u > g; )
            this.unshift(arguments[--u]);
          for (f = i; f > 0; f--)
            this.unshift(l[f - 1]);
        } else {
          l = new Array(o - (i + r));
          var k = l.length;
          for (f = 0; f < k; f++)
            l[f] = this._list[this._head + i + r + f & this._capacityMask];
          for (r === 0 ? (a = [], i != o && (this._tail = this._head + i + y & this._capacityMask)) : (a = this.remove(i, r), this._tail = this._tail - k + y & this._capacityMask); g < u; )
            this.push(arguments[g++]);
          for (f = 0; f < k; f++)
            this.push(l[f]);
        }
        return a;
      } else
        return this.remove(i, r);
  }
};
H.prototype.clear = function() {
  this._list = new Array(this._list.length), this._head = 0, this._tail = 0;
};
H.prototype.isEmpty = function() {
  return this._head === this._tail;
};
H.prototype.toArray = function() {
  return this._copyArray(!1);
};
H.prototype._fromArray = function(e) {
  var r = e.length, i = this._nextPowerOf2(r);
  this._list = new Array(i), this._capacityMask = i - 1, this._tail = r;
  for (var o = 0; o < r; o++) this._list[o] = e[o];
};
H.prototype._copyArray = function(e, r) {
  var i = this._list, o = i.length, f = this.length;
  if (r = r | f, r == f && this._head < this._tail)
    return this._list.slice(this._head, this._tail);
  var l = new Array(r), a = 0, u;
  if (e || this._head > this._tail) {
    for (u = this._head; u < o; u++) l[a++] = i[u];
    for (u = 0; u < this._tail; u++) l[a++] = i[u];
  } else
    for (u = this._head; u < this._tail; u++) l[a++] = i[u];
  return l;
};
H.prototype._growArray = function() {
  if (this._head != 0) {
    var e = this._copyArray(!0, this._list.length << 1);
    this._tail = this._list.length, this._head = 0, this._list = e;
  } else
    this._tail = this._list.length, this._list.length <<= 1;
  this._capacityMask = this._capacityMask << 1 | 1;
};
H.prototype._shrinkArray = function() {
  this._list.length >>>= 1, this._capacityMask >>>= 1;
};
H.prototype._nextPowerOf2 = function(e) {
  var r = Math.log(e) / Math.log(2), i = 1 << r + 1;
  return Math.max(i, 4);
};
var zt = H;
Object.defineProperty(Qt, "__esModule", { value: !0 });
const zu = Z, Gu = zt, qu = (0, zu.Debug)("delayqueue");
class Ku {
  constructor() {
    this.queues = {}, this.timeouts = {};
  }
  /**
   * Add a new item to the queue
   *
   * @param bucket bucket name
   * @param item function that will run later
   * @param options
   */
  push(e, r, i) {
    const o = i.callback || process.nextTick;
    this.queues[e] || (this.queues[e] = new Gu()), this.queues[e].push(r), this.timeouts[e] || (this.timeouts[e] = setTimeout(() => {
      o(() => {
        this.timeouts[e] = null, this.execute(e);
      });
    }, i.timeout));
  }
  execute(e) {
    const r = this.queues[e];
    if (!r)
      return;
    const { length: i } = r;
    if (i)
      for (qu("send %d commands in %s queue", i, e), this.queues[e] = null; r.length > 0; )
        r.shift()();
  }
}
Qt.default = Ku;
var qe = {}, Ke = {}, Ar;
function Hu() {
  if (Ar) return Ke;
  Ar = 1, Object.defineProperty(Ke, "__esModule", { value: !0 });
  const t = J, e = Z, r = ye(), i = (0, e.Debug)("cluster:subscriberGroup:shardedSubscriber");
  let o = class {
    constructor(l, a) {
      this.emitter = l, this.started = !1, this.instance = null, this.messageListeners = /* @__PURE__ */ new Map(), this.onEnd = () => {
        this.started = !1, this.emitter.emit("-node", this.instance, this.nodeKey);
      }, this.onError = (u) => {
        this.emitter.emit("nodeError", u, this.nodeKey);
      }, this.onMoved = () => {
        this.emitter.emit("moved");
      }, this.instance = new r.default({
        port: a.port,
        host: a.host,
        username: a.username,
        password: a.password,
        enableReadyCheck: !1,
        offlineQueue: !0,
        connectionName: (0, t.getConnectionName)("ssubscriber", a.connectionName),
        lazyConnect: !0,
        tls: a.tls,
        /**
         * Disable auto reconnection for subscribers.
         * The ClusterSubscriberGroup will handle the reconnection.
         */
        retryStrategy: null
      }), this.nodeKey = (0, t.getNodeKey)(a), this.instance.once("end", this.onEnd), this.instance.on("error", this.onError), this.instance.on("moved", this.onMoved);
      for (const u of ["smessage", "smessageBuffer"]) {
        const y = (...g) => {
          this.emitter.emit(u, ...g);
        };
        this.messageListeners.set(u, y), this.instance.on(u, y);
      }
    }
    async start() {
      if (this.started) {
        i("already started %s", this.nodeKey);
        return;
      }
      try {
        await this.instance.connect(), i("started %s", this.nodeKey), this.started = !0;
      } catch (l) {
        throw i("failed to start %s: %s", this.nodeKey, l), this.started = !1, l;
      }
    }
    stop() {
      this.started = !1, this.instance && (this.instance.disconnect(), this.instance.removeAllListeners(), this.messageListeners.clear(), this.instance = null), i("stopped %s", this.nodeKey);
    }
    isStarted() {
      return this.started;
    }
    getInstance() {
      return this.instance;
    }
    getNodeKey() {
      return this.nodeKey;
    }
  };
  return Ke.default = o, Ke;
}
var Br;
function Yu() {
  if (Br) return qe;
  Br = 1, Object.defineProperty(qe, "__esModule", { value: !0 });
  const t = Z, e = J, r = Ze, i = Hu(), o = (0, t.Debug)("cluster:subscriberGroup");
  let f = class Ve {
    /**
     * Register callbacks
     *
     * @param cluster
     */
    constructor(a) {
      this.subscriberGroupEmitter = a, this.shardedSubscribers = /* @__PURE__ */ new Map(), this.clusterSlots = [], this.subscriberToSlotsIndex = /* @__PURE__ */ new Map(), this.channels = /* @__PURE__ */ new Map(), this.failedAttemptsByNode = /* @__PURE__ */ new Map(), this.isResetting = !1, this.pendingReset = null, this.handleSubscriberConnectFailed = (u, y) => {
        const k = (this.failedAttemptsByNode.get(y) || 0) + 1;
        this.failedAttemptsByNode.set(y, k);
        const w = Math.min(k, Ve.MAX_RETRY_ATTEMPTS), x = Math.min(Ve.BASE_BACKOFF_MS * 2 ** w, Ve.MAX_BACKOFF_MS), p = Math.floor((Math.random() - 0.5) * (x * 0.5)), R = Math.max(0, x + p);
        o("Failed to connect subscriber for %s. Refreshing slots in %dms", y, R), this.subscriberGroupEmitter.emit("subscriberConnectFailed", {
          delay: R,
          error: u
        });
      }, this.handleSubscriberConnectSucceeded = (u) => {
        this.failedAttemptsByNode.delete(u);
      };
    }
    /**
     * Get the responsible subscriber.
     *
     * @param slot
     */
    getResponsibleSubscriber(a) {
      const u = this.clusterSlots[a][0];
      return this.shardedSubscribers.get(u);
    }
    /**
     * Adds a channel for which this subscriber group is responsible
     *
     * @param channels
     */
    addChannels(a) {
      const u = r(a[0]);
      for (const g of a)
        if (r(g) !== u)
          return -1;
      const y = this.channels.get(u);
      return y ? this.channels.set(u, y.concat(a)) : this.channels.set(u, a), Array.from(this.channels.values()).reduce((g, k) => g + k.length, 0);
    }
    /**
     * Removes channels for which the subscriber group is responsible by optionally unsubscribing
     * @param channels
     */
    removeChannels(a) {
      const u = r(a[0]);
      for (const g of a)
        if (r(g) !== u)
          return -1;
      const y = this.channels.get(u);
      if (y) {
        const g = y.filter((k) => !a.includes(k));
        this.channels.set(u, g);
      }
      return Array.from(this.channels.values()).reduce((g, k) => g + k.length, 0);
    }
    /**
     * Disconnect all subscribers and clear some of the internal state.
     */
    stop() {
      for (const a of this.shardedSubscribers.values())
        a.stop();
      this.pendingReset = null, this.shardedSubscribers.clear(), this.subscriberToSlotsIndex.clear();
    }
    /**
     * Start all not yet started subscribers
     */
    start() {
      const a = [];
      for (const u of this.shardedSubscribers.values())
        u.isStarted() || a.push(u.start().then(() => {
          this.handleSubscriberConnectSucceeded(u.getNodeKey());
        }).catch((y) => {
          this.handleSubscriberConnectFailed(y, u.getNodeKey());
        }));
      return Promise.all(a);
    }
    /**
     * Resets the subscriber group by disconnecting all subscribers that are no longer needed and connecting new ones.
     */
    async reset(a, u) {
      if (this.isResetting) {
        this.pendingReset = { slots: a, nodes: u };
        return;
      }
      this.isResetting = !0;
      try {
        const y = this._refreshSlots(a), g = this.hasUnhealthySubscribers();
        if (!y && !g) {
          o("No topology change detected or failed subscribers. Skipping reset.");
          return;
        }
        for (const [w, x] of this.shardedSubscribers) {
          if (
            // If the subscriber is still responsible for a slot range and is running then keep it
            this.subscriberToSlotsIndex.has(w) && x.isStarted()
          ) {
            o("Skipping deleting subscriber for %s", w);
            continue;
          }
          o("Removing subscriber for %s", w), x.stop(), this.shardedSubscribers.delete(w), this.subscriberGroupEmitter.emit("-subscriber");
        }
        const k = [];
        for (const [w, x] of this.subscriberToSlotsIndex) {
          if (this.shardedSubscribers.has(w)) {
            o("Skipping creating new subscriber for %s", w);
            continue;
          }
          o("Creating new subscriber for %s", w);
          const p = u.find((_) => (0, e.getNodeKey)(_.options) === w);
          if (!p) {
            o("Failed to find node for key %s", w);
            continue;
          }
          const R = new i.default(this.subscriberGroupEmitter, p.options);
          this.shardedSubscribers.set(w, R), k.push(R.start().then(() => {
            this.handleSubscriberConnectSucceeded(w);
          }).catch((_) => {
            this.handleSubscriberConnectFailed(_, w);
          })), this.subscriberGroupEmitter.emit("+subscriber");
        }
        await Promise.all(k), this._resubscribe(), this.subscriberGroupEmitter.emit("subscribersReady");
      } finally {
        if (this.isResetting = !1, this.pendingReset) {
          const { slots: y, nodes: g } = this.pendingReset;
          this.pendingReset = null, await this.reset(y, g);
        }
      }
    }
    /**
     * Refreshes the subscriber-related slot ranges
     *
     * Returns false if no refresh was needed
     *
     * @param targetSlots
     */
    _refreshSlots(a) {
      if (this._slotsAreEqual(a))
        return o("Nothing to refresh because the new cluster map is equal to the previous one."), !1;
      o("Refreshing the slots of the subscriber group."), this.subscriberToSlotsIndex = /* @__PURE__ */ new Map();
      for (let u = 0; u < a.length; u++) {
        const y = a[u][0];
        this.subscriberToSlotsIndex.has(y) || this.subscriberToSlotsIndex.set(y, []), this.subscriberToSlotsIndex.get(y).push(Number(u));
      }
      return this.clusterSlots = JSON.parse(JSON.stringify(a)), !0;
    }
    /**
     * Resubscribes to the previous channels
     *
     * @private
     */
    _resubscribe() {
      this.shardedSubscribers && this.shardedSubscribers.forEach((a, u) => {
        const y = this.subscriberToSlotsIndex.get(u);
        y && y.forEach((g) => {
          const k = a.getInstance(), w = this.channels.get(g);
          if (w && w.length > 0) {
            if (k.status === "end")
              return;
            k.status === "ready" ? k.ssubscribe(...w).catch((x) => {
              o("Failed to ssubscribe on node %s: %s", u, x);
            }) : k.once("ready", () => {
              k.ssubscribe(...w).catch((x) => {
                o("Failed to ssubscribe on node %s: %s", u, x);
              });
            });
          }
        });
      });
    }
    /**
     * Deep equality of the cluster slots objects
     *
     * @param other
     * @private
     */
    _slotsAreEqual(a) {
      return this.clusterSlots === void 0 ? !1 : JSON.stringify(this.clusterSlots) === JSON.stringify(a);
    }
    /**
     * Checks if any subscribers are in an unhealthy state.
     *
     * A subscriber is considered unhealthy if:
     * - It exists but is not started (failed/disconnected)
     * - It's missing entirely for a node that should have one
     *
     * @returns true if any subscribers need to be recreated
     */
    hasUnhealthySubscribers() {
      const a = Array.from(this.shardedSubscribers.values()).some((y) => !y.isStarted()), u = Array.from(this.subscriberToSlotsIndex.keys()).some((y) => !this.shardedSubscribers.has(y));
      return a || u;
    }
  };
  return qe.default = f, f.MAX_RETRY_ATTEMPTS = 10, f.MAX_BACKOFF_MS = 2e3, f.BASE_BACKOFF_MS = 100, qe;
}
var Tr;
function os() {
  if (Tr) return Qe;
  Tr = 1, Object.defineProperty(Qe, "__esModule", { value: !0 });
  const t = ve, e = Rt, r = Ae, i = fe, o = ue, f = Lt, l = ye(), a = Ie, u = Fe, y = Z, g = tt, k = Pe, w = rt, x = ju(), p = Qu(), R = Qt, _ = J, A = zt, I = Yu(), S = (0, y.Debug)("cluster"), T = /* @__PURE__ */ new WeakSet();
  class O extends k.default {
    /**
     * Creates an instance of Cluster.
     */
    //TODO: Add an option that enables or disables sharded PubSub
    constructor(d, m = {}) {
      if (super(), this.slots = [], this._groupsIds = {}, this._groupsBySlot = Array(16384), this.isCluster = !0, this.retryAttempts = 0, this.delayQueue = new R.default(), this.offlineQueue = new A(), this.isRefreshing = !1, this._refreshSlotsCacheCallbacks = [], this._autoPipelines = /* @__PURE__ */ new Map(), this._runningAutoPipelines = /* @__PURE__ */ new Set(), this._readyDelayedCallbacks = [], this.connectionEpoch = 0, e.EventEmitter.call(this), this.startupNodes = d, this.options = (0, y.defaults)({}, m, w.DEFAULT_CLUSTER_OPTIONS, this.options), this.options.shardedSubscribers && this.createShardedSubscriberGroup(), this.options.redisOptions && this.options.redisOptions.keyPrefix && !this.options.keyPrefix && (this.options.keyPrefix = this.options.redisOptions.keyPrefix), typeof this.options.scaleReads != "function" && ["all", "master", "slave"].indexOf(this.options.scaleReads) === -1)
        throw new Error('Invalid option scaleReads "' + this.options.scaleReads + '". Expected "all", "master", "slave" or a custom function');
      this.connectionPool = new p.default(this.options.redisOptions), this.connectionPool.on("-node", (E, v) => {
        this.emit("-node", E);
      }), this.connectionPool.on("+node", (E) => {
        this.emit("+node", E);
      }), this.connectionPool.on("drain", () => {
        this.setStatus("close");
      }), this.connectionPool.on("nodeError", (E, v) => {
        this.emit("node error", E, v);
      }), this.subscriber = new x.default(this.connectionPool, this), this.options.scripts && Object.entries(this.options.scripts).forEach(([E, v]) => {
        this.defineCommand(E, v);
      }), this.options.lazyConnect ? this.setStatus("wait") : this.connect().catch((E) => {
        S("connecting failed: %s", E);
      });
    }
    /**
     * Connect to a cluster
     */
    connect() {
      return new Promise((d, m) => {
        if (this.status === "connecting" || this.status === "connect" || this.status === "ready") {
          m(new Error("Redis is already connecting/connected"));
          return;
        }
        const E = ++this.connectionEpoch;
        this.setStatus("connecting"), this.resolveStartupNodeHostnames().then((v) => {
          if (this.connectionEpoch !== E) {
            S("discard connecting after resolving startup nodes because epoch not match: %d != %d", E, this.connectionEpoch), m(new r.RedisError("Connection is discarded because a new connection is made"));
            return;
          }
          if (this.status !== "connecting") {
            S("discard connecting after resolving startup nodes because the status changed to %s", this.status), m(new r.RedisError("Connection is aborted"));
            return;
          }
          this.connectionPool.reset(v), this.options.shardedSubscribers && this.shardedSubscribers.reset(this.slots, this.connectionPool.getNodes("all")).catch((P) => {
            S("Error while starting subscribers: %s", P);
          });
          const M = () => {
            this.setStatus("ready"), this.retryAttempts = 0, this.executeOfflineCommands(), this.resetNodesRefreshInterval(), d();
          };
          let L;
          const F = () => {
            this.invokeReadyDelayedCallbacks(void 0), this.removeListener("close", L), this.manuallyClosing = !1, this.setStatus("connect"), this.options.enableReadyCheck ? this.readyCheck((P, j) => {
              P || j ? (S("Ready check failed (%s). Reconnecting...", P || j), this.status === "connect" && this.disconnect(!0)) : M();
            }) : M();
          };
          L = () => {
            const P = new Error("None of startup nodes is available");
            this.removeListener("refresh", F), this.invokeReadyDelayedCallbacks(P), m(P);
          }, this.once("refresh", F), this.once("close", L), this.once("close", this.handleCloseEvent.bind(this)), this.refreshSlotsCache((P) => {
            P && P.message === f.default.defaultMessage && (l.default.prototype.silentEmit.call(this, "error", P), this.connectionPool.reset([]));
          }), this.subscriber.start(), this.options.shardedSubscribers && this.shardedSubscribers.start().catch((P) => {
            S("Error while starting subscribers: %s", P);
          });
        }).catch((v) => {
          this.setStatus("close"), this.handleCloseEvent(v), this.invokeReadyDelayedCallbacks(v), m(v);
        });
      });
    }
    /**
     * Disconnect from every node in the cluster.
     */
    disconnect(d = !1) {
      const m = this.status;
      this.setStatus("disconnecting"), d || (this.manuallyClosing = !0), this.reconnectTimeout && !d && (clearTimeout(this.reconnectTimeout), this.reconnectTimeout = null, S("Canceled reconnecting attempts")), this.clearNodesRefreshInterval(), this.subscriber.stop(), this.options.shardedSubscribers && this.shardedSubscribers.stop(), m === "wait" ? (this.setStatus("close"), this.handleCloseEvent()) : this.connectionPool.reset([]);
    }
    /**
     * Quit the cluster gracefully.
     */
    quit(d) {
      const m = this.status;
      if (this.setStatus("disconnecting"), this.manuallyClosing = !0, this.reconnectTimeout && (clearTimeout(this.reconnectTimeout), this.reconnectTimeout = null), this.clearNodesRefreshInterval(), this.subscriber.stop(), this.options.shardedSubscribers && this.shardedSubscribers.stop(), m === "wait") {
        const E = (0, i.default)(Promise.resolve("OK"), d);
        return setImmediate((function() {
          this.setStatus("close"), this.handleCloseEvent();
        }).bind(this)), E;
      }
      return (0, i.default)(Promise.all(this.nodes().map((E) => E.quit().catch((v) => {
        if (v.message === y.CONNECTION_CLOSED_ERROR_MSG)
          return "OK";
        throw v;
      }))).then(() => "OK"), d);
    }
    /**
     * Create a new instance with the same startup nodes and options as the current one.
     *
     * @example
     * ```js
     * var cluster = new Redis.Cluster([{ host: "127.0.0.1", port: "30001" }]);
     * var anotherCluster = cluster.duplicate();
     * ```
     */
    duplicate(d = [], m = {}) {
      const E = d.length > 0 ? d : this.startupNodes.slice(0), v = Object.assign({}, this.options, m);
      return new O(E, v);
    }
    /**
     * Get nodes with the specified role
     */
    nodes(d = "all") {
      if (d !== "all" && d !== "master" && d !== "slave")
        throw new Error('Invalid role "' + d + '". Expected "all", "master" or "slave"');
      return this.connectionPool.getNodes(d);
    }
    /**
     * This is needed in order not to install a listener for each auto pipeline
     *
     * @ignore
     */
    delayUntilReady(d) {
      this._readyDelayedCallbacks.push(d);
    }
    /**
     * Get the number of commands queued in automatic pipelines.
     *
     * This is not available (and returns 0) until the cluster is connected and slots information have been received.
     */
    get autoPipelineQueueSize() {
      let d = 0;
      for (const m of this._autoPipelines.values())
        d += m.length;
      return d;
    }
    /**
     * Refresh the slot cache
     *
     * @ignore
     */
    refreshSlotsCache(d) {
      if (d && this._refreshSlotsCacheCallbacks.push(d), this.isRefreshing)
        return;
      this.isRefreshing = !0;
      const m = this, E = (F) => {
        this.isRefreshing = !1;
        for (const P of this._refreshSlotsCacheCallbacks)
          P(F);
        this._refreshSlotsCacheCallbacks = [];
      }, v = (0, y.shuffle)(this.connectionPool.getNodes());
      let M = null;
      function L(F) {
        if (F === v.length) {
          const W = new f.default(f.default.defaultMessage, M);
          return E(W);
        }
        const P = v[F], j = `${P.options.host}:${P.options.port}`;
        S("getting slot cache from %s", j), m.getInfoFromNode(P, function(W) {
          switch (m.status) {
            case "close":
            case "end":
              return E(new Error("Cluster is disconnected."));
            case "disconnecting":
              return E(new Error("Cluster is disconnecting."));
          }
          W ? (m.emit("node error", W, j), M = W, L(F + 1)) : (m.emit("refresh"), E());
        });
      }
      L(0);
    }
    /**
     * @ignore
     */
    sendCommand(d, m, E) {
      if (this.status === "wait" && this.connect().catch(y.noop), this.status === "end")
        return d.reject(new Error(y.CONNECTION_CLOSED_ERROR_MSG)), d.promise;
      let v = this.options.scaleReads;
      v !== "master" && (d.isReadOnly || (0, t.exists)(d.name) && (0, t.hasFlag)(d.name, "readonly") || (v = "master"));
      let M = E ? E.slot : d.getSlot();
      const L = {}, F = this;
      if (!E && !T.has(d)) {
        T.add(d);
        const j = d.reject;
        d.reject = function(W) {
          const Q = P.bind(null, !0);
          F.handleError(W, L, {
            moved: function(G, U) {
              S("command %s is moved to %s", d.name, U), M = Number(G), F.slots[G] ? F.slots[G][0] = U : F.slots[G] = [U], F._groupsBySlot[G] = F._groupsIds[F.slots[G].join(";")], F.connectionPool.findOrCreate(F.natMapper(U)), P(), S("refreshing slot caches... (triggered by MOVED error)"), F.refreshSlotsCache();
            },
            ask: function(G, U) {
              S("command %s is required to ask %s:%s", d.name, U);
              const te = F.natMapper(U);
              F.connectionPool.findOrCreate(te), P(!1, `${te.host}:${te.port}`);
            },
            tryagain: Q,
            clusterDown: Q,
            connectionClosed: Q,
            maxRedirections: function(G) {
              j.call(d, G);
            },
            defaults: function() {
              j.call(d, W);
            }
          });
        };
      }
      P();
      function P(j, W) {
        if (F.status === "end") {
          d.reject(new r.AbortError("Cluster is ended."));
          return;
        }
        let Q;
        if (F.status === "ready" || d.name === "cluster") {
          if (E && E.redis)
            Q = E.redis;
          else if (o.default.checkFlag("ENTER_SUBSCRIBER_MODE", d.name) || o.default.checkFlag("EXIT_SUBSCRIBER_MODE", d.name)) {
            if (F.options.shardedSubscribers && (d.name == "ssubscribe" || d.name == "sunsubscribe")) {
              const G = F.shardedSubscribers.getResponsibleSubscriber(M);
              if (!G) {
                d.reject(new r.AbortError(`No sharded subscriber for slot: ${M}`));
                return;
              }
              let U = -1;
              d.name == "ssubscribe" && (U = F.shardedSubscribers.addChannels(d.getKeys())), d.name == "sunsubscribe" && (U = F.shardedSubscribers.removeChannels(d.getKeys())), U !== -1 ? Q = G.getInstance() : d.reject(new r.AbortError("Possible CROSSSLOT error: All channels must hash to the same slot"));
            } else
              Q = F.subscriber.getInstance();
            if (!Q) {
              d.reject(new r.AbortError("No subscriber for the cluster"));
              return;
            }
          } else {
            if (!j) {
              if (typeof M == "number" && F.slots[M]) {
                const G = F.slots[M];
                if (typeof v == "function") {
                  const U = G.map(function(te) {
                    return F.connectionPool.getInstanceByKey(te);
                  });
                  Q = v(U, d), Array.isArray(Q) && (Q = (0, y.sample)(Q)), Q || (Q = U[0]);
                } else {
                  let U;
                  v === "all" ? U = (0, y.sample)(G) : v === "slave" && G.length > 1 ? U = (0, y.sample)(G, 1) : U = G[0], Q = F.connectionPool.getInstanceByKey(U);
                }
              }
              W && (Q = F.connectionPool.getInstanceByKey(W), Q.asking());
            }
            Q || (Q = (typeof v == "function" ? null : F.connectionPool.getSampleInstance(v)) || F.connectionPool.getSampleInstance("all"));
          }
          E && !E.redis && (E.redis = Q);
        }
        Q ? Q.sendCommand(d, m) : F.options.enableOfflineQueue ? F.offlineQueue.push({
          command: d,
          stream: m,
          node: E
        }) : d.reject(new Error("Cluster isn't ready and enableOfflineQueue options is false"));
      }
      return d.promise;
    }
    sscanStream(d, m) {
      return this.createScanStream("sscan", { key: d, options: m });
    }
    sscanBufferStream(d, m) {
      return this.createScanStream("sscanBuffer", { key: d, options: m });
    }
    hscanStream(d, m) {
      return this.createScanStream("hscan", { key: d, options: m });
    }
    hscanBufferStream(d, m) {
      return this.createScanStream("hscanBuffer", { key: d, options: m });
    }
    zscanStream(d, m) {
      return this.createScanStream("zscan", { key: d, options: m });
    }
    zscanBufferStream(d, m) {
      return this.createScanStream("zscanBuffer", { key: d, options: m });
    }
    /**
     * @ignore
     */
    handleError(d, m, E) {
      if (typeof m.value > "u" ? m.value = this.options.maxRedirections : m.value -= 1, m.value <= 0) {
        E.maxRedirections(new Error("Too many Cluster redirections. Last error: " + d));
        return;
      }
      const v = d.message.split(" ");
      if (v[0] === "MOVED") {
        const M = this.options.retryDelayOnMoved;
        M && typeof M == "number" ? this.delayQueue.push("moved", E.moved.bind(null, v[1], v[2]), { timeout: M }) : E.moved(v[1], v[2]);
      } else v[0] === "ASK" ? E.ask(v[1], v[2]) : v[0] === "TRYAGAIN" ? this.delayQueue.push("tryagain", E.tryagain, {
        timeout: this.options.retryDelayOnTryAgain
      }) : v[0] === "CLUSTERDOWN" && this.options.retryDelayOnClusterDown > 0 ? this.delayQueue.push("clusterdown", E.connectionClosed, {
        timeout: this.options.retryDelayOnClusterDown,
        callback: this.refreshSlotsCache.bind(this)
      }) : d.message === y.CONNECTION_CLOSED_ERROR_MSG && this.options.retryDelayOnFailover > 0 && this.status === "ready" ? this.delayQueue.push("failover", E.connectionClosed, {
        timeout: this.options.retryDelayOnFailover,
        callback: this.refreshSlotsCache.bind(this)
      }) : E.defaults();
    }
    resetOfflineQueue() {
      this.offlineQueue = new A();
    }
    clearNodesRefreshInterval() {
      this.slotsTimer && (clearTimeout(this.slotsTimer), this.slotsTimer = null);
    }
    resetNodesRefreshInterval() {
      if (this.slotsTimer || !this.options.slotsRefreshInterval)
        return;
      const d = () => {
        this.slotsTimer = setTimeout(() => {
          S('refreshing slot caches... (triggered by "slotsRefreshInterval" option)'), this.refreshSlotsCache(() => {
            d();
          });
        }, this.options.slotsRefreshInterval);
      };
      d();
    }
    /**
     * Change cluster instance's status
     */
    setStatus(d) {
      S("status: %s -> %s", this.status || "[empty]", d), this.status = d, process.nextTick(() => {
        this.emit(d);
      });
    }
    /**
     * Called when closed to check whether a reconnection should be made
     */
    handleCloseEvent(d) {
      var m;
      d && S("closed because %s", d);
      let E;
      !this.manuallyClosing && typeof this.options.clusterRetryStrategy == "function" && (E = this.options.clusterRetryStrategy.call(this, ++this.retryAttempts, d)), typeof E == "number" ? (this.setStatus("reconnecting"), this.reconnectTimeout = setTimeout(() => {
        this.reconnectTimeout = null, S("Cluster is disconnected. Retrying after %dms", E), this.connect().catch(function(v) {
          S("Got error %s when reconnecting. Ignoring...", v);
        });
      }, E)) : (this.options.shardedSubscribers && ((m = this.subscriberGroupEmitter) === null || m === void 0 || m.removeAllListeners()), this.setStatus("end"), this.flushQueue(new Error("None of startup nodes is available")));
    }
    /**
     * Flush offline queue with error.
     */
    flushQueue(d) {
      let m;
      for (; m = this.offlineQueue.shift(); )
        m.command.reject(d);
    }
    executeOfflineCommands() {
      if (this.offlineQueue.length) {
        S("send %d commands in offline queue", this.offlineQueue.length);
        const d = this.offlineQueue;
        this.resetOfflineQueue();
        let m;
        for (; m = d.shift(); )
          this.sendCommand(m.command, m.stream, m.node);
      }
    }
    natMapper(d) {
      const m = typeof d == "string" ? d : `${d.host}:${d.port}`;
      let E = null;
      return this.options.natMap && typeof this.options.natMap == "function" ? E = this.options.natMap(m) : this.options.natMap && typeof this.options.natMap == "object" && (E = this.options.natMap[m]), E ? (S("NAT mapping %s -> %O", m, E), Object.assign({}, E)) : typeof d == "string" ? (0, _.nodeKeyToRedisOptions)(d) : d;
    }
    getInfoFromNode(d, m) {
      if (!d)
        return m(new Error("Node is disconnected"));
      const E = d.duplicate({
        enableOfflineQueue: !0,
        enableReadyCheck: !1,
        retryStrategy: null,
        connectionName: (0, _.getConnectionName)("refresher", this.options.redisOptions && this.options.redisOptions.connectionName)
      });
      E.on("error", y.noop), E.cluster("SLOTS", (0, y.timeout)((v, M) => {
        if (E.disconnect(), v)
          return S("error encountered running CLUSTER.SLOTS: %s", v), m(v);
        if (this.status === "disconnecting" || this.status === "close" || this.status === "end") {
          S("ignore CLUSTER.SLOTS results (count: %d) since cluster status is %s", M.length, this.status), m();
          return;
        }
        const L = [];
        S("cluster slots result count: %d", M.length);
        for (let P = 0; P < M.length; ++P) {
          const j = M[P], W = j[0], Q = j[1], G = [];
          for (let U = 2; U < j.length; U++) {
            if (!j[U][0])
              continue;
            const te = this.natMapper({
              host: j[U][0],
              port: j[U][1]
            });
            te.readOnly = U !== 2, L.push(te), G.push(te.host + ":" + te.port);
          }
          S("cluster slots result [%d]: slots %d~%d served by %s", P, W, Q, G);
          for (let U = W; U <= Q; U++)
            this.slots[U] = G;
        }
        this._groupsIds = /* @__PURE__ */ Object.create(null);
        let F = 0;
        for (let P = 0; P < 16384; P++) {
          const j = (this.slots[P] || []).join(";");
          if (!j.length) {
            this._groupsBySlot[P] = void 0;
            continue;
          }
          this._groupsIds[j] || (this._groupsIds[j] = ++F), this._groupsBySlot[P] = this._groupsIds[j];
        }
        this.connectionPool.reset(L), this.options.shardedSubscribers && this.shardedSubscribers.reset(this.slots, this.connectionPool.getNodes("all")).catch((P) => {
          S("Error while starting subscribers: %s", P);
        }), m();
      }, this.options.slotsRefreshTimeout));
    }
    invokeReadyDelayedCallbacks(d) {
      for (const m of this._readyDelayedCallbacks)
        process.nextTick(m, d);
      this._readyDelayedCallbacks = [];
    }
    /**
     * Check whether Cluster is able to process commands
     */
    readyCheck(d) {
      this.cluster("INFO", (m, E) => {
        if (m)
          return d(m);
        if (typeof E != "string")
          return d();
        let v;
        const M = E.split(`\r
`);
        for (let L = 0; L < M.length; ++L) {
          const F = M[L].split(":");
          if (F[0] === "cluster_state") {
            v = F[1];
            break;
          }
        }
        v === "fail" ? (S("cluster state not ok (%s)", v), d(null, v)) : d();
      });
    }
    resolveSrv(d) {
      return new Promise((m, E) => {
        this.options.resolveSrv(d, (v, M) => {
          if (v)
            return E(v);
          const L = this, F = (0, _.groupSrvRecords)(M), P = Object.keys(F).sort((W, Q) => parseInt(W) - parseInt(Q));
          function j(W) {
            if (!P.length)
              return E(W);
            const Q = P[0], G = F[Q], U = (0, _.weightSrvRecords)(G);
            G.records.length || P.shift(), L.dnsLookup(U.name).then((te) => m({
              host: te,
              port: U.port
            }), j);
          }
          j();
        });
      });
    }
    dnsLookup(d) {
      return new Promise((m, E) => {
        this.options.dnsLookup(d, (v, M) => {
          v ? (S("failed to resolve hostname %s to IP: %s", d, v.message), E(v)) : (S("resolved hostname %s to IP %s", d, M), m(M));
        });
      });
    }
    /**
     * Normalize startup nodes, and resolving hostnames to IPs.
     *
     * This process happens every time when #connect() is called since
     * #startupNodes and DNS records may chanage.
     */
    async resolveStartupNodeHostnames() {
      if (!Array.isArray(this.startupNodes) || this.startupNodes.length === 0)
        throw new Error("`startupNodes` should contain at least one node.");
      const d = (0, _.normalizeNodeOptions)(this.startupNodes), m = (0, _.getUniqueHostnamesFromOptions)(d);
      if (m.length === 0)
        return d;
      const E = await Promise.all(m.map((this.options.useSRVRecords ? this.resolveSrv : this.dnsLookup).bind(this))), v = (0, y.zipMap)(m, E);
      return d.map((M) => {
        const L = v.get(M.host);
        return L ? this.options.useSRVRecords ? Object.assign({}, M, L) : Object.assign({}, M, { host: L }) : M;
      });
    }
    createScanStream(d, { key: m, options: E = {} }) {
      return new a.default({
        objectMode: !0,
        key: m,
        redis: this,
        command: d,
        ...E
      });
    }
    createShardedSubscriberGroup() {
      this.subscriberGroupEmitter = new e.EventEmitter(), this.shardedSubscribers = new I.default(this.subscriberGroupEmitter);
      const d = (m) => {
        m instanceof f.default && this.disconnect(!0);
      };
      this.subscriberGroupEmitter.on("-node", (m, E) => {
        this.emit("-node", m, E), this.refreshSlotsCache(d);
      }), this.subscriberGroupEmitter.on("subscriberConnectFailed", ({ delay: m, error: E }) => {
        this.emit("error", E), setTimeout(() => {
          this.refreshSlotsCache(d);
        }, m);
      }), this.subscriberGroupEmitter.on("moved", () => {
        this.refreshSlotsCache(d);
      }), this.subscriberGroupEmitter.on("-subscriber", () => {
        this.emit("-subscriber");
      }), this.subscriberGroupEmitter.on("+subscriber", () => {
        this.emit("+subscriber");
      }), this.subscriberGroupEmitter.on("nodeError", (m, E) => {
        this.emit("nodeError", m, E);
      }), this.subscriberGroupEmitter.on("subscribersReady", () => {
        this.emit("subscribersReady");
      });
      for (const m of ["smessage", "smessageBuffer"])
        this.subscriberGroupEmitter.on(m, (E, v, M) => {
          this.emit(m, E, v, M);
        });
    }
  }
  return (0, g.default)(O, e.EventEmitter), (0, u.addTransactionSupport)(O.prototype), Qe.default = O, Qe;
}
var ge = {}, Gt = {}, Ne = {};
Object.defineProperty(Ne, "__esModule", { value: !0 });
const Vu = Z, Wu = (0, Vu.Debug)("AbstractConnector");
class Ju {
  constructor(e) {
    this.connecting = !1, this.disconnectTimeout = e;
  }
  check(e) {
    return !0;
  }
  disconnect() {
    if (this.connecting = !1, this.stream) {
      const e = this.stream, r = setTimeout(() => {
        Wu("stream %s:%s still open, destroying it", e.remoteAddress, e.remotePort), e.destroy();
      }, this.disconnectTimeout);
      e.on("close", () => clearTimeout(r)), e.end();
    }
  }
}
Ne.default = Ju;
Object.defineProperty(Gt, "__esModule", { value: !0 });
const Xu = se, Zu = se, $u = Z, el = Ne;
class tl extends el.default {
  constructor(e) {
    super(e.disconnectTimeout), this.options = e;
  }
  connect(e) {
    const { options: r } = this;
    this.connecting = !0;
    let i;
    return "path" in r && r.path ? i = {
      path: r.path
    } : (i = {}, "port" in r && r.port != null && (i.port = r.port), "host" in r && r.host != null && (i.host = r.host), "family" in r && r.family != null && (i.family = r.family)), r.tls && Object.assign(i, r.tls), new Promise((o, f) => {
      process.nextTick(() => {
        if (!this.connecting) {
          f(new Error($u.CONNECTION_CLOSED_ERROR_MSG));
          return;
        }
        try {
          r.tls ? this.stream = (0, Zu.connect)(i) : this.stream = (0, Xu.createConnection)(i);
        } catch (l) {
          f(l);
          return;
        }
        this.stream.once("error", (l) => {
          this.firstError = l;
        }), o(this.stream);
      });
    });
  }
}
Gt.default = tl;
var Ee = {}, qt = {};
Object.defineProperty(qt, "__esModule", { value: !0 });
function rl(t, e) {
  return (t.host || "127.0.0.1") === (e.host || "127.0.0.1") && (t.port || 26379) === (e.port || 26379);
}
class sl {
  constructor(e) {
    this.cursor = 0, this.sentinels = e.slice(0);
  }
  next() {
    const e = this.cursor >= this.sentinels.length;
    return { done: e, value: e ? void 0 : this.sentinels[this.cursor++] };
  }
  reset(e) {
    e && this.sentinels.length > 1 && this.cursor !== 1 && this.sentinels.unshift(...this.sentinels.splice(this.cursor - 1)), this.cursor = 0;
  }
  add(e) {
    for (let r = 0; r < this.sentinels.length; r++)
      if (rl(e, this.sentinels[r]))
        return !1;
    return this.sentinels.push(e), !0;
  }
  toString() {
    return `${JSON.stringify(this.sentinels)} @${this.cursor}`;
  }
}
qt.default = sl;
var st = {};
Object.defineProperty(st, "__esModule", { value: !0 });
st.FailoverDetector = void 0;
const nl = Z, gt = (0, nl.Debug)("FailoverDetector"), Rr = "+switch-master";
class il {
  // sentinels can't be used for regular commands after this
  constructor(e, r) {
    this.isDisconnected = !1, this.connector = e, this.sentinels = r;
  }
  cleanup() {
    this.isDisconnected = !0;
    for (const e of this.sentinels)
      e.client.disconnect();
  }
  async subscribe() {
    gt("Starting FailoverDetector");
    const e = [];
    for (const r of this.sentinels) {
      const i = r.client.subscribe(Rr).catch((o) => {
        gt("Failed to subscribe to failover messages on sentinel %s:%s (%s)", r.address.host || "127.0.0.1", r.address.port || 26739, o.message);
      });
      e.push(i), r.client.on("message", (o) => {
        !this.isDisconnected && o === Rr && this.disconnect();
      });
    }
    await Promise.all(e);
  }
  disconnect() {
    this.isDisconnected = !0, gt("Failover detected, disconnecting"), this.connector.disconnect();
  }
}
st.FailoverDetector = il;
var Mr;
function Kt() {
  if (Mr) return Ee;
  Mr = 1, Object.defineProperty(Ee, "__esModule", { value: !0 }), Ee.SentinelIterator = void 0;
  const t = se, e = Z, r = se, i = qt;
  Ee.SentinelIterator = i.default;
  const o = Ne, f = ye(), l = st, a = (0, e.Debug)("SentinelConnector");
  let u = class extends o.default {
    constructor(x) {
      if (super(x.disconnectTimeout), this.options = x, this.emitter = null, this.failoverDetector = null, !this.options.sentinels.length)
        throw new Error("Requires at least one sentinel to connect to.");
      if (!this.options.name)
        throw new Error("Requires the name of master.");
      this.sentinelIterator = new i.default(this.options.sentinels);
    }
    check(x) {
      const p = !x.role || this.options.role === x.role;
      return p || (a("role invalid, expected %s, but got %s", this.options.role, x.role), this.sentinelIterator.next(), this.sentinelIterator.next(), this.sentinelIterator.reset(!0)), p;
    }
    disconnect() {
      super.disconnect(), this.failoverDetector && this.failoverDetector.cleanup();
    }
    connect(x) {
      this.connecting = !0, this.retryAttempts = 0;
      let p;
      const R = async () => {
        const _ = this.sentinelIterator.next();
        if (_.done) {
          this.sentinelIterator.reset(!1);
          const T = typeof this.options.sentinelRetryStrategy == "function" ? this.options.sentinelRetryStrategy(++this.retryAttempts) : null;
          let O = typeof T != "number" ? "All sentinels are unreachable and retry is disabled." : `All sentinels are unreachable. Retrying from scratch after ${T}ms.`;
          p && (O += ` Last error: ${p.message}`), a(O);
          const N = new Error(O);
          if (typeof T == "number")
            return x("error", N), await new Promise((d) => setTimeout(d, T)), R();
          throw N;
        }
        let A = null, I = null;
        try {
          A = await this.resolve(_.value);
        } catch (T) {
          I = T;
        }
        if (!this.connecting)
          throw new Error(e.CONNECTION_CLOSED_ERROR_MSG);
        const S = _.value.host + ":" + _.value.port;
        if (A)
          return a("resolved: %s:%s from sentinel %s", A.host, A.port, S), this.options.enableTLSForSentinelMode && this.options.tls ? (Object.assign(A, this.options.tls), this.stream = (0, r.connect)(A), this.stream.once("secureConnect", this.initFailoverDetector.bind(this))) : (this.stream = (0, t.createConnection)(A), this.stream.once("connect", this.initFailoverDetector.bind(this))), this.stream.once("error", (T) => {
            this.firstError = T;
          }), this.stream;
        {
          const T = I ? "failed to connect to sentinel " + S + " because " + I.message : "connected to sentinel " + S + " successfully, but got an invalid reply: " + A;
          return a(T), x("sentinelError", new Error(T)), I && (p = I), R();
        }
      };
      return R();
    }
    async updateSentinels(x) {
      if (!this.options.updateSentinels)
        return;
      const p = await x.sentinel("sentinels", this.options.name);
      Array.isArray(p) && (p.map(e.packObject).forEach((R) => {
        if ((R.flags ? R.flags.split(",") : []).indexOf("disconnected") === -1 && R.ip && R.port) {
          const A = this.sentinelNatResolve(g(R));
          this.sentinelIterator.add(A) && a("adding sentinel %s:%s", A.host, A.port);
        }
      }), a("Updated internal sentinels: %s", this.sentinelIterator));
    }
    async resolveMaster(x) {
      const p = await x.sentinel("get-master-addr-by-name", this.options.name);
      return await this.updateSentinels(x), this.sentinelNatResolve(Array.isArray(p) ? { host: p[0], port: Number(p[1]) } : null);
    }
    async resolveSlave(x) {
      const p = await x.sentinel("slaves", this.options.name);
      if (!Array.isArray(p))
        return null;
      const R = p.map(e.packObject).filter((_) => _.flags && !_.flags.match(/(disconnected|s_down|o_down)/));
      return this.sentinelNatResolve(y(R, this.options.preferredSlaves));
    }
    sentinelNatResolve(x) {
      if (!x || !this.options.natMap)
        return x;
      const p = `${x.host}:${x.port}`;
      let R = x;
      return typeof this.options.natMap == "function" ? R = this.options.natMap(p) || x : typeof this.options.natMap == "object" && (R = this.options.natMap[p] || x), R;
    }
    connectToSentinel(x, p) {
      return new f.default({
        port: x.port || 26379,
        host: x.host,
        username: this.options.sentinelUsername || null,
        password: this.options.sentinelPassword || null,
        family: x.family || // @ts-expect-error
        ("path" in this.options && this.options.path ? void 0 : (
          // @ts-expect-error
          this.options.family
        )),
        tls: this.options.sentinelTLS,
        retryStrategy: null,
        enableReadyCheck: !1,
        connectTimeout: this.options.connectTimeout,
        commandTimeout: this.options.sentinelCommandTimeout,
        ...p
      });
    }
    async resolve(x) {
      const p = this.connectToSentinel(x);
      p.on("error", k);
      try {
        return this.options.role === "slave" ? await this.resolveSlave(p) : await this.resolveMaster(p);
      } finally {
        p.disconnect();
      }
    }
    async initFailoverDetector() {
      var x;
      if (!this.options.failoverDetector)
        return;
      this.sentinelIterator.reset(!0);
      const p = [];
      for (; p.length < this.options.sentinelMaxConnections; ) {
        const { done: R, value: _ } = this.sentinelIterator.next();
        if (R)
          break;
        const A = this.connectToSentinel(_, {
          lazyConnect: !0,
          retryStrategy: this.options.sentinelReconnectStrategy
        });
        A.on("reconnecting", () => {
          var I;
          (I = this.emitter) === null || I === void 0 || I.emit("sentinelReconnecting");
        }), p.push({ address: _, client: A });
      }
      this.sentinelIterator.reset(!1), this.failoverDetector && this.failoverDetector.cleanup(), this.failoverDetector = new l.FailoverDetector(this, p), await this.failoverDetector.subscribe(), (x = this.emitter) === null || x === void 0 || x.emit("failoverSubscribed");
    }
  };
  Ee.default = u;
  function y(w, x) {
    if (w.length === 0)
      return null;
    let p;
    if (typeof x == "function")
      p = x(w);
    else if (x !== null && typeof x == "object") {
      const R = Array.isArray(x) ? x : [x];
      R.sort((_, A) => (_.prio || (_.prio = 1), A.prio || (A.prio = 1), _.prio < A.prio ? -1 : _.prio > A.prio ? 1 : 0));
      for (let _ = 0; _ < R.length; _++) {
        for (let A = 0; A < w.length; A++) {
          const I = w[A];
          if (I.ip === R[_].ip && I.port === R[_].port) {
            p = I;
            break;
          }
        }
        if (p)
          break;
      }
    }
    return p || (p = (0, e.sample)(w)), g(p);
  }
  function g(w) {
    return { host: w.ip, port: Number(w.port) };
  }
  function k() {
  }
  return Ee;
}
var Or;
function ol() {
  if (Or) return ge;
  Or = 1, Object.defineProperty(ge, "__esModule", { value: !0 }), ge.SentinelConnector = ge.StandaloneConnector = void 0;
  const t = Gt;
  ge.StandaloneConnector = t.default;
  const e = Kt();
  return ge.SentinelConnector = e.default, ge;
}
var as = {}, nt = {}, Ht = {};
Object.defineProperty(Ht, "__esModule", { value: !0 });
const al = Ae;
class cl extends al.AbortError {
  constructor(e) {
    const r = `Reached the max retries per request limit (which is ${e}). Refer to "maxRetriesPerRequest" option for details.`;
    super(r), Error.captureStackTrace(this, this.constructor);
  }
  get name() {
    return this.constructor.name;
  }
}
Ht.default = cl;
Object.defineProperty(nt, "__esModule", { value: !0 });
nt.MaxRetriesPerRequestError = void 0;
const ul = Ht;
nt.MaxRetriesPerRequestError = ul.default;
var Yt = {}, Vt = {}, it = {};
it.byteLength = hl;
it.toByteArray = pl;
it.fromByteArray = ml;
var ae = [], ne = [], ll = typeof Uint8Array < "u" ? Uint8Array : Array, mt = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
for (var Ce = 0, fl = mt.length; Ce < fl; ++Ce)
  ae[Ce] = mt[Ce], ne[mt.charCodeAt(Ce)] = Ce;
ne[45] = 62;
ne[95] = 63;
function cs(t) {
  var e = t.length;
  if (e % 4 > 0)
    throw new Error("Invalid string. Length must be a multiple of 4");
  var r = t.indexOf("=");
  r === -1 && (r = e);
  var i = r === e ? 0 : 4 - r % 4;
  return [r, i];
}
function hl(t) {
  var e = cs(t), r = e[0], i = e[1];
  return (r + i) * 3 / 4 - i;
}
function dl(t, e, r) {
  return (e + r) * 3 / 4 - r;
}
function pl(t) {
  var e, r = cs(t), i = r[0], o = r[1], f = new ll(dl(t, i, o)), l = 0, a = o > 0 ? i - 4 : i, u;
  for (u = 0; u < a; u += 4)
    e = ne[t.charCodeAt(u)] << 18 | ne[t.charCodeAt(u + 1)] << 12 | ne[t.charCodeAt(u + 2)] << 6 | ne[t.charCodeAt(u + 3)], f[l++] = e >> 16 & 255, f[l++] = e >> 8 & 255, f[l++] = e & 255;
  return o === 2 && (e = ne[t.charCodeAt(u)] << 2 | ne[t.charCodeAt(u + 1)] >> 4, f[l++] = e & 255), o === 1 && (e = ne[t.charCodeAt(u)] << 10 | ne[t.charCodeAt(u + 1)] << 4 | ne[t.charCodeAt(u + 2)] >> 2, f[l++] = e >> 8 & 255, f[l++] = e & 255), f;
}
function yl(t) {
  return ae[t >> 18 & 63] + ae[t >> 12 & 63] + ae[t >> 6 & 63] + ae[t & 63];
}
function gl(t, e, r) {
  for (var i, o = [], f = e; f < r; f += 3)
    i = (t[f] << 16 & 16711680) + (t[f + 1] << 8 & 65280) + (t[f + 2] & 255), o.push(yl(i));
  return o.join("");
}
function ml(t) {
  for (var e, r = t.length, i = r % 3, o = [], f = 16383, l = 0, a = r - i; l < a; l += f)
    o.push(gl(t, l, l + f > a ? a : l + f));
  return i === 1 ? (e = t[r - 1], o.push(
    ae[e >> 2] + ae[e << 4 & 63] + "=="
  )) : i === 2 && (e = (t[r - 2] << 8) + t[r - 1], o.push(
    ae[e >> 10] + ae[e >> 4 & 63] + ae[e << 2 & 63] + "="
  )), o.join("");
}
var Wt = {};
/*! ieee754. BSD-3-Clause License. Feross Aboukhadijeh <https://feross.org/opensource> */
Wt.read = function(t, e, r, i, o) {
  var f, l, a = o * 8 - i - 1, u = (1 << a) - 1, y = u >> 1, g = -7, k = r ? o - 1 : 0, w = r ? -1 : 1, x = t[e + k];
  for (k += w, f = x & (1 << -g) - 1, x >>= -g, g += a; g > 0; f = f * 256 + t[e + k], k += w, g -= 8)
    ;
  for (l = f & (1 << -g) - 1, f >>= -g, g += i; g > 0; l = l * 256 + t[e + k], k += w, g -= 8)
    ;
  if (f === 0)
    f = 1 - y;
  else {
    if (f === u)
      return l ? NaN : (x ? -1 : 1) * (1 / 0);
    l = l + Math.pow(2, i), f = f - y;
  }
  return (x ? -1 : 1) * l * Math.pow(2, f - i);
};
Wt.write = function(t, e, r, i, o, f) {
  var l, a, u, y = f * 8 - o - 1, g = (1 << y) - 1, k = g >> 1, w = o === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0, x = i ? 0 : f - 1, p = i ? 1 : -1, R = e < 0 || e === 0 && 1 / e < 0 ? 1 : 0;
  for (e = Math.abs(e), isNaN(e) || e === 1 / 0 ? (a = isNaN(e) ? 1 : 0, l = g) : (l = Math.floor(Math.log(e) / Math.LN2), e * (u = Math.pow(2, -l)) < 1 && (l--, u *= 2), l + k >= 1 ? e += w / u : e += w * Math.pow(2, 1 - k), e * u >= 2 && (l++, u /= 2), l + k >= g ? (a = 0, l = g) : l + k >= 1 ? (a = (e * u - 1) * Math.pow(2, o), l = l + k) : (a = e * Math.pow(2, k - 1) * Math.pow(2, o), l = 0)); o >= 8; t[r + x] = a & 255, x += p, a /= 256, o -= 8)
    ;
  for (l = l << o | a, y += o; y > 0; t[r + x] = l & 255, x += p, l /= 256, y -= 8)
    ;
  t[r + x - p] |= R * 128;
};
/*!
 * The buffer module from node.js, for the browser.
 *
 * @author   Feross Aboukhadijeh <https://feross.org>
 * @license  MIT
 */
(function(t) {
  const e = it, r = Wt, i = typeof Symbol == "function" && typeof Symbol.for == "function" ? Symbol.for("nodejs.util.inspect.custom") : null;
  t.Buffer = a, t.SlowBuffer = I, t.INSPECT_MAX_BYTES = 50;
  const o = 2147483647;
  t.kMaxLength = o, a.TYPED_ARRAY_SUPPORT = f(), !a.TYPED_ARRAY_SUPPORT && typeof console < "u" && typeof console.error == "function" && console.error(
    "This browser lacks typed array (Uint8Array) support which is required by `buffer` v5.x. Use `buffer` v4.x if you require old browser support."
  );
  function f() {
    try {
      const c = new Uint8Array(1), s = { foo: function() {
        return 42;
      } };
      return Object.setPrototypeOf(s, Uint8Array.prototype), Object.setPrototypeOf(c, s), c.foo() === 42;
    } catch {
      return !1;
    }
  }
  Object.defineProperty(a.prototype, "parent", {
    enumerable: !0,
    get: function() {
      if (a.isBuffer(this))
        return this.buffer;
    }
  }), Object.defineProperty(a.prototype, "offset", {
    enumerable: !0,
    get: function() {
      if (a.isBuffer(this))
        return this.byteOffset;
    }
  });
  function l(c) {
    if (c > o)
      throw new RangeError('The value "' + c + '" is invalid for option "size"');
    const s = new Uint8Array(c);
    return Object.setPrototypeOf(s, a.prototype), s;
  }
  function a(c, s, n) {
    if (typeof c == "number") {
      if (typeof s == "string")
        throw new TypeError(
          'The "string" argument must be of type string. Received type number'
        );
      return k(c);
    }
    return u(c, s, n);
  }
  a.poolSize = 8192;
  function u(c, s, n) {
    if (typeof c == "string")
      return w(c, s);
    if (ArrayBuffer.isView(c))
      return p(c);
    if (c == null)
      throw new TypeError(
        "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof c
      );
    if (oe(c, ArrayBuffer) || c && oe(c.buffer, ArrayBuffer) || typeof SharedArrayBuffer < "u" && (oe(c, SharedArrayBuffer) || c && oe(c.buffer, SharedArrayBuffer)))
      return R(c, s, n);
    if (typeof c == "number")
      throw new TypeError(
        'The "value" argument must not be of type number. Received type number'
      );
    const h = c.valueOf && c.valueOf();
    if (h != null && h !== c)
      return a.from(h, s, n);
    const b = _(c);
    if (b) return b;
    if (typeof Symbol < "u" && Symbol.toPrimitive != null && typeof c[Symbol.toPrimitive] == "function")
      return a.from(c[Symbol.toPrimitive]("string"), s, n);
    throw new TypeError(
      "The first argument must be one of type string, Buffer, ArrayBuffer, Array, or Array-like Object. Received type " + typeof c
    );
  }
  a.from = function(c, s, n) {
    return u(c, s, n);
  }, Object.setPrototypeOf(a.prototype, Uint8Array.prototype), Object.setPrototypeOf(a, Uint8Array);
  function y(c) {
    if (typeof c != "number")
      throw new TypeError('"size" argument must be of type number');
    if (c < 0)
      throw new RangeError('The value "' + c + '" is invalid for option "size"');
  }
  function g(c, s, n) {
    return y(c), c <= 0 ? l(c) : s !== void 0 ? typeof n == "string" ? l(c).fill(s, n) : l(c).fill(s) : l(c);
  }
  a.alloc = function(c, s, n) {
    return g(c, s, n);
  };
  function k(c) {
    return y(c), l(c < 0 ? 0 : A(c) | 0);
  }
  a.allocUnsafe = function(c) {
    return k(c);
  }, a.allocUnsafeSlow = function(c) {
    return k(c);
  };
  function w(c, s) {
    if ((typeof s != "string" || s === "") && (s = "utf8"), !a.isEncoding(s))
      throw new TypeError("Unknown encoding: " + s);
    const n = S(c, s) | 0;
    let h = l(n);
    const b = h.write(c, s);
    return b !== n && (h = h.slice(0, b)), h;
  }
  function x(c) {
    const s = c.length < 0 ? 0 : A(c.length) | 0, n = l(s);
    for (let h = 0; h < s; h += 1)
      n[h] = c[h] & 255;
    return n;
  }
  function p(c) {
    if (oe(c, Uint8Array)) {
      const s = new Uint8Array(c);
      return R(s.buffer, s.byteOffset, s.byteLength);
    }
    return x(c);
  }
  function R(c, s, n) {
    if (s < 0 || c.byteLength < s)
      throw new RangeError('"offset" is outside of buffer bounds');
    if (c.byteLength < s + (n || 0))
      throw new RangeError('"length" is outside of buffer bounds');
    let h;
    return s === void 0 && n === void 0 ? h = new Uint8Array(c) : n === void 0 ? h = new Uint8Array(c, s) : h = new Uint8Array(c, s, n), Object.setPrototypeOf(h, a.prototype), h;
  }
  function _(c) {
    if (a.isBuffer(c)) {
      const s = A(c.length) | 0, n = l(s);
      return n.length === 0 || c.copy(n, 0, 0, s), n;
    }
    if (c.length !== void 0)
      return typeof c.length != "number" || ut(c.length) ? l(0) : x(c);
    if (c.type === "Buffer" && Array.isArray(c.data))
      return x(c.data);
  }
  function A(c) {
    if (c >= o)
      throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x" + o.toString(16) + " bytes");
    return c | 0;
  }
  function I(c) {
    return +c != c && (c = 0), a.alloc(+c);
  }
  a.isBuffer = function(s) {
    return s != null && s._isBuffer === !0 && s !== a.prototype;
  }, a.compare = function(s, n) {
    if (oe(s, Uint8Array) && (s = a.from(s, s.offset, s.byteLength)), oe(n, Uint8Array) && (n = a.from(n, n.offset, n.byteLength)), !a.isBuffer(s) || !a.isBuffer(n))
      throw new TypeError(
        'The "buf1", "buf2" arguments must be one of type Buffer or Uint8Array'
      );
    if (s === n) return 0;
    let h = s.length, b = n.length;
    for (let C = 0, B = Math.min(h, b); C < B; ++C)
      if (s[C] !== n[C]) {
        h = s[C], b = n[C];
        break;
      }
    return h < b ? -1 : b < h ? 1 : 0;
  }, a.isEncoding = function(s) {
    switch (String(s).toLowerCase()) {
      case "hex":
      case "utf8":
      case "utf-8":
      case "ascii":
      case "latin1":
      case "binary":
      case "base64":
      case "ucs2":
      case "ucs-2":
      case "utf16le":
      case "utf-16le":
        return !0;
      default:
        return !1;
    }
  }, a.concat = function(s, n) {
    if (!Array.isArray(s))
      throw new TypeError('"list" argument must be an Array of Buffers');
    if (s.length === 0)
      return a.alloc(0);
    let h;
    if (n === void 0)
      for (n = 0, h = 0; h < s.length; ++h)
        n += s[h].length;
    const b = a.allocUnsafe(n);
    let C = 0;
    for (h = 0; h < s.length; ++h) {
      let B = s[h];
      if (oe(B, Uint8Array))
        C + B.length > b.length ? (a.isBuffer(B) || (B = a.from(B)), B.copy(b, C)) : Uint8Array.prototype.set.call(
          b,
          B,
          C
        );
      else if (a.isBuffer(B))
        B.copy(b, C);
      else
        throw new TypeError('"list" argument must be an Array of Buffers');
      C += B.length;
    }
    return b;
  };
  function S(c, s) {
    if (a.isBuffer(c))
      return c.length;
    if (ArrayBuffer.isView(c) || oe(c, ArrayBuffer))
      return c.byteLength;
    if (typeof c != "string")
      throw new TypeError(
        'The "string" argument must be one of type string, Buffer, or ArrayBuffer. Received type ' + typeof c
      );
    const n = c.length, h = arguments.length > 2 && arguments[2] === !0;
    if (!h && n === 0) return 0;
    let b = !1;
    for (; ; )
      switch (s) {
        case "ascii":
        case "latin1":
        case "binary":
          return n;
        case "utf8":
        case "utf-8":
          return ct(c).length;
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return n * 2;
        case "hex":
          return n >>> 1;
        case "base64":
          return or(c).length;
        default:
          if (b)
            return h ? -1 : ct(c).length;
          s = ("" + s).toLowerCase(), b = !0;
      }
  }
  a.byteLength = S;
  function T(c, s, n) {
    let h = !1;
    if ((s === void 0 || s < 0) && (s = 0), s > this.length || ((n === void 0 || n > this.length) && (n = this.length), n <= 0) || (n >>>= 0, s >>>= 0, n <= s))
      return "";
    for (c || (c = "utf8"); ; )
      switch (c) {
        case "hex":
          return U(this, s, n);
        case "utf8":
        case "utf-8":
          return P(this, s, n);
        case "ascii":
          return Q(this, s, n);
        case "latin1":
        case "binary":
          return G(this, s, n);
        case "base64":
          return F(this, s, n);
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return te(this, s, n);
        default:
          if (h) throw new TypeError("Unknown encoding: " + c);
          c = (c + "").toLowerCase(), h = !0;
      }
  }
  a.prototype._isBuffer = !0;
  function O(c, s, n) {
    const h = c[s];
    c[s] = c[n], c[n] = h;
  }
  a.prototype.swap16 = function() {
    const s = this.length;
    if (s % 2 !== 0)
      throw new RangeError("Buffer size must be a multiple of 16-bits");
    for (let n = 0; n < s; n += 2)
      O(this, n, n + 1);
    return this;
  }, a.prototype.swap32 = function() {
    const s = this.length;
    if (s % 4 !== 0)
      throw new RangeError("Buffer size must be a multiple of 32-bits");
    for (let n = 0; n < s; n += 4)
      O(this, n, n + 3), O(this, n + 1, n + 2);
    return this;
  }, a.prototype.swap64 = function() {
    const s = this.length;
    if (s % 8 !== 0)
      throw new RangeError("Buffer size must be a multiple of 64-bits");
    for (let n = 0; n < s; n += 8)
      O(this, n, n + 7), O(this, n + 1, n + 6), O(this, n + 2, n + 5), O(this, n + 3, n + 4);
    return this;
  }, a.prototype.toString = function() {
    const s = this.length;
    return s === 0 ? "" : arguments.length === 0 ? P(this, 0, s) : T.apply(this, arguments);
  }, a.prototype.toLocaleString = a.prototype.toString, a.prototype.equals = function(s) {
    if (!a.isBuffer(s)) throw new TypeError("Argument must be a Buffer");
    return this === s ? !0 : a.compare(this, s) === 0;
  }, a.prototype.inspect = function() {
    let s = "";
    const n = t.INSPECT_MAX_BYTES;
    return s = this.toString("hex", 0, n).replace(/(.{2})/g, "$1 ").trim(), this.length > n && (s += " ... "), "<Buffer " + s + ">";
  }, i && (a.prototype[i] = a.prototype.inspect), a.prototype.compare = function(s, n, h, b, C) {
    if (oe(s, Uint8Array) && (s = a.from(s, s.offset, s.byteLength)), !a.isBuffer(s))
      throw new TypeError(
        'The "target" argument must be one of type Buffer or Uint8Array. Received type ' + typeof s
      );
    if (n === void 0 && (n = 0), h === void 0 && (h = s ? s.length : 0), b === void 0 && (b = 0), C === void 0 && (C = this.length), n < 0 || h > s.length || b < 0 || C > this.length)
      throw new RangeError("out of range index");
    if (b >= C && n >= h)
      return 0;
    if (b >= C)
      return -1;
    if (n >= h)
      return 1;
    if (n >>>= 0, h >>>= 0, b >>>= 0, C >>>= 0, this === s) return 0;
    let B = C - b, D = h - n;
    const Y = Math.min(B, D), K = this.slice(b, C), V = s.slice(n, h);
    for (let q = 0; q < Y; ++q)
      if (K[q] !== V[q]) {
        B = K[q], D = V[q];
        break;
      }
    return B < D ? -1 : D < B ? 1 : 0;
  };
  function N(c, s, n, h, b) {
    if (c.length === 0) return -1;
    if (typeof n == "string" ? (h = n, n = 0) : n > 2147483647 ? n = 2147483647 : n < -2147483648 && (n = -2147483648), n = +n, ut(n) && (n = b ? 0 : c.length - 1), n < 0 && (n = c.length + n), n >= c.length) {
      if (b) return -1;
      n = c.length - 1;
    } else if (n < 0)
      if (b) n = 0;
      else return -1;
    if (typeof s == "string" && (s = a.from(s, h)), a.isBuffer(s))
      return s.length === 0 ? -1 : d(c, s, n, h, b);
    if (typeof s == "number")
      return s = s & 255, typeof Uint8Array.prototype.indexOf == "function" ? b ? Uint8Array.prototype.indexOf.call(c, s, n) : Uint8Array.prototype.lastIndexOf.call(c, s, n) : d(c, [s], n, h, b);
    throw new TypeError("val must be string, number or Buffer");
  }
  function d(c, s, n, h, b) {
    let C = 1, B = c.length, D = s.length;
    if (h !== void 0 && (h = String(h).toLowerCase(), h === "ucs2" || h === "ucs-2" || h === "utf16le" || h === "utf-16le")) {
      if (c.length < 2 || s.length < 2)
        return -1;
      C = 2, B /= 2, D /= 2, n /= 2;
    }
    function Y(V, q) {
      return C === 1 ? V[q] : V.readUInt16BE(q * C);
    }
    let K;
    if (b) {
      let V = -1;
      for (K = n; K < B; K++)
        if (Y(c, K) === Y(s, V === -1 ? 0 : K - V)) {
          if (V === -1 && (V = K), K - V + 1 === D) return V * C;
        } else
          V !== -1 && (K -= K - V), V = -1;
    } else
      for (n + D > B && (n = B - D), K = n; K >= 0; K--) {
        let V = !0;
        for (let q = 0; q < D; q++)
          if (Y(c, K + q) !== Y(s, q)) {
            V = !1;
            break;
          }
        if (V) return K;
      }
    return -1;
  }
  a.prototype.includes = function(s, n, h) {
    return this.indexOf(s, n, h) !== -1;
  }, a.prototype.indexOf = function(s, n, h) {
    return N(this, s, n, h, !0);
  }, a.prototype.lastIndexOf = function(s, n, h) {
    return N(this, s, n, h, !1);
  };
  function m(c, s, n, h) {
    n = Number(n) || 0;
    const b = c.length - n;
    h ? (h = Number(h), h > b && (h = b)) : h = b;
    const C = s.length;
    h > C / 2 && (h = C / 2);
    let B;
    for (B = 0; B < h; ++B) {
      const D = parseInt(s.substr(B * 2, 2), 16);
      if (ut(D)) return B;
      c[n + B] = D;
    }
    return B;
  }
  function E(c, s, n, h) {
    return Le(ct(s, c.length - n), c, n, h);
  }
  function v(c, s, n, h) {
    return Le(bs(s), c, n, h);
  }
  function M(c, s, n, h) {
    return Le(or(s), c, n, h);
  }
  function L(c, s, n, h) {
    return Le(Ss(s, c.length - n), c, n, h);
  }
  a.prototype.write = function(s, n, h, b) {
    if (n === void 0)
      b = "utf8", h = this.length, n = 0;
    else if (h === void 0 && typeof n == "string")
      b = n, h = this.length, n = 0;
    else if (isFinite(n))
      n = n >>> 0, isFinite(h) ? (h = h >>> 0, b === void 0 && (b = "utf8")) : (b = h, h = void 0);
    else
      throw new Error(
        "Buffer.write(string, encoding, offset[, length]) is no longer supported"
      );
    const C = this.length - n;
    if ((h === void 0 || h > C) && (h = C), s.length > 0 && (h < 0 || n < 0) || n > this.length)
      throw new RangeError("Attempt to write outside buffer bounds");
    b || (b = "utf8");
    let B = !1;
    for (; ; )
      switch (b) {
        case "hex":
          return m(this, s, n, h);
        case "utf8":
        case "utf-8":
          return E(this, s, n, h);
        case "ascii":
        case "latin1":
        case "binary":
          return v(this, s, n, h);
        case "base64":
          return M(this, s, n, h);
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return L(this, s, n, h);
        default:
          if (B) throw new TypeError("Unknown encoding: " + b);
          b = ("" + b).toLowerCase(), B = !0;
      }
  }, a.prototype.toJSON = function() {
    return {
      type: "Buffer",
      data: Array.prototype.slice.call(this._arr || this, 0)
    };
  };
  function F(c, s, n) {
    return s === 0 && n === c.length ? e.fromByteArray(c) : e.fromByteArray(c.slice(s, n));
  }
  function P(c, s, n) {
    n = Math.min(c.length, n);
    const h = [];
    let b = s;
    for (; b < n; ) {
      const C = c[b];
      let B = null, D = C > 239 ? 4 : C > 223 ? 3 : C > 191 ? 2 : 1;
      if (b + D <= n) {
        let Y, K, V, q;
        switch (D) {
          case 1:
            C < 128 && (B = C);
            break;
          case 2:
            Y = c[b + 1], (Y & 192) === 128 && (q = (C & 31) << 6 | Y & 63, q > 127 && (B = q));
            break;
          case 3:
            Y = c[b + 1], K = c[b + 2], (Y & 192) === 128 && (K & 192) === 128 && (q = (C & 15) << 12 | (Y & 63) << 6 | K & 63, q > 2047 && (q < 55296 || q > 57343) && (B = q));
            break;
          case 4:
            Y = c[b + 1], K = c[b + 2], V = c[b + 3], (Y & 192) === 128 && (K & 192) === 128 && (V & 192) === 128 && (q = (C & 15) << 18 | (Y & 63) << 12 | (K & 63) << 6 | V & 63, q > 65535 && q < 1114112 && (B = q));
        }
      }
      B === null ? (B = 65533, D = 1) : B > 65535 && (B -= 65536, h.push(B >>> 10 & 1023 | 55296), B = 56320 | B & 1023), h.push(B), b += D;
    }
    return W(h);
  }
  const j = 4096;
  function W(c) {
    const s = c.length;
    if (s <= j)
      return String.fromCharCode.apply(String, c);
    let n = "", h = 0;
    for (; h < s; )
      n += String.fromCharCode.apply(
        String,
        c.slice(h, h += j)
      );
    return n;
  }
  function Q(c, s, n) {
    let h = "";
    n = Math.min(c.length, n);
    for (let b = s; b < n; ++b)
      h += String.fromCharCode(c[b] & 127);
    return h;
  }
  function G(c, s, n) {
    let h = "";
    n = Math.min(c.length, n);
    for (let b = s; b < n; ++b)
      h += String.fromCharCode(c[b]);
    return h;
  }
  function U(c, s, n) {
    const h = c.length;
    (!s || s < 0) && (s = 0), (!n || n < 0 || n > h) && (n = h);
    let b = "";
    for (let C = s; C < n; ++C)
      b += ks[c[C]];
    return b;
  }
  function te(c, s, n) {
    const h = c.slice(s, n);
    let b = "";
    for (let C = 0; C < h.length - 1; C += 2)
      b += String.fromCharCode(h[C] + h[C + 1] * 256);
    return b;
  }
  a.prototype.slice = function(s, n) {
    const h = this.length;
    s = ~~s, n = n === void 0 ? h : ~~n, s < 0 ? (s += h, s < 0 && (s = 0)) : s > h && (s = h), n < 0 ? (n += h, n < 0 && (n = 0)) : n > h && (n = h), n < s && (n = s);
    const b = this.subarray(s, n);
    return Object.setPrototypeOf(b, a.prototype), b;
  };
  function X(c, s, n) {
    if (c % 1 !== 0 || c < 0) throw new RangeError("offset is not uint");
    if (c + s > n) throw new RangeError("Trying to access beyond buffer length");
  }
  a.prototype.readUintLE = a.prototype.readUIntLE = function(s, n, h) {
    s = s >>> 0, n = n >>> 0, h || X(s, n, this.length);
    let b = this[s], C = 1, B = 0;
    for (; ++B < n && (C *= 256); )
      b += this[s + B] * C;
    return b;
  }, a.prototype.readUintBE = a.prototype.readUIntBE = function(s, n, h) {
    s = s >>> 0, n = n >>> 0, h || X(s, n, this.length);
    let b = this[s + --n], C = 1;
    for (; n > 0 && (C *= 256); )
      b += this[s + --n] * C;
    return b;
  }, a.prototype.readUint8 = a.prototype.readUInt8 = function(s, n) {
    return s = s >>> 0, n || X(s, 1, this.length), this[s];
  }, a.prototype.readUint16LE = a.prototype.readUInt16LE = function(s, n) {
    return s = s >>> 0, n || X(s, 2, this.length), this[s] | this[s + 1] << 8;
  }, a.prototype.readUint16BE = a.prototype.readUInt16BE = function(s, n) {
    return s = s >>> 0, n || X(s, 2, this.length), this[s] << 8 | this[s + 1];
  }, a.prototype.readUint32LE = a.prototype.readUInt32LE = function(s, n) {
    return s = s >>> 0, n || X(s, 4, this.length), (this[s] | this[s + 1] << 8 | this[s + 2] << 16) + this[s + 3] * 16777216;
  }, a.prototype.readUint32BE = a.prototype.readUInt32BE = function(s, n) {
    return s = s >>> 0, n || X(s, 4, this.length), this[s] * 16777216 + (this[s + 1] << 16 | this[s + 2] << 8 | this[s + 3]);
  }, a.prototype.readBigUInt64LE = he(function(s) {
    s = s >>> 0, ke(s, "offset");
    const n = this[s], h = this[s + 7];
    (n === void 0 || h === void 0) && Te(s, this.length - 8);
    const b = n + this[++s] * 2 ** 8 + this[++s] * 2 ** 16 + this[++s] * 2 ** 24, C = this[++s] + this[++s] * 2 ** 8 + this[++s] * 2 ** 16 + h * 2 ** 24;
    return BigInt(b) + (BigInt(C) << BigInt(32));
  }), a.prototype.readBigUInt64BE = he(function(s) {
    s = s >>> 0, ke(s, "offset");
    const n = this[s], h = this[s + 7];
    (n === void 0 || h === void 0) && Te(s, this.length - 8);
    const b = n * 2 ** 24 + this[++s] * 2 ** 16 + this[++s] * 2 ** 8 + this[++s], C = this[++s] * 2 ** 24 + this[++s] * 2 ** 16 + this[++s] * 2 ** 8 + h;
    return (BigInt(b) << BigInt(32)) + BigInt(C);
  }), a.prototype.readIntLE = function(s, n, h) {
    s = s >>> 0, n = n >>> 0, h || X(s, n, this.length);
    let b = this[s], C = 1, B = 0;
    for (; ++B < n && (C *= 256); )
      b += this[s + B] * C;
    return C *= 128, b >= C && (b -= Math.pow(2, 8 * n)), b;
  }, a.prototype.readIntBE = function(s, n, h) {
    s = s >>> 0, n = n >>> 0, h || X(s, n, this.length);
    let b = n, C = 1, B = this[s + --b];
    for (; b > 0 && (C *= 256); )
      B += this[s + --b] * C;
    return C *= 128, B >= C && (B -= Math.pow(2, 8 * n)), B;
  }, a.prototype.readInt8 = function(s, n) {
    return s = s >>> 0, n || X(s, 1, this.length), this[s] & 128 ? (255 - this[s] + 1) * -1 : this[s];
  }, a.prototype.readInt16LE = function(s, n) {
    s = s >>> 0, n || X(s, 2, this.length);
    const h = this[s] | this[s + 1] << 8;
    return h & 32768 ? h | 4294901760 : h;
  }, a.prototype.readInt16BE = function(s, n) {
    s = s >>> 0, n || X(s, 2, this.length);
    const h = this[s + 1] | this[s] << 8;
    return h & 32768 ? h | 4294901760 : h;
  }, a.prototype.readInt32LE = function(s, n) {
    return s = s >>> 0, n || X(s, 4, this.length), this[s] | this[s + 1] << 8 | this[s + 2] << 16 | this[s + 3] << 24;
  }, a.prototype.readInt32BE = function(s, n) {
    return s = s >>> 0, n || X(s, 4, this.length), this[s] << 24 | this[s + 1] << 16 | this[s + 2] << 8 | this[s + 3];
  }, a.prototype.readBigInt64LE = he(function(s) {
    s = s >>> 0, ke(s, "offset");
    const n = this[s], h = this[s + 7];
    (n === void 0 || h === void 0) && Te(s, this.length - 8);
    const b = this[s + 4] + this[s + 5] * 2 ** 8 + this[s + 6] * 2 ** 16 + (h << 24);
    return (BigInt(b) << BigInt(32)) + BigInt(n + this[++s] * 2 ** 8 + this[++s] * 2 ** 16 + this[++s] * 2 ** 24);
  }), a.prototype.readBigInt64BE = he(function(s) {
    s = s >>> 0, ke(s, "offset");
    const n = this[s], h = this[s + 7];
    (n === void 0 || h === void 0) && Te(s, this.length - 8);
    const b = (n << 24) + // Overflow
    this[++s] * 2 ** 16 + this[++s] * 2 ** 8 + this[++s];
    return (BigInt(b) << BigInt(32)) + BigInt(this[++s] * 2 ** 24 + this[++s] * 2 ** 16 + this[++s] * 2 ** 8 + h);
  }), a.prototype.readFloatLE = function(s, n) {
    return s = s >>> 0, n || X(s, 4, this.length), r.read(this, s, !0, 23, 4);
  }, a.prototype.readFloatBE = function(s, n) {
    return s = s >>> 0, n || X(s, 4, this.length), r.read(this, s, !1, 23, 4);
  }, a.prototype.readDoubleLE = function(s, n) {
    return s = s >>> 0, n || X(s, 8, this.length), r.read(this, s, !0, 52, 8);
  }, a.prototype.readDoubleBE = function(s, n) {
    return s = s >>> 0, n || X(s, 8, this.length), r.read(this, s, !1, 52, 8);
  };
  function re(c, s, n, h, b, C) {
    if (!a.isBuffer(c)) throw new TypeError('"buffer" argument must be a Buffer instance');
    if (s > b || s < C) throw new RangeError('"value" argument is out of bounds');
    if (n + h > c.length) throw new RangeError("Index out of range");
  }
  a.prototype.writeUintLE = a.prototype.writeUIntLE = function(s, n, h, b) {
    if (s = +s, n = n >>> 0, h = h >>> 0, !b) {
      const D = Math.pow(2, 8 * h) - 1;
      re(this, s, n, h, D, 0);
    }
    let C = 1, B = 0;
    for (this[n] = s & 255; ++B < h && (C *= 256); )
      this[n + B] = s / C & 255;
    return n + h;
  }, a.prototype.writeUintBE = a.prototype.writeUIntBE = function(s, n, h, b) {
    if (s = +s, n = n >>> 0, h = h >>> 0, !b) {
      const D = Math.pow(2, 8 * h) - 1;
      re(this, s, n, h, D, 0);
    }
    let C = h - 1, B = 1;
    for (this[n + C] = s & 255; --C >= 0 && (B *= 256); )
      this[n + C] = s / B & 255;
    return n + h;
  }, a.prototype.writeUint8 = a.prototype.writeUInt8 = function(s, n, h) {
    return s = +s, n = n >>> 0, h || re(this, s, n, 1, 255, 0), this[n] = s & 255, n + 1;
  }, a.prototype.writeUint16LE = a.prototype.writeUInt16LE = function(s, n, h) {
    return s = +s, n = n >>> 0, h || re(this, s, n, 2, 65535, 0), this[n] = s & 255, this[n + 1] = s >>> 8, n + 2;
  }, a.prototype.writeUint16BE = a.prototype.writeUInt16BE = function(s, n, h) {
    return s = +s, n = n >>> 0, h || re(this, s, n, 2, 65535, 0), this[n] = s >>> 8, this[n + 1] = s & 255, n + 2;
  }, a.prototype.writeUint32LE = a.prototype.writeUInt32LE = function(s, n, h) {
    return s = +s, n = n >>> 0, h || re(this, s, n, 4, 4294967295, 0), this[n + 3] = s >>> 24, this[n + 2] = s >>> 16, this[n + 1] = s >>> 8, this[n] = s & 255, n + 4;
  }, a.prototype.writeUint32BE = a.prototype.writeUInt32BE = function(s, n, h) {
    return s = +s, n = n >>> 0, h || re(this, s, n, 4, 4294967295, 0), this[n] = s >>> 24, this[n + 1] = s >>> 16, this[n + 2] = s >>> 8, this[n + 3] = s & 255, n + 4;
  };
  function $t(c, s, n, h, b) {
    ir(s, h, b, c, n, 7);
    let C = Number(s & BigInt(4294967295));
    c[n++] = C, C = C >> 8, c[n++] = C, C = C >> 8, c[n++] = C, C = C >> 8, c[n++] = C;
    let B = Number(s >> BigInt(32) & BigInt(4294967295));
    return c[n++] = B, B = B >> 8, c[n++] = B, B = B >> 8, c[n++] = B, B = B >> 8, c[n++] = B, n;
  }
  function er(c, s, n, h, b) {
    ir(s, h, b, c, n, 7);
    let C = Number(s & BigInt(4294967295));
    c[n + 7] = C, C = C >> 8, c[n + 6] = C, C = C >> 8, c[n + 5] = C, C = C >> 8, c[n + 4] = C;
    let B = Number(s >> BigInt(32) & BigInt(4294967295));
    return c[n + 3] = B, B = B >> 8, c[n + 2] = B, B = B >> 8, c[n + 1] = B, B = B >> 8, c[n] = B, n + 8;
  }
  a.prototype.writeBigUInt64LE = he(function(s, n = 0) {
    return $t(this, s, n, BigInt(0), BigInt("0xffffffffffffffff"));
  }), a.prototype.writeBigUInt64BE = he(function(s, n = 0) {
    return er(this, s, n, BigInt(0), BigInt("0xffffffffffffffff"));
  }), a.prototype.writeIntLE = function(s, n, h, b) {
    if (s = +s, n = n >>> 0, !b) {
      const Y = Math.pow(2, 8 * h - 1);
      re(this, s, n, h, Y - 1, -Y);
    }
    let C = 0, B = 1, D = 0;
    for (this[n] = s & 255; ++C < h && (B *= 256); )
      s < 0 && D === 0 && this[n + C - 1] !== 0 && (D = 1), this[n + C] = (s / B >> 0) - D & 255;
    return n + h;
  }, a.prototype.writeIntBE = function(s, n, h, b) {
    if (s = +s, n = n >>> 0, !b) {
      const Y = Math.pow(2, 8 * h - 1);
      re(this, s, n, h, Y - 1, -Y);
    }
    let C = h - 1, B = 1, D = 0;
    for (this[n + C] = s & 255; --C >= 0 && (B *= 256); )
      s < 0 && D === 0 && this[n + C + 1] !== 0 && (D = 1), this[n + C] = (s / B >> 0) - D & 255;
    return n + h;
  }, a.prototype.writeInt8 = function(s, n, h) {
    return s = +s, n = n >>> 0, h || re(this, s, n, 1, 127, -128), s < 0 && (s = 255 + s + 1), this[n] = s & 255, n + 1;
  }, a.prototype.writeInt16LE = function(s, n, h) {
    return s = +s, n = n >>> 0, h || re(this, s, n, 2, 32767, -32768), this[n] = s & 255, this[n + 1] = s >>> 8, n + 2;
  }, a.prototype.writeInt16BE = function(s, n, h) {
    return s = +s, n = n >>> 0, h || re(this, s, n, 2, 32767, -32768), this[n] = s >>> 8, this[n + 1] = s & 255, n + 2;
  }, a.prototype.writeInt32LE = function(s, n, h) {
    return s = +s, n = n >>> 0, h || re(this, s, n, 4, 2147483647, -2147483648), this[n] = s & 255, this[n + 1] = s >>> 8, this[n + 2] = s >>> 16, this[n + 3] = s >>> 24, n + 4;
  }, a.prototype.writeInt32BE = function(s, n, h) {
    return s = +s, n = n >>> 0, h || re(this, s, n, 4, 2147483647, -2147483648), s < 0 && (s = 4294967295 + s + 1), this[n] = s >>> 24, this[n + 1] = s >>> 16, this[n + 2] = s >>> 8, this[n + 3] = s & 255, n + 4;
  }, a.prototype.writeBigInt64LE = he(function(s, n = 0) {
    return $t(this, s, n, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
  }), a.prototype.writeBigInt64BE = he(function(s, n = 0) {
    return er(this, s, n, -BigInt("0x8000000000000000"), BigInt("0x7fffffffffffffff"));
  });
  function tr(c, s, n, h, b, C) {
    if (n + h > c.length) throw new RangeError("Index out of range");
    if (n < 0) throw new RangeError("Index out of range");
  }
  function rr(c, s, n, h, b) {
    return s = +s, n = n >>> 0, b || tr(c, s, n, 4), r.write(c, s, n, h, 23, 4), n + 4;
  }
  a.prototype.writeFloatLE = function(s, n, h) {
    return rr(this, s, n, !0, h);
  }, a.prototype.writeFloatBE = function(s, n, h) {
    return rr(this, s, n, !1, h);
  };
  function sr(c, s, n, h, b) {
    return s = +s, n = n >>> 0, b || tr(c, s, n, 8), r.write(c, s, n, h, 52, 8), n + 8;
  }
  a.prototype.writeDoubleLE = function(s, n, h) {
    return sr(this, s, n, !0, h);
  }, a.prototype.writeDoubleBE = function(s, n, h) {
    return sr(this, s, n, !1, h);
  }, a.prototype.copy = function(s, n, h, b) {
    if (!a.isBuffer(s)) throw new TypeError("argument should be a Buffer");
    if (h || (h = 0), !b && b !== 0 && (b = this.length), n >= s.length && (n = s.length), n || (n = 0), b > 0 && b < h && (b = h), b === h || s.length === 0 || this.length === 0) return 0;
    if (n < 0)
      throw new RangeError("targetStart out of bounds");
    if (h < 0 || h >= this.length) throw new RangeError("Index out of range");
    if (b < 0) throw new RangeError("sourceEnd out of bounds");
    b > this.length && (b = this.length), s.length - n < b - h && (b = s.length - n + h);
    const C = b - h;
    return this === s && typeof Uint8Array.prototype.copyWithin == "function" ? this.copyWithin(n, h, b) : Uint8Array.prototype.set.call(
      s,
      this.subarray(h, b),
      n
    ), C;
  }, a.prototype.fill = function(s, n, h, b) {
    if (typeof s == "string") {
      if (typeof n == "string" ? (b = n, n = 0, h = this.length) : typeof h == "string" && (b = h, h = this.length), b !== void 0 && typeof b != "string")
        throw new TypeError("encoding must be a string");
      if (typeof b == "string" && !a.isEncoding(b))
        throw new TypeError("Unknown encoding: " + b);
      if (s.length === 1) {
        const B = s.charCodeAt(0);
        (b === "utf8" && B < 128 || b === "latin1") && (s = B);
      }
    } else typeof s == "number" ? s = s & 255 : typeof s == "boolean" && (s = Number(s));
    if (n < 0 || this.length < n || this.length < h)
      throw new RangeError("Out of range index");
    if (h <= n)
      return this;
    n = n >>> 0, h = h === void 0 ? this.length : h >>> 0, s || (s = 0);
    let C;
    if (typeof s == "number")
      for (C = n; C < h; ++C)
        this[C] = s;
    else {
      const B = a.isBuffer(s) ? s : a.from(s, b), D = B.length;
      if (D === 0)
        throw new TypeError('The value "' + s + '" is invalid for argument "value"');
      for (C = 0; C < h - n; ++C)
        this[C + n] = B[C % D];
    }
    return this;
  };
  const Se = {};
  function at(c, s, n) {
    Se[c] = class extends n {
      constructor() {
        super(), Object.defineProperty(this, "message", {
          value: s.apply(this, arguments),
          writable: !0,
          configurable: !0
        }), this.name = `${this.name} [${c}]`, this.stack, delete this.name;
      }
      get code() {
        return c;
      }
      set code(b) {
        Object.defineProperty(this, "code", {
          configurable: !0,
          enumerable: !0,
          value: b,
          writable: !0
        });
      }
      toString() {
        return `${this.name} [${c}]: ${this.message}`;
      }
    };
  }
  at(
    "ERR_BUFFER_OUT_OF_BOUNDS",
    function(c) {
      return c ? `${c} is outside of buffer bounds` : "Attempt to access memory outside buffer bounds";
    },
    RangeError
  ), at(
    "ERR_INVALID_ARG_TYPE",
    function(c, s) {
      return `The "${c}" argument must be of type number. Received type ${typeof s}`;
    },
    TypeError
  ), at(
    "ERR_OUT_OF_RANGE",
    function(c, s, n) {
      let h = `The value of "${c}" is out of range.`, b = n;
      return Number.isInteger(n) && Math.abs(n) > 2 ** 32 ? b = nr(String(n)) : typeof n == "bigint" && (b = String(n), (n > BigInt(2) ** BigInt(32) || n < -(BigInt(2) ** BigInt(32))) && (b = nr(b)), b += "n"), h += ` It must be ${s}. Received ${b}`, h;
    },
    RangeError
  );
  function nr(c) {
    let s = "", n = c.length;
    const h = c[0] === "-" ? 1 : 0;
    for (; n >= h + 4; n -= 3)
      s = `_${c.slice(n - 3, n)}${s}`;
    return `${c.slice(0, n)}${s}`;
  }
  function ys(c, s, n) {
    ke(s, "offset"), (c[s] === void 0 || c[s + n] === void 0) && Te(s, c.length - (n + 1));
  }
  function ir(c, s, n, h, b, C) {
    if (c > n || c < s) {
      const B = typeof s == "bigint" ? "n" : "";
      let D;
      throw s === 0 || s === BigInt(0) ? D = `>= 0${B} and < 2${B} ** ${(C + 1) * 8}${B}` : D = `>= -(2${B} ** ${(C + 1) * 8 - 1}${B}) and < 2 ** ${(C + 1) * 8 - 1}${B}`, new Se.ERR_OUT_OF_RANGE("value", D, c);
    }
    ys(h, b, C);
  }
  function ke(c, s) {
    if (typeof c != "number")
      throw new Se.ERR_INVALID_ARG_TYPE(s, "number", c);
  }
  function Te(c, s, n) {
    throw Math.floor(c) !== c ? (ke(c, n), new Se.ERR_OUT_OF_RANGE("offset", "an integer", c)) : s < 0 ? new Se.ERR_BUFFER_OUT_OF_BOUNDS() : new Se.ERR_OUT_OF_RANGE(
      "offset",
      `>= 0 and <= ${s}`,
      c
    );
  }
  const gs = /[^+/0-9A-Za-z-_]/g;
  function ms(c) {
    if (c = c.split("=")[0], c = c.trim().replace(gs, ""), c.length < 2) return "";
    for (; c.length % 4 !== 0; )
      c = c + "=";
    return c;
  }
  function ct(c, s) {
    s = s || 1 / 0;
    let n;
    const h = c.length;
    let b = null;
    const C = [];
    for (let B = 0; B < h; ++B) {
      if (n = c.charCodeAt(B), n > 55295 && n < 57344) {
        if (!b) {
          if (n > 56319) {
            (s -= 3) > -1 && C.push(239, 191, 189);
            continue;
          } else if (B + 1 === h) {
            (s -= 3) > -1 && C.push(239, 191, 189);
            continue;
          }
          b = n;
          continue;
        }
        if (n < 56320) {
          (s -= 3) > -1 && C.push(239, 191, 189), b = n;
          continue;
        }
        n = (b - 55296 << 10 | n - 56320) + 65536;
      } else b && (s -= 3) > -1 && C.push(239, 191, 189);
      if (b = null, n < 128) {
        if ((s -= 1) < 0) break;
        C.push(n);
      } else if (n < 2048) {
        if ((s -= 2) < 0) break;
        C.push(
          n >> 6 | 192,
          n & 63 | 128
        );
      } else if (n < 65536) {
        if ((s -= 3) < 0) break;
        C.push(
          n >> 12 | 224,
          n >> 6 & 63 | 128,
          n & 63 | 128
        );
      } else if (n < 1114112) {
        if ((s -= 4) < 0) break;
        C.push(
          n >> 18 | 240,
          n >> 12 & 63 | 128,
          n >> 6 & 63 | 128,
          n & 63 | 128
        );
      } else
        throw new Error("Invalid code point");
    }
    return C;
  }
  function bs(c) {
    const s = [];
    for (let n = 0; n < c.length; ++n)
      s.push(c.charCodeAt(n) & 255);
    return s;
  }
  function Ss(c, s) {
    let n, h, b;
    const C = [];
    for (let B = 0; B < c.length && !((s -= 2) < 0); ++B)
      n = c.charCodeAt(B), h = n >> 8, b = n % 256, C.push(b), C.push(h);
    return C;
  }
  function or(c) {
    return e.toByteArray(ms(c));
  }
  function Le(c, s, n, h) {
    let b;
    for (b = 0; b < h && !(b + n >= s.length || b >= c.length); ++b)
      s[b + n] = c[b];
    return b;
  }
  function oe(c, s) {
    return c instanceof s || c != null && c.constructor != null && c.constructor.name != null && c.constructor.name === s.name;
  }
  function ut(c) {
    return c !== c;
  }
  const ks = function() {
    const c = "0123456789abcdef", s = new Array(256);
    for (let n = 0; n < 16; ++n) {
      const h = n * 16;
      for (let b = 0; b < 16; ++b)
        s[h + b] = c[n] + c[b];
    }
    return s;
  }();
  function he(c) {
    return typeof BigInt > "u" ? ws : c;
  }
  function ws() {
    throw new Error("BigInt not supported");
  }
})(Vt);
var us = {}, vt = { exports: {} };
/*! safe-buffer. MIT License. Feross Aboukhadijeh <https://feross.org/opensource> */
(function(t, e) {
  var r = Vt, i = r.Buffer;
  function o(l, a) {
    for (var u in l)
      a[u] = l[u];
  }
  i.from && i.alloc && i.allocUnsafe && i.allocUnsafeSlow ? t.exports = r : (o(r, e), e.Buffer = f);
  function f(l, a, u) {
    return i(l, a, u);
  }
  f.prototype = Object.create(i.prototype), o(i, f), f.from = function(l, a, u) {
    if (typeof l == "number")
      throw new TypeError("Argument must not be a number");
    return i(l, a, u);
  }, f.alloc = function(l, a, u) {
    if (typeof l != "number")
      throw new TypeError("Argument must be a number");
    var y = i(l);
    return a !== void 0 ? typeof u == "string" ? y.fill(a, u) : y.fill(a) : y.fill(0), y;
  }, f.allocUnsafe = function(l) {
    if (typeof l != "number")
      throw new TypeError("Argument must be a number");
    return i(l);
  }, f.allocUnsafeSlow = function(l) {
    if (typeof l != "number")
      throw new TypeError("Argument must be a number");
    return r.SlowBuffer(l);
  };
})(vt, vt.exports);
var bl = vt.exports, Jt = bl.Buffer, Ir = Jt.isEncoding || function(t) {
  switch (t = "" + t, t && t.toLowerCase()) {
    case "hex":
    case "utf8":
    case "utf-8":
    case "ascii":
    case "binary":
    case "base64":
    case "ucs2":
    case "ucs-2":
    case "utf16le":
    case "utf-16le":
    case "raw":
      return !0;
    default:
      return !1;
  }
};
function Sl(t) {
  if (!t) return "utf8";
  for (var e; ; )
    switch (t) {
      case "utf8":
      case "utf-8":
        return "utf8";
      case "ucs2":
      case "ucs-2":
      case "utf16le":
      case "utf-16le":
        return "utf16le";
      case "latin1":
      case "binary":
        return "latin1";
      case "base64":
      case "ascii":
      case "hex":
        return t;
      default:
        if (e) return;
        t = ("" + t).toLowerCase(), e = !0;
    }
}
function kl(t) {
  var e = Sl(t);
  if (typeof e != "string" && (Jt.isEncoding === Ir || !Ir(t))) throw new Error("Unknown encoding: " + t);
  return e || t;
}
us.StringDecoder = De;
function De(t) {
  this.encoding = kl(t);
  var e;
  switch (this.encoding) {
    case "utf16le":
      this.text = vl, this.end = Al, e = 4;
      break;
    case "utf8":
      this.fillLast = Cl, e = 4;
      break;
    case "base64":
      this.text = Bl, this.end = Tl, e = 3;
      break;
    default:
      this.write = Rl, this.end = Ml;
      return;
  }
  this.lastNeed = 0, this.lastTotal = 0, this.lastChar = Jt.allocUnsafe(e);
}
De.prototype.write = function(t) {
  if (t.length === 0) return "";
  var e, r;
  if (this.lastNeed) {
    if (e = this.fillLast(t), e === void 0) return "";
    r = this.lastNeed, this.lastNeed = 0;
  } else
    r = 0;
  return r < t.length ? e ? e + this.text(t, r) : this.text(t, r) : e || "";
};
De.prototype.end = xl;
De.prototype.text = _l;
De.prototype.fillLast = function(t) {
  if (this.lastNeed <= t.length)
    return t.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, this.lastNeed), this.lastChar.toString(this.encoding, 0, this.lastTotal);
  t.copy(this.lastChar, this.lastTotal - this.lastNeed, 0, t.length), this.lastNeed -= t.length;
};
function bt(t) {
  return t <= 127 ? 0 : t >> 5 === 6 ? 2 : t >> 4 === 14 ? 3 : t >> 3 === 30 ? 4 : t >> 6 === 2 ? -1 : -2;
}
function wl(t, e, r) {
  var i = e.length - 1;
  if (i < r) return 0;
  var o = bt(e[i]);
  return o >= 0 ? (o > 0 && (t.lastNeed = o - 1), o) : --i < r || o === -2 ? 0 : (o = bt(e[i]), o >= 0 ? (o > 0 && (t.lastNeed = o - 2), o) : --i < r || o === -2 ? 0 : (o = bt(e[i]), o >= 0 ? (o > 0 && (o === 2 ? o = 0 : t.lastNeed = o - 3), o) : 0));
}
function El(t, e, r) {
  if ((e[0] & 192) !== 128)
    return t.lastNeed = 0, "�";
  if (t.lastNeed > 1 && e.length > 1) {
    if ((e[1] & 192) !== 128)
      return t.lastNeed = 1, "�";
    if (t.lastNeed > 2 && e.length > 2 && (e[2] & 192) !== 128)
      return t.lastNeed = 2, "�";
  }
}
function Cl(t) {
  var e = this.lastTotal - this.lastNeed, r = El(this, t);
  if (r !== void 0) return r;
  if (this.lastNeed <= t.length)
    return t.copy(this.lastChar, e, 0, this.lastNeed), this.lastChar.toString(this.encoding, 0, this.lastTotal);
  t.copy(this.lastChar, e, 0, t.length), this.lastNeed -= t.length;
}
function _l(t, e) {
  var r = wl(this, t, e);
  if (!this.lastNeed) return t.toString("utf8", e);
  this.lastTotal = r;
  var i = t.length - (r - this.lastNeed);
  return t.copy(this.lastChar, 0, i), t.toString("utf8", e, i);
}
function xl(t) {
  var e = t && t.length ? this.write(t) : "";
  return this.lastNeed ? e + "�" : e;
}
function vl(t, e) {
  if ((t.length - e) % 2 === 0) {
    var r = t.toString("utf16le", e);
    if (r) {
      var i = r.charCodeAt(r.length - 1);
      if (i >= 55296 && i <= 56319)
        return this.lastNeed = 2, this.lastTotal = 4, this.lastChar[0] = t[t.length - 2], this.lastChar[1] = t[t.length - 1], r.slice(0, -1);
    }
    return r;
  }
  return this.lastNeed = 1, this.lastTotal = 2, this.lastChar[0] = t[t.length - 1], t.toString("utf16le", e, t.length - 1);
}
function Al(t) {
  var e = t && t.length ? this.write(t) : "";
  if (this.lastNeed) {
    var r = this.lastTotal - this.lastNeed;
    return e + this.lastChar.toString("utf16le", 0, r);
  }
  return e;
}
function Bl(t, e) {
  var r = (t.length - e) % 3;
  return r === 0 ? t.toString("base64", e) : (this.lastNeed = 3 - r, this.lastTotal = 3, r === 1 ? this.lastChar[0] = t[t.length - 1] : (this.lastChar[0] = t[t.length - 2], this.lastChar[1] = t[t.length - 1]), t.toString("base64", e, t.length - r));
}
function Tl(t) {
  var e = t && t.length ? this.write(t) : "";
  return this.lastNeed ? e + this.lastChar.toString("base64", 0, 3 - this.lastNeed) : e;
}
function Rl(t) {
  return t.toString(this.encoding);
}
function Ml(t) {
  return t && t.length ? this.write(t) : "";
}
const Xt = Vt.Buffer, Ol = us.StringDecoder, St = new Ol(), ls = Ae, Il = ls.ReplyError, Fl = ls.ParserError;
var ie = Xt.allocUnsafe(32 * 1024), ee = 0, Je = null, Re = 0, kt = 0;
function Pl(t) {
  const e = t.buffer.length - 1;
  var r = t.offset, i = 0, o = 1;
  for (t.buffer[r] === 45 && (o = -1, r++); r < e; ) {
    const f = t.buffer[r++];
    if (f === 13)
      return t.offset = r + 1, o * i;
    i = i * 10 + (f - 48);
  }
}
function Nl(t) {
  const e = t.buffer.length - 1;
  var r = t.offset, i = 0, o = "";
  for (t.buffer[r] === 45 && (o += "-", r++); r < e; ) {
    var f = t.buffer[r++];
    if (f === 13)
      return t.offset = r + 1, i !== 0 && (o += i), o;
    i > 429496728 ? (o += i * 10 + (f - 48), i = 0) : f === 48 && i === 0 ? o += 0 : i = i * 10 + (f - 48);
  }
}
function fs(t) {
  const e = t.offset, r = t.buffer, i = r.length - 1;
  for (var o = e; o < i; )
    if (r[o++] === 13)
      return t.offset = o + 1, t.optionReturnBuffers === !0 ? t.buffer.slice(e, o - 1) : t.buffer.toString("utf8", e, o - 1);
}
function hs(t) {
  const e = t.buffer.length - 1;
  for (var r = t.offset, i = 0; r < e; ) {
    const o = t.buffer[r++];
    if (o === 13)
      return t.offset = r + 1, i;
    i = i * 10 + (o - 48);
  }
}
function Dl(t) {
  return t.optionStringNumbers === !0 ? Nl(t) : Pl(t);
}
function Ll(t) {
  const e = hs(t);
  if (e === void 0)
    return;
  if (e < 0)
    return null;
  const r = t.offset + e;
  if (r + 2 > t.buffer.length) {
    t.bigStrSize = r + 2, t.totalChunkSize = t.buffer.length, t.bufferCache.push(t.buffer);
    return;
  }
  const i = t.offset;
  return t.offset = r + 2, t.optionReturnBuffers === !0 ? t.buffer.slice(i, r) : t.buffer.toString("utf8", i, r);
}
function Ul(t) {
  var e = fs(t);
  if (e !== void 0)
    return t.optionReturnBuffers === !0 && (e = e.toString()), new Il(e);
}
function jl(t, e) {
  const r = new Fl(
    "Protocol error, got " + JSON.stringify(String.fromCharCode(e)) + " as reply type byte",
    JSON.stringify(t.buffer),
    t.offset
  );
  t.buffer = null, t.returnFatalError(r);
}
function Ql(t) {
  const e = hs(t);
  if (e === void 0)
    return;
  if (e < 0)
    return null;
  const r = new Array(e);
  return ds(t, r, 0);
}
function At(t, e, r) {
  t.arrayCache.push(e), t.arrayPos.push(r);
}
function Bt(t) {
  const e = t.arrayCache.pop();
  var r = t.arrayPos.pop();
  if (t.arrayCache.length) {
    const i = Bt(t);
    if (i === void 0) {
      At(t, e, r);
      return;
    }
    e[r++] = i;
  }
  return ds(t, e, r);
}
function ds(t, e, r) {
  const i = t.buffer.length;
  for (; r < e.length; ) {
    const o = t.offset;
    if (t.offset >= i) {
      At(t, e, r);
      return;
    }
    const f = ps(t, t.buffer[t.offset++]);
    if (f === void 0) {
      t.arrayCache.length || t.bufferCache.length || (t.offset = o), At(t, e, r);
      return;
    }
    e[r] = f, r++;
  }
  return e;
}
function ps(t, e) {
  switch (e) {
    case 36:
      return Ll(t);
    case 43:
      return fs(t);
    case 42:
      return Ql(t);
    case 58:
      return Dl(t);
    case 45:
      return Ul(t);
    default:
      return jl(t, e);
  }
}
function zl() {
  if (ie.length > 50 * 1024)
    if (Re === 1 || kt > Re * 2) {
      const t = Math.floor(ie.length / 10), e = t < ee ? ee : t;
      ee = 0, ie = ie.slice(e, ie.length);
    } else
      kt++, Re--;
  else
    clearInterval(Je), Re = 0, kt = 0, Je = null;
}
function Gl(t) {
  if (ie.length < t + ee) {
    const e = t > 78643200 ? 2 : 3;
    ee > 1024 * 1024 * 111 && (ee = 1024 * 1024 * 50), ie = Xt.allocUnsafe(t * e + ee), ee = 0, Re++, Je === null && (Je = setInterval(zl, 50));
  }
}
function ql(t) {
  const e = t.bufferCache, r = t.offset;
  var i = e.length, o = t.bigStrSize - t.totalChunkSize;
  if (t.offset = o, o <= 2) {
    if (i === 2)
      return e[0].toString("utf8", r, e[0].length + o - 2);
    i--, o = e[e.length - 2].length + o;
  }
  for (var f = St.write(e[0].slice(r)), l = 1; l < i - 1; l++)
    f += St.write(e[l]);
  return f += St.end(e[l].slice(0, o - 2)), f;
}
function Kl(t) {
  const e = t.bufferCache, r = t.offset, i = t.bigStrSize - r - 2;
  var o = e.length, f = t.bigStrSize - t.totalChunkSize;
  if (t.offset = f, f <= 2) {
    if (o === 2)
      return e[0].slice(r, e[0].length + f - 2);
    o--, f = e[e.length - 2].length + f;
  }
  Gl(i);
  const l = ee;
  e[0].copy(ie, l, r, e[0].length), ee += e[0].length - r;
  for (var a = 1; a < o - 1; a++)
    e[a].copy(ie, ee), ee += e[a].length;
  return e[a].copy(ie, ee, 0, f - 2), ee += f - 2, ie.slice(l, ee);
}
class Hl {
  /**
   * Javascript Redis Parser constructor
   * @param {{returnError: Function, returnReply: Function, returnFatalError?: Function, returnBuffers: boolean, stringNumbers: boolean }} options
   * @constructor
   */
  constructor(e) {
    if (!e)
      throw new TypeError("Options are mandatory.");
    if (typeof e.returnError != "function" || typeof e.returnReply != "function")
      throw new TypeError("The returnReply and returnError options have to be functions.");
    this.setReturnBuffers(!!e.returnBuffers), this.setStringNumbers(!!e.stringNumbers), this.returnError = e.returnError, this.returnFatalError = e.returnFatalError || e.returnError, this.returnReply = e.returnReply, this.reset();
  }
  /**
   * Reset the parser values to the initial state
   *
   * @returns {undefined}
   */
  reset() {
    this.offset = 0, this.buffer = null, this.bigStrSize = 0, this.totalChunkSize = 0, this.bufferCache = [], this.arrayCache = [], this.arrayPos = [];
  }
  /**
   * Set the returnBuffers option
   *
   * @param {boolean} returnBuffers
   * @returns {undefined}
   */
  setReturnBuffers(e) {
    if (typeof e != "boolean")
      throw new TypeError("The returnBuffers argument has to be a boolean");
    this.optionReturnBuffers = e;
  }
  /**
   * Set the stringNumbers option
   *
   * @param {boolean} stringNumbers
   * @returns {undefined}
   */
  setStringNumbers(e) {
    if (typeof e != "boolean")
      throw new TypeError("The stringNumbers argument has to be a boolean");
    this.optionStringNumbers = e;
  }
  /**
   * Parse the redis buffer
   * @param {Buffer} buffer
   * @returns {undefined}
   */
  execute(e) {
    if (this.buffer === null)
      this.buffer = e, this.offset = 0;
    else if (this.bigStrSize === 0) {
      const i = this.buffer.length, o = i - this.offset, f = Xt.allocUnsafe(o + e.length);
      if (this.buffer.copy(f, 0, this.offset, i), e.copy(f, o, 0, e.length), this.buffer = f, this.offset = 0, this.arrayCache.length) {
        const l = Bt(this);
        if (l === void 0)
          return;
        this.returnReply(l);
      }
    } else if (this.totalChunkSize + e.length >= this.bigStrSize) {
      this.bufferCache.push(e);
      var r = this.optionReturnBuffers ? Kl(this) : ql(this);
      if (this.bigStrSize = 0, this.bufferCache = [], this.buffer = e, this.arrayCache.length && (this.arrayCache[0][this.arrayPos[0]++] = r, r = Bt(this), r === void 0))
        return;
      this.returnReply(r);
    } else {
      this.bufferCache.push(e), this.totalChunkSize += e.length;
      return;
    }
    for (; this.offset < this.buffer.length; ) {
      const i = this.offset, o = this.buffer[this.offset++], f = ps(this, o);
      if (f === void 0) {
        this.arrayCache.length || this.bufferCache.length || (this.offset = i);
        return;
      }
      o === 45 ? this.returnError(f) : this.returnReply(f);
    }
    this.buffer = null;
  }
}
var Yl = Hl, Vl = Yl, Zt = {};
Object.defineProperty(Zt, "__esModule", { value: !0 });
class Wl {
  constructor() {
    this.set = {
      subscribe: {},
      psubscribe: {},
      ssubscribe: {}
    };
  }
  add(e, r) {
    this.set[wt(e)][r] = !0;
  }
  del(e, r) {
    delete this.set[wt(e)][r];
  }
  channels(e) {
    return Object.keys(this.set[wt(e)]);
  }
  isEmpty() {
    return this.channels("subscribe").length === 0 && this.channels("psubscribe").length === 0 && this.channels("ssubscribe").length === 0;
  }
}
Zt.default = Wl;
function wt(t) {
  return t === "unsubscribe" ? "subscribe" : t === "punsubscribe" ? "psubscribe" : t === "sunsubscribe" ? "ssubscribe" : t;
}
Object.defineProperty(Yt, "__esModule", { value: !0 });
const Fr = ue, Jl = Z, Xl = Vl, Zl = Zt, $l = (0, Jl.Debug)("dataHandler");
class ef {
  constructor(e, r) {
    this.redis = e;
    const i = new Xl({
      stringNumbers: r.stringNumbers,
      returnBuffers: !0,
      returnError: (o) => {
        this.returnError(o);
      },
      returnFatalError: (o) => {
        this.returnFatalError(o);
      },
      returnReply: (o) => {
        this.returnReply(o);
      }
    });
    e.stream.prependListener("data", (o) => {
      i.execute(o);
    }), e.stream.resume();
  }
  returnFatalError(e) {
    e.message += ". Please report this.", this.redis.recoverFromFatalError(e, e, { offlineQueue: !1 });
  }
  returnError(e) {
    const r = this.shiftCommand(e);
    if (r) {
      if (e.command = {
        name: r.command.name,
        args: r.command.args
      }, r.command.name == "ssubscribe" && e.message.includes("MOVED")) {
        this.redis.emit("moved");
        return;
      }
      this.redis.handleReconnection(e, r);
    }
  }
  returnReply(e) {
    if (this.handleMonitorReply(e) || this.handleSubscriberReply(e))
      return;
    const r = this.shiftCommand(e);
    r && (Fr.default.checkFlag("ENTER_SUBSCRIBER_MODE", r.command.name) ? (this.redis.condition.subscriber = new Zl.default(), this.redis.condition.subscriber.add(r.command.name, e[1].toString()), Pr(r.command, e[2]) || this.redis.commandQueue.unshift(r)) : Fr.default.checkFlag("EXIT_SUBSCRIBER_MODE", r.command.name) ? Nr(r.command, e[2]) || this.redis.commandQueue.unshift(r) : r.command.resolve(e));
  }
  handleSubscriberReply(e) {
    if (!this.redis.condition.subscriber)
      return !1;
    const r = Array.isArray(e) ? e[0].toString() : null;
    switch ($l('receive reply "%s" in subscriber mode', r), r) {
      case "message":
        this.redis.listeners("message").length > 0 && this.redis.emit("message", e[1].toString(), e[2] ? e[2].toString() : ""), this.redis.emit("messageBuffer", e[1], e[2]);
        break;
      case "pmessage": {
        const i = e[1].toString();
        this.redis.listeners("pmessage").length > 0 && this.redis.emit("pmessage", i, e[2].toString(), e[3].toString()), this.redis.emit("pmessageBuffer", i, e[2], e[3]);
        break;
      }
      case "smessage": {
        this.redis.listeners("smessage").length > 0 && this.redis.emit("smessage", e[1].toString(), e[2] ? e[2].toString() : ""), this.redis.emit("smessageBuffer", e[1], e[2]);
        break;
      }
      case "ssubscribe":
      case "subscribe":
      case "psubscribe": {
        const i = e[1].toString();
        this.redis.condition.subscriber.add(r, i);
        const o = this.shiftCommand(e);
        if (!o)
          return;
        Pr(o.command, e[2]) || this.redis.commandQueue.unshift(o);
        break;
      }
      case "sunsubscribe":
      case "unsubscribe":
      case "punsubscribe": {
        const i = e[1] ? e[1].toString() : null;
        i && this.redis.condition.subscriber.del(r, i);
        const o = e[2];
        Number(o) === 0 && (this.redis.condition.subscriber = !1);
        const f = this.shiftCommand(e);
        if (!f)
          return;
        Nr(f.command, o) || this.redis.commandQueue.unshift(f);
        break;
      }
      default: {
        const i = this.shiftCommand(e);
        if (!i)
          return;
        i.command.resolve(e);
      }
    }
    return !0;
  }
  handleMonitorReply(e) {
    if (this.redis.status !== "monitoring")
      return !1;
    const r = e.toString();
    if (r === "OK")
      return !1;
    const i = r.indexOf(" "), o = r.slice(0, i), f = r.indexOf('"'), l = r.slice(f + 1, -1).split('" "').map((u) => u.replace(/\\"/g, '"')), a = r.slice(i + 2, f - 2).split(" ");
    return this.redis.emit("monitor", o, l, a[1], a[0]), !0;
  }
  shiftCommand(e) {
    const r = this.redis.commandQueue.shift();
    if (!r) {
      const i = "Command queue state error. If you can reproduce this, please report it.", o = new Error(i + (e instanceof Error ? ` Last error: ${e.message}` : ` Last reply: ${e.toString()}`));
      return this.redis.emit("error", o), null;
    }
    return r;
  }
}
Yt.default = ef;
const pe = /* @__PURE__ */ new WeakMap();
function Pr(t, e) {
  let r = pe.has(t) ? pe.get(t) : t.args.length;
  return r -= 1, r <= 0 ? (t.resolve(e), pe.delete(t), !0) : (pe.set(t, r), !1);
}
function Nr(t, e) {
  let r = pe.has(t) ? pe.get(t) : t.args.length;
  return r === 0 ? Number(e) === 0 ? (pe.delete(t), t.resolve(e), !0) : !1 : (r -= 1, r <= 0 ? (t.resolve(e), !0) : (pe.set(t, r), !1));
}
(function(t) {
  Object.defineProperty(t, "__esModule", { value: !0 }), t.readyHandler = t.errorHandler = t.closeHandler = t.connectHandler = void 0;
  const e = Ae, r = ue, i = nt, o = Z, f = Yt, l = (0, o.Debug)("connection");
  function a(p) {
    return function() {
      var R;
      p.setStatus("connect"), p.resetCommandQueue();
      let _ = !1;
      const { connectionEpoch: A } = p;
      p.condition.auth && p.auth(p.condition.auth, function(S) {
        A === p.connectionEpoch && S && (S.message.indexOf("no password is set") !== -1 ? console.warn("[WARN] Redis server does not require a password, but a password was supplied.") : S.message.indexOf("without any password configured for the default user") !== -1 ? console.warn("[WARN] This Redis server's `default` user does not require a password, but a password was supplied") : S.message.indexOf("wrong number of arguments for 'auth' command") !== -1 ? console.warn(`[ERROR] The server returned "wrong number of arguments for 'auth' command". You are probably passing both username and password to Redis version 5 or below. You should only pass the 'password' option for Redis version 5 and under.`) : (_ = !0, p.recoverFromFatalError(S, S)));
      }), p.condition.select && p.select(p.condition.select).catch((S) => {
        p.silentEmit("error", S);
      }), new f.default(p, {
        stringNumbers: p.options.stringNumbers
      });
      const I = [];
      p.options.connectionName && (l("set the connection name [%s]", p.options.connectionName), I.push(p.client("setname", p.options.connectionName).catch(o.noop))), p.options.disableClientInfo || (l("set the client info"), I.push((0, o.getPackageMeta)().then((S) => p.client("SETINFO", "LIB-VER", S.version).catch(o.noop)).catch(o.noop)), I.push(p.client("SETINFO", "LIB-NAME", !((R = p.options) === null || R === void 0) && R.clientInfoTag ? `ioredis(${p.options.clientInfoTag})` : "ioredis").catch(o.noop))), Promise.all(I).catch(o.noop).finally(() => {
        p.options.enableReadyCheck || t.readyHandler(p)(), p.options.enableReadyCheck && p._readyCheck(function(S, T) {
          A === p.connectionEpoch && (S ? _ || p.recoverFromFatalError(new Error("Ready check failed: " + S.message), S) : p.connector.check(T) ? t.readyHandler(p)() : p.disconnect(!0));
        });
      });
    };
  }
  t.connectHandler = a;
  function u(p) {
    const R = new e.AbortError("Command aborted due to connection close");
    return R.command = {
      name: p.name,
      args: p.args
    }, R;
  }
  function y(p) {
    var R;
    let _ = 0;
    for (let A = 0; A < p.length; ) {
      const I = (R = p.peekAt(A)) === null || R === void 0 ? void 0 : R.command, S = I.pipelineIndex;
      if ((S === void 0 || S === 0) && (_ = 0), S !== void 0 && S !== _++) {
        p.remove(A, 1), I.reject(u(I));
        continue;
      }
      A++;
    }
  }
  function g(p) {
    var R;
    for (let _ = 0; _ < p.length; ) {
      const A = (R = p.peekAt(_)) === null || R === void 0 ? void 0 : R.command;
      if (A.name === "multi")
        break;
      if (A.name === "exec") {
        p.remove(_, 1), A.reject(u(A));
        break;
      }
      A.inTransaction ? (p.remove(_, 1), A.reject(u(A))) : _++;
    }
  }
  function k(p) {
    return function() {
      const _ = p.status;
      if (p.setStatus("close"), p.commandQueue.length && y(p.commandQueue), p.offlineQueue.length && g(p.offlineQueue), _ === "ready" && (p.prevCondition || (p.prevCondition = p.condition), p.commandQueue.length && (p.prevCommandQueue = p.commandQueue)), p.manuallyClosing)
        return p.manuallyClosing = !1, l("skip reconnecting since the connection is manually closed."), R();
      if (typeof p.options.retryStrategy != "function")
        return l("skip reconnecting because `retryStrategy` is not a function"), R();
      const A = p.options.retryStrategy(++p.retryAttempts);
      if (typeof A != "number")
        return l("skip reconnecting because `retryStrategy` doesn't return a number"), R();
      l("reconnect in %sms", A), p.setStatus("reconnecting", A), p.reconnectTimeout = setTimeout(function() {
        p.reconnectTimeout = null, p.connect().catch(o.noop);
      }, A);
      const { maxRetriesPerRequest: I } = p.options;
      typeof I == "number" && (I < 0 ? l("maxRetriesPerRequest is negative, ignoring...") : p.retryAttempts % (I + 1) === 0 && (l("reach maxRetriesPerRequest limitation, flushing command queue..."), p.flushQueue(new i.MaxRetriesPerRequestError(I))));
    };
    function R() {
      p.setStatus("end"), p.flushQueue(new Error(o.CONNECTION_CLOSED_ERROR_MSG));
    }
  }
  t.closeHandler = k;
  function w(p) {
    return function(R) {
      l("error: %s", R), p.silentEmit("error", R);
    };
  }
  t.errorHandler = w;
  function x(p) {
    return function() {
      if (p.setStatus("ready"), p.retryAttempts = 0, p.options.monitor) {
        p.call("monitor").then(() => p.setStatus("monitoring"), (A) => p.emit("error", A));
        const { sendCommand: _ } = p;
        p.sendCommand = function(A) {
          return r.default.checkFlag("VALID_IN_MONITOR_MODE", A.name) ? _.call(p, A) : (A.reject(new Error("Connection is in monitoring mode, can't process commands.")), A.promise);
        }, p.once("close", function() {
          delete p.sendCommand;
        });
        return;
      }
      const R = p.prevCondition ? p.prevCondition.select : p.condition.select;
      if (p.options.readOnly && (l("set the connection to readonly mode"), p.readonly().catch(o.noop)), p.prevCondition) {
        const _ = p.prevCondition;
        if (p.prevCondition = null, _.subscriber && p.options.autoResubscribe) {
          p.condition.select !== R && (l("connect to db [%d]", R), p.select(R));
          const A = _.subscriber.channels("subscribe");
          A.length && (l("subscribe %d channels", A.length), p.subscribe(A));
          const I = _.subscriber.channels("psubscribe");
          I.length && (l("psubscribe %d channels", I.length), p.psubscribe(I));
          const S = _.subscriber.channels("ssubscribe");
          if (S.length) {
            l("ssubscribe %s", S.length);
            for (const T of S)
              p.ssubscribe(T);
          }
        }
      }
      if (p.prevCommandQueue)
        if (p.options.autoResendUnfulfilledCommands)
          for (l("resend %d unfulfilled commands", p.prevCommandQueue.length); p.prevCommandQueue.length > 0; ) {
            const _ = p.prevCommandQueue.shift();
            _.select !== p.condition.select && _.command.name !== "select" && p.select(_.select), p.sendCommand(_.command, _.stream);
          }
        else
          p.prevCommandQueue = null;
      if (p.offlineQueue.length) {
        l("send %d commands in offline queue", p.offlineQueue.length);
        const _ = p.offlineQueue;
        for (p.resetOfflineQueue(); _.length > 0; ) {
          const A = _.shift();
          A.select !== p.condition.select && A.command.name !== "select" && p.select(A.select), p.sendCommand(A.command, A.stream);
        }
      }
      p.condition.select !== R && (l("connect to db [%d]", R), p.select(R));
    };
  }
  t.readyHandler = x;
})(as);
var ot = {};
Object.defineProperty(ot, "__esModule", { value: !0 });
ot.DEFAULT_REDIS_OPTIONS = void 0;
ot.DEFAULT_REDIS_OPTIONS = {
  // Connection
  port: 6379,
  host: "localhost",
  family: 0,
  connectTimeout: 1e4,
  disconnectTimeout: 2e3,
  retryStrategy: function(t) {
    return Math.min(t * 50, 2e3);
  },
  keepAlive: 0,
  noDelay: !0,
  connectionName: null,
  disableClientInfo: !1,
  clientInfoTag: void 0,
  // Sentinel
  sentinels: null,
  name: null,
  role: "master",
  sentinelRetryStrategy: function(t) {
    return Math.min(t * 10, 1e3);
  },
  sentinelReconnectStrategy: function() {
    return 6e4;
  },
  natMap: null,
  enableTLSForSentinelMode: !1,
  updateSentinels: !0,
  failoverDetector: !1,
  // Status
  username: null,
  password: null,
  db: 0,
  // Others
  enableOfflineQueue: !0,
  enableReadyCheck: !0,
  autoResubscribe: !0,
  autoResendUnfulfilledCommands: !0,
  lazyConnect: !1,
  keyPrefix: "",
  reconnectOnError: null,
  readOnly: !1,
  stringNumbers: !1,
  maxRetriesPerRequest: 20,
  maxLoadingRetryTime: 1e4,
  enableAutoPipelining: !1,
  autoPipeliningIgnoredCommands: [],
  sentinelMaxConnections: 10,
  blockingTimeoutGrace: 100
};
var Dr;
function ye() {
  if (Dr) return je;
  Dr = 1, Object.defineProperty(je, "__esModule", { value: !0 });
  const t = ve, e = Rt, r = fe, i = os(), o = ue, f = ol(), l = Kt(), a = as, u = ot, y = Ie, g = Fe, k = Z, w = tt, x = Pe, p = ce, R = zt, _ = (0, k.Debug)("redis");
  class A extends x.default {
    constructor(S, T, O) {
      if (super(), this.status = "wait", this.isCluster = !1, this.reconnectTimeout = null, this.connectionEpoch = 0, this.retryAttempts = 0, this.manuallyClosing = !1, this._autoPipelines = /* @__PURE__ */ new Map(), this._runningAutoPipelines = /* @__PURE__ */ new Set(), this.parseOptions(S, T, O), e.EventEmitter.call(this), this.resetCommandQueue(), this.resetOfflineQueue(), this.options.Connector)
        this.connector = new this.options.Connector(this.options);
      else if (this.options.sentinels) {
        const N = new l.default(this.options);
        N.emitter = this, this.connector = N;
      } else
        this.connector = new f.StandaloneConnector(this.options);
      this.options.scripts && Object.entries(this.options.scripts).forEach(([N, d]) => {
        this.defineCommand(N, d);
      }), this.options.lazyConnect ? this.setStatus("wait") : this.connect().catch(p.noop);
    }
    /**
     * Create a Redis instance.
     * This is the same as `new Redis()` but is included for compatibility with node-redis.
     */
    static createClient(...S) {
      return new A(...S);
    }
    get autoPipelineQueueSize() {
      let S = 0;
      for (const T of this._autoPipelines.values())
        S += T.length;
      return S;
    }
    /**
     * Create a connection to Redis.
     * This method will be invoked automatically when creating a new Redis instance
     * unless `lazyConnect: true` is passed.
     *
     * When calling this method manually, a Promise is returned, which will
     * be resolved when the connection status is ready. The promise can reject
     * if the connection fails, times out, or if Redis is already connecting/connected.
     */
    connect(S) {
      const T = new Promise((O, N) => {
        if (this.status === "connecting" || this.status === "connect" || this.status === "ready") {
          N(new Error("Redis is already connecting/connected"));
          return;
        }
        this.connectionEpoch += 1, this.setStatus("connecting");
        const { options: d } = this;
        this.condition = {
          select: d.db,
          auth: d.username ? [d.username, d.password] : d.password,
          subscriber: !1
        };
        const m = this;
        (0, r.default)(this.connector.connect(function(E, v) {
          m.silentEmit(E, v);
        }), function(E, v) {
          if (E) {
            m.flushQueue(E), m.silentEmit("error", E), N(E), m.setStatus("end");
            return;
          }
          let M = d.tls ? "secureConnect" : "connect";
          if ("sentinels" in d && d.sentinels && !d.enableTLSForSentinelMode && (M = "connect"), m.stream = v, d.noDelay && v.setNoDelay(!0), typeof d.keepAlive == "number" && (v.connecting ? v.once(M, () => {
            v.setKeepAlive(!0, d.keepAlive);
          }) : v.setKeepAlive(!0, d.keepAlive)), v.connecting) {
            if (v.once(M, a.connectHandler(m)), d.connectTimeout) {
              let P = !1;
              v.setTimeout(d.connectTimeout, function() {
                if (P)
                  return;
                v.setTimeout(0), v.destroy();
                const j = new Error("connect ETIMEDOUT");
                j.errorno = "ETIMEDOUT", j.code = "ETIMEDOUT", j.syscall = "connect", a.errorHandler(m)(j);
              }), v.once(M, function() {
                P = !0, v.setTimeout(0);
              });
            }
          } else if (v.destroyed) {
            const P = m.connector.firstError;
            P && process.nextTick(() => {
              a.errorHandler(m)(P);
            }), process.nextTick(a.closeHandler(m));
          } else
            process.nextTick(a.connectHandler(m));
          v.destroyed || (v.once("error", a.errorHandler(m)), v.once("close", a.closeHandler(m)));
          const L = function() {
            m.removeListener("close", F), O();
          };
          var F = function() {
            m.removeListener("ready", L), N(new Error(k.CONNECTION_CLOSED_ERROR_MSG));
          };
          m.once("ready", L), m.once("close", F);
        });
      });
      return (0, r.default)(T, S);
    }
    /**
     * Disconnect from Redis.
     *
     * This method closes the connection immediately,
     * and may lose some pending replies that haven't written to client.
     * If you want to wait for the pending replies, use Redis#quit instead.
     */
    disconnect(S = !1) {
      S || (this.manuallyClosing = !0), this.reconnectTimeout && !S && (clearTimeout(this.reconnectTimeout), this.reconnectTimeout = null), this.status === "wait" ? a.closeHandler(this)() : this.connector.disconnect();
    }
    /**
     * Disconnect from Redis.
     *
     * @deprecated
     */
    end() {
      this.disconnect();
    }
    /**
     * Create a new instance with the same options as the current one.
     *
     * @example
     * ```js
     * var redis = new Redis(6380);
     * var anotherRedis = redis.duplicate();
     * ```
     */
    duplicate(S) {
      return new A({ ...this.options, ...S });
    }
    /**
     * Mode of the connection.
     *
     * One of `"normal"`, `"subscriber"`, or `"monitor"`. When the connection is
     * not in `"normal"` mode, certain commands are not allowed.
     */
    get mode() {
      var S;
      return this.options.monitor ? "monitor" : !((S = this.condition) === null || S === void 0) && S.subscriber ? "subscriber" : "normal";
    }
    /**
     * Listen for all requests received by the server in real time.
     *
     * This command will create a new connection to Redis and send a
     * MONITOR command via the new connection in order to avoid disturbing
     * the current connection.
     *
     * @param callback The callback function. If omit, a promise will be returned.
     * @example
     * ```js
     * var redis = new Redis();
     * redis.monitor(function (err, monitor) {
     *   // Entering monitoring mode.
     *   monitor.on('monitor', function (time, args, source, database) {
     *     console.log(time + ": " + util.inspect(args));
     *   });
     * });
     *
     * // supports promise as well as other commands
     * redis.monitor().then(function (monitor) {
     *   monitor.on('monitor', function (time, args, source, database) {
     *     console.log(time + ": " + util.inspect(args));
     *   });
     * });
     * ```
     */
    monitor(S) {
      const T = this.duplicate({
        monitor: !0,
        lazyConnect: !1
      });
      return (0, r.default)(new Promise(function(O, N) {
        T.once("error", N), T.once("monitoring", function() {
          O(T);
        });
      }), S);
    }
    /**
     * Send a command to Redis
     *
     * This method is used internally and in most cases you should not
     * use it directly. If you need to send a command that is not supported
     * by the library, you can use the `call` method:
     *
     * ```js
     * const redis = new Redis();
     *
     * redis.call('set', 'foo', 'bar');
     * // or
     * redis.call(['set', 'foo', 'bar']);
     * ```
     *
     * @ignore
     */
    sendCommand(S, T) {
      var O, N;
      if (this.status === "wait" && this.connect().catch(p.noop), this.status === "end")
        return S.reject(new Error(k.CONNECTION_CLOSED_ERROR_MSG)), S.promise;
      if (!((O = this.condition) === null || O === void 0) && O.subscriber && !o.default.checkFlag("VALID_IN_SUBSCRIBER_MODE", S.name))
        return S.reject(new Error("Connection in subscriber mode, only subscriber commands may be used")), S.promise;
      typeof this.options.commandTimeout == "number" && S.setTimeout(this.options.commandTimeout);
      const d = this.getBlockingTimeoutInMs(S);
      let m = this.status === "ready" || !T && this.status === "connect" && (0, t.exists)(S.name, { caseInsensitive: !0 }) && ((0, t.hasFlag)(S.name, "loading", { nameCaseInsensitive: !0 }) || o.default.checkFlag("HANDSHAKE_COMMANDS", S.name));
      if (this.stream && this.stream.writable ? this.stream._writableState && this.stream._writableState.ended && (m = !1) : m = !1, m)
        _.enabled && _("write command[%s]: %d -> %s(%o)", this._getDescription(), (N = this.condition) === null || N === void 0 ? void 0 : N.select, S.name, S.args), T ? "isPipeline" in T && T.isPipeline ? T.write(S.toWritable(T.destination.redis.stream)) : T.write(S.toWritable(T)) : this.stream.write(S.toWritable(this.stream)), this.commandQueue.push({
          command: S,
          stream: T,
          select: this.condition.select
        }), d !== void 0 && S.setBlockingTimeout(d), o.default.checkFlag("WILL_DISCONNECT", S.name) && (this.manuallyClosing = !0), this.options.socketTimeout !== void 0 && this.socketTimeoutTimer === void 0 && this.setSocketTimeout();
      else {
        if (!this.options.enableOfflineQueue)
          return S.reject(new Error("Stream isn't writeable and enableOfflineQueue options is false")), S.promise;
        if (S.name === "quit" && this.offlineQueue.length === 0)
          return this.disconnect(), S.resolve(Buffer.from("OK")), S.promise;
        if (_.enabled && _("queue command[%s]: %d -> %s(%o)", this._getDescription(), this.condition.select, S.name, S.args), this.offlineQueue.push({
          command: S,
          stream: T,
          select: this.condition.select
        }), o.default.checkFlag("BLOCKING_COMMANDS", S.name)) {
          const E = this.getConfiguredBlockingTimeout();
          E !== void 0 && S.setBlockingTimeout(E);
        }
      }
      if (S.name === "select" && (0, k.isInt)(S.args[0])) {
        const E = parseInt(S.args[0], 10);
        this.condition.select !== E && (this.condition.select = E, this.emit("select", E), _("switch to db [%d]", this.condition.select));
      }
      return S.promise;
    }
    getBlockingTimeoutInMs(S) {
      var T;
      if (!o.default.checkFlag("BLOCKING_COMMANDS", S.name))
        return;
      const O = this.getConfiguredBlockingTimeout();
      if (O === void 0)
        return;
      const N = S.extractBlockingTimeout();
      if (typeof N == "number")
        return N > 0 ? N + ((T = this.options.blockingTimeoutGrace) !== null && T !== void 0 ? T : u.DEFAULT_REDIS_OPTIONS.blockingTimeoutGrace) : O;
      if (N === null)
        return O;
    }
    getConfiguredBlockingTimeout() {
      if (typeof this.options.blockingTimeout == "number" && this.options.blockingTimeout > 0)
        return this.options.blockingTimeout;
    }
    setSocketTimeout() {
      this.socketTimeoutTimer = setTimeout(() => {
        this.stream.destroy(new Error(`Socket timeout. Expecting data, but didn't receive any in ${this.options.socketTimeout}ms.`)), this.socketTimeoutTimer = void 0;
      }, this.options.socketTimeout), this.stream.once("data", () => {
        clearTimeout(this.socketTimeoutTimer), this.socketTimeoutTimer = void 0, this.commandQueue.length !== 0 && this.setSocketTimeout();
      });
    }
    scanStream(S) {
      return this.createScanStream("scan", { options: S });
    }
    scanBufferStream(S) {
      return this.createScanStream("scanBuffer", { options: S });
    }
    sscanStream(S, T) {
      return this.createScanStream("sscan", { key: S, options: T });
    }
    sscanBufferStream(S, T) {
      return this.createScanStream("sscanBuffer", { key: S, options: T });
    }
    hscanStream(S, T) {
      return this.createScanStream("hscan", { key: S, options: T });
    }
    hscanBufferStream(S, T) {
      return this.createScanStream("hscanBuffer", { key: S, options: T });
    }
    zscanStream(S, T) {
      return this.createScanStream("zscan", { key: S, options: T });
    }
    zscanBufferStream(S, T) {
      return this.createScanStream("zscanBuffer", { key: S, options: T });
    }
    /**
     * Emit only when there's at least one listener.
     *
     * @ignore
     */
    silentEmit(S, T) {
      let O;
      if (!(S === "error" && (O = T, this.status === "end" || this.manuallyClosing && O instanceof Error && (O.message === k.CONNECTION_CLOSED_ERROR_MSG || // @ts-expect-error
      O.syscall === "connect" || // @ts-expect-error
      O.syscall === "read"))))
        return this.listeners(S).length > 0 ? this.emit.apply(this, arguments) : (O && O instanceof Error && console.error("[ioredis] Unhandled error event:", O.stack), !1);
    }
    /**
     * @ignore
     */
    recoverFromFatalError(S, T, O) {
      this.flushQueue(T, O), this.silentEmit("error", T), this.disconnect(!0);
    }
    /**
     * @ignore
     */
    handleReconnection(S, T) {
      var O;
      let N = !1;
      switch (this.options.reconnectOnError && !o.default.checkFlag("IGNORE_RECONNECT_ON_ERROR", T.command.name) && (N = this.options.reconnectOnError(S)), N) {
        case 1:
        case !0:
          this.status !== "reconnecting" && this.disconnect(!0), T.command.reject(S);
          break;
        case 2:
          this.status !== "reconnecting" && this.disconnect(!0), ((O = this.condition) === null || O === void 0 ? void 0 : O.select) !== T.select && T.command.name !== "select" && this.select(T.select), this.sendCommand(T.command);
          break;
        default:
          T.command.reject(S);
      }
    }
    /**
     * Get description of the connection. Used for debugging.
     */
    _getDescription() {
      let S;
      return "path" in this.options && this.options.path ? S = this.options.path : this.stream && this.stream.remoteAddress && this.stream.remotePort ? S = this.stream.remoteAddress + ":" + this.stream.remotePort : "host" in this.options && this.options.host ? S = this.options.host + ":" + this.options.port : S = "", this.options.connectionName && (S += ` (${this.options.connectionName})`), S;
    }
    resetCommandQueue() {
      this.commandQueue = new R();
    }
    resetOfflineQueue() {
      this.offlineQueue = new R();
    }
    parseOptions(...S) {
      const T = {};
      let O = !1;
      for (let N = 0; N < S.length; ++N) {
        const d = S[N];
        if (!(d === null || typeof d > "u"))
          if (typeof d == "object")
            (0, p.defaults)(T, d);
          else if (typeof d == "string")
            (0, p.defaults)(T, (0, k.parseURL)(d)), d.startsWith("rediss://") && (O = !0);
          else if (typeof d == "number")
            T.port = d;
          else
            throw new Error("Invalid argument " + d);
      }
      O && (0, p.defaults)(T, { tls: !0 }), (0, p.defaults)(T, A.defaultOptions), typeof T.port == "string" && (T.port = parseInt(T.port, 10)), typeof T.db == "string" && (T.db = parseInt(T.db, 10)), this.options = (0, k.resolveTLSProfile)(T);
    }
    /**
     * Change instance's status
     */
    setStatus(S, T) {
      _.enabled && _("status[%s]: %s -> %s", this._getDescription(), this.status || "[empty]", S), this.status = S, process.nextTick(this.emit.bind(this, S, T));
    }
    createScanStream(S, { key: T, options: O = {} }) {
      return new y.default({
        objectMode: !0,
        key: T,
        redis: this,
        command: S,
        ...O
      });
    }
    /**
     * Flush offline queue and command queue with error.
     *
     * @param error The error object to send to the commands
     * @param options options
     */
    flushQueue(S, T) {
      T = (0, p.defaults)({}, T, {
        offlineQueue: !0,
        commandQueue: !0
      });
      let O;
      if (T.offlineQueue)
        for (; O = this.offlineQueue.shift(); )
          O.command.reject(S);
      if (T.commandQueue && this.commandQueue.length > 0)
        for (this.stream && this.stream.removeAllListeners("data"); O = this.commandQueue.shift(); )
          O.command.reject(S);
    }
    /**
     * Check whether Redis has finished loading the persistent data and is able to
     * process commands.
     */
    _readyCheck(S) {
      const T = this;
      this.info(function(O, N) {
        if (O)
          return O.message && O.message.includes("NOPERM") ? (console.warn(`Skipping the ready check because INFO command fails: "${O.message}". You can disable ready check with "enableReadyCheck". More: https://github.com/luin/ioredis/wiki/Disable-ready-check.`), S(null, {})) : S(O);
        if (typeof N != "string")
          return S(null, N);
        const d = {}, m = N.split(`\r
`);
        for (let E = 0; E < m.length; ++E) {
          const [v, ...M] = m[E].split(":"), L = M.join(":");
          L && (d[v] = L);
        }
        if (!d.loading || d.loading === "0")
          S(null, d);
        else {
          const E = (d.loading_eta_seconds || 1) * 1e3, v = T.options.maxLoadingRetryTime && T.options.maxLoadingRetryTime < E ? T.options.maxLoadingRetryTime : E;
          _("Redis server still loading, trying again in " + v + "ms"), setTimeout(function() {
            T._readyCheck(S);
          }, v);
        }
      }).catch(p.noop);
    }
  }
  return A.Cluster = i.default, A.Command = o.default, A.defaultOptions = u.DEFAULT_REDIS_OPTIONS, (0, w.default)(A, e.EventEmitter), (0, g.addTransactionSupport)(A.prototype), je.default = A, je;
}
(function(t, e) {
  Object.defineProperty(e, "__esModule", { value: !0 }), e.print = e.ReplyError = e.SentinelIterator = e.SentinelConnector = e.AbstractConnector = e.Pipeline = e.ScanStream = e.Command = e.Cluster = e.Redis = e.default = void 0, e = t.exports = ye().default;
  var r = ye();
  Object.defineProperty(e, "default", { enumerable: !0, get: function() {
    return r.default;
  } });
  var i = ye();
  Object.defineProperty(e, "Redis", { enumerable: !0, get: function() {
    return i.default;
  } });
  var o = os();
  Object.defineProperty(e, "Cluster", { enumerable: !0, get: function() {
    return o.default;
  } });
  var f = ue;
  Object.defineProperty(e, "Command", { enumerable: !0, get: function() {
    return f.default;
  } });
  var l = Ie;
  Object.defineProperty(e, "ScanStream", { enumerable: !0, get: function() {
    return l.default;
  } });
  var a = et;
  Object.defineProperty(e, "Pipeline", { enumerable: !0, get: function() {
    return a.default;
  } });
  var u = Ne;
  Object.defineProperty(e, "AbstractConnector", { enumerable: !0, get: function() {
    return u.default;
  } });
  var y = Kt();
  Object.defineProperty(e, "SentinelConnector", { enumerable: !0, get: function() {
    return y.default;
  } }), Object.defineProperty(e, "SentinelIterator", { enumerable: !0, get: function() {
    return y.SentinelIterator;
  } }), e.ReplyError = Ae.ReplyError, Object.defineProperty(e, "Promise", {
    get() {
      return console.warn("ioredis v5 does not support plugging third-party Promise library anymore. Native Promise will be used."), Promise;
    },
    set(k) {
      console.warn("ioredis v5 does not support plugging third-party Promise library anymore. Native Promise will be used.");
    }
  });
  function g(k, w) {
    console.log(k ? "Error: " + k : "Reply: " + w);
  }
  e.print = g;
})(Et, Et.exports);
var tf = Et.exports;
const rf = /* @__PURE__ */ _s(tf);
class Me {
  // 24 hours
  static getClient() {
    if (!this.redis) {
      const e = process.env.REDIS_URL || "redis://localhost:6379";
      this.redis = new rf(e, {
        retryStrategy: (r) => r > 3 ? (console.error("[Cache] Redis connection failed after 3 retries"), null) : Math.min(r * 100, 3e3),
        maxRetriesPerRequest: 3
      }), this.redis.on("connect", () => {
        console.log("[Cache] ✅ Redis connected");
      }), this.redis.on("error", (r) => {
        console.error("[Cache] ❌ Redis error:", r);
      });
    }
    return this.redis;
  }
  /**
   * Generic get with automatic JSON parsing
   */
  static async get(e) {
    try {
      const i = await this.getClient().get(e);
      return i ? JSON.parse(i) : null;
    } catch (r) {
      return console.error(`[Cache] Error getting key ${e}:`, r), null;
    }
  }
  /**
   * Generic set with automatic JSON stringification
   */
  static async set(e, r, i = this.DEFAULT_TTL) {
    try {
      await this.getClient().setex(e, i, JSON.stringify(r));
    } catch (o) {
      console.error(`[Cache] Error setting key ${e}:`, o);
    }
  }
  /**
   * Delete key(s)
   */
  static async del(...e) {
    try {
      const r = this.getClient();
      e.length > 0 && await r.del(...e);
    } catch (r) {
      console.error("[Cache] Error deleting keys:", r);
    }
  }
  /**
   * Pattern-based deletion (e.g., "crystal:*")
   */
  static async delPattern(e) {
    try {
      const r = this.getClient(), i = await r.keys(e);
      return i.length === 0 ? 0 : (await r.del(...i), i.length);
    } catch (r) {
      return console.error(`[Cache] Error deleting pattern ${e}:`, r), 0;
    }
  }
  // ═══════════════════════════════════════════════════════════════
  // CRYSTAL CACHING
  // ═══════════════════════════════════════════════════════════════
  static async getCrystal(e) {
    return this.get(`crystal:${e}`);
  }
  static async setCrystal(e, r) {
    await this.set(`crystal:${e}`, r, this.LONG_TTL);
  }
  static async invalidateCrystal(e) {
    await this.del(`crystal:${e}`);
  }
  // ═══════════════════════════════════════════════════════════════
  // LLM RESPONSE CACHING
  // ═══════════════════════════════════════════════════════════════
  static async getLLMResponse(e, r) {
    const i = this.hashPrompt(e, r);
    return this.get(`llm:${i}`);
  }
  static async setLLMResponse(e, r, i) {
    const o = this.hashPrompt(e, r);
    await this.set(`llm:${o}`, i, this.LONG_TTL);
  }
  static hashPrompt(e, r) {
    return He.createHash("sha256").update(`${r}:${e}`).digest("hex").substring(0, 16);
  }
  // ═══════════════════════════════════════════════════════════════
  // SEARCH RESULT CACHING
  // ═══════════════════════════════════════════════════════════════
  static async getSearchResults(e, r) {
    const i = He.createHash("sha256").update(JSON.stringify({ query: e, filters: r })).digest("hex").substring(0, 16);
    return this.get(`search:${i}`);
  }
  static async setSearchResults(e, r, i) {
    const o = He.createHash("sha256").update(JSON.stringify({ query: e, filters: r })).digest("hex").substring(0, 16);
    await this.set(`search:${o}`, i, this.DEFAULT_TTL);
  }
  // ═══════════════════════════════════════════════════════════════
  // STATS & MONITORING
  // ═══════════════════════════════════════════════════════════════
  static async getStats() {
    try {
      const e = this.getClient(), r = await e.info("stats"), i = await e.dbsize(), o = r.match(/used_memory_human:([^\r\n]+)/), f = o ? o[1] : "unknown", l = r.match(/keyspace_hits:(\d+)/), a = r.match(/keyspace_misses:(\d+)/);
      let u;
      if (l && a) {
        const y = parseInt(l[1]), g = parseInt(a[1]);
        y + g > 0 && (u = y / (y + g));
      }
      return {
        keys: i,
        memory_used: f,
        hit_rate: u
      };
    } catch (e) {
      return console.error("[Cache] Error getting stats:", e), { keys: 0, memory_used: "error" };
    }
  }
  /**
   * Increment counter (for rate limiting, analytics)
   */
  static async incr(e, r) {
    try {
      const i = this.getClient(), o = await i.incr(e);
      return r && o === 1 && await i.expire(e, r), o;
    } catch (i) {
      return console.error(`[Cache] Error incrementing key ${e}:`, i), 0;
    }
  }
  /**
   * Graceful shutdown
   */
  static async disconnect() {
    this.redis && (await this.redis.quit(), this.redis = null);
  }
}
Ue(Me, "redis", null), Ue(Me, "DEFAULT_TTL", 3600), // 1 hour
Ue(Me, "LONG_TTL", 86400);
process.on("SIGTERM", async () => {
  await Me.disconnect();
});
process.on("SIGINT", async () => {
  await Me.disconnect();
});
export {
  Me as CacheManager
};
//# sourceMappingURL=cache-BXUlwCn5.js.map
