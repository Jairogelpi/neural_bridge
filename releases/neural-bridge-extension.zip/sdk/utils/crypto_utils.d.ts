/**
 * Universal Crypto Utilities
 * Uses Web Crypto API for browser compatibility.
 */
export declare const cryptoUtils: {
    /**
     * Generate a SHA-256 hash (hex string)
     */
    sha256(data: string): Promise<string>;
    /**
     * Generate secure random bytes as hex string
     */
    randomHex(length: number): string;
    /**
     * Generate HMAC-SHA256 signature
     */
    hmacSha256(key: string, data: string): Promise<string>;
};
