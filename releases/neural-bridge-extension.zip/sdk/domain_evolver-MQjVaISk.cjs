"use strict";var m=Object.defineProperty;var v=(o,e,n)=>e in o?m(o,e,{enumerable:!0,configurable:!0,writable:!0,value:n}):o[e]=n;var l=(o,e,n)=>v(o,typeof e!="symbol"?e+"":e,n);Object.defineProperty(exports,Symbol.toStringTag,{value:"Module"});const s=require("./index-BTB1CzpV.cjs");class d{static async evolveDomain(e){var r;console.log("[DomainEvolver] 🧠 Analyzing context for evolutionary potential...");const n=`
        ACT AS AN ONTOLOGICAL ARCHITECT.
        The following text does not fit any standard knowledge domain.
        
        TEXT: "${e.substring(0,500)}"
        
        TASK:
        1. Synthesize a UNIQUE domain name for this knowledge.
        2. Extract 3 fundamental AXIOMS (rules) that govern this specific "random" reality.
        3. Assign an Evolution Confidence score (0.0 to 1.0).
        
        Return JSON:
        {
            "domain": "...",
            "axioms": ["...", "...", "..."],
            "confidence": 0.0
        }
        `;let c;try{c=await s.SCPService.resilientCallLLM(n,s.CONFIG.model_stack.free,"You are a master of spontaneous ontology.")}catch(i){if((i&&typeof i=="object"&&"message"in i&&typeof i.message=="string"?i.message:"")==="SOVEREIGN_REQUIRED")return{domain:"sovereign_evolution",axioms:["Logic is the only anchor","Structure survives chaos"],confidence:1,discovered_at:new Date().toISOString()};throw i}let a;try{a=JSON.parse(((r=c.content.match(/\{[\s\S]*\}/))==null?void 0:r[0])||"{}")}catch{a={domain:"stochastic_anomaly",axioms:[],confidence:.1}}const t={domain:a.domain||"unknown_evolution",axioms:a.axioms||[],confidence:Number(a.confidence)||0,discovered_at:new Date().toISOString()};return t.confidence>.7&&(this.evolvedCache.set(t.domain,t),await s.Sentinel.emit({type:"CHAOS_EVOLUTION",severity:"info",message:`New Domain Evolved: ${t.domain.toUpperCase()}`,details:t})),t}}l(d,"evolvedCache",new Map);exports.DomainEvolver=d;
//# sourceMappingURL=domain_evolver-MQjVaISk.cjs.map
