export interface DecisionReceipt {
    receipt_id: string;
    timestamp: string;
    crystal_refs: {
        crystal_id: string;
        version: string;
        hash: string;
    }[];
    question: string;
    answer: string;
    verification: {
        invariants_used: string[];
        invariants_passed: string[];
        invariants_failed: string[];
        counterfactuals_passed: string[];
        counterfactuals_failed: string[];
        sri: number;
        pac_epsilon: number;
        fidelity_badge: string;
    };
    model_config: {
        provider: string;
        model: string;
        temperature: number;
        max_tokens: number;
        top_p?: number;
    };
    signature: {
        alg: string;
        payload_hash: string;
        signature: string;
        public_key: string;
        timestamp: string;
    };
    requester: string;
    author?: {
        id: string;
        tier: 'community' | 'verified' | 'certified' | 'trusted';
        reputation: number;
    } | undefined;
    reputation_impact?: number;
    audit?: {
        requester: string;
        approver?: string;
        approved_at?: string;
        notes?: string;
    };
    /** Optional: Flag for high-performance turbo mode */
    turbo_mode?: boolean;
}
export declare class DecisionReceipts {
    /**
     * Generate a cryptographically signed receipt of a decision.
     * This is the "Invoice of Truth".
     */
    static generateDecisionReceipt(params: {
        crystal_refs: {
            crystal_id: string;
            version: string;
            hash: string;
        }[];
        question: string;
        answer: string;
        verification_result: {
            invariants_used: string[];
            invariants_passed: string[];
            invariants_failed: string[];
            counterfactuals_passed: string[];
            counterfactuals_failed: string[];
            sri: number;
            pac_epsilon: number;
            fidelity_badge: string;
        };
        model_config: {
            provider: string;
            model: string;
            temperature: number;
            max_tokens: number;
            top_p?: number;
        };
        requester: string;
        author?: {
            id: string;
            tier: 'community' | 'verified' | 'certified' | 'trusted';
            reputation: number;
        } | undefined;
        reputation_impact?: number;
        sign?: boolean;
    }): Promise<DecisionReceipt>;
    /**
     * Verify a decision receipt's cryptographic integrity.
     */
    static verifyReceipt(receipt: DecisionReceipt): Promise<boolean>;
}
