/**
 * Cloud Bridge Service
 * Connects the SDK to the Neural Bridge SaaS API.
 * Enables: Remote Verification, Shared Crystals, Reputation, and heavy-duty Compilation.
 */
import type { Crystal } from "../types/crystal_format";
import type { DecisionReceipt } from "./decision_receipts";
export interface CloudConfig {
    apiKey: string;
    baseUrl?: string;
}
export declare class CloudBridge {
    private baseUrl;
    private apiKey;
    constructor(config: CloudConfig);
    private request;
    /**
     * Offload compilation to the cloud.
     * Useful for weak client devices or when using enterprise PDF parsing pipelines.
     */
    compile(content: string, domain?: string): Promise<Crystal>;
    /**
     * Remote Verification.
     * No local LLM required. Zero-knowledge proof returned.
     */
    verify(params: {
        crystal: Crystal;
        question: string;
        answer: string;
    }): Promise<{
        passed: boolean;
        sri: number;
        receipt: DecisionReceipt;
    }>;
    /**
     * Register a new Knowledge Author identity.
     */
    registerAuthor(name: string, handle: string, publicKey: string): Promise<unknown>;
    /**
     * Send telemetry for reputation tracking.
     */
    reportResult(receipt: DecisionReceipt): Promise<unknown>;
}
