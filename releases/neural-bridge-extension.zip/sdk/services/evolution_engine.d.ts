import { Crystal } from '../types/crystal_format';
/**
 * THE EVOLUTION ENGINE 🧬
 *
 * Component: Antifragile Optimization Layer
 * Function: When a prompt fails to yield a high-reliability Crystal, this engine
 *           wakes up, analyzes the failure, and "Genetically Mutates" the prompt
 *           to evolve a better strategy.
 *
 * UPGRADE (Phase 10): Now manages BIOLOGICAL EVOLUTION of Crystals.
 * - Breeding (Sexual Reproduction of Knowledge)
 * - Mutation (Random Variation)
 * - Natural Selection (Reaping Weak Ideas)
 */
export declare class EvolutionEngine {
    /**
     * BREEDING (Sexual Reproduction) 🌹
     * Combines two high-performing crystals to create a superior offspring.
     * Strategy:
     * - Intent: Synthesis of both.
     * - Constraints: Crossover (Random mix from both).
     * - Evidence: Union of non-duplicate evidence.
     */
    static breed(parentA: Crystal, parentB: Crystal): Crystal;
    /**
     * NATURAL SELECTION (The Reaper) 💀
     * Identifies weak crystals that should be culled from the population.
     * Criteria: High Usage but Low Q-Score (Proven to be bad).
     */
    static reap(population: Crystal[]): string[];
    private static crossoverConstraints;
    /**
     * Evolve a better prompt strategy based on failure context.
     * @param intent The original user intent
     * @param currentPrompt The prompt that failed (or performed poorly)
     * @param reliabilityScore The low score that triggered evolution
     * @returns The mutated, optimized prompt (or null if evolution failed)
     */
    static evolve(intent: string, currentPrompt: string, reliabilityScore: number): Promise<string | null>;
}
