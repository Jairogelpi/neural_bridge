export interface CrystalSignature {
    signature: string;
    public_key: string;
    timestamp: string;
    capturer_id: string;
    payload_hash: string;
}
export interface AttestationRecord {
    crystal_id: string;
    signature: CrystalSignature;
    verification_attestation?: {
        environment: 'browser' | 'tee_sgx' | 'tee_sev' | 'reproducible_build';
        execution_hash?: string;
        signed_logs?: string[];
    };
    audit_trail: AuditEntry[];
}
export interface AuditEntry {
    timestamp: string;
    action: 'capture' | 'transfer' | 'verify' | 'reject';
    actor: string;
    details: unknown;
    signature?: string;
}
import type { Crystal } from '../types/crystal_format';
/**
 * Sign a Crystal using REAL Web Crypto API (ECDSA P-256)
 */
export declare function signCrystal(params: {
    crystal: Crystal;
    keyPair?: {
        privateKey: CryptoKey;
        publicKey: CryptoKey;
    };
    capturer_id: string;
}): Promise<CrystalSignature>;
/**
 * Verify Crystal signature using REAL crypto
 */
export declare function verifyCrystalSignature(params: {
    crystal: Crystal;
    signature: CrystalSignature;
}): Promise<{
    valid: boolean;
    reason?: string;
}>;
/**
 * Create audit trail entry
 */
export declare function createAuditEntry(params: {
    action: 'capture' | 'transfer' | 'verify' | 'reject';
    actor: string;
    details: unknown;
}): AuditEntry;
declare function realSHA256(data: string): Promise<string>;
declare function generateKeyPair(): Promise<CryptoKeyPair>;
export declare function signData(message: string, privateKey: CryptoKey): Promise<string>;
export declare function verifySignature(message: string, signatureHex: string, publicKey: CryptoKey): Promise<boolean>;
export declare function exportPublicKey(publicKey: CryptoKey): Promise<string>;
export declare function importPublicKey(publicKeyHex: string): Promise<CryptoKey>;
export declare const Attestation: {
    signCrystal: typeof signCrystal;
    verifyCrystalSignature: typeof verifyCrystalSignature;
    createAuditEntry: typeof createAuditEntry;
    generateKeyPair: typeof generateKeyPair;
    realSHA256: typeof realSHA256;
    signData: typeof signData;
    verifySignature: typeof verifySignature;
    exportPublicKey: typeof exportPublicKey;
    importPublicKey: typeof importPublicKey;
};
export {};
