import type { Crystal } from '../types/crystal_format';
export type KnowledgeDomain = string;
export interface DomainScore {
    domain: KnowledgeDomain;
    confidence: number;
}
export declare const DomainHeuristics: {
    /**
     * Analyze text to detect the knowledge domain
     */
    detect(text: string): DomainScore;
    /**
     * EXTENDED HARMONY: Verify domain using LLM if confidence is low
     */
    verifyDomainWithLLM(text: string, currentDomain: KnowledgeDomain): Promise<KnowledgeDomain>;
    /**
     * TURBO OPTIMIZATION: Quick Safety Check (Deterministic, Zero LLM Cost)
     * Detects obvious constraint violations without calling LLM
     * Returns immediately if a clear violation is found
     */
    quickSafetyCheck(crystal: Crystal, answer: string): {
        obviousViolation: boolean;
        reason: string;
        violatedConstraint?: string;
        confidence: number;
    };
    /**
     * SILENT GUARDIAN: Detect if a text block contains a "Source of Truth"
     * (Rules, constraints, protocols that should be protected)
     */
    detectSourceOfTruth(text: string): {
        isSOT: boolean;
        confidence: number;
        type: string;
    };
};
