/**
 * OPENWEBUI BRIDGE (The External Injector) 🌉🔌
 *
 * Capability: Prompt Augmentation.
 * Injects sovereign knowledge into external LLM interfaces
 * (OpenWebUI, ChatGPT, etc.) via prompt grounding.
 */
export declare class OpenWebUIBridge {
    /**
     * PREPARE INJECTION: Calculates the context to be injected into an external prompt.
     */
    static prepareInjection(userQuery: string, crystalIds: string[]): Promise<string>;
    /**
     * TRIGGER UI INJECTION: Conceptually send message to content script to type into chatbox.
     */
    static triggerUIInjection(tabId: number, payload: string): Promise<void>;
}
