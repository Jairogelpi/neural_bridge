import { Crystal } from '../types/crystal_format';
/**
 * EDGE DISTILLATOR (The Zero-Cost Arbiter) 🔬💎
 *
 * Capability: Absolute Potency at Zero Marginal Cost.
 *
 * This service performs high-integrity semantic audits using pure
 * Hyperdimensional Computing (HDC). It is 100% local, 100% free,
 * and operates at the speed of memory.
 */
export declare class EdgeDistillator {
    /**
     * VERIFY INVARIANT (HDC Logic Gate)
     * Checks if an 'answer' satisfies a semantic invariant without LLM calls.
     */
    static verifyInvariantHDC(answer: string, invariant: {
        prompt: string;
        expected: {
            type: string;
            value: any;
        };
    }): {
        passed: boolean;
        resonance: number;
    };
    /**
     * DETECT CONTRADICTION (HDC Collision Check)
     * Checks if current text contradicts a verified Truth node.
     */
    static checkContradictionHDC(textA: string, textB: string): {
        contradictory: boolean;
        distance: number;
    };
    /**
     * DISTILL LOGIC: Mark a high-fidelity result as a local axiom.
     */
    static distill(crystal: Crystal): void;
}
