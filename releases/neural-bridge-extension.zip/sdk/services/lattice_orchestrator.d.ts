import type { Crystal, CrystalConstraint } from '../types/crystal_format';
export interface LatticePath {
    id: string;
    model_used: string;
    steps: number;
    reliability_score: number;
    crystal: Crystal | null;
    error?: string;
    prompt_used: string;
}
/**
 * LATTICE ORCHESTRATOR (The Stochastic Engine) 🕸️
 *
 * Replaces linear chains (LangChain) with self-healing Lattices.
 * Goal: Find a path to the Truth (Crystal) regardless of which model is used.
 */
export declare class LatticeOrchestrator {
    /**
     * Crystallize a Truth from an Intent.
     * "Find me a path to X" (Declarative) vs "Do A then B then C" (Imperative)
     */
    static crystallizeIntent(intent: string, constraints: CrystalConstraint[]): Promise<LatticePath>;
    private static attemptPath;
    private static calculateReliability;
}
