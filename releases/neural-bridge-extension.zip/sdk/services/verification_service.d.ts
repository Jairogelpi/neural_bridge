import type { CrystalExecutionResult } from "../services/crystal_runtime";
import type { KnowledgeDomain } from "../services/domain_heuristics";
import type { Crystal } from "../types/crystal_format";
export interface VerificationRequest {
    context_id?: string;
    domain?: KnowledgeDomain;
    question: string;
    answer: string;
    mode: 'active' | 'passive';
    requester: string;
}
/**
 * VERIFICATION SERVICE
 *
 * The Unified Source of Truth for all verification logic in Neural Bridge.
 * Harmonizes BridgeFlow and FirewallAgent.
 */
export declare class VerificationService {
    /**
     * Harvest the most relevant crystals for a given context
     */
    static harvestCrystals(params: {
        domain: KnowledgeDomain;
        text: string;
    }): Promise<any[]>;
    /**
     * Execute a full verification cycle
     */
    static verify(req: VerificationRequest): Promise<CrystalExecutionResult | null>;
    static suggestRepair(params: {
        crystal: Crystal | null;
        question: string;
        originalAnswer: string;
        failedInvariants: string[];
    }): Promise<string>;
    static getActiveCrystal(): Promise<any | null>;
}
