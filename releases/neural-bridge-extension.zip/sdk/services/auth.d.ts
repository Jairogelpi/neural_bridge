export declare class AuthService {
    /**
     * Register a new author/user
     */
    static register(name: string, handle: string, email: string, password: string): Promise<{
        author: any;
        token: string;
    }>;
    /**
     * Login an existing user
     */
    static login(email: string, password: string): Promise<{
        author: any;
        token: string;
    }>;
    /**
     * Middleware to verify JWT
     */
    static authenticate(req: any, res: any, next: any): any;
}
