export interface ChatSession {
    id: string;
    active_crystal_ids: string[];
    history: Array<{
        role: 'user' | 'assistant';
        content: string;
    }>;
    created_at: string;
}
/**
 * NEURAL SURFACE (Talk to my Knowledge) 💬🧠
 *
 * Capability: Crystal-Grounded Reasoning.
 * Orchestrates chat sessions where the LLM is strictly bound
 * to the axioms defined in selected Crystals.
 */
export declare class NeuralSurface {
    private static activeSessions;
    /**
     * INITIATE CHAT: Starts a session bound to specific crystals.
     */
    static initiateSession(crystalIds: string[]): Promise<string>;
    /**
     * GROUNDED CHAT: Send a prompt to the LLM filtered by active crystals.
     */
    static groundedChat(sessionId: string, userPrompt: string): Promise<string>;
    static getSession(id: string): ChatSession | undefined;
    /**
     * RECURSIVE REFINEMENT: Evolve crystals based on interaction success.
     */
    static refineKnowledge(sessionId: string, interactionResult: string): Promise<void>;
}
