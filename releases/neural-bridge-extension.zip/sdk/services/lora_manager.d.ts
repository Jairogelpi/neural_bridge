/**
 * LORA MANAGER (The Specialist) 🎭⚡
 *
 * Capability: Local Model Refinement.
 * Tracks "Cognitive Specialization" of local models. When a domain
 * reaches critical concept density, the manager activates a virtual
 * LoRA adapter to improve local reasoning accuracy.
 */
export declare class LoRAManager {
    private static activeAdapters;
    private static MIN_DENSITY_FOR_LORA;
    /**
     * EVALUATE SPECIALIZATION: Check if any domain qualifies for a LoRA adapter.
     */
    static evaluateSpecialization(): Promise<void>;
    /**
     * ACTIVATE ADAPTER: Simulate the hot-swapping of a reasoning adapter.
     */
    static activateAdapter(id: string, precision: number): Promise<void>;
    static getActiveAdapters(): string[];
    /**
     * APPLY REFINEMENT: conceptually boosts accuracy for a specific domain.
     */
    static getDomainBoost(domain: string): number;
}
