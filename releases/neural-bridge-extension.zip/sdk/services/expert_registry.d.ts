/**
 * UNIVERSAL EXPERT REGISTRY 🏛️🧠
 *
 * Goal: No more hardcoded JUDGES.
 * This service finds the most capable models for any given domain
 * in real-time, optimizing for Intelligence-per-Token.
 */
export declare class ExpertRegistry {
    private static capabilityCache;
    /**
     * Finds the best judges for a specific domain.
     * Uses meta-reasoning to rank available models.
     */
    static findBestJudges(domain: string, limit?: number): Promise<string[]>;
    /**
     * Clears cache for dynamic updates.
     */
    static flush(): void;
}
