import type { Crystal } from '../types/crystal_format';
/**
 * LATENT ANCHORING ENGINE (Crystal Injection)
 *
 * Goal: Transform structured knowledge into an "Axiomatic Anchor" that
 * forces the LLM's latent space to align with the context's invariants.
 *
 * This treats the Crystal not as "helpful info", but as "Immutable Ground Truth".
 */
export declare class LatentAnchor {
    /**
     * Anchors a Crystal into a high-priority, axiomatic prompt structure.
     */
    static anchor(crystal: Crystal): string;
    /**
     * MASTER ANCHOR SYNTHESIS 💎
     *
     * The ultimate counter to brute-force context.
     * It filters out noise using EntropyAudit and bundles the remaining
     * signal into a single Holographic Master Crystal.
     */
    static synthesizeMasterAnchor(query: string, candidates: Crystal[]): string;
}
