import { IngestSource } from './synaptic_ingestor';
/**
 * AUTONOMOUS ONBOARDING (Zero-Config Brain) 🧠✨
 *
 * Capability: Automated Knowledge Expansion.
 * Orchestrates the "One-Click" onboarding process.
 * It coordinates the ingestor, domain detection, and neurogenesis.
 */
export declare class AutonomousOnboarding {
    /**
     * UNIVERSAL PLUG: The ultimate zero-friction entry point.
     * 1. Ingest via SynapticIngestor.
     * 2. Analyze for potential Capability Gaps.
     * 3. Trigger spontaneous evolution if needed.
     */
    static universalPlug(source: IngestSource): Promise<{
        status: 'COMPLETE' | 'EVOLVING' | 'ERROR';
        domain: string;
        stats: any;
    }>;
}
