import { type Crystal } from '../types/crystal_format';
/**
 * SEMANTIC CACHE 🧠⚡
 *
 * LSH-based deduplication to avoid re-crystallizing similar content.
 * Returns cached crystals for >95% similarity matches.
 */
export declare class SemanticCache {
    private static cache;
    private static readonly SIMILARITY_THRESHOLD;
    private static readonly MAX_CACHE_SIZE;
    private static readonly TTL_MS;
    /**
     * Check if similar content exists in cache.
     * Returns cached crystal if semantic similarity > 95%.
     */
    static check(text: string): Crystal | null;
    /**
     * Store a crystal in the semantic cache.
     */
    static store(text: string, crystal: Crystal): void;
    /**
     * Clear expired entries.
     */
    static cleanup(): void;
    /**
     * Get cache statistics.
     */
    static stats(): {
        size: number;
        max_size: number;
        ttl_hours: number;
    };
}
