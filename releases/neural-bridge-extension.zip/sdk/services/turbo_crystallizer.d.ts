import { type Crystal } from '../types/crystal_format';
export type CrystallizationTier = 'flash' | 'smart' | 'deep';
export interface TurboCrystallizeOptions {
    tier: CrystallizationTier;
    domain?: string;
    autoUpgrade?: boolean;
}
/**
 * TURBO CRYSTALLIZER ⚡💎
 *
 * Revolutionary 3-Tier Crystallization System:
 * - FLASH (0ms): Pure math, instant, 100% deterministic
 * - SMART (200ms): Fast AI, good enough for 90% of cases
 * - DEEP (2s): Full power, runs in background
 *
 * Includes semantic caching for instant duplicate detection.
 */
export declare class TurboCrystallizer {
    private static backgroundQueue;
    private static isProcessingQueue;
    /**
     * Main entry point - intelligent tier selection with caching.
     */
    static crystallize(text: string, options: TurboCrystallizeOptions): Promise<Crystal>;
    /**
     * TIER 0: FLASH MODE ⚡
     * Pure mathematical crystallization - NO LLM calls.
     * Returns instantly with 100% deterministic results.
     */
    private static flashCrystallize;
    /**
     * TIER 1: SMART MODE 🧠
     * Uses fast, small AI models (~7B params) for good-enough results.
     * Target: <500ms
     */
    private static smartCrystallize;
    /**
     * TIER 2: DEEP MODE 🔬
     * Full power crystallization with best models.
     * Runs in background, no rush.
     */
    private static deepCrystallize;
    /**
     * BACKGROUND UPGRADE SYSTEM 🔄
     * Queues Flash/Smart crystals for Deep refinement.
     */
    private static queueForUpgrade;
    /**
     * Process the background upgrade queue.
     */
    private static processUpgradeQueue;
    /**
     * Get queue statistics.
     */
    static getQueueStats(): {
        queued: number;
        processing: boolean;
        cache: {
            size: number;
            max_size: number;
            ttl_hours: number;
        };
    };
}
