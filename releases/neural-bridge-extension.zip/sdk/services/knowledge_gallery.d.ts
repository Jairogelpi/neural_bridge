export interface GalleryTheme {
    id: string;
    label: string;
    cluster_vector_hash: string;
    node_ids: string[];
}
/**
 * KNOWLEDGE GALLERY (The Library of Truths) 🖼️📚
 *
 * Capability: Automated Taxonomy.
 * Groups individual Crystals into thematic galleries based on
 * HDC geometric proximity.
 */
export declare class KnowledgeGallery {
    private static themes;
    /**
     * CLUSTER CRYSTALS: Group all active crystals into themes.
     */
    static clusterGalleries(): Promise<GalleryTheme[]>;
    /**
     * PERSIST GALLERY: Saves a user-defined gallery or chat configuration.
     */
    static persistGalleryConfig(label: string, crystalIds: string[]): Promise<void>;
    /**
     * LOAD GALLERIES
     */
    static loadUserGalleries(): Promise<any[]>;
}
