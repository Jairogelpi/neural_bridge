/**
 * THE HOLOGRAPHIC CORTEX (Long-Term Memory) 🧠
 *
 * Manages the "Semantic Lattice" - the graph of learned synonyms and relationships.
 * PERSISTENT: Saves to Supabase so knowledge survives restarts.
 * SHARED: All nodes (Extension/Backend) share this wisdom.
 */
export declare class SemanticLattice {
    private static cache;
    private static isDirty;
    private static lastSave;
    /**
     * Initialize: Load from Supabase "Cortex"
     */
    static initialize(): Promise<void>;
    /**
     * Add a semantic link (Bidirectional)
     * "King" <-> "Royal"
     */
    static addLink(a: string, b: string): void;
    private static _add;
    /**
     * Get related concepts for a token
     */
    static getRelated(token: string): string[];
    /**
     * Persist to Supabase (Debounced)
     */
    private static saveDebounced;
    /**
     * Force Save (e.g. on shutdown)
     */
    static forceSave(): Promise<void>;
}
