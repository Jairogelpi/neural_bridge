/**
 * RECURSIVE DREAMING ENGINE 🌌😴
 *
 * Periodically scans the knowledge lattice for patterns.
 * Fuses related crystals into higher-order "Sovereign Axioms."
 */
export declare class DreamingService {
    private static isDreaming;
    /**
     * Start the autonomous dreaming loop.
     */
    static startDreamingLoop(intervalMs?: number): Promise<void>;
    /**
     * A single "Dream" cycle.
     * Finds related crystals and fuses them into universal laws.
     */
    static dream(): Promise<void>;
}
