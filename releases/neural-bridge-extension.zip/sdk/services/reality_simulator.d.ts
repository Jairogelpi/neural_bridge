import type { RealityBranch } from './reality_brancher';
import type { Crystal } from '../types/crystal_format';
/**
 * REALITY SIMULATOR (The Multiverse Engine) 🌌🧪
 *
 * Capability: Stress-tests a Reality Branch against a battery of
 * counterfactuals and edge cases to prove its "Stability" before merge.
 */
export declare class RealitySimulator {
    /**
     * Runs a full Reality Stress Test on a branch.
     */
    static simulate(branch: RealityBranch, parent: Crystal): Promise<{
        stability_score: number;
        failures: string[];
    }>;
}
