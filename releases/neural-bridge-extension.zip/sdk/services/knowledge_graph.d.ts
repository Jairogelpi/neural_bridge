import type { Crystal } from '../types/crystal_format';
export interface CrystalReference {
    crystal_id: string;
    version: string;
    hash: string;
}
export interface CrystalDependency {
    ref: CrystalReference;
    type: 'requires' | 'extends' | 'conflicts_with';
    scope: 'domain' | 'client' | 'project' | 'implementation';
}
export interface VersionedCrystal {
    crystal_id: string;
    version: string;
    content: Crystal;
    dependencies: CrystalDependency[];
    created_at: string;
    deprecated?: boolean;
    superseded_by?: CrystalReference;
}
export interface KnowledgeGraph {
    crystals: Map<string, VersionedCrystal[]>;
    dependency_graph: Map<string, string[]>;
}
/**
 * Create a versioned Crystal with dependencies
 */
export declare function createVersionedCrystal(params: {
    crystal: Crystal;
    version: string;
    dependencies?: CrystalDependency[];
}): VersionedCrystal;
/**
 * Resolve Crystal dependencies
 * Returns the full dependency tree in topological order
 */
export declare function resolveDependencies(params: {
    crystal_ref: CrystalReference;
    graph: KnowledgeGraph;
}): {
    resolved: VersionedCrystal[];
    conflicts: string[];
};
/**
 * Merge multiple Crystals into a composite context
 * Useful for combining domain + client + project knowledge
 */
export declare function mergecrystals(params: {
    crystals: VersionedCrystal[];
    merge_strategy?: 'union' | 'priority' | 'strict';
}): Crystal;
/**
 * Version comparison (semantic versioning)
 */
export declare function compareVersions(v1: string, v2: string): number;
/**
 * Detect semantic or structural conflicts between two Crystals
 */
export declare function detectConflicts(base: Crystal, incoming: Crystal): string[];
export declare const KnowledgeGraphOS: {
    createVersionedCrystal: typeof createVersionedCrystal;
    resolveDependencies: typeof resolveDependencies;
    mergecrystals: typeof mergecrystals;
    detectConflicts: typeof detectConflicts;
    compareVersions: typeof compareVersions;
};
