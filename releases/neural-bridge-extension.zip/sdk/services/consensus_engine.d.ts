export interface ConsensusReceipt {
    axiom_id: string;
    decision: 'TRUTH' | 'REJECTED' | 'DISPUTED';
    confidence: number;
    votes: Array<{
        model: string;
        response: string;
        score: number;
    }>;
    timestamp: string;
    signature: string;
}
/**
 * BYZANTINE SEMANTIC CONSENSUS ENGINE 🌌⚖️
 *
 * Goal: Establish a Universal Truth Layer by forcing agreement between
 * mathematically disparate model architectures.
 */
export declare class ConsensusEngine {
    /**
     * Reaches a Byzantine consensus on a specific axiom or fact.
     */
    static reachConsensus(axiom: string, domain: string): Promise<ConsensusReceipt>;
    /**
     * SOVEREIGN CONSENSUS (Isolation Mode)
     * Uses formal logic and the Ontological Anchor to determine truth
     * without external API calls.
     */
    private static reachSovereignConsensus;
}
