import type { Crystal } from '../types/crystal_format';
/**
 * REHYDRATION ENGINE
 * Converts a Knowledge Crystal (JSON) into a potent "Primer Prompt"
 * that forces any LLM (Claude, ChatGPT, Llama) to adopt the state.
 */
export declare class RehydrationEngine {
    static rehydrate(crystal: Crystal): string;
}
