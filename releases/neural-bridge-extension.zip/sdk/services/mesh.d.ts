export interface MeshState {
    activeCrystal: string | null;
    checkpoints: Record<string, string>;
    lastUpdated: number;
}
export interface MeshEvent {
    type: 'CRYSTAL_UPDATED' | 'CHECKPOINT_CREATED' | 'HOST_ACTIVE';
    crystalId?: string;
    host?: string;
    data?: Record<string, unknown>;
}
export declare function broadcastMeshUpdate(event: MeshEvent): void;
export declare function onMeshUpdate(callback: (event: MeshEvent) => void): void;
export declare function saveCheckpoint(name: string, crystalJSON: string): Promise<void>;
export declare function getProactiveHint(host: string, entities: {
    type: string;
}[], intents: {
    type: string;
}[]): string | null;
export declare const MeshService: {
    broadcastMeshUpdate: typeof broadcastMeshUpdate;
    onMeshUpdate: typeof onMeshUpdate;
    saveCheckpoint: typeof saveCheckpoint;
    getProactiveHint: typeof getProactiveHint;
};
