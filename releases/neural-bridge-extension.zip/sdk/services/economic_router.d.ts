export type ModelTier = 'CHEAP' | 'BALANCED' | 'POTENT' | 'OMEGA';
export interface RoutingDecision {
    tier: ModelTier;
    selected_model: string;
    risk_score: number;
    complexity_score: number;
    reasoning: string;
}
/**
 * ECONOMIC STEERING ENGINE (Quantum Routing) 💰⚖️
 *
 * Goal: Maximize ROI by dynamically selecting models based on:
 * 1. Domain Risk (Medicine/Law = OMEGA)
 * 2. Task Complexity (Brainstorming = CHEAP)
 * 3. Semantic Uncertainty (High Dissent = POTENT)
 */
export declare class EconomicRouter {
    private static MODEL_TIERS;
    /**
     * Determines the optimal model for a given context and task.
     */
    static route(params: {
        text: string;
        domain: string;
        task: 'compile' | 'verify' | 'repair' | 'dream';
        isCritical?: boolean;
    }): Promise<RoutingDecision>;
}
