export interface ConsensusResult {
    final_decision: 'CONSENSUS_REACHED' | 'DISSENT' | 'UNCERTAIN';
    consensus_score: number;
    participants: {
        model: string;
        vote: 'AGREE' | 'DISAGREE';
        reason: string;
    }[];
    jury_case_id?: string | undefined;
}
/**
 * CONSENSUS ENGINE (Universal Truth)
 * Instead of trusting one AI, we form a "Jury" of diverse models.
 * If they all agree, the reality is highly probable.
 */
export declare class ConsensusEngine {
    private static JURY_MODELS;
    static verify(fact: string, context: string): Promise<ConsensusResult>;
    private static getVote;
}
