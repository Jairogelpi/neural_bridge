import type { Crystal } from '../types/crystal_format';
export interface SemanticHandshake {
    source_model: string;
    target_model: string;
    fingerprint: string;
    resonance: number;
    conflicts: string[];
    timestamp: string;
}
/**
 * THE OMEGA PROTOCOL: UNIVERSAL SEMANTIC SYNCHRONIZATION (USS) 🌌⚡🔗
 *
 * Capability: Establishes a formal "Axiomatic Handshake" between two AI
 * models before knowledge is transferred. This ensures that Model B's
 * internal world-view aligns mathematically with Model A's intent.
 *
 * If a mismatch is detected, the models perform a "Synchronous Alignment"
 * to merge their ontologies before processing.
 */
export declare class SemanticProtocol {
    /**
     * Performs a pre-flight handshake between the system and a target model.
     */
    static performHandshake(crystal: Crystal, targetModel: string): Promise<SemanticHandshake>;
}
