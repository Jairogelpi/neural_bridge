import { type Crystal } from '../types/crystal_format';
import { type DecisionReceipt } from './decision_receipts';
export interface LLMResponse {
    content: string;
    model: string;
    tokens: {
        prompt: number;
        completion: number;
        total: number;
    };
    cost: number;
    latency: number;
}
export interface VerificationResult {
    decision: 'ACCEPT' | 'FAIL';
    score: number;
    confidence_interval: [number, number];
    passed_invariants: string[];
    failed_invariants: Array<{
        id: string;
        expected: unknown;
        actual: string;
        reason: string;
    }>;
    ladder_level: number;
    total_attempts: number;
    tokens_used: number;
    cost: number;
    receipt?: DecisionReceipt;
}
declare function callLLM(prompt: string, model?: string, systemPrompt?: string, maxRetries?: number): Promise<LLMResponse>;
/**
 * Resilient wrapper with REDIS CACHING for 1000x speed
 */
declare function resilientCallLLM(prompt: string, model: string, systemPrompt?: string): Promise<LLMResponse>;
/**
 * Detect domain autonomously using a real LLM call
 */
export declare function detectDomainAutonomously(text: string): Promise<string>;
/**
 * Generate Crystal using real LLM and official types.
 */
export declare function generateCrystal(conversationText: string, sourceModel: string, author?: {
    id: string;
    name: string;
    reputation: number;
}): Promise<{
    crystal: Crystal;
    llmResponse: LLMResponse;
}>;
export declare function verifyTransfer(crystal: Crystal, targetModel?: string): Promise<VerificationResult>;
export declare function verifyBatch(params: {
    crystal: Crystal;
    invariants: Array<{
        id: string;
        prompt: string;
        expected: unknown;
        weight: number;
    }>;
    answer: string;
    targetModel?: string;
}): Promise<{
    results: Array<{
        id: string;
        score: number;
        reasoning: string;
    }>;
    cost: number;
    latency: number;
}>;
export declare function verifyArbitrary(params: {
    crystal: Crystal;
    question: string;
    answer: string;
    targetModel?: string;
    useCache?: boolean;
}): Promise<{
    score: number;
    reasoning: string;
    cost: number;
}>;
export declare function getOptimalModel(params: {
    domain?: string;
    isCritical?: boolean;
    task?: 'compile' | 'verify' | 'repair' | 'dream' | 'abstract';
    text?: string;
    stats?: {
        free_energy: number;
        surprise: number;
    };
}): string;
export declare function sovereignSynthesize(text: string, domain: string): Promise<{
    crystal: Crystal;
    llmResponse: LLMResponse;
}>;
export declare const SCPService: {
    generateCrystal: typeof generateCrystal;
    verifyTransfer: typeof verifyTransfer;
    verifyArbitrary: typeof verifyArbitrary;
    verifyBatch: typeof verifyBatch;
    callLLM: typeof callLLM;
    getOptimalModel: typeof getOptimalModel;
    resilientCallLLM: typeof resilientCallLLM;
};
export {};
