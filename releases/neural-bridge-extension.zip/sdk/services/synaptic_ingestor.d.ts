export interface IngestSource {
    type: 'text' | 'url' | 'file';
    content: string;
    metadata?: Record<string, any>;
}
/**
 * SYNAPTIC INGESTOR (Zero-Friction Gateway) ⚡🔌
 *
 * Capability: Universal Plug-and-Play.
 * It takes any raw input and proactively prepares it for the Talamic Singularity.
 * No manual chunking or DB setup needed.
 */
export declare class SynapticIngestor {
    /**
     * QUICK INGEST: The "One-Click" entry point.
     * Automatically detects domain, cleans text, and pushes to Atlas.
     */
    static fastPlug(source: IngestSource): Promise<{
        nodesIndexed: number;
        detectedDomain: string;
        resonanceScore: number;
    }>;
    /**
     * NORMALIZE CONTENT: Strips boilerplate and prepared for HDC projection.
     */
    private static normalizeContent;
    /**
     * BATCH INGEST: For entire folders or complex datasets.
     */
    static batchPlug(contents: IngestSource[]): Promise<number>;
}
