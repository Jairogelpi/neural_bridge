import type { Crystal } from '../types/crystal_format';
/**
 * CRYSTAL FUSION ENGINE (Reality Merging) 💎
 *
 * Capability: Takes multiple Crystals (possibly from different models or sessions)
 * and fuses them into a single, high-fidelity "Master Crystal" while resolving
 * all semantic conflicts autonomously.
 */
export declare class CrystalFuser {
    /**
     * HOLOGRAPHIC MATH FUSION ⚡ (Phase 9)
     * Instant O(N) merging of crystals using Hyperdimensional Computing.
     * No LLM costs. Pure superpositions.
     */
    static fuseHolographic(crystals: Crystal[]): Crystal;
    /**
     * Merges an array of Crystals into one.
     */
    static fuse(crystals: Crystal[]): Promise<Crystal>;
    /**
     * sovereignInject
     *
     * Formats a Crystal as a "Sovereign Instruction Block" for downstream LLMs.
     * This REPLACES the typical RAG "context dump".
     */
    static fuseCrystalIntoContext(crystal: Crystal): string;
}
