export interface DialecticalResult {
    final_thesis: string;
    iterations: number;
    history: {
        round: number;
        thesis: string;
        attack: string;
        synthesis: string;
    }[];
    is_resilient: boolean;
}
/**
 * THE DIALECTICAL ENGINE (The Hegel Pipe)
 *
 * Thesis -> Antithesis (Attack) -> Synthesis (Improved Truth)
 *
 * This engine takes a fragile idea and "hardens" it by exposing it to
 * repeated Red Team attacks and auto-evolving the claim to survive.
 */
export declare class DialecticalEngine {
    static evolve(initialThesis: string, context: string): Promise<DialecticalResult>;
}
