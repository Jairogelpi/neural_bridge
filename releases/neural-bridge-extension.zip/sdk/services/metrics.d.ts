export interface TransferMetrics {
    id: string;
    timestamp: string;
    source_model: string;
    target_model: string;
    crystal_generation: {
        tokens_used: number;
        cost_usd: number;
        latency_ms: number;
        entities_extracted: number;
        invariants_generated: number;
        compression_ratio: number;
        quality_score: number;
    };
    transfer: {
        success: boolean;
        score: number;
        confidence_interval: [number, number];
        invariants_passed: number;
        invariants_total: number;
        ladder_level: number;
        attempts: number;
    };
    verification: {
        tokens_used: number;
        cost_usd: number;
        latency_ms: number;
    };
    total_tokens: number;
    total_cost_usd: number;
    total_latency_ms: number;
}
export interface AggregateMetrics {
    period: 'hour' | 'day' | 'week' | 'month';
    total_transfers: number;
    successful_transfers: number;
    failed_transfers: number;
    success_rate: number;
    total_cost_usd: number;
    avg_cost_per_transfer: number;
    cost_by_model: Record<string, number>;
    avg_score: number;
    avg_latency_ms: number;
    avg_invariants_passed: number;
    total_tokens: number;
    avg_tokens_per_transfer: number;
    source_model_distribution: Record<string, number>;
    target_model_distribution: Record<string, number>;
}
export declare function recordTransfer(metrics: TransferMetrics): void;
export declare function getMetrics(): TransferMetrics[];
export declare function getAggregateMetrics(period?: 'hour' | 'day' | 'week' | 'month'): AggregateMetrics;
export declare function formatCurrency(usd: number): string;
export declare function formatNumber(n: number): string;
export declare const MetricsService: {
    recordTransfer: typeof recordTransfer;
    getMetrics: typeof getMetrics;
    getAggregateMetrics: typeof getAggregateMetrics;
    formatCurrency: typeof formatCurrency;
    formatNumber: typeof formatNumber;
};
