import type { UniversalConstraint, uSidResult, SystemCapabilities, UnsatCoreItem, ConflictRepair } from '../types/usid';
export declare class UsidEngine {
    /**
     * COMPILER: Transforms natural language intent into Logic Constraints
     */
    static compileIntent(intent: string, domain?: string): Promise<UniversalConstraint[]>;
    /**
     * SOLVER: Checks if the constraints are Satisfiable (SAT)
     */
    static solve(intent: string, capabilities?: SystemCapabilities): Promise<uSidResult>;
    static checkLogicalConsistency(constraints: UniversalConstraint[]): Promise<{
        consistent: boolean;
        conflicts: UnsatCoreItem[];
        ids: string[];
    }>;
    static generateRepairs(unsatCore: UnsatCoreItem[]): Promise<ConflictRepair[]>;
}
