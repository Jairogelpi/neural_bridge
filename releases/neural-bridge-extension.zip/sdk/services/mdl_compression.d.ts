import type { Crystal, SemanticInvariant } from '../types/crystal_format';
export interface CompressionResult {
    original_tokens: number;
    compressed_tokens: number;
    compression_ratio: number;
    removed_invariants: string[];
    core_invariants: string[];
    counterfactual_pass_rate: number;
    mdl_score: number;
}
export interface AblationTestResult {
    invariant_id: string;
    impact_on_score: number;
    essential: boolean;
}
/**
 * MDL-based Crystal compression
 * Removes invariants until counterfactual pass rate drops below threshold
 */
export declare function compressCrystalMDL(params: {
    crystal: Crystal;
    invariants: SemanticInvariant[];
    verifier: (invariants: SemanticInvariant[]) => Promise<{
        score: number;
    }>;
    min_pass_rate?: number;
}): Promise<CompressionResult>;
/**
 * Find the absolute minimum core that maintains counterfactual pass rate
 * Uses greedy algorithm to aggressively remove non-essential invariants
 */
export declare function findMinimalCore(params: {
    crystal: Crystal;
    invariants: SemanticInvariant[];
    verifier: (invariants: SemanticInvariant[]) => Promise<{
        score: number;
    }>;
    target_pass_rate: number;
}): Promise<{
    core: SemanticInvariant[];
    compression_ratio: number;
    pass_rate: number;
}>;
export declare const MDL: {
    compressCrystalMDL: typeof compressCrystalMDL;
    findMinimalCore: typeof findMinimalCore;
};
