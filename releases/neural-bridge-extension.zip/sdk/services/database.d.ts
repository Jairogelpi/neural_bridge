import { Pool, PoolClient } from 'pg';
/**
 * DATABASE CONNECTION POOL 🗄️
 *
 * Prevents database exhaustion by reusing connections.
 * Supports 10x more concurrent users without connection overhead.
 */
export declare class DatabasePool {
    private static pool;
    static getPool(): Pool;
    /**
     * Execute a query with automatic connection management
     */
    static query<T = any>(text: string, params?: any[]): Promise<T[]>;
    /**
     * Get a connection for transaction
     */
    static getConnection(): Promise<PoolClient>;
    /**
     * Execute in transaction
     */
    static transaction<T>(callback: (client: PoolClient) => Promise<T>): Promise<T>;
    /**
     * Get pool statistics
     */
    static getStats(): {
        total: number;
        idle: number;
        waiting: number;
    };
    /**
     * Graceful shutdown
     */
    static close(): Promise<void>;
}
