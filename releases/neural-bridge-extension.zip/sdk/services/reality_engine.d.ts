import type { RealityProof } from '../types/crystal_format';
export declare class RealityBreachError extends Error {
    attemptedOutput: string;
    constructor(message: string, attemptedOutput: string);
}
export declare class RealityEngine {
    /**
     * The core primitive of RCI:
     * Transforms an "Attempted Output" into a "Reality Validated Output" OR blocks it.
     */
    static constrain(attemptedOutput: string, domain: string, constraints: string[]): Promise<RealityProof>;
    /**
     * ARD (AI Refusal by Design)
     * Checks if the INTENT itself is ontologically possible.
     * Returns a "Proof of Impossibility" if the request cannot exist in reality.
     */
    static validateIntent(intent: string, domainModel: string[]): Promise<{
        possible: boolean;
        reason: string;
        violated_constraints: string[];
    }>;
    /**
     * UNIVERSAL REALITY DISCOVERY
     * Dynamically identifies the domain and its immutable laws based on the intent.
     * This removes the need for hardcoded constraints.
     */
    static inferRealityModel(intent: string): Promise<{
        domain: string;
        constraints: string[];
    }>;
}
