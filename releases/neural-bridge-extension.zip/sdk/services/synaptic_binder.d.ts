import { Crystal } from '../types/crystal_format';
export declare class SynapticBinder {
    /**
     * Main entry point: Bind a new crystal to the existing manifold.
     * Discovers parents, siblings, and semantic kin.
     */
    static bind(crystal: Crystal): Promise<Crystal>;
    /**
     * Fractalize: Create a child crystal from a parent, preserving lineage.
     */
    static fractalize(parent: Crystal, newContent: string, mutationType: 'REFINEMENT' | 'BRANCH'): Promise<Crystal>;
    /**
     * Uses HDC/Vector Search to find related crystals
     */
    private static discoverSemanticSynapses;
}
