/**
 * RECURSIVE BRAIN (The Self-Expanding Intelligence) 🧠🌌
 *
 * Goal: Autonomously detect "Knowledge Voids" and fill them
 * via background mining and curiosity-driven probes.
 */
export declare class RecursiveBrain {
    /**
     * Identifies "voids" in the current knowledge domain.
     * Uses HDC distribution analysis to find regions with low truth density.
     */
    static detectKnowledgeGaps(domain: string): Promise<string[]>;
    /**
     * Generates a "Probe Question" for a specific gap.
     */
    static generateProbe(gap: string, domain: string): Promise<string>;
    /**
     * Performs a single "Learning Pulse".
     */
    static learningPulse(domain: string): Promise<void>;
}
