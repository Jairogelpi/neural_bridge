/**
 * RECURSIVE BRAIN (The Self-Expanding Intelligence) 🧠🌌
 *
 * Goal: Autonomously detect "Knowledge Voids" and fill them
 * via background mining and curiosity-driven probes.
 */
export declare class RecursiveBrain {
    /**
     * EPISTEMIC AUDIT: Ranks knowledge gaps by "Expected Free Energy".
     * Prioritizes regions where learning provides the maximum Information Gain.
     */
    static performEpistemicAudit(domain: string): Promise<Array<{
        gap: string;
        expected_information_gain: number;
    }>>;
    /**
     * ABDUCTIVE SINGULARITY: Proposes "Hidden Laws" or "Theories"
     * based on existing knowledge. This is where true abstraction happens.
     */
    static detectAbductiveHypotheses(domain: string): Promise<Array<{
        theory: string;
        rationale: string;
        confidence: number;
    }>>;
    /**
     * Generates a "Probe Question" for a specific gap.
     */
    static generateProbe(gap: string, domain: string): Promise<string>;
    /**
     * Performs a single "Learning Pulse".
     * Driven by Expected Free Energy.
     */
    static learningPulse(domain: string): Promise<void>;
}
