import type { Crystal } from '../types/crystal_format';
export interface ModelRequirements {
    min_sri_threshold: number;
    requires_external_verification: boolean;
    requires_citations: boolean;
    blocked_outputs: string[];
    allowed_models: string[];
}
export interface CrystalComplexity {
    domain: string;
    risk_level: 'critical' | 'high' | 'medium' | 'low';
    invariant_count: number;
    counterfactual_count: number;
    complexity_score: number;
}
/**
 * Calculate Crystal complexity and risk
 */
export declare function calculateComplexity(crystal: Crystal): CrystalComplexity;
/**
 * Determine model requirements based on Crystal
 * This is the "firewall" that blocks unsafe routing
 */
export declare function determineModelRequirements(complexity: CrystalComplexity): ModelRequirements;
/**
 * Validate if a model is suitable for this Crystal
 */
export declare function validateModelForCrystal(params: {
    model: string;
    crystal: Crystal;
}): {
    allowed: boolean;
    reason?: string;
    requirements: ModelRequirements;
};
export declare const ModelRouting: {
    calculateComplexity: typeof calculateComplexity;
    determineModelRequirements: typeof determineModelRequirements;
    validateModelForCrystal: typeof validateModelForCrystal;
};
