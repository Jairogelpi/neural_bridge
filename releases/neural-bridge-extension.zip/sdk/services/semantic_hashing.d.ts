export interface SemanticHashResult {
    raw_text: string;
    canonical_concept: string;
    s_hash: string;
    is_stable: boolean;
}
/**
 * SEMANTIC HASHING ENGINE V2 (Holographic Edition) 🌌
 *
 * Uses Hyperdimensional Computing (4096-bit Vectors) to capture
 * deep semantic nuances with O(N) complexity.
 */
export declare class SemanticHasher {
    /**
     * Map a token to a deterministic 4096-bit Hypervector.
     * "Dog" -> Always same random pattern X.
     * "Cat" -> Always same random pattern Y.
     * Orthogonal by default.
     */
    private static getVectorForToken;
    /**
     * ADAPTIVE LEARNING 🧠
     * The system "reads" a text and evolves its semantic lattice to understand the domain.
     * This eliminates hardcoded synonyms.
     */
    static learn(context: string): Promise<void>;
    /**
     * GEOMETRIC STEMMING (Linguistic Liberation) 🌐📐
     *
     * Replaces hardcoded regex-based stemming with Topological Rooting.
     * Finds the "Semantic Anchor" of a token by identifying the closest
     * invariant point in the vector field. Works on ALL languages.
     */
    private static geometricStemming;
    /**
     * TOPOLOGICAL TOPOGRAPHY 🧠
     * Learns the shape of a domain's logic purely through vector density.
     */
    static learnTopology(context: string): Promise<void>;
    /**
     * HOLOGRAPHIC HASHING (HDC)
     * Combines tokens into a document vector using Majority Rule Bundling.
     *
     * UPGRADE: Now uses N-Gram Sequence Encoding to capture CONTEXT.
     * "Dog bites Man" != "Man bites Dog"
     * + MORPHOLOGY LAYER: Captures Root words automatically.
     */
    static computeHolographicHash(text: string): string;
    /**
     * Similarity between two Holographic Hashes.
     * Uses HDC Similarity (Normalized Hamming).
     */
    static holographicSimilarity(hexA: string, hexB: string): number;
    /**
     * Legacy Adapter: Computes SimHash but via Holographic Engine.
     * Returns the hex string.
     */
    static computeSimHash(text: string): string;
    static hammingDistance(hashA: string, hashB: string): number;
    static computeHash(text: string): Promise<SemanticHashResult>;
}
