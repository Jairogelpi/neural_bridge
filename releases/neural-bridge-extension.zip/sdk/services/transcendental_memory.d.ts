import { Crystal } from '../types/crystal_format';
/**
 * TRANSCENDENTAL HIVE MEMORY 🧠☁️
 *
 * Capability: Active Superposition.
 * Unlike a database (static storage), this memory keeps Sovereign Axioms "Alive".
 * It runs a background "Thought Loop" where axioms collide, merge, and compete.
 */
export declare class TranscendentalMemory {
    private static activeLattice;
    /**
     * WAKE UP PROTOCOL: Loads high-tier axioms into active memory.
     */
    static wakeUp(): Promise<void>;
    /**
     * THE THOUGHT LOOP (Subconscious Processing) 💭
     * Randomly collides axioms to see if they can form a higher truth.
     */
    private static thoughtLoop;
    /**
     * INJECT THOUGHT: Manually add a crystal to the active stream.
     */
    static injectThought(crystal: Crystal): void;
}
