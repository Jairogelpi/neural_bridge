import type { Crystal } from '../types/crystal_format';
/**
 * FAST-PATH JURY (The Speed Demon) 🏎️💨
 *
 * Goal: Sub-10ms truth verification using pure bitwise math.
 * Instead of asking a high-latency LLM Jury, we check if the
 * proposed response "aligns" with the Master Crystal's hypervector.
 */
export declare class FastPathJury {
    /**
     * Verifies if a proposed response fragment is truthful relative to a Crystal.
     * Returns a Boolean decision in <5ms.
     */
    static verifyEdge(fragment: string, anchor: Crystal): Promise<{
        accepted: boolean;
        score: number;
        latency_ms: number;
    }>;
    /**
     * Multi-Point Check: verifies several fragments simultaneously.
     * Uses HDC Bundling to check "Contextual Resonace" of the entire stream.
     */
    static auditStream(fragments: string[], anchor: Crystal): Promise<boolean>;
}
