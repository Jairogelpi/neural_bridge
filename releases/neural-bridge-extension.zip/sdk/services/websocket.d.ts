import { Server as HTTPServer } from 'http';
/**
 * WEBSOCKET REAL-TIME SERVER 🔴⚡
 *
 * Provides real-time updates for:
 * - New crystals (cortex graph auto-update)
 * - Job progress (crystallization, multimodal)
 * - System stats (cache, queue)
 * - Live notifications
 */
export declare class WebSocketServer {
    private static io;
    /**
     * Initialize WebSocket server
     */
    static initialize(httpServer: HTTPServer): void;
    /**
     * Emit new crystal event
     */
    static emitNewCrystal(crystal: any): void;
    /**
     * Emit crystal updated event
     */
    static emitCrystalUpdated(crystal: any): void;
    /**
     * Emit job progress
     */
    static emitJobProgress(jobId: string, progress: {
        status: 'waiting' | 'active' | 'completed' | 'failed';
        progress?: number;
        result?: any;
        error?: string;
    }): void;
    /**
     * Broadcast system stats
     */
    private static broadcastStats;
    /**
     * Get connected clients count
     */
    static getConnectedClients(): number;
    /**
     * Shutdown WebSocket server
     */
    static shutdown(): void;
}
