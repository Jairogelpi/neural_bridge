import type { DecisionReceipt } from './decision_receipts';
import type { Crystal } from '../types/crystal_format';
export interface CrystalRuntimeConfig {
    domain: string;
    sri_threshold?: number;
    sign_receipt?: boolean;
    enable_adversarials?: boolean;
    enable_counterfactuals?: boolean;
}
export interface CrystalExecutionResult {
    sri: number;
    pac_epsilon: number;
    fidelity_badge: string;
    invariants_passed: string[];
    invariants_failed: string[];
    invariants_total: number;
    counterfactuals_passed: string[];
    counterfactuals_failed: string[];
    counterfactuals_total: number;
    adversarial_families_tested: number;
    adversarial_pass_rate: number;
    receipt: DecisionReceipt;
    execution_log: Array<{
        timestamp: string;
        action: string;
        result: Record<string, unknown>;
    }>;
    passed: boolean;
    issues: string[];
    total_cost: number;
}
/**
 * CRYSTAL RUNTIME CORE
 *
 * This is the MVP that proves Neural Bridge is REAL:
 * 1. Takes a Crystal (JSON)
 * 2. Executes ALL verifications
 * 3. Returns signed Receipt with SRI
 *
 * EVERYTHING is deterministic and reproducible.
 */
export declare function executeCrystal(params: {
    crystal: Crystal;
    question: string;
    answer: string;
    config: CrystalRuntimeConfig;
    requester: string;
}): Promise<CrystalExecutionResult>;
/**
 * Quick validation: Does this Crystal pass basic checks?
 */
export declare function validateCrystalStructure(crystal: Crystal): {
    valid: boolean;
    errors: string[];
};
export declare const CrystalRuntime: {
    executeCrystal: typeof executeCrystal;
    validateCrystalStructure: typeof validateCrystalStructure;
};
