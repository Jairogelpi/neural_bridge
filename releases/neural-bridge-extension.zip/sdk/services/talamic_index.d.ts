import { Hypervector } from '../math/hypervector';
export interface AtlasNode {
    id: string;
    vector: Hypervector;
    metadata: {
        source_id: string;
        preview: string;
        domain: string;
        is_crystallized: boolean;
    };
}
/**
 * TALAMIC INDEX (The Holographic Atlas) 🪐📐
 *
 * Capability: Massive-scale ingestion.
 * Unlike RAG, this doesn't store billions of vectors in a slow database.
 * it projects documents into a "Conceptual Manifold" using HDC.
 */
export declare class TalamicIndex {
    private static atlas;
    private static spatialIndex;
    private static isInitialized;
    /**
     * INITIALIZE: Loads the Atlas from persistent storage.
     */
    /**
     * INITIALIZE: Loads the Atlas from persistent storage.
     */
    static initialize(): Promise<void>;
    /**
     * INGEST: Projects text into the Geometric Atlas.
     */
    static ingest(text: string, sourceId: string, domain: string): Promise<void>;
    /**
     * SYNC TO PERSISTENT STORAGE (The Infinite Cache)
     */
    private static syncToPersistentStorage;
    /**
     * SEARCH: O(1) Retrieval via Spatial Hashing.
     */
    static search(query: string, topK?: number): Promise<{
        node: AtlasNode;
        score: number;
    }[]>;
    /**
     * MARK CRYSTALLIZED
     */
    static setCrystallized(nodeId: string): void;
    static getAtlasSize(): number;
    private static generateSecureUUID;
}
