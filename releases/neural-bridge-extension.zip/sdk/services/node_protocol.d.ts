import { Crystal } from '../types/crystal_format';
/**
 * SOVEREIGN NODE PROTOCOL (The Hive Interface) 🐝🌐
 *
 * Capability: Enables decentralized "Handshakes" between Neural Nodes.
 * It strictly verifies semantic integrity via ZK-Proofs before allowing
 * external knowledge to enter the local lattice.
 */
export declare class SovereignNodeProtocol {
    /**
     * PROCESS INCOMING CRYSTAL (The Immune System Gate)
     * 1. Verifies ZKP Receipts (Privacy Proof)
     * 2. Checks Semantic Hash Integrity
     * 3. Calculates "Collective Value" (Does this help the Hive?)
     */
    static receiveCrystal(incomingCrystal: Crystal, senderReputation: number): Promise<{
        accepted: boolean;
        reason: string;
        collective_fe_delta: number;
    }>;
    /**
     * ASSIMILATE CRYSTAL INTO LATTICE
     */
    private static assimilate;
    /**
     * COLLECTIVE FREE ENERGY SCORER (The Hive Brain)
     *
     * Calculates F = Complexity - Accuracy
     * relative to the *Local Node's* existing knowledge base.
     *
     * If the incoming crystal explains local data BETTER than local axioms,
     * it reduces Free Energy (Negative Delta) -> ACCEPT.
     */
    private static evaluateCollectiveUtility;
    /**
     * Verifies Zero-Knowledge Proof receipts attached to the Crystal.
     * Returns true if all proofs are valid.
     */
    private static verifyZKP;
}
