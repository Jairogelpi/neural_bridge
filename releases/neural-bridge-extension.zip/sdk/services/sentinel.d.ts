export interface SentinelEvent {
    type: 'VACCINE_SYNTHESIS' | 'ORACLE_DREAM' | 'JURY_ESCALATION' | 'FRACTAL_COMPRESSION' | 'ECONOMIC_ROUTING' | 'CRYSTAL_FUSION' | 'ENTROPY_PURIFICATION' | 'CHAOS_EVOLUTION' | 'SEMANTIC_HANDSHAKE' | 'SOVEREIGN_CONSENSUS';
    severity: 'info' | 'warning' | 'critical';
    message: string;
    details: Record<string, unknown>;
    timestamp: string;
}
/**
 * THE SENTINEL (Global Observability) 👁️
 *
 * Central hub for monitoring the "Semantic Health" of the Neural Bridge.
 * It tracks all Omega-level events and provides real-time telemetry.
 */
export declare class Sentinel {
    /**
     * Emits an event to the global observability store.
     */
    static emit(event: Omit<SentinelEvent, 'timestamp'>): Promise<void>;
    /**
     * SEMANTIC ENTANGLEMENT 🕸️
     *
     * When a new vaccine is created, the Sentinel scans the entire Knowledge Lattice
     * to find existing Crystals that are "infected" by the newly discovered fallacy.
     */
    static triggerEntanglement(vaccineId: string): Promise<number>;
}
