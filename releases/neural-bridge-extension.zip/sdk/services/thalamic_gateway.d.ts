import { Crystal } from '../types/crystal_format';
/**
 * THALAMIC GATEWAY (Attentional Routing) 🧠⚡
 *
 * Capability: The "Thalamic Filter".
 * It receives a user query, scans the massive Atlas (TalamicIndex),
 * and decides whether to provide a "Shallow" answer or trigger a
 * "Deep" Crystallization on the relevant data.
 */
export declare class ThalamicGateway {
    /**
     * ROUTE QUERY: The main entry point for massive context questions.
     * 1. Search Atlas for Resonant Nodes.
     * 2. If node is already Crystallized, use it.
     * 3. If "Shallow", trigger Lazy Crystallization.
     */
    static route(query: string, domain: string): Promise<{
        bestCrystal?: Crystal;
        contextPreview: string;
        isLazyTriggered: boolean;
    }>;
}
