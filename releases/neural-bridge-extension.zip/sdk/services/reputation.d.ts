import type { Crystal } from '../types/crystal_format';
export interface ReputationChange {
    author_id: string;
    delta: number;
    reason: string;
    evidence_hash: string;
}
/**
 * Evidence-Backed Reputation System
 * Rewards authors for providing verifiable, high-quality knowledge.
 */
export declare class ReputationSystem {
    /**
     * Calculate and apply reputation changes based on crystal quality and usage.
     */
    static rewardQuality(crystal: Crystal): Promise<number>;
    /**
     * Penalize reputation for detected contradictions or failed verifications.
     */
    static penalize(authorId: string, reason: string): Promise<number>;
    /**
     * Rewards an author for participating in a Jury Case.
     */
    static rewardJuryParticipation(authorId: string, caseId: string): Promise<number>;
}
