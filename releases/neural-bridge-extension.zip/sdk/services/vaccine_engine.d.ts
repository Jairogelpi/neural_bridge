import type { Crystal } from '../types/crystal_format';
export interface SemanticVaccine {
    vaccine_id?: string;
    error_signature_hash: string;
    fallacy_type: string;
    meta_invariant: {
        rule: string;
        logical_constraint: string;
        prohibited_pattern: string;
    };
    context_domain: string;
}
export interface Contradiction {
    claim_a: string;
    claim_b: string;
}
/**
 * SEMANTIC IMMUNITY ENGINE (Vaccine Synthesis)
 *
 * Logic:
 * 1. Detect: TruthVault identifies a contradiction.
 * 2. Extract: Identify the "Logical DNA" (the abstract reason for the fail).
 * 3. Synthesize: Create a Meta-Invariant that prevents this logical pattern.
 * 4. Immunize: Inject the vaccine into all future verifications in the same domain.
 */
export declare class VaccineEngine {
    /**
     * Extracts the "Logical DNA" of a contradiction and creates a vaccine.
     */
    static synthesizeFromContradiction(crystal: Crystal, contradiction: Contradiction): Promise<SemanticVaccine | null>;
    /**
     * 🔮 PRECOGNITIVE VACCINATION
     * Synthesizes a vaccine for a failure that hasn't happened yet (predicted by the Oracle).
     */
    static synthesizePrecognitiveVaccine(crystal: Crystal, predictedFailure: string): Promise<SemanticVaccine | null>;
    /**
     * Returns relevant vaccines for a given source text to be used as pre-emptive guards.
     */
    static getActiveGuards(source: string, domain: string): Promise<SemanticVaccine[]>;
}
