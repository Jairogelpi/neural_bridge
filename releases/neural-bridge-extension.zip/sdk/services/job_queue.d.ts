import { Queue, Job } from 'bullmq';
export declare const crystallizationQueue: Queue<any, any, string, any, any, string>;
export declare const multimodalQueue: Queue<any, any, string, any, any, string>;
export declare const upgradeQueue: Queue<any, any, string, any, any, string>;
export interface CrystallizationJobData {
    text: string;
    options: {
        tier?: 'flash' | 'smart' | 'deep';
        domain?: string;
        autoUpgrade?: boolean;
    };
    userId?: string;
    requestId: string;
}
export interface MultimodalJobData {
    type: 'audio' | 'video';
    fileBuffer: Buffer;
    metadata: Record<string, any>;
    options: Record<string, any>;
    userId?: string;
    requestId: string;
}
export interface UpgradeJobData {
    crystalId: string;
    text: string;
    domain: string;
}
/**
 * Job Queue Manager
 */
export declare class JobQueueManager {
    private static crystallizationWorker;
    private static multimodalWorker;
    private static upgradeWorker;
    /**
     * Start all workers
     */
    static startWorkers(): Promise<void>;
    /**
     * Add crystallization job
     */
    static addCrystallizationJob(data: CrystallizationJobData): Promise<Job>;
    /**
     * Add multimodal processing job
     */
    static addMultimodalJob(data: MultimodalJobData): Promise<Job>;
    /**
     * Add background upgrade job
     */
    static addUpgradeJob(data: UpgradeJobData): Promise<Job>;
    /**
     * Get job status
     */
    static getJobStatus(queue: Queue, jobId: string): Promise<{
        status: 'waiting' | 'active' | 'completed' | 'failed' | 'delayed';
        progress?: number;
        result?: any;
        error?: string;
    }>;
    /**
     * Get queue stats
     */
    static getStats(): Promise<{
        crystallization: {
            [index: string]: number;
        };
        multimodal: {
            [index: string]: number;
        };
        backgroundUpgrade: {
            [index: string]: number;
        };
    }>;
    /**
     * Graceful shutdown
     */
    static shutdown(): Promise<void>;
}
