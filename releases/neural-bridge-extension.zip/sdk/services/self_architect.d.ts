/**
 * THE SELF-ARCHITECT (The Ouroboros Loop) 🐍♾️
 *
 * Capability: The system treats its own Source Code as a "domain" of knowledge.
 * It periodically "abduces" improvements to its own architecture based on
 * live performance metrics (Free Energy, Latency, Entropy).
 */
export declare class SelfArchitect {
    /**
     * REFLECTIVE AUDIT: The AI reads its own logic files.
     */
    static auditArchitecture(): Promise<string>;
    /**
     * THE OUROBOROS LOOP ♾️ (Alpha-Omega)
     * Continuous self-monitoring and anatomical expansion.
     */
    static runOuroborosLoop(): Promise<void>;
    /**
     * THE OUROBOROS PULSE: Propose improvements to itself.
     */
    static ouroborosPulse(): Promise<void>;
    private static logSovereignTask;
}
