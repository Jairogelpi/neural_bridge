export interface EvolvedOntology {
    domain: string;
    axioms: string[];
    confidence: number;
    discovered_at: string;
}
/**
 * DOMAIN EVOLVER 🧠🌀
 *
 * Goal: Autonomously discover and map new knowledge domains in real-time.
 * If the system encounters a "random" or unknown topic, it synthesizes
 * an ad-hoc ontology to master it.
 */
export declare class DomainEvolver {
    private static evolvedCache;
    /**
     * Detects or evolves a domain from unstructured text.
     */
    static evolveDomain(text: string): Promise<EvolvedOntology>;
}
