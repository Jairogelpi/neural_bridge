export interface SonicResponse {
    audio_buffer: any;
    is_verified: boolean;
    correction_needed: boolean;
    metadata: any;
}
/**
 * SONIC REALITY STREAMER (The Real-Time Voice Guardian) 🎙️🛡️
 *
 * Goal: Deliver sub-50ms emotional voice responses while
 * verifying truth asynchronously in the back-channel.
 */
export declare class SonicStream {
    private static activeContext;
    /**
     * Streams a response with "Late-Correction" logic.
     */
    static streamVerifiedVoice(text: string, domain: string): Promise<SonicResponse>;
    private static triggerLateCorrection;
}
