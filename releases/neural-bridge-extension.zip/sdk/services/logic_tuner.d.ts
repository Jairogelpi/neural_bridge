import type { Crystal } from '../types/crystal_format';
/**
 * ADAPTIVE LOGIC TUNER (The Self-Optimizer) ⚙️🌀
 *
 * Goal: Eliminate hardcoded constants (0.6, 0.75).
 * Thresholds now adapt based on the domain's maturity and volatility.
 */
export declare class LogicTuner {
    /**
     * INFERENTIAL AUTO-CALIBRATION ⚖️🌀
     *
     * Calculates the optimal SNR threshold for a domain by running
     * differential tests between verified truths and synthetic noise.
     */
    static autoCalibrationLoop(domain: string, crystals: Crystal[]): Promise<number>;
    /**
     * Calculates the optimal SNR threshold for a domain.
     * Delegates to auto-calibration if possible.
     */
    static getOptimalThreshold(domainStats: {
        avg_q: number;
        volatility: number;
        calibrated_threshold?: number;
    }): number;
    /**
     * Computes the "Reality Stability Index" for a domain.
     */
    static calculateStability(crystals: Crystal[]): number;
}
