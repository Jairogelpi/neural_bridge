import { type Crystal } from '../types/crystal_format';
export interface CrystallizationOptions {
    domain?: string;
    author?: {
        id: string;
        name: string;
        reputation: number;
    };
    compress?: boolean;
    tier?: 'community' | 'trusted' | 'sovereign';
}
/**
 * CRYSTALLIZATION ENGINE ("The Refinery")
 *
 * Transforms raw, chaos-bound text into immutable, verified Crystals.
 * This is the Deterministic replacement for "Embeddings".
 */
export declare class CrystallizationService {
    /**
     * Mine a Crystal from raw text.
     * This process is strict, expensive, and deterministic.
     */
    static mineCrystal(text: string, options?: CrystallizationOptions): Promise<Crystal>;
    /**
     * VECTOR-FIELD AXIOMATIC EXTRACTION 🌐📐
     *
     * REPLACES WORD-MATCHING WITH GEOMETRIC SINGULARITY DETECTION.
     * Identifies "Logical Gravity" points where concept vectors are too dense
     * to be anything other than a fundamental invariant (MUST).
     */
    private static vectorFieldExtraction;
    /**
     * FLASH CRYSTALS ⚡
     *
     * Now upgraded to Sovereign Reality (HDC Vector Field Extraction).
     * No more regex. Pure math.
     */
    static mineProtoCrystal(text: string, domain?: string, metadata?: any): Crystal;
    /**
     * SUBLIMATION REFINERY ⚗️
     *
     * Upgrades a dirty "Proto-Crystal" into a verified "Diamond Crystal" just-in-time.
     */
    static sublimateCrystal(proto: Crystal): Promise<Crystal>;
}
