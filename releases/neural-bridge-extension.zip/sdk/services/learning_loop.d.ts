/**
 * LEARNING LOOP (The Background Thinker) 🔄
 */
export declare class LearningLoop {
    private static intervals;
    static start(domain: string, intervalMs?: number): void;
    static stop(domain: string): void;
}
