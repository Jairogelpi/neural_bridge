import type { Crystal } from '../types/crystal_format';
export interface Contradiction {
    crystal_id_a: string;
    crystal_id_b: string;
    claim_a: string;
    claim_b: string;
    explanation: string;
    severity: 'critical' | 'warning';
}
/**
 * The Self-Healing Truth Vault
 * Detects and resolves contradictions across all stored knowledge crystals.
 */
export declare class TruthVault {
    /**
     * Scan for contradictions between a new crystal and existing ones.
     */
    static scanForContradictions(newCrystal: Crystal): Promise<Contradiction[]>;
    /**
     * Heal the vault by marking contradictory crystals or generating a resolution crystal.
     * 💉 INTEGRATION: Synthesize Semantic Vaccines from contradictions.
     */
    static heal(contradictions: Contradiction[]): Promise<void>;
    /**
     * Retrieve the best Crystal for a given query/domain.
     * This replaces RAG vector search with deterministic key/tag lookup.
     */
    static retrieveBestCrystal(params: {
        domain: string;
        tags?: string[];
    }): Promise<Crystal | null>;
    /**
     * FUZZY RETRIEVAL (The RAG Killer) 🔫
     * Uses LSH Hamming Distance to find semantically similar crystals WITHOUT embeddings.
     * + RLM (Active Inference): Re-ranks based on learned utility.
     */
    static retrieveSemanticallySimilar(query: string, domain: string): Promise<Crystal[]>;
    /**
     * Checks if the incoming text contradicts previously verified truths.
     * Use LSH/HDC Similarity to find relevant truths quickly.
     */
    static checkReality(text: string, domain: string): Promise<{
        is_conflict: boolean;
        contradiction_reason?: string;
        conflicting_entry?: any;
    }>;
    /**
     * Corrects a conflicting reality based on the Truth Vault's source of truth.
     */
    static healReality(text: string, conflict: {
        reason: string;
        entry: any;
    }): Promise<string>;
    /**
     * Crystallizes a new truth into the global archive.
     */
    static saveTruth(crystal: Crystal): Promise<void>;
}
export declare const truthVault: typeof TruthVault;
