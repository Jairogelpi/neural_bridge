/**
 * FRACTAL COMPRESSION ENGINE v3.0 (OMEGA) 🌀
 *
 * Goal: Achieve "Infinite Context" by recursively distilling knowledge into
 * Meta-Invariants while maintaining logic at every "zoom level".
 *
 * This engine handles massive data by creating a "Knowledge Hologram":
 * a 10,000-page reality condensed into a dense Axiomatic Core.
 */
export declare class FractalCompressor {
    static MAX_TOKEN_TARGET: number;
    static LAYER_REDUCTION_FACTOR: number;
    /**
     * Entry point for Fractal Compression.
     * Recursively shrinks context until it fits the target size or hits recursion depth.
     */
    static compress(fullText: string, depth?: number): Promise<string>;
    /**
     * Extracts absolute logic ("Invariants") from a text chunk.
     */
    private static distillToAxioms;
    /**
     * Fuses multiple axiomatic shards into a coherent "Meta-Reality".
     */
    private static fuseAndRefine;
    /**
     * TOPOLOGICAL SHARDING: Shards reality at Vector Phase Shifts.
     * Uses HDC Trajectory Analysis to identify semantic boundaries.
     */
    private static shardReality;
    /**
     * INTEGRITY CHECK (Recall Challenge)
     * Proof that the compression is "Zero-Loss" in a logical sense.
     */
    static verifyIntegrity(original: string, compressed: string): Promise<number>;
}
