import type { Crystal } from '../types/crystal_format';
export interface AdversarialFamily {
    family_id: string;
    concept: string;
    templates: string[];
    false_variants: string[];
}
export interface MetamorphicTest {
    id: string;
    original_question: string;
    transformations: {
        type: 'synonym' | 'reorder' | 'unit_change' | 'paraphrase';
        transformed_question: string;
        expected_consistency: boolean;
    }[];
}
/**
 * Generate adaptive adversarial invariants DYNAMICALLY from Crystal content
 * NO HARDCODED TEMPLATES - uses real constraints from the Crystal
 */
export declare function generateAdaptiveAdversarials(params: {
    crystal: Crystal;
    domain: string;
    count?: number;
}): AdversarialFamily[];
/**
 * Generate chained logic adversarials (A -> B, B -> C, then A -> C)
 * Tests multi-step reasoning capabilities
 */
export declare function generateChainedAdversarials(params: {
    crystal: Crystal;
}): AdversarialFamily[];
/**
 * Create metamorphic tests to ensure consistency
 * Tests REAL semantic understanding, not pattern matching
 */
export declare function generateMetamorphicTests(params: {
    original_question: string;
    expected_answer: string;
}): MetamorphicTest;
/**
 * Counterfactual Transfer Test Generator - REAL from Crystal
 */
export declare function generateCounterfactualTest(params: {
    crystal: Crystal;
    domain: string;
}): {
    id: string;
    question: string;
    reasoning_requirements: string[];
    not_in_crystal: boolean;
    requires_derivation: boolean;
};
export declare const AntiGaming: {
    generateAdaptiveAdversarials: typeof generateAdaptiveAdversarials;
    generateChainedAdversarials: typeof generateChainedAdversarials;
    generateMetamorphicTests: typeof generateMetamorphicTests;
    generateCounterfactualTest: typeof generateCounterfactualTest;
};
