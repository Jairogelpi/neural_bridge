export interface IngestProgress {
    totalChunks: number;
    processedChunks: number;
    status: string;
}
/**
 * FRACTAL INGEST SERVICE 🌀
 *
 * Outperforms classic LLM context windows (1M tokens) by transforming
 * massive data into a persistent, navigable, holographic Knowledge Tree.
 */
export declare class FractalIngestService {
    /**
     * Ingest a large corpus of text fractally.
     */
    static ingest(text: string, domain?: string, onProgress?: (p: IngestProgress) => void): Promise<string>;
    /**
     * Persist Crystal to Supabase.
     */
    private static persist;
}
