/**
 * THE STOCHASTIC ENGINE 🌀
 *
 * Goal: Transform chaotic, unstructured, or random input into organized
 * semantic potential. It models 'Randomness' as a high-dimensional
 * information source rather than noise.
 */
export declare class StochasticEngine {
    /**
     * PURIFICATION: Measures true Shannon Bit-Entropy using the HDC manifestation.
     * No more word-level estimations. Pure bit-perfect complexity analysis.
     */
    static processChaos(input: string): Promise<{
        semanticPotential: number;
        entropy: number;
    }>;
    /**
     * PREDICTIVE CODING: Calculates the 'Prediction Error' between input and existing Axioms.
     * Only 'Surprising' information (high prediction error) is passed to refinement.
     */
    static performPredictiveCoding(input: string, domain: string): Promise<{
        predictionError: number;
        residualContent: string;
    }>;
    /**
     * Balances entropy within the Knowledge Lattice to ensure that
     * rapid adaptation doesn't lead to logic fragmentation.
     */
    static entropyBalancer(currentEntropy: number): Promise<boolean>;
}
