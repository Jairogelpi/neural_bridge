import type { Crystal } from '../types/crystal_format';
export interface RealityBranch {
    branch_id: string;
    parent_crystal_id: string;
    branch_name: string;
    status: 'draft' | 'simulating' | 'merged' | 'rejected';
    modifications: Record<string, unknown>;
    created_at: string;
}
/**
 * REALITY BRANCHER (Semantic Git) 🌳
 *
 * Capability: Allows "Hypothetical Truths" to be developed in isolation
 * without contaminating the Master Lattice. Once validated, branches can
 * be Atomically Merged.
 */
export declare class RealityBrancher {
    /**
     * Creates a new Reality Branch from an existing Crystal.
     */
    static createBranch(parent: Crystal, name: string): Promise<RealityBranch>;
    /**
     * Atomically merges a branch back into the Parent Crystal.
     */
    static merge(branch: RealityBranch, parent: Crystal): Promise<Crystal>;
}
