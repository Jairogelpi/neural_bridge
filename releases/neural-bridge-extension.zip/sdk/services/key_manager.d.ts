/**
 * KEY MANAGER (The Sovereign Vault) 🔑🛡️
 *
 * Capability: Secure Key Management.
 * Manages user-provided API keys in persistent storage.
 * Prioritizes user keys for total autonomy.
 */
export declare class KeyManager {
    private static STORAGE_KEY;
    /**
     * SAVE KEYS: Stores a set of API keys.
     */
    static saveKeys(keys: Record<string, string>): Promise<void>;
    /**
     * GET KEY: Retrieves a specific key if it exists.
     */
    static getKey(provider: string): Promise<string | null>;
    /**
     * CLEAR KEYS
     */
    static clearKeys(): Promise<void>;
    /**
     * GET ALL KEYS: Returns the current set of keys.
     */
    static getAllKeys(): Promise<Record<string, string>>;
}
