import type { Crystal } from '../types/crystal_format';
/**
 * REINFORCEMENT LOGIC MODELING (RLM) ENGINE 🧠
 *
 * Implements "Active Inference" for Knowledge Crystals.
 * Converts static data into "Living Wisdom" that evolves based on utility.
 */
export declare class RLMEngine {
    /**
     * DYNAMIC HYPERPARAMETERS 0️⃣
     *
     * ALPHA and C react to the domain's Real-Time Stability.
     */
    private static getDynamicParams;
    /**
     * Updates the Crystal's Q-Score based on user feedback.
     * Uses Exponential Moving Average (EMA) approximation for Q-Learning.
     *
     * @param crystal The crystal to update
     * @param reward +1 (Helpful), -1 (Harmful/Hallucinated), 0 (Neutral)
     */
    static updateCrystalUtility(crystal: Crystal, reward: number, domain?: string): Promise<Crystal>;
    /**
     * Calculates the Exploration Bonus using UCB1.
     * High bonus for rarely used crystals.
     * Low bonus for well-known crystals.
     */
    static calculateExplorationBonus(crystal: Crystal, totalSystemUsage: number, domain?: string): Promise<number>;
    /**
     * Rank candidates by combining Exploitation (Q-Score) + Exploration (Bonus) + Certainty (Fisher).
     */
    static rankCandidates(candidates: Crystal[], totalSystemUsage: number, domain?: string): Promise<Crystal[]>;
}
