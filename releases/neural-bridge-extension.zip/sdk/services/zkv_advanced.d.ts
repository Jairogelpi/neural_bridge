export interface ZKPPayload {
    commitment: string;
    nullifier: string;
    proof: string;
}
/**
 * Zero-Knowledge Verification (ZKV) Module
 * Allows verifying that a model knows "the truth" without exposing the actual data.
 */
export declare class ZKAdvancedVerifier {
    /**
     * Create a commitment to private data (SHA-256 with salt)
     */
    static generateCommitment(data: string, salt: string): Promise<string>;
    /**
     * Verify that the answer provided by an LLM matches the hidden private data
     * without the LLM ever seeing the original data or the salt.
     */
    static verifyBlind(params: {
        providedAnswer: string;
        commitment: string;
        salt: string;
        privateData: string;
    }): Promise<boolean>;
    /**
     * Prove that a claim is true without revealing the claim itself.
     * Returns a verifiable receipt.
     */
    static generateZKPReceipt(claim: string): Promise<ZKPPayload>;
}
