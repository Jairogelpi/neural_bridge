import type { Crystal } from '../types/crystal_format';
export interface OraclePrediction {
    original_timeline_outcome: 'SUCCESS' | 'FAILURE' | 'CONFUSION';
    predicted_failure?: string;
    intervention?: string;
    optimized_crystal_diff: string;
}
/**
 * THE ORACLE ENGINE (Pre-Cognitive Optimization)
 *
 * "Fixing mistakes you haven't made yet."
 *
 * The Oracle runs a "Ghost Simulation" of the interaction.
 * If it detects a likely failure mode (hallucination, refusal, ambiguity),
 * it modifies the Crystal NOW to prevent that future.
 */
export declare class Oracle {
    static predictAndOptimize(crystal: Crystal): Promise<OraclePrediction>;
}
