import type { Crystal } from '../types/crystal_format';
/**
 * GLOBAL CORTEX (Collective Intelligence) 🌌🤝
 *
 * Goal: A decentralized knowledge network where every verified truth
 * discovered by one user strengthens the entire ecosystem.
 */
export declare class GlobalCortex {
    /**
     * Publishes a verified Crystal to the Global Ledger.
     * Knowledge is anonymized (author_id removed or masked).
     */
    static publish(crystal: Crystal): Promise<void>;
    /**
     * Retrieves knowledge from the global pool using Mutual Information.
     * Knowledge is selected if it maximizes Information Gain relative to the query.
     */
    static globalRetrieve(query: string): Promise<Crystal[]>;
}
