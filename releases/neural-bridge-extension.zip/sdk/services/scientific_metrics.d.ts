export interface PACBounds {
    epsilon: number;
    delta: number;
    n: number;
}
export interface SRIMetrics {
    raw_score: number;
    pac_bounds: PACBounds;
    sri: number;
    fidelity_badge: string;
    acceptance_status: 'ACCEPT' | 'FAIL' | 'NEEDS_REVIEW';
    statistical_context: {
        mean: number;
        std_dev: number;
        sample_size: number;
        risk_factor: number;
        threshold_applied: number;
    };
    reputation_impact?: number;
}
export interface KnowledgeABI {
    facts: AtomicFact[];
    constraints: LogicalConstraint[];
    derivations: InferenceRule[];
    counterfactuals: CounterfactualTest[];
}
export interface AtomicFact {
    id: string;
    value: string | number | boolean;
    type: 'string' | 'number' | 'boolean' | 'regex';
    deterministic_check?: string;
}
export interface LogicalConstraint {
    id: string;
    rule: 'MUST' | 'NEVER' | 'IF_THEN';
    condition: string;
    symbolic_validator?: string;
}
export interface InferenceRule {
    id: string;
    antecedent: string;
    consequent: string;
    rule: string;
}
export interface CounterfactualTest {
    id: string;
    question: string;
    expected_reasoning_path: string[];
    not_in_crystal: boolean;
}
/**
 * Calculate Proxy PAC-style Confidence Bound using Hoeffding inequality
 * Note: This is an OPERATIONAL BOUND, not a theoretical guarantee (LLMs are not i.i.d.)
 */
export declare function calculatePACBound(params: {
    n: number;
    delta?: number;
}): PACBounds;
/**
 * Calculate dynamic acceptance threshold based on risk factor and statistical confidence
 * Higher risk requires higher confidence (lower epsilon) or higher raw score.
 */
export declare function calculateAcceptanceThreshold(params: {
    risk_factor: number;
    epsilon: number;
}): number;
/**
 * Calculate Semantic Reliability Index (SRI)
 * This is a REPRODUCIBLE EMPIRICAL INDICATOR, not a mathematical guarantee
 */
export declare function calculateSRI(params: {
    raw_score: number;
    invariant_count: number;
    risk_factor?: number;
    delta?: number;
    historical_scores?: number[];
}): SRIMetrics;
/**
 * External Deterministic Verification
 * Reduces "LLM-judging-LLM" bias by using regex, parsers, and constraints
 */
export declare function externalDeterministicVerification(params: {
    fact: AtomicFact;
    actual_value: unknown;
}): {
    passed: boolean;
    method: string;
};
/**
 * Format SRI for scientific display
 */
export declare function formatSRI(sri: SRIMetrics): string;
/**
 * Calculate reputation impact based on SRI and Tier.
 * High tier authors have more to lose (Higher Slash).
 */
export declare function calculateReputationImpact(params: {
    sri: number;
    tier: 'community' | 'verified' | 'certified' | 'trusted' | 'sovereign';
    threshold: number;
}): number;
export declare const ScientificMetrics: {
    calculatePACBound: typeof calculatePACBound;
    calculateAcceptanceThreshold: typeof calculateAcceptanceThreshold;
    calculateSRI: typeof calculateSRI;
    externalDeterministicVerification: typeof externalDeterministicVerification;
    calculateReputationImpact: typeof calculateReputationImpact;
    formatSRI: typeof formatSRI;
};
