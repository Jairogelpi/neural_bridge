import { type Crystal } from '../../types/crystal_format';
export interface AudioMetadata {
    duration_seconds: number;
    sample_rate: number;
    channels: number;
    format: string;
    file_size_bytes: number;
}
export interface TranscriptSegment {
    start: number;
    end: number;
    text: string;
    confidence: number;
}
export interface AcousticFeatures {
    avg_pitch?: number;
    avg_energy: number;
    tempo_bpm?: number;
    voice_signature: string;
    spectral_centroid?: number;
}
export interface EmotionPoint {
    timestamp: number;
    emotion: 'neutral' | 'happy' | 'sad' | 'angry' | 'surprised' | 'fearful';
    confidence: number;
    energy: number;
}
export interface Speaker {
    id: string;
    name?: string;
    segments: number[];
    voice_signature: string;
}
export interface AudioCrystal extends Crystal {
    audio_metadata: AudioMetadata;
    transcript: {
        text: string;
        segments: TranscriptSegment[];
        language?: string;
    };
    acoustic_features: AcousticFeatures;
    emotion_timeline: EmotionPoint[];
    speakers?: Speaker[];
    audio_hash: string;
}
/**
 * AUDIO CRYSTALLIZER 🎵💎
 *
 * Converts audio files into verifiable Audio Crystals with:
 * - Transcription (Whisper API)
 * - Acoustic analysis (energy, pitch, tempo)
 * - Holographic audio fingerprinting (HDC-based)
 * - Emotion detection from acoustic features
 * - Speaker diarization
 */
export declare class AudioCrystallizer {
    /**
     * Main entry point: Audio File → Audio Crystal
     */
    static crystallize(audioBuffer: Buffer, metadata: Partial<AudioMetadata>, options?: {
        includeEmotions?: boolean;
        includeSpeakers?: boolean;
        tier?: 'free' | 'premium';
    }): Promise<AudioCrystal>;
    /**
     * TRANSCRIPTION using Whisper API
     */
    private static transcribe;
    /**
     * ACOUSTIC ANALYSIS
     * Extract pitch, energy, tempo from audio buffer
     */
    private static analyzeAcoustics;
    /**
     * HOLOGRAPHIC AUDIO FINGERPRINT
     * Create HDC-based hash of audio waveform
     */
    private static computeAudioHash;
    /**
     * EMOTION DETECTION from acoustic features
     */
    private static detectEmotions;
    /**
     * SPEAKER DIARIZATION
     * Identify different speakers in audio
     */
    private static diarizeSpeakers;
    /**
     * HELPER: Convert audio buffer to normalized samples
     */
    private static bufferToSamples;
    /**
     * HELPER: Compute RMS energy
     */
    private static computeEnergy;
    /**
     * HELPER: Compute voice signature (HDC)
     */
    private static computeVoiceSignature;
    /**
     * HELPER: Extract constraints from transcript
     */
    private static extractConstraints;
    /**
     * HELPER: Generate semantic invariants
     */
    private static generateInvariants;
}
