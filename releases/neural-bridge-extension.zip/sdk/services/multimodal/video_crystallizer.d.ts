import { type Crystal } from '../../types/crystal_format';
export interface VideoMetadata {
    duration_seconds: number;
    width: number;
    height: number;
    fps: number;
    codec: string;
    file_size_bytes: number;
}
export interface VisualFeatures {
    objects: Array<{
        label: string;
        confidence: number;
        bbox?: number[];
    }>;
    faces: Array<{
        bbox: number[];
        landmarks?: any;
    }>;
    text_detected: string;
    dominant_colors: string[];
    description: string;
}
export interface Keyframe {
    timestamp: number;
    frame_hash: string;
    scene_id: string;
    visual_features: VisualFeatures;
    frame_data?: string;
}
export interface Scene {
    id: string;
    start: number;
    end: number;
    description: string;
    keyframe_indices: number[];
}
export interface VideoCrystal extends Crystal {
    video_metadata: VideoMetadata;
    keyframes: Keyframe[];
    scenes: Scene[];
    visual_merkle_root: string;
}
/**
 * VIDEO CRYSTALLIZER 🎬💎
 *
 * Uses Gemini 1.5 Flash Vision (FREE) for best cost/performance ratio.
 * Processes video into verifiable crystals with visual semantic merkle trees.
 */
export declare class VideoCrystallizer {
    private static gemini;
    private static getGeminiClient;
    /**
     * Main entry point: Video File → Video Crystal
     */
    static crystallize(videoBuffer: Buffer, metadata: Partial<VideoMetadata>, options?: {
        keyframeInterval?: number;
        useLocal?: boolean;
        saveFrames?: boolean;
    }): Promise<VideoCrystal>;
    /**
     * EXTRACT KEYFRAMES from video (using ffmpeg)
     */
    private static extractKeyframes;
    /**
     * ANALYZE KEYFRAMES in parallel using Gemini Flash Vision (FREE!)
     */
    private static analyzeKeyframesParallel;
    /**
     * ANALYZE SINGLE KEYFRAME with Gemini Flash Vision
     */
    private static analyzeKeyframe;
    /**
     * PARSE Gemini response into structured data
     */
    private static parseGeminiResponse;
    /**
     * DETECT SCENES based on visual continuity
     */
    private static detectScenes;
    /**
     * BUILD VISUAL SEMANTIC MERKLE TREE
     */
    private static buildVisualMerkleTree;
    /**
     * GENERATE overall description
     */
    private static generateDescription;
    /**
     * EXTRACT constraints from visual features
     */
    private static extractConstraints;
    /**
     * GENERATE invariants for verification
     */
    private static generateInvariants;
}
