import type { Crystal } from '../types/crystal_format';
/**
 * SEMANTIC ENTROPY AUDIT (The Noise Filter) 🛡️
 *
 * Goal: Mathematically calculate the "Information Gain" vs "Semantic Noise"
 * of a Crystal relative to a query. This ensures we only inject context
 * that strengthens the "Gravity Well" of the truth.
 */
export declare class EntropyAudit {
    /**
     * Calculates the Signal-to-Noise Ratio (SNR) of a set of candidates.
     * Returns the "Minimum Sufficient Set" (MSS) of Crystals.
     */
    static audit(query: string, candidates: Crystal[], threshold?: number): Crystal[];
    /**
     * Measures the "Semantic Drift" potential of a context package.
     * High entropy = high hallucination risk.
     */
    static calculateDriftRisk(query: string, context: Crystal[]): number;
}
