import type { Crystal } from '../types/crystal_format';
export interface JuryEscalation {
    case_id?: string;
    context_id: string;
    issue_description: string;
    consensus_score_ai: number;
    status: 'pending' | 'resolved' | 'failed';
}
/**
 * JURY OF TRUTH SERVICE (Human Oracle)
 *
 * Logic:
 * 1. Escalate: When AI consensus is low/divided, create a 'Jury Case'.
 * 2. Notify: Experts in the relevant domain are alerted (simulation).
 * 3. Sign: Experts verify and sign the truth with cryptographic signatures.
 * 4. Finalize: Once a threshold of signatures is reached, the Crystal is finalized.
 */
export declare class JuryService {
    /**
     * Get all pending jury cases
     */
    static getPendingCases(): Promise<JuryEscalation[]>;
    /**
     * Escalates an uncertain claim to the human jury.
     */
    static escalate(crystal: Crystal, consensusScore: number, reason: string): Promise<string | null>;
    /**
     * Records a cryptographically signed vote from an expert.
     + In a real implementation, 'signature' would be verified against the expert's public key.
     */
    static recordExpertVote(params: {
        case_id: string;
        author_id: string;
        decision: 'ACCEPT' | 'FAIL';
        signature: string;
    }): Promise<boolean>;
    private static verifySignature;
    private static finalizeCase;
}
