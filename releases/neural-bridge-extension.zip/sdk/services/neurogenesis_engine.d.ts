export interface CapabilityGap {
    id: string;
    description: string;
    required_logic: string;
    context_domain: string;
    detected_at: string;
}
/**
 * NEUROGENESIS ENGINE (The Creator) 🧬🌌
 *
 * Capability: Synthetic Neurogenesis.
 * Detects gaps in the system's "Mathematical Anatomy" and spawns
 * new TypeScript services to bridge those gaps autonomously.
 */
export declare class NeurogenesisEngine {
    private static activeBirths;
    /**
     * DETECT ANOMALY (The Awareness)
     * Called when an external query or internal abductive loop fails
     * due to a missing functional primitive.
     */
    static detectCapabilityGap(gap: Omit<CapabilityGap, 'detected_at'>): Promise<void>;
    /**
     * SPAWN SERVICE (The Creation)
     * Synthesizes a full TypeScript class that follows Neural Bridge protocols.
     */
    private static spawnService;
    /**
     * PROPOSE INJECTION
     * Finalizes the creation cycle by registering the service into the
     * Neural Bridge Hot-Swap Registry.
     */
    private static proposeInjection;
    static getBornServices(): string[];
}
