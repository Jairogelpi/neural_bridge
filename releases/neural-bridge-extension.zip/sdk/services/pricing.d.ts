export interface ModelPricing {
    id: string;
    name: string;
    context_length: number;
    prompt_usd: number;
    completion_usd: number;
    image_usd: number;
    request_usd: number;
}
export interface ModelStats {
    id: string;
    name: string;
    pricing: ModelPricing;
    top_provider: string;
    description: string;
}
export declare function fetchLivePricing(): Promise<Record<string, ModelPricing>>;
export declare function calculateRealCost(modelId: string, promptTokens: number, completionTokens: number): number;
export declare function getModelPricing(modelId: string): Promise<ModelPricing | null>;
export declare const PricingService: {
    fetchLivePricing: typeof fetchLivePricing;
    calculateRealCost: typeof calculateRealCost;
    getModelPricing: typeof getModelPricing;
};
