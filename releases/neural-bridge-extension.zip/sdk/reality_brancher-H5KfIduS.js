import { S as r } from "./index-DBmPd9PA.js";
class d {
  /**
   * Creates a new Reality Branch from an existing Crystal.
   */
  static async createBranch(t, e) {
    console.log(`[RealityBrancher] 🌳 Branching Reality: "${e}" from ${t.context_id}...`);
    const a = {
      branch_id: `branch_${Date.now()}`,
      parent_crystal_id: t.context_id,
      branch_name: e,
      status: "draft",
      modifications: {},
      created_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    return await r.emit({
      type: "CRYSTAL_FUSION",
      // Using fusion for now
      severity: "info",
      message: `New Reality Branch created: "${e}" (ID: ${a.branch_id})`,
      details: { branch_id: a.branch_id, parent_id: t.context_id }
    }), a;
  }
  /**
   * Atomically merges a branch back into the Parent Crystal.
   */
  static async merge(t, e) {
    t.status !== "simulating" && console.warn("[RealityBrancher] ⚠️ Merging a branch that hasn't been simulated yet."), console.log(`[RealityBrancher] ⛓️ Merging Branch [${t.branch_id}] into Master...`);
    const { CrystalFuser: a } = await import("./index-DBmPd9PA.js").then((c) => c.r), n = {
      ...e,
      context_id: t.branch_id,
      ...t.modifications
    }, i = await a.fuse([e, n]);
    return t.status = "merged", await r.emit({
      type: "CRYSTAL_FUSION",
      severity: "critical",
      message: `Reality Branch "${t.branch_name}" MERGED into Master Lattice.`,
      details: { branch_id: t.branch_id, master_id: i.context_id }
    }), i;
  }
}
export {
  d as RealityBrancher
};
//# sourceMappingURL=reality_brancher-H5KfIduS.js.map
