import type { TrustState } from "../content/firewall_agent";
export interface RevolutionaryFeatures {
    pck: {
        enabled: boolean;
        llm_calls_saved: number;
        cost_saved: string;
    };
    zkv: {
        enabled: boolean;
        proofs_generated: number;
        data_protected: boolean;
    };
    smt: {
        enabled: boolean;
        contradictions_found: number;
        semantic_hash: string;
    };
    clpv: {
        enabled: boolean;
        receipts_generated: number;
        cross_llm_compatible: boolean;
    };
}
export interface IFirewallOverlay {
    render(): void;
    update(state: TrustState, sri: number, reason?: string, invariants?: Array<{
        id: string;
        passed: boolean;
        reason?: string;
    }>, features?: RevolutionaryFeatures, verification_time_ms?: number, healing?: {
        needed: boolean;
        corrected_text: string;
        reason: string;
    }): void;
    showProtectInvitation(type: string): void;
    showFixButton(): void;
    showRealityRepair(correctedText: string, reason: string): void;
    applyContentBlur(): void;
    toggleReceipt(): void;
    _lastState: TrustState;
    _lastSri: number;
    _lastInvariants?: Array<{
        id: string;
        passed: boolean;
        reason?: string;
    }>;
    _features?: RevolutionaryFeatures | undefined;
    _verification_time_ms?: number;
    _healing?: {
        needed: boolean;
        corrected_text: string;
        reason: string;
    } | undefined;
}
export declare const FirewallOverlay: IFirewallOverlay & {
    _lastReason?: string;
};
