export declare const API_BASE_URL: string;
export declare const API_TIMEOUT_MS = 20000;
/**
 * PHASE UPSILON: BUDGET & POTENCY MODES 💎
 */
export type BudgetMode = 'sovereign' | 'balanced' | 'performance';
export declare const CONFIG: {
    budget_mode: BudgetMode;
    free_tier_limits: {
        max_premium_calls: number;
        max_free_tokens: number;
        force_local_if_offline: boolean;
    };
    model_stack: {
        local: string;
        free: string;
        flash: string;
        premium: string;
    };
};
