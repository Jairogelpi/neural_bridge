export declare const API_BASE_URL: string;
export declare const API_TIMEOUT_MS = 20000;
