var x = Object.defineProperty;
var u = (n, t, e) => t in n ? x(n, t, { enumerable: !0, configurable: !0, writable: !0, value: e }) : n[t] = e;
var d = (n, t, e) => u(n, typeof t != "symbol" ? t + "" : t, e);
import { d as h, H as m, e as f } from "./index-DBmPd9PA.js";
const l = class l {
  /**
   * INITIALIZE: Loads the Atlas from persistent storage.
   */
  /**
   * INITIALIZE: Loads the Atlas from persistent storage.
   */
  static async initialize() {
    var t;
    if (!this.isInitialized) {
      console.log("[TalamicIndex] 🧬 Initializing Holographic Atlas from Supabase...");
      try {
        const { supabase: e } = await import("./index-DBmPd9PA.js").then((o) => o.o), { data: i, error: a } = await e.from("crystals").select("*").neq("intent->>status", "deprecated");
        if (a) {
          console.error("[TalamicIndex] ❌ Failed to fetch crystals:", a);
          return;
        }
        if (i && i.length > 0) {
          console.log(`[TalamicIndex] 📥 Hydrating ${i.length} crystals...`);
          for (const o of i) {
            const s = ((t = o.intent) == null ? void 0 : t.primary) || o.description || "";
            s && await this.ingest(s, o.context_id, o.domain || "general");
          }
        } else
          console.log("[TalamicIndex] ℹ️ No existing crystals found. Starting fresh.");
        this.isInitialized = !0, console.log("[TalamicIndex] ✅ Atlas is fully hydrated and ready.");
      } catch (e) {
        console.error("[TalamicIndex] ❌ Initialization critical failure:", e);
      }
    }
  }
  /**
   * INGEST: Projects text into the Geometric Atlas.
   */
  static async ingest(t, e, i) {
    const a = h.computeHolographicHash(t), o = m.fromString(a), s = o.getBucketHash(), c = {
      id: l.generateSecureUUID(),
      vector: o,
      metadata: {
        source_id: e,
        preview: t.substring(0, 500),
        domain: i,
        is_crystallized: !1
      }
    };
    this.atlas.set(c.id, c), this.spatialIndex.has(s) || this.spatialIndex.set(s, /* @__PURE__ */ new Set()), this.spatialIndex.get(s).add(c.id), console.log(`[TalamicIndex] 🪐 Ingested node [${c.id}] into bucket [${s}]. Total Nodes: ${this.atlas.size}`), await this.syncToPersistentStorage(c);
  }
  /**
   * SYNC TO PERSISTENT STORAGE (The Infinite Cache)
   */
  static async syncToPersistentStorage(t) {
    try {
      const { supabase: e } = await import("./index-DBmPd9PA.js").then((a) => a.o), { error: i } = await e.from("crystals").upsert({
        context_id: `ATLAS_${t.id}`,
        domain: t.metadata.domain,
        tier: "trusted",
        metadata: {
          ...t.metadata,
          is_atlas_node: !0,
          vector_hash: t.vector.toString()
        }
      });
      i && console.warn("[TalamicIndex] ⚠️ Persistence sync error:", i.message);
    } catch {
    }
  }
  /**
   * SEARCH: O(1) Retrieval via Spatial Hashing.
   */
  static async search(t, e = 3) {
    const i = h.computeHolographicHash(t), a = m.fromString(i), o = a.getBucketHash(), s = this.spatialIndex.get(o);
    return !s || s.size === 0 ? this.atlas.size < 20 ? Array.from(this.atlas.values()).map((r) => ({ node: r, score: a.similarity(r.vector) })).filter((r) => r.score > 0.45).sort((r, g) => g.score - r.score).slice(0, e) : [] : Array.from(s).map((r) => this.atlas.get(r)).filter(Boolean).map((r) => ({
      node: r,
      score: a.similarity(r.vector)
    })).filter((r) => r.score > 0.45).sort((r, g) => g.score - r.score).slice(0, e);
  }
  /**
   * MARK CRYSTALLIZED
   */
  static setCrystallized(t) {
    const e = this.atlas.get(t);
    e && (e.metadata.is_crystallized = !0);
  }
  static getAtlasSize() {
    return this.atlas.size;
  }
  static generateSecureUUID() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (t) => {
      const e = Math.random() * 16 | 0;
      return (t === "x" ? e : e & 3 | 8).toString(16);
    });
  }
};
d(l, "atlas", /* @__PURE__ */ new Map()), d(l, "spatialIndex", /* @__PURE__ */ new Map()), // Bucket -> [Node IDs]
d(l, "isInitialized", !1);
let y = l;
class z {
  /**
   * ROUTE QUERY: The main entry point for massive context questions.
   * 1. Search Atlas for Resonant Nodes.
   * 2. If node is already Crystallized, use it.
   * 3. If "Shallow", trigger Lazy Crystallization.
   */
  static async route(t, e) {
    console.log(`[ThalamicGateway] 🧠 Attention shift detected for query: "${t.substring(0, 40)}..."`);
    const i = await y.search(t);
    if (i.length === 0)
      return { contextPreview: "No resonant data found in Atlas.", isLazyTriggered: !1 };
    const a = i[0];
    if (a.node.metadata.is_crystallized)
      return console.log("[ThalamicGateway] ✨ High-Fidelity Match found: Already Crystallized."), { contextPreview: a.node.metadata.preview, isLazyTriggered: !1 };
    console.log("[ThalamicGateway] ⏳ Shallow node identified. Triggering Lazy Crystallization...");
    const o = a.node.metadata.preview;
    try {
      const { crystal: s } = await f(o, "system_sigma", {
        id: "thalamic_lazy",
        name: "Talamic Catalyst",
        reputation: 1
      });
      return y.setCrystallized(a.node.id), {
        bestCrystal: s,
        contextPreview: s.intent.primary,
        isLazyTriggered: !0
      };
    } catch (s) {
      return console.error("[ThalamicGateway] 🛡️ Lazy Crystallization failed:", s), { contextPreview: a.node.metadata.preview, isLazyTriggered: !1 };
    }
  }
}
export {
  z as ThalamicGateway
};
//# sourceMappingURL=thalamic_gateway-BhB7-ypS.js.map
