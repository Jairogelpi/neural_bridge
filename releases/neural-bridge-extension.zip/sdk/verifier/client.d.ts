import type { Invariant, VerificationResult, GenerateInvariantsResponse } from "./types";
export interface VerifyOptions {
    contextId: string;
    invariants: Invariant[];
    threshold?: number;
    onRetry?: (step: number, result: VerificationResult) => void;
}
/**
 * Full verification ladder: injects prompt, reads response, verifies with backend
 * Automatically retries with stronger prompts on partial failures
 */
export declare function runVerificationLadder(options: VerifyOptions, injectPrompt: (prompt: string) => Promise<void>, readResponse: () => Promise<string>): Promise<VerificationResult>;
/**
 * Generate invariants from a crystal via backend
 */
export declare function generateInvariants(crystal: Record<string, any>): Promise<GenerateInvariantsResponse>;
/**
 * Quick local check (no backend) for basic invariants
 * Use for fast UI feedback before full verification
 */
export declare function quickLocalVerify(invariants: Invariant[], response: string): {
    score: number;
    passed: boolean;
};
