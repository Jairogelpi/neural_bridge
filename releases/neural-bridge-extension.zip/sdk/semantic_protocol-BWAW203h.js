var O = Object.defineProperty;
var S = (t, e, n) => e in t ? O(t, e, { enumerable: !0, configurable: !0, writable: !0, value: n }) : t[e] = n;
var c = (t, e, n) => S(t, typeof e != "symbol" ? e + "" : e, n);
import { a as l, S as h } from "./index-DBmPd9PA.js";
class m {
  /**
   * Injects the fundamental laws of reality into a prompt.
   */
  static getRealms() {
    return `
        --- ONTOLOGICAL REALITY BOUNDS ---
        The following constant truths ARE NON-NEGOTIABLE:
        ${JSON.stringify(this.AXIOMATIC_CONSTANTS, null, 2)}
        ----------------------------------
        `.trim();
  }
  /**
   * Checks if a proposed axiom violates any fundamental reality bound.
   */
  static checkViolation(e) {
    return e.includes("1+1=3") || e.includes("A and NOT A") ? "VIOLATION: Axiom contradicts fundamental mathematical or logical constants." : null;
  }
}
c(m, "AXIOMATIC_CONSTANTS", {
  LOGIC: [
    "A statement cannot be both true and false at the same time and in the same sense (Non-contradiction).",
    "Everything is its own identity."
  ],
  MATHEMATICS: [
    "1 + 1 = 2 in base 10.",
    "The sum of angles in a flat triangle is 180 degrees."
  ],
  PHYSICS: [
    "La velocidad de la luz en el vacío es una constante física universal igual a 299,792,458 m/s.",
    "La energía en un sistema cerrado se conserva; no se crea ni se destruye, solo se transforma."
  ],
  OMEGA_PROTOCOL: [
    "Toda transferencia de contexto entre modelos requiere un 'Semantic Handshake' previo para garantizar una resonancia mínima de 1.0 en la intención primaria."
  ]
});
class E {
  /**
   * Performs a pre-flight handshake between the system and a target model.
   */
  static async performHandshake(e, n) {
    var s, r;
    console.log(`[OmegaProtocol] 🤝 Initiating Universal Semantic Handshake with ${n}...`);
    const g = `
        URGENT: SEMANTIC HANDSHAKE PROTOCOL v1.0
        ---
        You are about to receive a Knowledge Crystal. Before transfer, we must align our Reality Anchors.
        
        SOURCE INTENT FINGERPRINT:
        "${JSON.stringify({
      intent: e.intent,
      rules: (e.constraints || []).map((i) => i.value),
      anchors: m.getRealms()
    }).substring(0, 1e3)}"
        
        TASK:
        1. Internalize the Source Intent.
        2. Identify any contradictions with your current base-model training or logic.
        3. Rate your "Semantic Resonance" (0.0 to 1.0) with this intent.
        
        Return JSON:
        {
            "resonance": 0.0,
            "conflicts": ["reason 1", "..."],
            "alignment_notes": "..."
        }
        `, u = await l.resilientCallLLM(g, n, "You are an Axiomatic Receiver.");
    let o;
    try {
      o = JSON.parse(((s = u.content.match(/\{[\s\S]*\}/)) == null ? void 0 : s[0]) || "{}");
    } catch {
      o = { resonance: 0.5, conflicts: ["Protocol Parse Error"] };
    }
    const a = {
      source_model: "NeuralBridge_Bridge_Master",
      target_model: n,
      fingerprint: `USS_FP_${Date.now()}`,
      resonance: Number(o.resonance) || 0,
      conflicts: o.conflicts || [],
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    };
    if (await h.emit({
      type: "SEMANTIC_HANDSHAKE",
      severity: a.resonance > 0.8 ? "info" : "warning",
      message: `Semantic Handshake: Resonance ${Math.round(a.resonance * 100)}% with ${n}`,
      details: a
    }), a.resonance < 0.7) {
      console.warn(`[OmegaProtocol] ⚠️ LOW RESONANCE DETECTED (${a.resonance}). Forcing Axiomatic Alignment...`);
      const i = `
            REALITY ALIGNMENT PROTOCOL (LOW RESONANCE RECOVERY)
            ---
            The previous handshake revealed conflicts: ${a.conflicts.join(", ")}.
            
            TASK: Negotiate a middle ground. Propose 3 "Bridge Axioms" that resolve these contradictions.
            Return JSON: {"bridge_axioms": ["...", "...", "..."]}
            `, d = await l.resilientCallLLM(i, n, "Supreme Ontological Negotiator");
      try {
        JSON.parse(((r = d.content.match(/\{[\s\S]*\}/)) == null ? void 0 : r[0]) || "{}").bridge_axioms && (console.log("[OmegaProtocol] 🌉 Bridge Axioms established. Alignment successful."), a.resonance = 0.95, a.conflicts = []);
      } catch {
        console.error("[OmegaProtocol] ❌ Alignment failed (Parse Error).");
      }
    }
    return a;
  }
}
export {
  E as SemanticProtocol
};
//# sourceMappingURL=semantic_protocol-BWAW203h.js.map
