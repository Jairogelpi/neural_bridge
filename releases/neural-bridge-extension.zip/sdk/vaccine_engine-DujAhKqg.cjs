"use strict";Object.defineProperty(exports,Symbol.toStringTag,{value:"Module"});const i=require("./index-C3zKAfyQ.cjs");class v{static async synthesizeFromContradiction(a,t){console.log(`[VaccineEngine] 💉 Analyzing contradiction for context ${a.context_id}...`);const{SemanticHasher:r}=await Promise.resolve().then(()=>require("./index-C3zKAfyQ.cjs")).then(l=>l.semantic_hashing),{Hypervector:o}=await Promise.resolve().then(()=>require("./index-C3zKAfyQ.cjs")).then(l=>l.hypervector),u=o.fromString(r.computeHolographicHash(t.claim_a)),h=o.fromString(r.computeHolographicHash(t.claim_b)),n=u.bind(h),c=await i.Attestation.realSHA256(n.toString()),{data:s}=await i.supabase.from("vaccines").select("*").eq("error_signature_hash",c).single();if(s)return console.log("[VaccineEngine] ⚡ Vaccine already exists for this pattern. Strengthening..."),await i.supabase.rpc("increment_vaccine_potency",{vid:s.vaccine_id}),s;const d=`
        LOGICAL DNA EXTRACTION
        
        A contradiction was found in an AI-generated knowledge crystal:
        CLAIM A: "${t.claim_a}"
        CLAIM B: "${t.claim_b}"
        
        Task: Identify the underlying LOGICAL FALLACY (e.g., Causal Reversal, Temporal Inconsistency, Scope Creep).
        Then, write a UNIVERSAL RULE (Meta-Invariant) that prevents this specific logical error.
        
        Return JSON:
        {
            "fallacy": "string",
            "rule": "High-level human readable rule",
            "logical_constraint": "Precise mathematical/logical constraint",
            "pattern_to_block": "Semantic pattern that triggers this error"
        }
        `,p=await i.SCPService.resilientCallLLM(d,"google/gemini-pro","You are a Formal Logician.");let e;try{e=JSON.parse(p.content)}catch{return null}const g={error_signature_hash:c,fallacy_type:e.fallacy,meta_invariant:{rule:e.rule,logical_constraint:e.logical_constraint,prohibited_pattern:e.pattern_to_block},context_domain:a.domain||"general"},{error:m}=await i.supabase.from("vaccines").insert({...g,meta_invariant:g.meta_invariant});if(m)return console.error("[VaccineEngine] ❌ Failed to store vaccine:",m.message),null;console.log(`[VaccineEngine] ✅ New Vaccine synthesized: ${e.fallacy} ("${e.rule}")`);const{Sentinel:_}=await Promise.resolve().then(()=>require("./index-C3zKAfyQ.cjs")).then(l=>l.sentinel);return await _.emit({type:"VACCINE_SYNTHESIS",severity:"info",message:`New Vaccine synthesized for ${e.fallacy}: "${e.rule}"`,details:{fallacy:e.fallacy,rule:e.rule,domain:a.domain}}),await _.triggerEntanglement(g.vaccine_id||c),g}static async synthesizePrecognitiveVaccine(a,t){console.log(`[VaccineEngine] 🔮 Precognitive synthesis for predicted error: "${t}"`);const r=`PRECOGNITIVE_FAILURE: [${t}] in DOMAIN: [${a.domain}]`,o=await(await Promise.resolve().then(()=>require("./index-C3zKAfyQ.cjs")).then(s=>s.attestation)).Attestation.realSHA256(r),u=`
        PRECOGNITIVE DNA EXTRACTION
        
        The Oracle predicted a future failure in an AI knowledge crystal:
        PREDICTED FAILURE: "${t}"
        DOMAIN: "${a.domain}"
        
        Task: Identify the underlying LOGICAL FALLACY that would cause this.
        Write a UNIVERSAL RULE (Meta-Invariant) to BLOCK this failure before it ever happens.
        
        Return JSON:
        {
            "fallacy": "string",
            "rule": "High-level human readable rule",
            "logical_constraint": "Precise mathematical/logical constraint",
            "pattern_to_block": "Semantic pattern that triggers this error"
        }
        `,h=await i.SCPService.resilientCallLLM(u,"google/gemini-pro","You are a Precognitive Logician.");let n;try{n=JSON.parse(h.content)}catch{return null}const c={error_signature_hash:o,fallacy_type:n.fallacy,meta_invariant:{rule:n.rule,logical_constraint:n.logical_constraint,prohibited_pattern:n.pattern_to_block},context_domain:a.domain||"general"};return await i.supabase.from("vaccines").insert({...c,meta_invariant:c.meta_invariant}),console.log(`[VaccineEngine] 💉 PRE-IMMUNIZED: System is now protected against "${n.fallacy}" (Oracle Prediction).`),c}static async getActiveGuards(a,t){const{data:r,error:o}=await i.supabase.from("vaccines").select("*").eq("context_domain",t).order("severity",{ascending:!1}).limit(5);return o||!r?[]:r}}exports.VaccineEngine=v;
//# sourceMappingURL=vaccine_engine-DujAhKqg.cjs.map
