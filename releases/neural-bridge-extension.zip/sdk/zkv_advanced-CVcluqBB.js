import { h as a } from "./index-DBmPd9PA.js";
class m {
  /**
   * Create a commitment to private data (SHA-256 with salt)
   */
  static async generateCommitment(t, i) {
    return await a.sha256(t + i);
  }
  /**
   * Verify that the answer provided by an LLM matches the hidden private data
   * without the LLM ever seeing the original data or the salt.
   */
  static async verifyBlind(t) {
    if (await this.generateCommitment(t.privateData, t.salt) !== t.commitment)
      return !1;
    const e = t.providedAnswer.toLowerCase().trim(), n = t.privateData.toLowerCase().trim();
    return e.includes(n) || n.includes(e);
  }
  /**
   * Prove that a claim is true without revealing the claim itself.
   * Returns a verifiable receipt.
   */
  static async generateZKPReceipt(t) {
    const i = a.randomHex(16), e = await this.generateCommitment(t, i), n = a.randomHex(16), r = await a.sha256(e + n);
    return {
      commitment: e,
      nullifier: n,
      proof: r
    };
  }
}
export {
  m as ZKAdvancedVerifier
};
//# sourceMappingURL=zkv_advanced-CVcluqBB.js.map
