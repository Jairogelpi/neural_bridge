import { A as f, s as m, a as y } from "./index-CIIX_jvs.js";
class I {
  /**
   * Extracts the "Logical DNA" of a contradiction and creates a vaccine.
   */
  static async synthesizeFromContradiction(n, t) {
    console.log(`[VaccineEngine] 💉 Analyzing contradiction for context ${n.context_id}...`);
    const { SemanticHasher: c } = await import("./index-CIIX_jvs.js").then((g) => g.p), { Hypervector: o } = await import("./index-CIIX_jvs.js").then((g) => g.n), s = o.fromString(c.computeHolographicHash(t.claim_a)), l = o.fromString(c.computeHolographicHash(t.claim_b)), i = s.bind(l), e = await f.realSHA256(i.toString()), { data: r } = await m.from("vaccines").select("*").eq("error_signature_hash", e).single();
    if (r)
      return console.log("[VaccineEngine] ⚡ Vaccine already exists for this pattern. Strengthening..."), await m.rpc("increment_vaccine_potency", { vid: r.vaccine_id }), r;
    const p = `
        LOGICAL DNA EXTRACTION
        
        A contradiction was found in an AI-generated knowledge crystal:
        CLAIM A: "${t.claim_a}"
        CLAIM B: "${t.claim_b}"
        
        Task: Identify the underlying LOGICAL FALLACY (e.g., Causal Reversal, Temporal Inconsistency, Scope Creep).
        Then, write a UNIVERSAL RULE (Meta-Invariant) that prevents this specific logical error.
        
        Return JSON:
        {
            "fallacy": "string",
            "rule": "High-level human readable rule",
            "logical_constraint": "Precise mathematical/logical constraint",
            "pattern_to_block": "Semantic pattern that triggers this error"
        }
        `, u = await y.resilientCallLLM(p, "google/gemini-pro", "You are a Formal Logician.");
    let a;
    try {
      a = JSON.parse(u.content);
    } catch {
      return null;
    }
    const h = {
      error_signature_hash: e,
      fallacy_type: a.fallacy,
      meta_invariant: {
        rule: a.rule,
        logical_constraint: a.logical_constraint,
        prohibited_pattern: a.pattern_to_block
      },
      context_domain: n.domain || "general"
    }, { error: _ } = await m.from("vaccines").insert({
      ...h,
      meta_invariant: h.meta_invariant
    });
    if (_)
      return console.error("[VaccineEngine] ❌ Failed to store vaccine:", _.message), null;
    console.log(`[VaccineEngine] ✅ New Vaccine synthesized: ${a.fallacy} ("${a.rule}")`);
    const { Sentinel: d } = await import("./index-CIIX_jvs.js").then((g) => g.q);
    return await d.emit({
      type: "VACCINE_SYNTHESIS",
      severity: "info",
      message: `New Vaccine synthesized for ${a.fallacy}: "${a.rule}"`,
      details: { fallacy: a.fallacy, rule: a.rule, domain: n.domain }
    }), await d.triggerEntanglement(h.vaccine_id || e), h;
  }
  /**
   * 🔮 PRECOGNITIVE VACCINATION
   * Synthesizes a vaccine for a failure that hasn't happened yet (predicted by the Oracle).
   */
  static async synthesizePrecognitiveVaccine(n, t) {
    console.log(`[VaccineEngine] 🔮 Precognitive synthesis for predicted error: "${t}"`);
    const c = `PRECOGNITIVE_FAILURE: [${t}] in DOMAIN: [${n.domain}]`, o = await (await import("./index-CIIX_jvs.js").then((r) => r.m)).Attestation.realSHA256(c), s = `
        PRECOGNITIVE DNA EXTRACTION
        
        The Oracle predicted a future failure in an AI knowledge crystal:
        PREDICTED FAILURE: "${t}"
        DOMAIN: "${n.domain}"
        
        Task: Identify the underlying LOGICAL FALLACY that would cause this.
        Write a UNIVERSAL RULE (Meta-Invariant) to BLOCK this failure before it ever happens.
        
        Return JSON:
        {
            "fallacy": "string",
            "rule": "High-level human readable rule",
            "logical_constraint": "Precise mathematical/logical constraint",
            "pattern_to_block": "Semantic pattern that triggers this error"
        }
        `, l = await y.resilientCallLLM(s, "google/gemini-pro", "You are a Precognitive Logician.");
    let i;
    try {
      i = JSON.parse(l.content);
    } catch {
      return null;
    }
    const e = {
      error_signature_hash: o,
      fallacy_type: i.fallacy,
      meta_invariant: {
        rule: i.rule,
        logical_constraint: i.logical_constraint,
        prohibited_pattern: i.pattern_to_block
      },
      context_domain: n.domain || "general"
    };
    return await m.from("vaccines").insert({
      ...e,
      meta_invariant: e.meta_invariant
    }), console.log(`[VaccineEngine] 💉 PRE-IMMUNIZED: System is now protected against "${i.fallacy}" (Oracle Prediction).`), e;
  }
  /**
   * Returns relevant vaccines for a given source text using GEOMETRIC SEARCH (HDC)
   */
  static async getActiveGuards(n, t) {
    const { SemanticHasher: c } = await import("./index-CIIX_jvs.js").then((e) => e.p), { data: o, error: s } = await m.from("vaccines").select("*").eq("context_domain", t).limit(20);
    if (s || !o || o.length === 0) return [];
    const l = c.computeHolographicHash(n);
    return o.map((e) => {
      var a;
      const r = ((a = e.meta_invariant) == null ? void 0 : a.prohibited_pattern) || e.fallacy_type, p = c.computeHolographicHash(r), u = c.holographicSimilarity(l, p);
      return { vaccine: e, similarity: u };
    }).filter((e) => e.similarity > 0.4).sort((e, r) => r.similarity - e.similarity).slice(0, 5).map((e) => e.vaccine);
  }
}
export {
  I as VaccineEngine
};
//# sourceMappingURL=vaccine_engine-D7gTsmae.js.map
