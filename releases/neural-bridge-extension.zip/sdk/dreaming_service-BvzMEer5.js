var f = Object.defineProperty;
var y = (i, t, a) => t in i ? f(i, t, { enumerable: !0, configurable: !0, writable: !0, value: a }) : i[t] = a;
var m = (i, t, a) => y(i, typeof t != "symbol" ? t + "" : t, a);
import { s as d, C as D } from "./index-CIIX_jvs.js";
class h {
  /**
   * Start the autonomous dreaming loop.
   */
  static async startDreamingLoop(t = 6e4) {
    this.isDreaming || (this.isDreaming = !0, console.log("[Dreaming] 🌌 Recursive Dreamer activated."), setInterval(async () => {
      try {
        await this.dream();
      } catch (a) {
        console.error("[Dreaming] ⛔ Nightmare detected:", a);
      }
    }, t));
  }
  /**
   * A single "Dream" cycle. 
   * Finds related crystals and fuses them into universal laws.
   */
  static async dream() {
    const { data: t, error: a } = await d.from("crystals").select("*").order("created_at", { ascending: !1 }).limit(10);
    if (a || !t || t.length < 2) return;
    console.log(`[Dreaming] 😴 Analyzing ${t.length} crystals for pattern synthesis...`);
    const g = [...new Set(t.map((r) => r.domain))];
    for (const r of g) {
      const o = t.filter((n) => n.domain === r);
      if (o.length < 2) continue;
      const c = o[0], l = o[1];
      console.log(`[Dreaming] ⚗️ Fusing ${c.context_id} + ${l.context_id} into Axiom...`);
      const e = await D.fuseHolographic([c, l]);
      try {
        const { DialecticalEngine: n } = await import("./dialectical_engine-BnXzR1Up.js"), s = await n.evolve(e.intent.primary, `Synthesized from ${c.context_id} and ${l.context_id}`);
        s.is_resilient && (console.log(`[Dreaming] ✨ HEGELIAN SYNTHESIS SUCCESS: "${s.final_thesis.substring(0, 50)}..."`), e.intent.primary = s.final_thesis, e.metadata = {
          ...e.metadata || {},
          dream_evolution: !0,
          dialectic_iterations: s.iterations
        });
      } catch (n) {
        console.warn("[Dreaming] ⚖️ Dialectic bypassed in dream:", n);
      }
      e.tier = "sovereign", e.created_at = (/* @__PURE__ */ new Date()).toISOString(), e.context_id = `axiom_${Date.now()}`, await d.from("crystals").insert(e), console.log(`[Dreaming] ✨ NEW AXIOM CRYSTALLIZED: ${e.context_id}`);
    }
  }
}
m(h, "isDreaming", !1);
export {
  h as DreamingService
};
//# sourceMappingURL=dreaming_service-BvzMEer5.js.map
