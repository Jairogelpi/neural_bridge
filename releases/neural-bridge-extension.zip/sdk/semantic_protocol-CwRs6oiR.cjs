"use strict";var S=Object.defineProperty;var d=(a,e,n)=>e in a?S(a,e,{enumerable:!0,configurable:!0,writable:!0,value:n}):a[e]=n;var s=(a,e,n)=>d(a,typeof e!="symbol"?e+"":e,n);Object.defineProperty(exports,Symbol.toStringTag,{value:"Module"});const r=require("./index-BcNYtQwH.cjs");class c{static getRealms(){return`
        --- ONTOLOGICAL REALITY BOUNDS ---
        The following constant truths ARE NON-NEGOTIABLE:
        ${JSON.stringify(this.AXIOMATIC_CONSTANTS,null,2)}
        ----------------------------------
        `.trim()}static checkViolation(e){return e.includes("1+1=3")||e.includes("A and NOT A")?"VIOLATION: Axiom contradicts fundamental mathematical or logical constants.":null}}s(c,"AXIOMATIC_CONSTANTS",{LOGIC:["A statement cannot be both true and false at the same time and in the same sense (Non-contradiction).","Everything is its own identity."],MATHEMATICS:["1 + 1 = 2 in base 10.","The sum of angles in a flat triangle is 180 degrees."],PHYSICS:["La velocidad de la luz en el vacío es una constante física universal igual a 299,792,458 m/s.","La energía en un sistema cerrado se conserva; no se crea ni se destruye, solo se transforma."],OMEGA_PROTOCOL:["Toda transferencia de contexto entre modelos requiere un 'Semantic Handshake' previo para garantizar una resonancia mínima de 1.0 en la intención primaria."]});class g{static async performHandshake(e,n){var o;console.log(`[OmegaProtocol] 🤝 Initiating Universal Semantic Handshake with ${n}...`);const l=`
        URGENT: SEMANTIC HANDSHAKE PROTOCOL v1.0
        ---
        You are about to receive a Knowledge Crystal. Before transfer, we must align our Reality Anchors.
        
        SOURCE INTENT FINGERPRINT:
        "${JSON.stringify({intent:e.intent,rules:(e.constraints||[]).map(u=>u.value),anchors:c.getRealms()}).substring(0,1e3)}"
        
        TASK:
        1. Internalize the Source Intent.
        2. Identify any contradictions with your current base-model training or logic.
        3. Rate your "Semantic Resonance" (0.0 to 1.0) with this intent.
        
        Return JSON:
        {
            "resonance": 0.0,
            "conflicts": ["reason 1", "..."],
            "alignment_notes": "..."
        }
        `,m=await r.SCPService.resilientCallLLM(l,n,"You are an Axiomatic Receiver.");let i;try{i=JSON.parse(((o=m.content.match(/\{[\s\S]*\}/))==null?void 0:o[0])||"{}")}catch{i={resonance:.5,conflicts:["Protocol Parse Error"]}}const t={source_model:"NeuralBridge_Bridge_Master",target_model:n,fingerprint:`USS_FP_${Date.now()}`,resonance:Number(i.resonance)||0,conflicts:i.conflicts||[],timestamp:new Date().toISOString()};return await r.Sentinel.emit({type:"SEMANTIC_HANDSHAKE",severity:t.resonance>.8?"info":"warning",message:`Semantic Handshake: Resonance ${Math.round(t.resonance*100)}% with ${n}`,details:t}),t.resonance<.7&&console.warn(`[OmegaProtocol] ⚠️ LOW RESONANCE DETECTED (${t.resonance}). Forcing Axiomatic Alignment...`),t}}exports.SemanticProtocol=g;
//# sourceMappingURL=semantic_protocol-CwRs6oiR.cjs.map
