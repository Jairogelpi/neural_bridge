/**
 * Extract the first JSON object or array from a string
 * Handles markdown fences, extra text, and nested structures
 */
export declare function extractFirstJSON(text: string): unknown;
